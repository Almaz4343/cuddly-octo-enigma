<?

include_once 'sys/inc/start.php';
include_once 'sys/inc/compress.php';
include_once 'sys/inc/sess.php';
include_once 'sys/inc/home.php';
include_once 'sys/inc/settings.php';
include_once 'sys/inc/db_connect.php';
include_once 'sys/inc/ipua.php';
include_once 'sys/inc/fnc.php';
include_once 'sys/inc/user.php';
only_reg(); 

if (isset($user) && isset($_GET['write']))
{
$set['title'] = 'Новое сообщение : Почта : ' .  $user['nick']; // заголовок страницы
include_once 'sys/inc/thead.php';
title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt="" /> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep" /> <a href="/user/?id=<?= $user['id']?>"><?= $user['nick']?></a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep" /> <a href="/konts.php">Почта</a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep" /> <span class="lc_br_text">Новое сообщение</span> </span>       </div>
<?
$k_post1 = mysql_result(mysql_query("SELECT COUNT(*) FROM `frends` WHERE `user` = '$user[id]' AND `i` = '1'"), 0);
$k_page1 = k_page($k_post1,$set['p_str']);
$page1 = page($k_page1);
$start1 = $set['p_str'] * $page1 - $set['p_str'];

$q1 = mysql_query("SELECT * FROM `frends` WHERE `user` = '$user[id]' AND `i` = '1' ORDER BY time DESC LIMIT $start1, $set[p_str]");


if ($k_post1 == 0){
?>
<div class="wrapper">
<div class="col_blocks block">  У вас нет друзей.  </div>
</div>
<?
}
else{

?>
<div class="wrapper" style="border-bottom:0;"> <div class="fix_btn-width"> <div class="list f-c_fll">
<?
while ($frend = mysql_fetch_assoc($q1))
{
	$frend1 = get_user($frend['frend']);
?>
<div class="js-row block bord-botm oh grey relative">        
<div class="left font0">   
<a href="/mail.php?id=<?= $frend1['id']?>" class="tdn">       
<span class="pr">   <div class="inl_bl relative"> <?= ava40($frend1['id'])?></div>     </span>        
</a>  
</div>   
<div class="pre_content_wrap break-word"> 
<?= group($frend1['id'])?>   
<a href="/mail.php?id=<?= $frend1['id']?>" class="black full_link">   <b><?= $frend1['nick']?></b>  </a>   
<?= medal($frend1['id'])?>                 
<div class="grey">  <div class="break-word"> 
<?
if($frend1['ank_name'] != null){
?>
<?= text($frend1['ank_name'])?> 
<?
}

if($frend1['ank_family'] != null){
?>
<?= text($frend1['ank_family'])?> 
<?
}
?>
</div>      </div>             
</div>     </div>
<?

}
?>
</div></div></div>
<?
}
?>
<a href="/konts.php" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?

include_once 'sys/inc/tfoot.php';
exit;
}

$type_get = isset($_GET['type']) && preg_match('#^(common|ignor|favorite|deleted)$#',$_GET['type']) ? $_GET['type'] : 'default';
$type = array('type' => array('favorite' => 'favorite',
							  'ignor' => 'ignor',
							  'deleted' => 'deleted',
							  'common' => 'common',
							  'default' => 'common'),
				'type_name'  => array('favorite' => 'Избранные',
							  'ignor' => 'Игнорируемые',
							  'deleted' => 'Корзина',
							  'common' => 'Активные',
							  'default' => 'Активные'));

$set['title'] = $type['type_name'][$type_get].' : Почта :  ' .  $user['nick'];
include_once 'sys/inc/thead.php';

title();


if (isset($_GET['id']))
{
$ank =  get_user($_GET['id']);

if ($ank)
{
if (isset($_GET['act']))
{
switch ($_GET['act']) {

case 'add':
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `users_konts` WHERE `id_user` = '$user[id]' AND `id_kont` = '$ank[id]'"), 0) == 1)
$err[]='Этот пользователь уже есть в списке контактов.';
else
{
mysql_query("INSERT INTO `users_konts` (`id_user`, `id_kont`, `time`) VALUES ('$user[id]', '$ank[id]', '$time')");
$_SESSION['message'] = 'Контакт успешно добавлен.';
header("Location: ?");
exit;
}
break;

case 'del':
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `users_konts` WHERE `id_user` = '$user[id]' AND `id_kont` = '$ank[id]'"), 0) == 0)
$warn[]='Этого пользователя нет в списке контактов.';
else
{
mysql_query("UPDATE `users_konts` SET `type` = 'deleted', `time` = '$time' WHERE `id_user` = '$user[id]' AND `id_kont` = '$ank[id]' LIMIT 1");
$_SESSION['message'] = 'Контакт перенесен в корзину.';
header("Location: ?");
exit;
}
break;
}
}
}
else
$err[]='Пользователь не найден';
}
if (isset($_GET['act']) && $_GET['act'] == 'edit_ok' && isset($_GET['id']) && mysql_result(mysql_query("SELECT COUNT(*) FROM `user` WHERE `id` = '".intval($_GET['id'])."' LIMIT 1"),0) == 1)
{
$ank=get_user(intval($_GET['id']));
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `users_konts` WHERE `id_user` = '$user[id]' AND `id_kont` = '$ank[id]'"), 0) == 1)
{
$kont=mysql_fetch_array(mysql_query("SELECT * FROM `users_konts` WHERE `id_user` = '$user[id]' AND `id_kont` = '$ank[id]'"));

if (isset($_POST['type']) && preg_match('#^(common|ignor|favorite|deleted)$#',$_POST['type']) && $_POST['type']!=$type['type'][$type_get])
{
mysql_query("UPDATE `users_konts` SET `type` = '$_POST[type]', `time` = '$time' WHERE `id_user` = '$user[id]' AND `id_kont` = '$ank[id]' LIMIT 1");
$_SESSION['message'] = 'Контакт успешно перенесен';
header("Location: ?");
exit;
}
}
else
$err[]='Контакт не найден';
}


/*========================================Отмеченные========================================*/
foreach ($_POST as $key => $value)
{
if (preg_match('#^post_([0-9]*)$#',$key,$postnum) && $value='1')
{
$delpost[] = $postnum[1];
}
}
// игнор 
if (isset($_POST['ignor']))
{
if (isset($delpost) && is_array($delpost))
{
echo '<div class="oh info">';
for ($q=0; $q<=count($delpost)-1; $q++) {
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `users_konts` WHERE `id_user` = '$user[id]' AND `id_kont` = '$delpost[$q]'"), 0) == 0)
$warn[]='Этого пользователя нет в списке контактов.';
else
{
mysql_query("UPDATE `users_konts` SET `type` = 'ignor', `time` = '$time' WHERE `id_user` = '$user[id]' AND `id_kont` = '$delpost[$q]' LIMIT 1");
}
}
echo 'Контакт(ы) перенесён в Черный список.</div>';
}else{
//$err[] = '';
}
}
// активные 
if (isset($_POST['common']))
{
if (isset($delpost) && is_array($delpost))
{
echo '<div class="oh info">';
for ($q=0; $q<=count($delpost)-1; $q++) {
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `users_konts` WHERE `id_user` = '$user[id]' AND `id_kont` = '$delpost[$q]'"), 0) == 0)
$warn[]='Этого пользователя нет в списке контактов.';
else
{
mysql_query("UPDATE `users_konts` SET `type` = 'common', `time` = '$time' WHERE `id_user` = '$user[id]' AND `id_kont` = '$delpost[$q]' LIMIT 1");
}
}
echo 'Контакт(ы) перенесён в активное.</div>';
}else{
//$err[] = '';
}
}
// избранное
if (isset($_POST['favorite']))
{
if (isset($delpost) && is_array($delpost))
{
echo '<div class="oh info">';
for ($q=0; $q<=count($delpost)-1; $q++) {
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `users_konts` WHERE `id_user` = '$user[id]' AND `id_kont` = '$delpost[$q]'"), 0) == 0)
$warn[]='Этого пользователя нет в списке контактов!';
else
{
mysql_query("UPDATE `users_konts` SET `type` = 'favorite', `time` = '$time' WHERE `id_user` = '$user[id]' AND `id_kont` = '$delpost[$q]' LIMIT 1");
}
}
echo 'Контакт(ы) перенесён в избранное.</div>';
}else{
//$err[] = '';
}
}
// удаляем
if (isset($_POST['deleted']))
{
if (isset($delpost) && is_array($delpost))
{
echo '<div class="oh info">';
for ($q=0; $q<=count($delpost)-1; $q++) {
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `users_konts` WHERE `id_user` = '$user[id]' AND `id_kont` = '$delpost[$q]'"), 0) == 0)
$warn[]='Этого пользователя нет в списке контактов.';
else
{
mysql_query("UPDATE `users_konts` SET `type` = 'deleted', `time` = '$time' WHERE `id_user` = '$user[id]' AND `id_kont` = '$delpost[$q]' LIMIT 1");
}
}
echo 'Контакт(ы) перенесён в корзину.</div>';
}else{
//$err[] = '1';
}
}


?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $user['id']?>"><?= $user['nick']?></a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Почта</span> </span>       </div>
<?

err();

?>
<div class="oh">
<?

$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `users_konts` WHERE `id_user` = '$user[id]' AND `type` = '".$type['type'][$type_get]."'"), 0);
$k_neww = mysql_result(mysql_query("SELECT COUNT(`mail`.`id`) FROM `mail`
	LEFT JOIN `users_konts` ON `mail`.`id_user` = `users_konts`.`id_kont` AND `users_konts`.`id_user` = '$user[id]'
	WHERE `mail`.`id_kont` = '$user[id]' AND (`users_konts`.`type` IS NULL OR `users_konts`.`type` = 'common' 
	OR `users_konts`.`type` = 'favorite') AND `mail`.`read` = '0'"),0);
			 
$k_neww_fav = mysql_result(mysql_query("SELECT COUNT(`mail`.`id`) FROM `mail`
	LEFT JOIN `users_konts` ON `mail`.`id_user` = `users_konts`.`id_kont` AND `users_konts`.`id_user` = '$user[id]'
	WHERE `mail`.`id_kont` = '$user[id]' AND (`users_konts`.`type` = 'favorite') AND `mail`.`read` = '0'"),0);




if($type['type'][$type_get] != 'favorite' && $type['type'][$type_get] != 'ignor' && $type['type'][$type_get] != 'deleted' && $k_neww != 0 && $k_neww_fav == 0){
?>
<div class="right" id="mail__new_dialog">    
<a href="/konts.php?write" class="inl-link ">      
<div class="no-text">    <img src="/style/i/mail_blue.png" alt="" class="m">    </div>     
<!-- --><!-- --><!-- --></a><!-- --> 
</div>

<div class="tabs_block oh">    
<div class="tab_item left tab_active black">  Вс<span id="transmark" style="display: none; width: 0px; height: 0px;"></span>е  </div>   
<a href="/new_mess.php" class="tab_item left">  Новые  </a>   
</div>
<?
}else{
?>
<div class="wrapper">
<a href="/konts.php?write" class="link    blue      "> 
<span>        
<img src="/style/i/mail_blue.png" alt="" class="m">       <span class="m">  Новое сообщение </span>          
</span>  
</a>
</div>
<?
}


if ($k_post){
$set['p_str'] = $user['set_p_maill'];
	$k_page=k_page($k_post,$set['p_str']);
	$page=page($k_page);
	$start=$set['p_str']*$page-$set['p_str'];

	$q = mysql_query("SELECT * FROM `users_konts` WHERE `id_user` = '$user[id]' AND `type` = '".$type['type'][$type_get]."' ORDER BY `time` DESC, `new_msg` DESC LIMIT $start, $set[p_str]");	
?>
<div class="wrapper">
<form method="post" action="">
<div class="col_blocks block"> 
<?
while ($post = mysql_fetch_array($q))
{
	$ank_kont = get_user($post['id_kont']);
	$k_mess = mysql_result(mysql_query("SELECT COUNT(*) FROM `mail` WHERE `unlink` != '$user[id]' AND `id_user` = '$ank_kont[id]' AND `id_kont` = '$user[id]'"), 0);
	$k_mess2 = mysql_result(mysql_query("SELECT COUNT(*) FROM `mail` WHERE `unlink` != '$user[id]' AND `id_user` = '$user[id]' AND `id_kont` = '$ank_kont[id]'"), 0);		
	$k_mess_to = mysql_result(mysql_query("SELECT COUNT(*) FROM `mail` WHERE `unlink` != '$user[id]' AND `id_user` = '$user[id]' AND `id_kont` = '$ank_kont[id]' AND `read` = '0'"), 0);
	$k_new_mess = mysql_result(mysql_query("SELECT COUNT(*) FROM `mail` WHERE `id_user` = '$ank_kont[id]' AND `id_kont` = '$user[id]' AND `read` = '0'"), 0);				
	if ($k_mess_to > 0)		
	
	$k_mess_to = ' <font color=red><b>&uarr;</b></font> [<font color=red>' . $k_mess_to . '</font>]';		
	else		
	$k_mess_to = null;
if($k_new_mess != 0 ){
?>
<div class="stnd_padd oh">   
<input name="post_<?= $post['id_kont']?>" value="1" type="checkbox">   
<span class="p14">   <?= group($ank_kont['id'])?> </span>
<a href="/mail.php?id=<?= $ank_kont['id']?>">   <b><?= $ank_kont['nick']?></b>  </a>    
<span style="color:green"> <b>(<?= $k_mess?>/<?= $k_mess2?>)</b> </span> <span style="color:red">+<?= $k_new_mess?></span>   
</div>
<?
}else{
?>
<div class="stnd_padd oh">   
<input name="post_<?= $post['id_kont']?>" value="1" type="checkbox">    
<span class="p14">   <?= group($ank_kont['id'])?> </span>  
<a href="/mail.php?id=<?= $ank_kont['id']?>">  <?= $ank_kont['nick']?>  </a>     <span>(<?= $k_mess?>/<?= $k_mess2?>)
<span id="transmark" style="display: none; width: 0px; height: 0px;"></span></span>    
</div>
<?
}
}			
?>
</div>
<div class="bord-top"> <table class="table__wrap"> <tbody><tr>
<?
if ($type['type'][$type_get] != 'common'){
?>
<td class="table__cell" width="33%"> <!-- --><!-- --><!-- --><!-- --><!-- --><button name="common" value="Активные" class="  link full is_final    " id="archive_contacts"><!--   --><img src="/style/i/archive.png" alt="" class="m"> <!--   --><span class="m"> Активные</span><!-- --></button><!-- --><!-- --> </td>
<?
}
if ($type['type'][$type_get] != 'favorite'){
?>
<td class="table__cell" width="33%"> <!-- --><!-- --><!-- --><!-- --><!-- --><button name="favorite" value="Избранное" class="  link full is_final    " id="fav_contacts"><!--   --><img src="/style/i/ico/fav.png" alt="" class="m"> <!--   --><span class="m"> Избранное</span><!-- --></button><!-- --><!-- --> </td>
<?
}
if ($type['type'][$type_get] != 'ignor'){
if ($type['type'][$type_get] == 'deleted'){
$lolka  = 'table__cell_last';
}else{
$lolka  = '';
}
?>
<td class="table__cell <?= $lolka?>" width="34%"> <!-- --><!-- --><!-- --><!-- --><!-- --><button name="ignor" value="Игнор" class="  link full is_final    " id="ignor_contacts"><!--   --><img src="/style/i/spam.png" alt="" class="m"> <!--   --><span class="m"> Игнор</span><!-- --></button><!-- --><!-- --> </td>
<?
}
if ($type['type'][$type_get] != 'deleted'){
?>
<td class="table__cell table__cell_last" width="33%"> <!-- --><!-- --><!-- --><!-- --><!-- --><button name="deleted" value="Удалить" class="  link full is_final    " id="delete_contacts"><!--   --><img src="/style/i/garbage.png" alt="" class="m"> <!--   --><span class="m"> Удалить</span><!-- --></button><!-- --><!-- --> </td>
<?
}

?>
</td>  </tr> </tbody></table> </div>
</form>
</div>
<?
if ($k_page > 1){
?>
<div class="wrapper">
<?
str("?type=".$type['type'][$type_get]."&amp;",$k_page,$page); // Вывод страниц
?>
</div>
<?
}
}
// ЕСЛИ КОНТАКТОВ НЕТ
else{
?>
<div class="wrapper">
<div class="col_blocks block">  Контакты не найдены.  </div>
</div>
<?
}

$izbran = mysql_result(mysql_query("SELECT COUNT(*) FROM `users_konts` WHERE `id_user` = '$user[id]' AND `type` = 'favorite'"), 0);
$acktiv = mysql_result(mysql_query("SELECT COUNT(*) FROM `users_konts` WHERE `id_user` = '$user[id]' AND `type` = 'common'"), 0);
$ignoor = mysql_result(mysql_query("SELECT COUNT(*) FROM `users_konts` WHERE `id_user` = '$user[id]' AND `type` = 'ignor'"), 0);
$korzin = mysql_result(mysql_query("SELECT COUNT(*) FROM `users_konts` WHERE `id_user` = '$user[id]' AND `type` = 'deleted'"), 0);



?>
</div><div class="wrapper">
<?

if ($type['type'][$type_get] != 'common'){
?>
<a href="?type=common" class="link  darkblue  arrow    "> <span>        
<img src="/style/i/ico/people_darkblue.png" alt="" class="m p16">       <span class="m"> Активные </span> 
<?
if ($acktiv > 0){
?>
<span class="m">(<?= $acktiv?>)</span>       
<?
}
?>
</span>  
</a>
<?
}
if ($type['type'][$type_get] != 'favorite'){
?>
<a href="?type=favorite" class="link  darkblue  arrow    "> 
<span>  <img src="/style/i/mail/fav_blue.png" alt="" class="m p16">  <span class="m">  Избранные </span>   
<?
if ($izbran > 0){
?>
<span class="m">(<?= $izbran?>)</span>       
<?
}
?>     
</span>  
</a>
<?
}else{
?>
<a href="?type=favorite" class="link  darkblue  arrow   b selected   "> <span>        
<img src="/style/i/mail/fav_blue.png" alt="" class="m">       <span class="m">  Избранное </span>   
<?
if ($izbran > 0){
?>
<span class="m">(<?= $izbran?>)</span>       
<?
}
?>      
</span>  </a>
<?
}


if ($type['type'][$type_get] != 'ignor'){
?>
<a href="?type=ignor" class="link  darkblue  arrow    "> <span>        
<img src="/style/i/mail/spam_blue.png" alt="" class="m">       <span class="m">  Игнор </span>      
<?
if ($ignoor > 0){
?>
<span class="m">(<?= $ignoor?>)</span>       
<?
}
?> 
</span>  
</a>
<?
}else{
?>
<a href="?type=ignor" class="link  darkblue  arrow   b selected   "> <span>        
<img src="/style/i/mail/spam_blue.png" alt="" class="m">       <span class="m">  Игнор </span>      
<?
if ($ignoor > 0){
?>
<span class="m">(<?= $ignoor?>)</span>       
<?
}
?> 
</span>  
</a>
<?
}
if ($type['type'][$type_get] != 'deleted'){
?>
<a href="?type=deleted" class="link  darkblue  arrow    "> <span>        
<img src="/style/i/mail/garbage_blue.png" alt="" class="m">       <span class="m">  Корзина </span>      
<?
if ($korzin > 0){
?>
<span class="m">(<?= $korzin?>)</span>       
<?
}
?> 
</span>  
</a>
<?
}else{
?>
<a href="?type=deleted" class="link  darkblue  arrow   b selected  "> <span>        
<img src="/style/i/mail/garbage_blue.png" alt="" class="m">       <span class="m">  Корзина </span>      
<?
if ($korzin > 0){
?>
<span class="m">(<?= $korzin?>)</span>       
<?
}
?> 
</span>  
</a>
<?
}
?>
</div>
<div class="wrapper">     
<a href="/user/settings/mail.php" class="link  darkblue  arrow    "> 
<span>        
<img src="/style/i/mail/cog_blue.png" alt="" class="m">       <span class="m">  Настройки почты </span>          
</span>  
</a>    
</div>
<?

if ($type['type'][$type_get] == 'deleted')echo '<div class="busi"> Внимание!<br>Контакты хранятся в папке не более 1 месяца. После этого они полностью удаляются. </div>';
if ($type['type'][$type_get] == 'ignor')echo '<div class="busi">Уведомления о сообщениях от этих контактов не появляются.</div>';
if ($type['type'][$type_get] == 'favorite')echo '<div class="busi">Уведомления о сообщениях от этих контактов выделяются.</div>';

include_once 'sys/inc/tfoot.php';
?>