<?

include_once 'sys/inc/start.php';
include_once 'sys/inc/compress.php';
include_once 'sys/inc/sess.php';
include_once 'sys/inc/home.php';
include_once 'sys/inc/settings.php';
include_once 'sys/inc/db_connect.php';
include_once 'sys/inc/ipua.php';
include_once 'sys/inc/fnc.php';
include_once 'sys/inc/user.php';
only_reg(); 


$set['title'] = 'Новые сообщения : Почта : ' .  $user['nick']; // заголовок страницы

include_once 'sys/inc/thead.php';

title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt="" /> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep" /> <a href="/user/?id=<?= $user['id']?>"><?= $user['nick']?></a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep" /> <a href="/konts.php">Почта</a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep" /> <span class="lc_br_text">Новые сообщения</span> </span>       </div>

<div class="oh">
<?



$k_post = mysql_result(mysql_query("SELECT COUNT(DISTINCT `mail`.`id_user`) FROM `mail`
 LEFT JOIN `users_konts` ON `mail`.`id_user` = `users_konts`.`id_kont` AND `users_konts`.`id_user` = '$user[id]'
 WHERE `mail`.`id_kont` = '$user[id]' AND (`users_konts`.`type` IS NULL OR `users_konts`.`type` = 'common' OR `users_konts`.`type` = 'favorite') AND `mail`.`read` = '0'"),0);

$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str']*$page-$set['p_str'];


if ($k_post == 0)
{
?>
<div class="wrapper">
<a href="/konts.php?write" class="link    blue      "> 
<span>        
<img src="/style/i/mail_blue.png" alt="" class="m">       <span class="m">  Новое сообщение </span>          
</span>  
</a>
</div>

<div class="wrapper">
<div class="col_blocks block"> Контакты не найдены.   </div>
</div>
<?
}
else{

?>
<div class="right" id="mail__new_dialog">    
<a href="/konts.php?write" class="inl-link ">      
<div class="no-text">    <img src="/style/i/mail_blue.png" alt="" class="m">    </div>     
<!-- --><!-- --><!-- --></a><!-- --> 
</div>

<div class="tabs_block oh"> 
<a href="/konts.php" class="tab_item left">  Все  </a>    
<div class="tab_item left tab_active black">  Новы<span id="transmark" style="display: none; width: 0px; height: 0px;"></span>е  </div>   
  
</div>


<div class="wrapper">
<div class="col_blocks block"> 
<?



$q = mysql_query("SELECT MAX(`mail`.`time`) AS `last_time`, COUNT(`mail`.`id`) AS `count`, `mail`.`id_user`, `users_konts`.`name` FROM `mail`

 LEFT JOIN `users_konts` ON `mail`.`id_user` = `users_konts`.`id_kont` AND `users_konts`.`id_user` = '$user[id]'

 WHERE `mail`.`id_kont` = '$user[id]' AND (`users_konts`.`type` IS NULL  OR `users_konts`.`type` = 'common' OR `users_konts`.`type` = 'favorite') AND `mail`.`read` = '0'

  GROUP BY `mail`.`id_user` ORDER BY `count` DESC LIMIT $start, $set[p_str]");


while ($kont = mysql_fetch_assoc($q))
{
$ank = get_user($kont['id_user']);
$k_mess = mysql_result(mysql_query("SELECT COUNT(*) FROM `mail` WHERE `unlink` != '$user[id]' AND `id_user` = '$ank[id]' AND `id_kont` = '$user[id]'"), 0);
$k_mess2 = mysql_result(mysql_query("SELECT COUNT(*) FROM `mail` WHERE `unlink` != '$user[id]' AND `id_user` = '$user[id]' AND `id_kont` = '$ank[id]'"), 0);		
	

if($ank){
?>
<div class="stnd_padd oh">     
<span class="p14">   <?= group($ank['id'])?> </span>
<a href="/mail.php?id=<?= $ank['id']?>">   <b><?= ($kont['name'] ? $kont['name'] : $ank['nick'])?></b>  </a>    
<span style="color:green"> <b>(<?= $k_mess?>/<?= $k_mess2?>)</b> </span> <span style="color:red">+<?= $kont['count']?></span>   
</div>
<?
}
else{
?>
<div class="stnd_padd oh">     
<a href="/mail.php?id=<?= $ank['id']?>">   <b>[DELETED]</b>  </a>    
<span style="color:red">+<?= $kont['count']?></span>   
</div>
<?
}

}
?>
</div></div>
<?
}

?>
</div>
<?





if ($k_page > 1){
?>
<div class="wrapper">
<?
str('?',$k_page,$page); // Вывод страниц
?>
</div>
<?
}

$msg_aktiv = mysql_result(mysql_query("SELECT COUNT(*) FROM `users_konts` WHERE `id_user` = '$user[id]' AND `type` = 'common'"), 0);
$msg_fav = mysql_result(mysql_query("SELECT COUNT(*) FROM `users_konts` WHERE `id_user` = '$user[id]' AND `type` = 'favorite'"), 0);
$msg_ignor = mysql_result(mysql_query("SELECT COUNT(*) FROM `users_konts` WHERE `id_user` = '$user[id]' AND `type` = 'ignor'"), 0);
$msg_deleted = mysql_result(mysql_query("SELECT COUNT(*) FROM `users_konts` WHERE `id_user` = '$user[id]' AND `type` = 'deleted'"), 0);
//$new_msg = mysql_result(mysql_query("SELECT COUNT(*) FROM `users_konts` WHERE `id_user` = '$user[id]' AND `unread` = '1'"), 0);

?>
<div class="wrapper">      

<a href="/konts.php" class="link  darkblue  arrow    "> 
<span>        <img src="/style/i/ico/people_darkblue.png" alt="" class="m">      
<span class="m">  Активные </span>   <span class="m">(<?= $msg_aktiv?>)</span>       
</span>  
</a>         

        

<a href="/konts.php?type=favorite" class="link  darkblue  arrow    "> 
<span>        <img src="/style/i/mail/fav_blue.png" alt="" class="m">      
<span class="m">  Избранное </span>          
<?
if($msg_fav > 0){
?>
<span class="m">(<?= $msg_fav?>)</span> 
<?
}
?>
</span>  
</a>                  

<a href="/konts.php?type=ignor" class="link  darkblue  arrow    "> 
<span>        <img src="/style/i/mail/spam_blue.png" alt="" class="m">      
<span class="m">  Игнор </span>          
<?
if($msg_ignor > 0){
?>
<span class="m">(<?= $msg_ignor?>)</span> 
<?
}
?>
</span>  
</a>         

<a href="/konts.php?type=deleted" class="link  darkblue  arrow    "> 
<span>        <img src="/style/i/mail/garbage_blue.png" alt="" class="m">      
<span class="m">  Корзина </span>          
<?
if($msg_deleted > 0){
?>
<span class="m">(<?= $msg_deleted?>)</span> 
<?
}
?>
</span>  
</a>     
</div>

<div class="wrapper">     
<a href="/user/settings/mail.php" class="link  darkblue  arrow    "> 
<span>        
<img src="/style/i/mail/cog_blue.png" alt="" class="m">       <span class="m">  Настройки почты </span>          
</span>  
</a>    
</div>
<?




include_once 'sys/inc/tfoot.php';

?>