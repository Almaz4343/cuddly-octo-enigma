<? 

include_once '../sys/inc/start.php'; 

include_once '../sys/inc/compress.php'; 

include_once '../sys/inc/sess.php'; 

include_once '../sys/inc/home.php'; 

include_once '../sys/inc/settings.php'; 

include_once '../sys/inc/db_connect.php'; 

include_once '../sys/inc/ipua.php'; 

include_once '../sys/inc/fnc.php'; 

include_once '../sys/inc/adm_check.php'; 

include_once '../sys/inc/user.php'; 

user_access('adm_mysql',null,'index.php?'.SID); 

adm_check(); 

$set['title']='MySQL запрос'; 

include_once '../sys/inc/thead.php'; 

title();  



if (isset($_GET['set']) && $_GET['set']=='set' && isset($_POST['query'])) 

{ 

$sql=trim($_POST['query']);     

if ($conf['phpversion']==5) 

{ 

include_once H.'sys/inc/sql_parser.php'; 

$sql=SQLParser::getQueries($sql); // при помощи парсера запросы разбиваются точнее, но работает это только в php5 

} 

else 

{ 

$sql=split(";(\n|\r)*",$sql); 

}      



$k_z=0; $k_z_ok=0; 

for ($i=0;$i<count($sql);$i++) 

{ 

if ($sql[$i]!=''){ 

$k_z++; 

if(mysql_query($sql[$i])) 

{ 

$k_z_ok++; 

}}} 

if ($k_z_ok>0) 

{ 

if ($k_z_ok==1 && $k_z=1) 

msg("Запрос успешно выполнен"); 

else 

msg("Выполнено $k_z_ok запросов из $k_z");     

admin_log('Админка','MySQL',"Выполнено $k_z_ok запрос(ов)"); 

} 

}  

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> 
<a href="/info.php?id=<?= $user['id']?>"><?= $user['nick']?></a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Запросы SQL</span> </span>       </div>
<?

err(); 
  
?>
<div class=" pad_t_a">  
<div class="wrapper" style="margin: 0 5px;"> 
<form action="mysql.php?set=set" method="post"> 
<div class="block bord-botm">  
<div>   <div class="input-txt_wrapper">  <textarea class="input-txt" name="query"></textarea>  </div>   </div>  
</div>  
<table class="table__wrap"> <tbody><tr> 
<td class="table__cell" width="50%"> 
<!-- --><!-- --><!-- --><!-- --><!-- -->
<button type="submit" value="Выполнить" class="  link  blue full is_final    " id="cfms">
<!--   -->
<img src="/style/i/ok_blue.png" alt="" class="m"> 
<!--   -->
<span class="m"> Выполнить</span>
<!-- -->
</button>
<!-- --><!-- --> 
</td> 
<td class="table__cell table__cell_last" width="50%">     
<a href="/adm_panel/" class="link         "> <span>Отменить</span>  </a>    
</td> 
</tr> </tbody></table> 
</form> 
</div>   </div>
<?


if (user_access('adm_panel_show')){ 

echo "<div class='foot'>\n"; 
 

echo "&laquo;<a href='tables.php'>Залить файлом</a><br />\n"; 

echo "</div>\n"; 

} 

include_once '../sys/inc/tfoot.php'; 

?>