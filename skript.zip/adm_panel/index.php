<?
include_once '../sys/inc/start.php';
include_once '../sys/inc/compress.php';
include_once '../sys/inc/sess.php';
include_once '../sys/inc/home.php';
include_once '../sys/inc/settings.php';
include_once '../sys/inc/db_connect.php';
include_once '../sys/inc/ipua.php';
include_once '../sys/inc/fnc.php';
include_once '../sys/inc/adm_check.php';
include_once '../sys/inc/user.php';
user_access('adm_panel_show',null,'/index.php?'.SID);
		   
if (!isset($_SESSION['adm_auth']) && $_SESSION['adm_auth']>$time || isset($_SESSION['captcha']) && isset($_POST['chislo']) && $_SESSION['captcha']==$_POST['chislo'])
{
    $_SESSION['adm_auth'] = $time + 600;
    if (isset($_GET['go']) && $_GET['go'] != null)
    {
        header('Location: '.base64_decode($_GET['go']));
        exit;
    }

$set['title']='Админка';
include_once '../sys/inc/thead.php';
title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="//c.spac.me/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/adm_panel/">Админка</a> </span>     <span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Разделы</span> </span>       </div>
<?

err();

?>
<div class="wrapper">
<div class="title oh black">    <span class="block-title">Modification by Tw1nGo</span>     </div>
<?


if (user_access('adm_mysql')){
?>
<div class="light_border_bottom oh t-bg3">  
<a href="navi.php" class="t-block_item t-padd_right t-link_no_underline_block oh"> 
<span class="t-block_item stnd_padd t-bg_arrow_next">  
<span class="oh inl_bl m"> <span class="t-strong_item t-link_item_hover"> Настройки нижней навигации </span>    </span>  
</span> 
</a> 
</div>
<?
}
if ($user['level'] > 4){
?>
<div class="light_border_bottom oh t-bg3">  
<a href="gifts.php" class="t-block_item t-padd_right t-link_no_underline_block oh"> 
<span class="t-block_item stnd_padd t-bg_arrow_next">  
<span class="oh inl_bl m"> <span class="t-strong_item t-link_item_hover"> Настройки подарков </span>    </span>  
</span> 
</a> 
</div>
<?
} 
if (user_access('adm_mysql')){
?>
<div class="light_border_bottom oh t-bg3">  
<a href="mysql.php" class="t-block_item t-padd_right t-link_no_underline_block oh"> 
<span class="t-block_item stnd_padd t-bg_arrow_next">  
<span class="oh inl_bl m"> <span class="t-strong_item t-link_item_hover"> MySQL запросы </span>    </span>  
</span> 
</a> 
</div>
<?
}     
    
    
    if (user_access('adm_info'))echo "<div class='main'><img src='/style/icons/str.gif' alt=''/> <a href='info.php'>Общая информация</a></div>\n";
    if (user_access('adm_statistic'))echo "<div class='main'><img src='/style/icons/str.gif' alt=''/> <a href='statistic.php'>Статистика сайта</a></div>\n";
    if (user_access('adm_set_sys'))echo "<div class='main'><img src='/style/icons/str.gif' alt=''/> <a href='settings_sys.php'>Настройки системы</a></div>\n";
    if (user_access('adm_set_sys'))echo "<div class='main'><img src='/style/icons/str.gif' alt=''/> <a href='settings_bbcode.php'>Настройки BBcode</a></div>\n";
    if ($user['level'] > 3)echo "<div class='main'><img src='/style/icons/str.gif' alt=''/> <a href='smiles.php'>Смайлы</a></div>\n";
    if (user_access('adm_set_forum'))echo "<div class='main'><img src='/style/icons/str.gif' alt=''/> <a href='settings_forum.php'>Настройки форума</a></div>\n";
    if (user_access('adm_set_user'))echo "<div class='main'><img src='/style/icons/str.gif' alt=''/> <a href='settings_user.php'>Пользовательские настройки</a></div>\n";
    if (user_access('adm_accesses'))echo "<div class='main'><img src='/style/icons/str.gif' alt=''/> <a href='accesses.php'>Привилегии групп пользователей</a></div>\n";
    if (user_access('adm_banlist'))echo "<div class='main'><img src='/style/icons/str.gif' alt=''/> <a href='banlist.php'>Список забаненых</a></div>\n";
    if (user_access('adm_set_foto'))echo "<div class='main'><img src='/style/icons/str.gif' alt=''/> <a href='settings_foto.php'>Настройки фотогалереи</a></div>\n";

    if (user_access('adm_forum_sinc'))echo "<div class='main'><img src='/style/icons/str.gif' alt=''/> <a href='forum_sinc.php'>Синхронизация таблиц форума</a></div>\n";
    if (user_access('adm_ref'))echo "<div class='main'><img src='/style/icons/str.gif' alt=''/> <a href='referals.php'>Рефералы</a></div>\n";
    if (user_access('adm_ip_edit'))echo "<div class='main'><img src='/style/icons/str.gif' alt=''/> <a href='opsos.php'>Редактирование IP операторов</a></div>\n";
    if (user_access('adm_ban_ip'))echo "<div class='main'><img src='/style/icons/str.gif' alt=''/> <a href='ban_ip.php'>Бан по IP адресу (диапазону)</a></div>\n";

    if (user_access('adm_mysql'))echo "<div class='main'><img src='/style/icons/str.gif' alt=''/> <a href='mysql.php'>MySQL запросы</a></div>\n";
    if (user_access('adm_mysql'))echo "<div class='main'><img src='/style/icons/str.gif' alt=''/> <a href='tables.php'>Заливка таблиц</a></div>\n";
    
    $opdirbase=@opendir(H.'sys/add/admin');
    while ($filebase=@readdir($opdirbase))
    if (preg_match('#\.php$#i',$filebase))
    include_once(H.'sys/add/admin/'.$filebase);
    closedir($opdirbase);
?>
</div>
<?    
}
else
{
    $set['title']='Защита от автоматических изменений';
    include_once '../sys/inc/thead.php';
    title();
    err();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="//c.spac.me/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/adm_panel/">Админка</a> </span>     <span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Защита</span> </span>       </div>
<div class="wrapper">
<div class="link">
<?
echo "<form method='post' action='?gen=$passgen&amp;".(isset($_GET['go'])?"go=$_GET[go]":null)."'>\n";
echo "<img src='/captcha.php?$passgen&amp;SESS=$sess' width='100' height='30' alt='Проверочное число' /><br />\n";
?>
<div class="stnd_padd">    
<label class="lbl"> Введите число:  </label> 
<input name="chislo" size="5" maxlength="5" value="" type="text" />
</div>
<input value="Войти" class="main_submit" id="mainSubmitForm" type="submit">   
</div>
</div>
</form>
<?    
}

include_once '../sys/inc/tfoot.php';
?>