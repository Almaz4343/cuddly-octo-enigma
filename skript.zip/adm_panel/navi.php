<? 

include_once '../sys/inc/start.php'; 
include_once '../sys/inc/compress.php'; 
include_once '../sys/inc/sess.php'; 
include_once '../sys/inc/home.php'; 
include_once '../sys/inc/settings.php'; 
include_once '../sys/inc/db_connect.php'; 
include_once '../sys/inc/ipua.php'; 
include_once '../sys/inc/fnc.php'; 
include_once '../sys/inc/adm_check.php'; 
include_once '../sys/inc/user.php'; 

user_access('adm_mysql',null,'index.php?'.SID); 

adm_check(); 

$set['title'] = 'Нижняя панель навигации : Админка'; 

include_once '../sys/inc/thead.php'; 
title(); 


//Добавляем новую ссылку
if(isset($_GET['add']))
{
if(isset($_GET['cfms']) && isset($_POST['name']) && isset($_POST['mini_name']))
{
$name = my_esc($_POST['name']);

//if (strlen2($name) < 3)$err = 'Короткое название ссылки!';
if (strlen2($name) > 32)$err = 'Превышен лимит символов!';

$mini_name = my_esc($_POST['mini_name']);

//if (strlen2($name) < 3)$err = 'Короткое название мини-ссылки!';
if (strlen2($mini_name) > 32)$err = 'Превышен лимит в мини-ссылке!';

$url = esc(stripcslashes(htmlspecialchars($_POST['url'])));

if (mysql_result(mysql_query("SELECT COUNT(*) FROM `links_niz` WHERE `name` = '$name'"),0) != 0)
$err = 'Ссылка с таким названием уже существует!';

if (!isset($err)){
mysql_query("INSERT INTO `links_niz` (`name`, `mini_name`, `url`) VALUES ('$name', '$mini_name', '$url')");
$_SESSION['message'] = 'Ссылка успешно добавлена.';
header("location: ?");
exit;
}
}
else
{

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/adm_panel/">Админка</a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/adm_panel/navi.php">Нижняя панель</a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Добавление ссылки</span> </span>       </div>
<?

err();

?>
<div class="wrapper"> 
<form action="?add&cfms" method="post">
<div class="bord-botm">

<div class="block">  <div>  
<label class="lbl"> Название: </label>   
<div class="input-txt_wrapper">  
<input class="input-txt" name="name" value="" type="text">  
</div>   
</div>   </div>

<div class="block">  <div>  
<label class="lbl"> Сокращение: </label>   
<div class="input-txt_wrapper">  
<input class="input-txt" name="mini_name" value="" type="text">  
</div>   
</div>   </div>

<div class="block">  <div>  
<label class="lbl"> Ссылка: </label>   
<div class="input-txt_wrapper">  
<input class="input-txt" name="url" value="/" type="text">  
</div>   
</div>   </div>

</div>
<table class="table__wrap table__links"> 
<tbody><tr> 
<td class="table__cell" width="50%"> 
<!-- --><!-- --><!-- --><!-- --><!-- -->
<button name="cfms" value="Сохранить" class="  link  blue full is_final    " id="cfms">
<!--   -->
<img src="//c.spac.me/i/ok_blue.png" alt="" class="m"> <!--   --><span class="m"> Сохранить</span><!-- -->
</button>
<!-- --><!-- --> 
</td> 
<td class="table__cell table__cell_last" width="50%">     
<a href="?" class="link          "> <span>Отменить</span>  </a>    
</td> 
</tr> </tbody></table>
</form>
</div>
<?
}

?>
<a href="?" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?

}elseif(isset($_GET['edit'])){
// Редактируем ссылку
$editi = intval($_GET['edit']);

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/adm_panel/">Админка</a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/adm_panel/navi.php">Нижняя панель</a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Редактор ссылки</span> </span>       </div>
<?

$link = mysql_fetch_array(mysql_query("SELECT * FROM `links_niz` WHERE `id` = '".$editi."' LIMIT 1"));
if(mysql_result(mysql_query("SELECT COUNT(*) FROM `links_niz` WHERE `id` = '$link[id]' LIMIT 1"),0)!=0)
{
if(isset($_GET['cfms']) && isset($_POST['name']) && isset($_POST['mini_name']))
{
$name = $_POST['name'];
$mini_name = $_POST['mini_name'];

if (strlen2($name) > 32)$err = 'Превышен лимит символов!';
if (strlen2($mini_name) > 32)$err = 'Превышен лимит символов!';

$name = my_esc($_POST['name']);
$mini_name = my_esc($_POST['mini_name']);
$url = esc(stripcslashes(htmlspecialchars($_POST['url'])));

if (!isset($err)){
mysql_query("UPDATE `links_niz` SET `name` = '$name', `mini_name` = '$mini_name', `url` = '$url' WHERE `id` = '".$link['id']."' LIMIT 1");

$_SESSION['message'] = 'Ссылка успешно изменена.';
header("location: ?");
exit;
}

}
else
{


err();

?>
<div class="wrapper"> 
<form action="?edit=<?= $link['id']?>&cfms" method="post">
<div class="bord-botm">

<div class="block">  <div>  
<label class="lbl"> Название: </label>   
<div class="input-txt_wrapper">  
<input class="input-txt" name="name" value="<?= text($link['name'])?>" type="text">  
</div>   
</div>   </div>

<div class="block">  <div>  
<label class="lbl"> Сокращение: </label>   
<div class="input-txt_wrapper">  
<input class="input-txt" name="mini_name" value="<?= text($link['mini_name'])?>" type="text">  
</div>   
</div>   </div>

<div class="block">  <div>  
<label class="lbl"> Ссылка: </label>   
<div class="input-txt_wrapper">  
<input class="input-txt" name="url" value="<?= text($link['url'])?>" type="text">  
</div>   
</div>   </div>

</div>
<table class="table__wrap table__links"> 
<tbody><tr> 
<td class="table__cell" width="50%"> 
<!-- --><!-- --><!-- --><!-- --><!-- -->
<button name="cfms" value="Сохранить" class="  link  blue full is_final    " id="cfms">
<!--   -->
<img src="//c.spac.me/i/ok_blue.png" alt="" class="m"> <!--   --><span class="m"> Сохранить</span><!-- -->
</button>
<!-- --><!-- --> 
</td> 
<td class="table__cell table__cell_last" width="50%">     
<a href="?" class="link          "> <span>Отменить</span>  </a>    
</td> 
</tr> </tbody></table>
</form>
</div>
<?
}



}else{
?>
<div class="wrapper"><div class="block">
<span class="m">Ссылка не найдена.</span>
</div></div>
<?
}
?>
<a href="?" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?
}elseif(isset($_GET['del'])){
// Удаляем ссылку
$deli = intval($_GET['del']);

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/adm_panel/">Админка</a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/adm_panel/navi.php">Нижняя панель</a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Удаляем ссылку</span> </span>       </div>
<?

$link = mysql_fetch_array(mysql_query("SELECT * FROM `links_niz` WHERE `id` = '".$deli."' LIMIT 1"));

if(mysql_result(mysql_query("SELECT COUNT(*) FROM `links_niz` WHERE `id` = '".$deli."' LIMIT 1"),0)==0)
{
?>
<div class="wrapper"><div class="block">
<span class="m">Ссылка не найдена.</span>
</div></div>
<?
}
else{
if(isset($_GET['cfms']))
{
mysql_query("DELETE FROM `links_niz` WHERE `id` = '".$link['id']."'");
mysql_query("DELETE FROM `links_niz_user` WHERE `id_link` = '".$link['id']."'");
header("location: ?");
exit;
}
else
{

err();

?>
<div class="wrapper">  
<div class="block bord-botm grey t_center"> 
<span class="m">Вы действительно хотите удалить ссылку</span> «<span class="m b"> <?= text($link['name'])?> </span>»</a>  
</div>  
<table class="table__wrap"> <tbody><tr> 
<td class="table__cell" width="50%"> 
<a href="?del=<?= $link['id']?>&cfms" class="link blue"> <img src="//c.spac.me/i/ok_blue.png" alt="" class="m"> <span class="m">Да</span> </a> 
</td> 
<td class="table__cell table__cell_last" width="50%"> 
<a href="?" class="link"> <span>Отмена</span> </a> 
</td> 
</tr> </tbody></table>  
</div>
<?

}
}
?>
<a href="?" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?
}
// Главная страница настроек
else{

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/adm_panel/">Админка</a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Нижняя панель навигации</span> </span>       </div>
<div class="t-block_item stnd_padd arrow_link vlight_border_bottom">
<a href="?add" class="right " title="Добавить ссылку">
<img src="//c.spac.me/i/lj.gif" alt="" class="m p16"> <span style="margin-left:5px;" class="t"> Добавить ссылку </span>
</a> <br />
</div>
<?



$links = mysql_query("SELECT * FROM `links_niz` ORDER BY `name` DESC");

if (mysql_num_rows($links) == 0)
{
?>
<div class="wrapper"><div class="block">
<span class="m">Ссылки не найдены.</span>
</div></div>
<?
}

?>
<div>
<?

while ($post = mysql_fetch_array($links))
{
?>
<div class="stnd_padd vlight_border_bottom overfl_hid">    
<a href="?del=<?= $post['id']?>" class="right" title="Удалить">
<img src="//c.spac.me/i/cross_r.gif" alt="" class="m p16"></a>  
<a href="?edit=<?= $post['id']?>" class="right" style="margin-right:5px;" title="Изменить">
<img src="//c.spac.me/i/edit.gif" alt="" class="m p16"></a>
<div class="overfl_hid">
<b><?= text($post['name'])?></b> - <?= text($post['mini_name'])?>  <br> https://xmyx.ru<?= text($post['url'])?>
</div> 
</div>
<?
}

?>
</div>
<a href="/adm_panel/" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?


}
include_once '../sys/inc/tfoot.php';

?>