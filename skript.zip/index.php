<?
include_once 'sys/inc/start.php';
include_once 'sys/inc/compress.php';
include_once 'sys/inc/sess.php';
include_once 'sys/inc/home.php';
include_once 'sys/inc/settings.php';
include_once 'sys/inc/db_connect.php';
include_once 'sys/inc/ipua.php';
include_once 'sys/inc/fnc.php';
include_once 'sys/inc/user.php';
include_once 'sys/inc/icons.php'; // Иконки главного меню

include_once 'sys/inc/thead.php';
title();
err();

$onl = mysql_result(mysql_query("SELECT COUNT(*) FROM `user` WHERE `date_last` > ".(time()-600).""), 0);

if (!$set['web'])
{
?>
<div id="index_page">
<a href="/online.php" class="list-link list-link_online"> 
<?
if(isset($user)){
?>
<span class="ico ico_user_online"></span>
<?
}
?>
Сейчас онлайн: <?= $onl?> </a>

<div class="wrapper-nobg"> 
<form action="/plugins/search/?search" method="post">     
<table class="table__wrap search-wrap input-txt_grid"> <tbody><tr> 
<td class="input-txt_grid_input"> 
<div class="input-txt_wrapper_search relative"> <input class="input-txt" name="search" value="" maxlength="64" type="text">  </div> 
</td> 
<td class="input-txt_grid_sep"></td> 
<td class="input-txt_grid_btn"> <input class="search__btn" value="Найти" type="submit"> </td> 
</tr> </tbody></table>     
</form> 
</div>

<?

	// новости 
	include_once 'sys/inc/news_main.php'; 

	// главное меню
	include_once 'sys/inc/main_menu.php'; 
?>
</div>
<?
}
else
{
	// главная web темы
	include_once 'style/themes/' . $set['set_them'] . '/index.php'; 
}
include_once 'sys/inc/tfoot.php';
?>