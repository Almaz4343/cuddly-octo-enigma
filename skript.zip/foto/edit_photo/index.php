<?


include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';
only_reg();


if (isset($_GET['Delete'])){

	if ($user['id'] == $user['id']){
	mysql_query("UPDATE `gallery_foto` SET `avatar` = '0' WHERE `id_user` = '$user[id]'");
	$_SESSION['message'] = 'Фотография успешно убрана с аватара.';
	}
	
	header("Location: ?");
	exit;

}
if (isset($_GET['avatar']))  {
  if (isset($user)) {
    $id = (int) $_GET['avatar'];
    $foto = mysql_fetch_array(mysql_query("SELECT * FROM `gallery_foto` WHERE `id` = '$id'"));
  	if (mysql_result(mysql_query("SELECT COUNT(*) FROM `gallery_foto`  WHERE `id_user` = '$user[id]' AND `avatar` = '1' AND `id` = '$foto[id]'"),0) == 0) {
    	mysql_query("UPDATE `gallery_foto` SET `avatar` = '0' WHERE `id_user` = '$user[id]'");
    	mysql_query("UPDATE `gallery_foto` SET `avatar` = '1' WHERE `id` = '$foto[id]' LIMIT 1");
    	$_SESSION['message'] = 'Фотография изменена.';
  	}else{
  	$_SESSION['err'] = 'Эта фотография у Вас на аватаре.';
  	}
    	header('Location: /foto/edit_photo/?');
    	exit;
  }
}

$set['title'] = 'Фотография : Анкета : ' . text($user['nick']);

include_once H.'sys/inc/thead.php';
title();


$avatar = mysql_fetch_array(mysql_query("SELECT id,id_gallery,ras FROM `gallery_foto` WHERE `id_user` = '$user[id]' AND `avatar` = '1' LIMIT 1"));
$gallery = mysql_fetch_assoc(mysql_query("SELECT * FROM `gallery` WHERE `id` = '$avatar[id_gallery]' LIMIT 1"));

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> 
<a href="/user/?id=<?= $user['id']?>"> <?= $user['nick']?> </a> </span>     
<span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> 
<a href="/foto/<?= $user['id']?>/">Фото</a> </span>   
<span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> 
<span class="lc_br_text">Фотография</span> </span>    </div>


<div class="wrapper t_center image_limit stnd_padd">  
<?
if($avatar != 0){
?>    
<a href="/foto/<?= $user['id']?>/<?= $gallery['id']?>/<?= $avatar['id']?>/">    
<img src="/foto/pic400/<?= $avatar['id']?>.p.401.400.0.jpg" alt="" class="preview">
</a>       
<?
}else{
?>
<img src="/style/i/<?= ($user['pol'] == 1 ? 'man' : 'woman')?>.png" alt="" class="preview">
<?
}
?>
</div>   

<div class="wrapper">
<a href="/foto/select/?uid=<?= $user['id']?>" class="link">          
<img src="/foto/css/ico/edit.png">     <span class="t">  Изменить аватар  </span>             
</a> 
<?
if($avatar != 0){
?>          
<a href="?Delete" class="link  red      ">          
<img src="/foto/css/ico/dell.png">      <span class="t">  Удалить с аватара  </span>             
</a>
<?
}   
?>   
</div>
<a href="/user/?id=<?= $user['id']?>" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   <span class="m">Назад</span>  </a>  
<?

include_once H.'sys/inc/tfoot.php';
?>