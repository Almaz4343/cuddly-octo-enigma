<?

// Защита на удаление чужих фото, простым юзером 
if (isset($user) && mysql_result(mysql_query("SELECT COUNT(*) FROM `gallery_foto` WHERE `id` = '".$foto['id']."' AND `id_gallery` = '".$gallery['id']."' LIMIT 1"),0)==0){
header("Location: /foto/".$ank['id']."/".$gallery['id']."/?".SID);
exit;
}
else
{

/*
* Удаление фотографии
*/

if ((user_access('foto_foto_edit') || isset($user) && $user['id'] == $ank['id']) && isset($_GET['act']) && $_GET['act'] == 'delete' && isset($_GET['ok']))
{
	if ($user['id'] != $ank['id'])
	admin_log('Фотогалерея','Фотографии',"Удаление фото пользователя '[url=/id$ank[id]]" . user::nick($ank['id'], 0) . "[/url]'");
	@unlink(H."sys/tpic/pic40/$foto[id].p.41.40.0.jpg");
	@unlink(H."sys/tpic/pic50/$foto[id].p.51.50.0.jpg");
	@unlink(H."sys/tpic/pic80/$foto[id].p.81.80.0.jpg");
	@unlink(H."sys/tpic/pic100/$foto[id].p.101.100.0.jpg");
	@unlink(H."sys/tpic/pic200/$foto[id].p.201.200.0.jpg");
	@unlink(H."sys/tpic/pic400/$foto[id].p.401.400.0.jpg");
	@unlink(H."sys/tpic/pictures/$foto[id].0.jpg");


	mysql_query("DELETE FROM `gallery_foto` WHERE `id` = '$foto[id]' LIMIT 1");
	mysql_query("DELETE FROM `bookmarks` WHERE `id_user` = '$ank[id]' AND  `id_object` = '$foto[id]' AND `type` = 'foto'");
	mysql_query("DELETE FROM `bookmarks_like` WHERE `id_user` = '$ank[id]' AND  `id_object` = '$foto[id]' AND `type` = 'photo'");
	$_SESSION['message'] = 'Фотография успешно удалена';
	header("Location: /foto/$ank[id]/$gallery[id]/");
	exit;
}

/*
* Редактирование фотографии
*/


if ((user_access('foto_foto_edit') || isset($user) && $user['id'] == $ank['id']) && isset($_GET['act']) && $_GET['act'] == 'rename' && isset($_GET['ok']) && isset($_POST['name']) && isset($_POST['opis']))
{
	$name = esc(stripcslashes(htmlspecialchars($_POST['name'])),1);
	if (!preg_match("#^([A-zА-я0-9\-\_\(\)\,\.\ ])+$#ui",$name))$err = 'В названии темы присутствуют запрещенные символы';
	if (strlen2($name) < 3 )$err = 'Короткое название';
	if (strlen2($name) > 32 )$err = 'Название не должно быть длиннее 32-х символов';
	$name = my_esc($name);

	$msg = $_POST['opis'];
	
	if (strlen2($msg) > 1024)$err = 'Длина описания превышает предел в 1024 символа';
	$msg = my_esc($msg);

	if ($_POST['metka'] == 0 || $_POST['metka'] == 1)
	$metka = $_POST['metka'];
	else $metka = 0;

	if (!isset($err))
	{
		if ($user['id'] != $ank['id'])
		admin_log('Фотогалерея','Фотографии',"Переименование фото пользователя '[url=/id$ank[id]]" . user::nick($ank['id'], 0) . "[/url]'");
		mysql_query("UPDATE `gallery_foto` SET `name` = '$name', `metka` = '$metka', `opis` = '$msg' WHERE `id` = '$foto[id]' LIMIT 1");
		$foto=mysql_fetch_assoc(mysql_query("SELECT * FROM `gallery_foto` WHERE `id` = '$foto[id]'  LIMIT 1"));
		$_SESSION['message'] = 'Фотография успешно переименована';
		header("Location: ?");
		exit;
	}
}
}
?>