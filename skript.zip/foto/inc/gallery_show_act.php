<?
// Удаление альбома
if ((user_access('foto_alb_del') || isset($user) && $user['id'] == $ank['id']) && isset($_GET['act']) && $_GET['act'] == 'delete' && isset($_GET['ok']))
{
	$q = mysql_query("SELECT * FROM `gallery_foto` WHERE `id_gallery` = '$gallery[id]'");
	
	while ($post = mysql_fetch_assoc($q))
	{
	@unlink(H."sys/tpic/pic40/$post[id].p.41.40.0.jpg");
	@unlink(H."sys/tpic/pic50/$post[id].p.51.50.0.jpg");
	@unlink(H."sys/tpic/pic80/$post[id].p.81.80.0.jpg");
	@unlink(H."sys/tpic/pic100/$post[id].p.101.100.0.jpg");
	@unlink(H."sys/tpic/pic200/$post[id].p.201.200.0.jpg");
	@unlink(H."sys/tpic/pic400/$post[id].p.401.400.0.jpg");
	@unlink(H."sys/tpic/pictures/$post[id].0.jpg");
	mysql_query("DELETE FROM `gallery_komm` WHERE `id_foto` = '$post[id]' LIMIT 1");
	mysql_query("DELETE FROM `gallery_foto` WHERE `id` = '$post[id]' LIMIT 1");
	mysql_query("DELETE FROM `bookmarks` WHERE `id_object` = '$post[id]' AND `type` = 'foto'");
	mysql_query("DELETE FROM `bookmarks_like` WHERE `id_object` = '$post[id]' AND `type` = 'photo'");
	}
	
	if ($user['id'] != $ank['id'])
	admin_log('Фотогалерея','Фотоальбомы',"Удаление альбома " . text($gallery['name']) . " (фотографий: ".mysql_num_rows($q).")");
	mysql_query("DELETE FROM `gallery` WHERE `id` = '$gallery[id]' LIMIT 1");
	$_SESSION['message'] = 'Фотоальбом успешно удален';
	header("Location: /foto/$ank[id]/");
	exit;
}

// Загрузка фото
if (isset($user) && $user['id'] == $ank['id'] && isset($_FILES['file']))
{

if ($imgc = @imagecreatefromstring(file_get_contents($_FILES['file']['tmp_name'])))
{

$name = $_POST['name'];

if ($name == null)
$name = esc(stripcslashes(htmlspecialchars(preg_replace('#\.[^\.]*$#i', NULL, $_FILES['file']['name'])))); 
   
if (!preg_match("#^([A-zА-я0-9\-\_\ ])+$#ui",$name))$err = 'В названии фото присутствуют запрещенные символы';
if (strlen2($name) < 3)$err = 'Короткое название';
if (strlen2($name) > 32)$err = 'Название не должно быть длиннее 32-х символов';

$name = my_esc($name);

if (isset($_POST['metka']) && ($_POST['metka'] == 0 || $_POST['metka'] == 1))
$metka = $_POST['metka'];
else 
{
	$metka = 0;
}

$msg = $_POST['opis'];

if (strlen2($msg) > 1024)$err = 'Длина описания превышает предел в 1024 символов';
$msg = my_esc($msg);
$img_x = imagesx($imgc);
$img_y = imagesy($imgc);
if ($img_x > $set['max_upload_foto_x'] || $img_y>$set['max_upload_foto_y'])
   $err = 'Размер изображения превышает ограничения в '.$set['max_upload_foto_x'].'*'.$set['max_upload_foto_y'];

if ($img_x < 50 || $img_y < 50)
   $err = 'Изображение слишком маленькое, загружайте файлы не меньше 50x50 (у вас '.$img_x.'x'.$img_y.')';
   
if (!isset($err))
{

if (isset($_GET['avatar']))
{
	mysql_query("UPDATE `gallery_foto` SET `avatar` = '0' WHERE `id_user` = '$user[id]'");
	mysql_query("INSERT INTO `gallery_foto` (`id_gallery`, `name`, `ras`, `type`, `opis`, `id_user`,`avatar`, `metka`, `time`) values ('$gallery[id]', '$name', 'jpg', 'image/jpeg', '$msg', '$user[id]','1', '$metka', '$time')");
}
else
{
	mysql_query("INSERT INTO `gallery_foto` (`id_gallery`, `name`, `ras`, `type`, `opis`, `id_user`, `metka`, `time`) values ('$gallery[id]', '$name', 'jpg', 'image/jpeg', '$msg', '$user[id]', '$metka', '$time')");
}


$id_foto = mysql_insert_id();

mysql_query("UPDATE `gallery` SET `time` = '$time' WHERE `id` = '$gallery[id]' LIMIT 1");
		   
$q = mysql_query("SELECT * FROM `frends` WHERE `user` = '$user[id]' AND `lenta_foto` = '1' AND `i` = '1'");

$foto['id'] = $id_foto;


// Мод: Активность как на спейсе
// Cделал: Tw1nGo

/* -Активность- */
mysql_query("INSERT INTO `user_activity` (`id_user`,`avtor`, `type`, `time`, `id_file`, `id_photo`) values('$user[id]', '$user[id]', 'album', '$time', '$gallery[id]', '".$foto['id']."')"); 
/* -Активность конец- */


/*
* Лента друзей
*/

mysql_query("UPDATE `tape` SET `count` = '0' WHERE  `type` = 'album' AND `read` = '1' AND `id_file` = '$gallery[id]'");

$q = mysql_query("SELECT * FROM `frends` WHERE `user` = '" . $gallery['id_user'] . "' AND `i` = '1'");

while ($f = mysql_fetch_array($q))
{
	$a = get_user($f['frend']);
	
	// Общая настройка ленты
	$lentaSet = mysql_fetch_array(mysql_query("SELECT * FROM `tape_set` WHERE `id_user` = '".$a['id']."' LIMIT 1")); 
	
	/* Фильтр рассылки */	
	if  ($f['lenta_foto'] == 1 && $lentaSet['lenta_foto'] == 1)
	{
		/* Если грузим со страницы то отправляем как смену аватара */
		if (isset($_GET['avatar']))
		{
			if ($a['id'] != $user['id'] && $foto['id'] != $avatar['id'])
			mysql_query("INSERT INTO `tape` (`id_user`, `avtor`, `type`, `time`, `id_file`, `count`, `avatar`) values('$a[id]', '$gallery[id_user]', 'avatar', '$time', '$foto[id]', '1', '$avatar[id]')"); 
		}
		else
		{ 
			/* Если нет то просто шлем в ленту как новое фото */

			if (mysql_result(mysql_query("SELECT COUNT(*) FROM `tape` WHERE `id_user` = '$a[id]' AND `type` = 'album' AND `id_file` = '$gallery[id]' LIMIT 1"),0)==0)
			{
				mysql_query("INSERT INTO `tape` (`id_user`, `avtor`, `type`, `time`, `id_file`, `count`) values('$a[id]', '$gallery[id_user]', 'album', '$time', '$gallery[id]', '1')"); 
			}
			else
			{
				$tape = mysql_fetch_array(mysql_query("SELECT * FROM `tape` WHERE `type` = 'album' AND `id_file` = '$gallery[id]'"));
				mysql_query("UPDATE `tape` SET `count` = '".($tape['count']+1)."', `read` = '0', `time` = '$time' WHERE `id_user` = '$a[id]' AND `type` = 'album' AND `id_file` = '$gallery[id]' LIMIT 1");
			}
		}
	}
		
}



// 200x200
if ($img_x == $img_y){
$dstW = 200; // ширина
$dstH = 200; // высота 
}elseif ($img_x > $img_y){
$prop = $img_x / $img_y;
$dstW = 200;
$dstH = ceil($dstW / $prop);
}else{
$prop = $img_y / $img_x;
$dstH = 200;
$dstW = ceil($dstH / $prop);
}

$screen = imagecreatetruecolor($dstW, $dstH);
imagecopyresampled($screen, $imgc, 0, 0, 0, 0, $dstW, $dstH, $img_x, $img_y);
//imagedestroy($imgc);
// $screen = img_copyright($screen); // наложение копирайта
imagejpeg($screen,H."sys/tpic/pic200/$id_foto.p.201.200.0.jpg",90);
@chmod(H."sys/tpic/pic200/$id_foto.p.201.200.0.jpg",0777);
imagedestroy($screen);

// 400x400 и родное
if ($img_x > 400 || $img_y > 400)
{
if ($img_x == $img_y){
$dstW = 400; // ширина
$dstH = 400; // высота 
}elseif ($img_x > $img_y){
$prop = $img_x / $img_y;
$dstW = 400;
$dstH = ceil($dstW / $prop);
}else{
$prop = $img_y / $img_x;
$dstH = 400;
$dstW = ceil($dstH / $prop);
}

$screen = imagecreatetruecolor($dstW, $dstH);
imagecopyresampled($screen, $imgc, 0, 0, 0, 0, $dstW, $dstH, $img_x, $img_y);
// imagedestroy($imgc);
// $screen=img_copyright($screen); // наложение копирайта
imagejpeg($screen,H."sys/tpic/pic400/$id_foto.p.401.400.0.jpg",90);
imagedestroy($screen);


//$imgc=img_copyright($imgc); // наложение копирайта
imagejpeg($imgc,H."sys/tpic/pictures/$id_foto.0.jpg",90);
@chmod(H."sys/tpic/pictures/$id_foto.0.jpg",0777);
}
else
{
imagejpeg($imgc,H."sys/tpic/pic400/$id_foto.p.401.400.0.jpg",90);
//$imgc = img_copyright($imgc); // наложение копирайта
	
imagejpeg($imgc,H."sys/tpic/pictures/$id_foto.0.jpg",90);
@chmod(H."sys/tpic/pictures/$id_foto.0.jpg",0777);
}

@chmod(H."sys/tpic/pic400/$id_foto.p.401.400.0.jpg",0777);
imagedestroy($imgc);


// 40x40
crop(H."sys/tpic/pictures/$id_foto.0.jpg", H."sys/tpic/pic40/$id_foto.p.41.40.0.tmp.jpg");
resize(H."sys/tpic/pic40/$id_foto.p.41.40.0.tmp.jpg", H."sys/tpic/pic40/$id_foto.p.41.40.0.jpg", 40, 40);
@chmod(H."sys/tpic/pic40/$id_foto.p.41.40.0.jpg",0777);
@unlink(H."sys/tpic/pic40/$id_foto.p.41.40.0.tmp.jpg");

// 50x50
crop(H."sys/tpic/pictures/$id_foto.0.jpg", H."sys/tpic/pic50/$id_foto.p.51.50.0.tmp.jpg");
resize(H."sys/tpic/pic50/$id_foto.p.51.50.0.tmp.jpg", H."sys/tpic/pic50/$id_foto.p.51.50.0.jpg", 50, 50);
@chmod(H."sys/tpic/pic50/$id_foto.p.51.50.0.jpg",0777);
@unlink(H."sys/tpic/pic50/$id_foto.p.51.50.0.tmp.jpg");

// 80x80
crop(H."sys/tpic/pictures/$id_foto.0.jpg", H."sys/tpic/pic80/$id_foto.p.81.80.0.tmp.jpg");
resize(H."sys/tpic/pic80/$id_foto.p.81.80.0.tmp.jpg", H."sys/tpic/pic80/$id_foto.p.81.80.0.jpg", 80, 80);
@chmod(H."sys/tpic/pic80/$id_foto.p.81.80.0.jpg",0777);
@unlink(H."sys/tpic/pic80/$id_foto.p.81.80.0.tmp.jpg");

// 100x100
crop(H."sys/tpic/pictures/$id_foto.0.jpg", H."sys/tpic/pic100/$id_foto.p.101.100.0.tmp.jpg");
resize(H."sys/tpic/pic100/$id_foto.p.101.100.0.tmp.jpg", H."sys/tpic/pic100/$id_foto.p.101.100.0.jpg", 100, 100);
@chmod(H."sys/tpic/pic100/$id_foto.p.101.100.0.jpg",0777);
@unlink(H."sys/tpic/pic100/$id_foto.p.101.100.0.tmp.jpg");



if (isset($_GET['avatar']))
{
	$_SESSION['message'] = 'Фото успешно установлено';
	header("Location: /user/");
	exit;
}

$_SESSION['message'] = 'Фото успешно загружено';
header("Location: /foto/$ank[id]/$gallery[id]/$id_foto/");
exit;
}
}
else 
$err = 'Выбранный Вами формат изображения не поддерживается';

}


// Редактирование альбома
if ((user_access('foto_foto_edit') || isset($user) && $user['id'] == $ank['id'])){
if (isset($_GET['edit']) && $_GET['edit'] == 'rename' && isset($_GET['ok']) && (isset($_POST['name'])))
{
	$name = $_POST['name'];
	$pass = $_POST['pass'];
	$privat = intval($_POST['privat']);

	if (strlen2($name) < 3)$err = 'Короткое название альбома.';
	if (strlen2($name) > 32)$err = 'Название альбома превышает лимит, не более 32-х символов.';
	$name = my_esc($name);
	$pass = my_esc($pass);


	if (!isset($err))
	{
		if ($user['id']!=$ank['id'])
		admin_log('Фотогалерея','Фотографии',"Переименование альбома пользователя '[url=/id$ank[id]]" . user::nick($ank['id'], 0) . "[/url]'");
		mysql_query("UPDATE `gallery` SET `name` = '$name', `privat` = '$privat', `privat_komm` = '$privat_komm', `pass` = '$pass' WHERE `id` = '$gallery[id]' LIMIT 1");
		$_SESSION['message'] = 'Настройки папки сохранены. ';
		header("Location: /foto/$ank[id]/$gallery[id]/?");
		exit;
	}
}
}
?>