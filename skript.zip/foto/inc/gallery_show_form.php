<?
if ($user['level'] > $ank['level'] || $user['id'] == $ank['id'])
{
	if (isset($_GET['edit']) && $_GET['edit'] == 'rename')
	{
?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $ank['id']?>"><?= $ank['nick']?></a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/foto/<?= $ank['id']?>/">Фото</a> </span>      </div>

<a href="/foto/<?= $ank['id']?>/<?= $gallery['id']?>/" class="link darkblue return full_link">  <span class="ico ico_arrow-back"><span id="transmark" style="display: none; width: 0px; height: 0px;"></span></span>   Назад  </a>

<div class="wrapper">
<div class="block pdb t_center"> <div class="upcs b"> Редактор папки  </div> </div>

<form action="?edit=rename&amp;ok" method="post">

<div class="block pdb"> <div> <div class="input-txt_wrapper"> 
<label class="lbl">Название:</label> 
<input class="input-txt" name="name" maxlength="50" value="<?= text($gallery['name'])?>" type="text">  
</div> </div> </div>

<div><div>
<div class="vlight_border_bottom stnd_padd pdb vlight_border_bottom"> <label class="lbl">Могут смотреть:</label> </div>

<div> 
<label for="am_na_0_3" class="t-block_item stnd_padd vlight_border_bottom"> 
<input name="privat" id="am_na_0_3" value="0" class="m" <?=($gallery['privat'] == 0 ? ' checked="checked"' : null)?> type="radio"> 
<img class="m p16" src="/style/i/ico/ac_all_darkblue.png" alt="Все"> <span class="m">&nbsp;Все</span> 
</label> 
</div>

<div> 
<label for="am_oo_0_3" class="t-block_item stnd_padd vlight_border_bottom"> 
<input name="privat" id="am_oo_0_3" value="2" class="m" <?=($gallery['privat'] == 2 ? ' checked="checked"' : null)?> type="radio"> 
<img class="m p16" src="/style/i/ico/ac_user_red.png" alt="Только я"> <span class="m">&nbsp;Только я</span> 
</label> 
</div>

<div> 
<label for="am_fo_0_3" class="t-block_item stnd_padd vlight_border_bottom"> 
<input name="privat" id="am_fo_0_3" value="1" class="m" <?=($gallery['privat'] == 1 ? ' checked="checked"' : null)?> type="radio"> 
<img class="m p16" src="/style/i/ico/ac_friends_green.png" alt="Мои друзья"> <span class="m">&nbsp;Мои друзья</span> 
</label> 
</div>
</div> </div>

<div><div>
<div class="vlight_border_bottom stnd_padd pdb vlight_border_bottom"> <label class="lbl">Могут комментировать:</label> </div>

<div> 
<label for="am_na_0_4" class="t-block_item stnd_padd vlight_border_bottom"> 
<input name="privat_komm" id="am_na_0_4" value="0" class="m" <?=($gallery['privat_komm'] == 0 ? ' checked="checked"' : null)?> type="radio"> 
<img class="m p16" src="/style/i/ico/ac_all_darkblue.png" alt="Все"> <span class="m">&nbsp;Все</span> 
</label> 
</div>

<div> 
<label for="am_oo_0_4" class="t-block_item stnd_padd vlight_border_bottom"> 
<input name="privat_komm" id="am_oo_0_4" value="2" class="m" <?=($gallery['privat_komm'] == 2 ? ' checked="checked"' : null)?> type="radio"> 
<img class="m p16" src="/style/i/ico/ac_user_red.png" alt="Только я"> <span class="m">&nbsp;Только я</span> 
</label> 
</div>

<div> 
<label for="am_fo_0_4" class="t-block_item stnd_padd vlight_border_bottom"> 
<input name="privat_komm" id="am_fo_0_4" value="1" class="m" <?=($gallery['privat_komm'] == 1 ? ' checked="checked"' : null)?> type="radio"> 
<img class="m p16" src="/style/i/ico/ac_friends_green.png" alt="Мои друзья"> <span class="m">&nbsp;Мои друзья</span> 
</label> 
</div>
</div> </div>

<div><div>
<div class="vlight_border_bottom stnd_padd pdb vlight_border_bottom" style="border-bottom:0;"> <label class="lbl">Пароль:</label> </div> 
<div class="t-block_item stnd_padd vlight_border_bottom"> 
 <input type="text" name="pass" value="<?= text($gallery['pass'])?>" />
</div>


</div> </div>
<div class="block"> <input value="Сохранить" class="main_submit" type="submit"> </div>
</form>
</div>

<div class="wrapper"> 
<a href="?act=delete" class="link red"> 
<img src="/style/i/ico/delete.png" alt="" class="m p16"> <span class="m">Удалить папку</span> 
</a> 
</div>

<a href="/foto/<?= $ank['id']?>/<?= $gallery['id']?>/" class="link darkblue return full_link">  <span class="ico ico_arrow-back"><span id="transmark" style="display: none; width: 0px; height: 0px;"></span></span>   Назад  </a>

<?
	
include_once '../sys/inc/tfoot.php';
exit;
	}
}


if ((user_access('foto_alb_del') || isset($user) && $user['id'] == $ank['id']) && isset($_GET['act']) && $_GET['act'] == 'delete')
{

if($gallery['pass'] != null){
$iconka = '<img src="/style/i/folder_password.gif" alt="" class="icon icon_align p16">';
}else{
if($gallery['privat'] == 0){
$iconka = '<img src="/style/i/folder.gif" alt="" class="icon icon_align p16">';
}elseif($gallery['privat'] == 1){
$iconka = '<img src="/style/i/folder_user.gif" alt="" class="icon icon_align p16">';
}elseif($gallery['privat'] == 2){
$iconka = '<img src="/style/i/folder_locked.gif" alt="" class="icon icon_align p16">';
}
}

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $ank['id']?>"><?= $ank['nick']?></a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/foto/<?= $ank['id']?>/">Фото</a> </span>      </div>

<a href="?edit=rename" class="link darkblue return full_link">  <span class="ico ico_arrow-back"><span id="transmark" style="display: none; width: 0px; height: 0px;"></span></span>   Назад  </a>

<div class="wrapper">  
<div class="block bord-botm grey t_center"> 
<span class="m">Вы действительно хотите удалить альбом</span> 
<a href="?" class="arrow_link break-word">   <?= $iconka?>   «<span class="m"><?= text($gallery['name'])?></span>»</a>  
<span class="m">и все файлы из неё?</span> 
</div>  
<table class="table__wrap"> <tbody><tr> 
<td class="table__cell" width="50%"> 
<a href="?act=delete&amp;ok" class="link blue"> <img src="/style/i/ok_blue.png" alt="" class="m"> <span class="m">Да</span> </a> 
</td> 
<td class="table__cell table__cell_last" width="50%"> 
<a href="?" class="link"> <span>Отмена</span> </a> 
</td> 
</tr> </tbody></table>  
</div>

<a href="?edit=rename" class="link darkblue return full_link">  <span class="ico ico_arrow-back"><span id="transmark" style="display: none; width: 0px; height: 0px;"></span></span>   Назад  </a>
<?
include_once '../sys/inc/tfoot.php';
exit;
}


if (isset($user) && $user['id'] == $ank['id'] && isset($_GET['act']) && $_GET['act'] == 'upload')
{
?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $ank['id']?>"><?= $ank['nick']?></a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/foto/<?= $ank['id']?>/">Фото</a> </span>   <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/foto/<?= $ank['id']?>/<?= $gallery['id']?>/"><?=  text($gallery['name'])?></a> </span>  <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Добавление файла</span> </span>  </div>

<div>     
<div class="wrapper form-checkbox-native"> 
<form method="post" action="?act=upload&amp;ok" enctype="multipart/form-data"> 

<div class="block pdb"> <div> <div class="input-txt_wrapper"> 
<label class="lbl">Название:</label> 
<input class="input-txt" name="name" maxlength="50" value="" type="text">  
</div> </div> </div>

<div class="bord-botm"> 
<div class="block pdb">
    
<div><input id="photo_form" name="file" accept="image/*,image/jpeg" type="file"></div>   

<div class="pad_t_a"> 
<div id="upl_textarea_toolbar"> 
<label for="upl_textarea" class="lbl">Описание (не более 3000 знаков):</label> 
</div> 
<div class="input-txt_wrapper"> 
<textarea class="input-txt" name="opis" maxlength="3000" rows="3" cols="17" id="upl_textarea"></textarea> 
</div> 
</div>    

</div> <div>   


<div class="block transpar"> 
<label class="input-checkbox"> 
<input value="1" name="metka" class="m" type="checkbox"> 
<span class="m grey chb_lbl"><!--      --><span>Файл для взрослых <!--      --><span class=" red">(18+)</span><!--   --></span><!--   --></span> 
</label>    
</div>    

</div>  </div>  
<!-- OnceFormFields.xhtml.tmpl -->   
<div>  <input value="Загрузить" class="link blue full is_final" type="submit">  </div> 
</form> 

</div> 

<div class="block-wrapper t_center grey">  Максимальный размер файла <b>10 Мб</b>.
<br>  Перед загрузкой прочитайте <a href="/foto/rules.php"><b>правила размещения файлов</b></a>. 
</div>   

</div>

<a href="/foto/<?= $ank['id']?>/<?= $gallery['id']?>/" class="link darkblue return full_link">  <span class="ico ico_arrow-back"><span id="transmark" style="display: none; width: 0px; height: 0px;"></span></span>   Назад  </a>

<?

	include_once '../sys/inc/tfoot.php';
	exit;
}
?>