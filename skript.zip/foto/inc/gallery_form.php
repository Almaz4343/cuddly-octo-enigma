<?
if (isset($user) && $user['id'] == $ank['id'])
{
	if (isset($_GET['act']) && $_GET['act'] == 'create')
	{
?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $ank['id']?>"><?= $ank['nick']?></a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/foto/<?= $ank['id']?>/">Фото</a> </span>      </div>

<a href="/foto/<?= $ank['id']?>/" class="link darkblue return full_link">  <span class="ico ico_arrow-back"><span id="transmark" style="display: none; width: 0px; height: 0px;"></span></span>   Назад  </a>

<div class="wrapper">
<div class="block pdb t_center"> <div class="upcs b"> Новая папка </div> </div>
<form action="?act=create&amp;ok" method="post">

<div class="block pdb"> <div> <div class="input-txt_wrapper"> 
<label class="lbl">Название:</label> 
<input class="input-txt" name="name" maxlength="50" value="" type="text">  
</div> </div> </div>

<div><div>
<div class="vlight_border_bottom stnd_padd pdb vlight_border_bottom"> <label class="lbl">Могут смотреть:</label> </div>

<div> 
<label for="am_na_0_3" class="t-block_item stnd_padd vlight_border_bottom"> 
<input name="privat" id="am_na_0_3" value="0" class="m" checked="checked" type="radio"> 
<img class="m p16" src="//c.spac.me/i/ico/ac_all_darkblue.png" alt="Все"> <span class="m">&nbsp;Все</span> 
</label> 
</div>

<div> 
<label for="am_oo_0_3" class="t-block_item stnd_padd vlight_border_bottom"> 
<input name="privat" id="am_oo_0_3" value="2" class="m" type="radio"> 
<img class="m p16" src="//c.spac.me/i/ico/ac_user_red.png" alt="Только я"> <span class="m">&nbsp;Только я</span> 
</label> 
</div>

<div> 
<label for="am_fo_0_3" class="t-block_item stnd_padd vlight_border_bottom"> 
<input name="privat" id="am_fo_0_3" value="1" class="m" type="radio"> 
<img class="m p16" src="//c.spac.me/i/ico/ac_friends_green.png" alt="Мои друзья"> <span class="m">&nbsp;Мои друзья</span> 
</label> 
</div>
</div> </div>

<div><div>
<div class="vlight_border_bottom stnd_padd pdb vlight_border_bottom"> <label class="lbl">Могут комментировать:</label> </div>

<div> 
<label for="am_na_0_4" class="t-block_item stnd_padd vlight_border_bottom"> 
<input name="privat_komm" id="am_na_0_4" value="0" class="m" checked="checked" type="radio"> 
<img class="m p16" src="//c.spac.me/i/ico/ac_all_darkblue.png" alt="Все"> <span class="m">&nbsp;Все</span> 
</label> 
</div>

<div> 
<label for="am_oo_0_4" class="t-block_item stnd_padd vlight_border_bottom"> 
<input name="privat_komm" id="am_oo_0_4" value="2" class="m" type="radio"> 
<img class="m p16" src="//c.spac.me/i/ico/ac_user_red.png" alt="Только я"> <span class="m">&nbsp;Только я</span> 
</label> 
</div>

<div> 
<label for="am_fo_0_4" class="t-block_item stnd_padd vlight_border_bottom"> 
<input name="privat_komm" id="am_fo_0_4" value="1" class="m" type="radio"> 
<img class="m p16" src="//c.spac.me/i/ico/ac_friends_green.png" alt="Мои друзья"> <span class="m">&nbsp;Мои друзья</span> 
</label> 
</div>
</div> </div>

<div><div>
<div class="vlight_border_bottom stnd_padd pdb vlight_border_bottom" style="border-bottom:0;"> <label class="lbl">Пароль:</label> </div> 
<div class="t-block_item stnd_padd vlight_border_bottom"> 
 <input type="text" name="pass" value="" />
</div>


</div> </div>
<div class="block"> <input value="Сохранить" class="main_submit" type="submit"> </div>
</form>
</div>
<?

		include_once '../sys/inc/tfoot.php';
		exit;
	}
}
?>