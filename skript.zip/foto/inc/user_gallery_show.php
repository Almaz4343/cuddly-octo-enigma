<?
if (!isset($user) && !isset($_GET['id_user'])){ header("Location: /foto/?".SID);exit; }
if (isset($user))$ank['id'] = $user['id'];
if (isset($_GET['id_user']))$ank['id'] = intval($_GET['id_user']);

// Автор альбома
$ank = get_user($ank['id']);

if (!$ank){header('Location: /foto/?' . SID);exit;}

// Если вы в бане 
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `ban` WHERE `razdel` = 'foto' AND `id_user` = '$user[id]' AND (`time` > '$time' OR `view` = '0' OR `navsegda` = '1')"), 0)!=0)
{
	header('Location: /ban.php?'.SID);
	exit;
}

// Альбом
$gallery['id'] = intval($_GET['id_gallery']);

if (mysql_result(mysql_query("SELECT COUNT(*) FROM `gallery` WHERE `id` = '$gallery[id]' AND `id_user` = '$ank[id]' LIMIT 1"),0) == 0)
{
	header('Location: /foto/' . $ank['id'] . '/?' . SID);
	exit;
}

$gallery = mysql_fetch_assoc(mysql_query("SELECT * FROM `gallery` WHERE `id` = '$gallery[id]' AND `id_user` = '$ank[id]' LIMIT 1"));

// заголовок страницы
$set['title'] = $ank['nick'] . ' : Фото : ' . text($gallery['name']); 

// Редактирование альбома и загрузка фото
include 'inc/gallery_show_act.php';

include_once '../sys/inc/thead.php';
title();
err();




// Формы
include 'inc/gallery_show_form.php';


// Настройки юзера
$uSet = mysql_fetch_array(mysql_query("SELECT * FROM `user_set` WHERE `id_user` = '$ank[id]'  LIMIT 1"));

// Статус друг ли вы
$frend = mysql_result(mysql_query("SELECT COUNT(*) FROM `frends` WHERE 
 (`user` = '$user[id]' AND `frend` = '$ank[id]') OR 
 (`user` = '$ank[id]' AND `frend` = '$user[id]') LIMIT 1"),0);

// Проверка завки в друзья
$frend_new = mysql_result(mysql_query("SELECT COUNT(*) FROM `frends_new` WHERE 
 (`user` = '$user[id]' AND `to` = '$ank[id]') OR 
 (`user` = '$ank[id]' AND `to` = '$user[id]') LIMIT 1"),0);


/*
* Если установлена приватность альбома
*/	
if ($gallery['privat'] == 1 && ($frend != 2 || !isset($user)) && $user['level'] <= $ank['level'] && $user['id'] != $ank['id'])
{
?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="//c.spac.me/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Ошибка</span> </span>       </div>
<div class="list_item error_block mb0"> <b>Ошибка</b><br> Доступ к альбому <b><?= text($gallery['name'])?></b> доступен только друзьям. </div>
<?

	$block_foto = true;
include_once '../sys/inc/tfoot.php';
exit;
}
elseif ($gallery['privat'] == 2 && $user['id'] != $ank['id'] && $user['level'] <= $ank['level'])
{
?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="//c.spac.me/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Ошибка</span> </span>       </div>
<div class="list_item error_block mb0"> <b>Ошибка</b><br> Доступ к альбому <b><?= text($gallery['name'])?></b> закрыт. </div>
<?
	
	$block_foto = true;
include_once '../sys/inc/tfoot.php';
exit;	
}

/*--------------------Альбом под паролем-------------------*/
if ($user['id'] != $ank['id'] && $gallery['pass'] != NULL)
{
	if (isset($_POST['password']))
	{
		$_SESSION['pass'] = my_esc($_POST['password']);
		
		if ($_SESSION['pass'] != $gallery['pass'])
		{
			$_SESSION['message'] = 'Неверный пароль'; 
			$_SESSION['pass'] = NULL;
		}
		header("Location: ?");
	}

if (!isset($_SESSION['pass']) || $_SESSION['pass'] != $gallery['pass'])
{
?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="//c.spac.me/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Ошибка</span> </span>       </div>

<div class="list_item error_block mb0"> 
<b>Ошибка</b><br> 
<form action="?" method="post">   
<div class="stnd_padd"> Альбом <b><?= text($gallery['name'])?></b> доступен только по паролю:<br>  Пароль: 
<input name="password" value="" type="text"> 
</div>           
<input value="OK" class="main_submit" id="mainSubmitForm" type="submit">     
</form> 
</div>

<?	

include_once '../sys/inc/tfoot.php';
exit;
}
}


?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $ank['id']?>"><?= $ank['nick']?></a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/foto/<?= $ank['id']?>/">Фото</a> </span>       </div>
<a href="/foto/<?= $ank['id']?>/" class="link darkblue return full_link">  
<span class="ico ico_arrow-back"></span>   Назад  
</a>
<?

if($gallery['pass'] != null){
$iconka = '<img src="/style/i/folder_password.gif" alt="" class="icon icon_align p16">';
}else{
if($gallery['privat'] == 0){
$iconka = '<img src="/style/i/folder.gif" alt="" class="icon icon_align p16">';
}elseif($gallery['privat'] == 1){
$iconka = '<img src="/style/i/folder_user.gif" alt="" class="icon icon_align p16">';
}elseif($gallery['privat'] == 2){
$iconka = '<img src="/style/i/folder_locked.gif" alt="" class="icon icon_align p16">';
}
}



?>
<div class="list_item">
<b>  <?= $iconka?>  «<span><?= text($gallery['name'])?></span>» </b>
</div>
<?

if (isset($user) && $user['id'] == $ank['id']){
?>
<div class="wrapper">     
<a href="?act=upload" class="link  blue   " style="text-align: center;"> 
<span>
<!--     --><img src="/style/i/ico/upload_blue.png" alt="" class="m"> <!--   -->
<span class="m"> Добавить файл</span>
<!--   -->
</span>  
</a>    
</div>
<?
}


/*---------------------------------------------------------*/

if (!isset($block_foto))
{
	$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `gallery_foto` WHERE `id_gallery` = '$gallery[id]'"),0);
	$k_page = k_page($k_post,$set['p_str']);
	$page = page($k_page);
	$start = $set['p_str']*$page-$set['p_str'];


if ($k_post == 0)
{
?>
<div class="wrapper link">В альбоме нет фото.</div>
<?
}
else{

?>
<link rel="stylesheet" href="/foto/css/Tw1nGo_Photo_Style.css" type="text/css" />
<div class="busi_switcher">  </div>

<div id="sz_gallery_loader" data-type="user" class="js-gallery_skip stnd_padd light_border_bottom oh font0 bg-white">
<?

$q = mysql_query("SELECT * FROM `gallery_foto` WHERE `id_gallery` = '$gallery[id]' ORDER BY `id` DESC LIMIT $start, $set[p_str]");
	
while ($post = mysql_fetch_assoc($q))
{

$comm = mysql_result(mysql_query("SELECT COUNT(*) FROM `gallery_komm` WHERE `id_foto` = '$post[id]'"),0);

?>
<div class="js-file_item  tiled_item tiled_item-200"> 
<div class="tiled_inner t_center relative">   
<span class="relative" style="display: inline-block;max-width: 100%; width: 100%;">
<div class="tiled-preview">    
<a href="/foto/<?= $ank['id']?>/<?= $gallery['id']?>/<?= $post['id']?>/">   
<img src="/foto/pic400/<?= $post['id']?>.p.401.400.0.<?= $post['ras']?>" alt="" class="preview s201_200">  
<?
if($post['metka'] != 0){
?>
<img class="p16 f_18p" src="/foto/css/ico/adult.png" alt="">     
<?
}
?>  
</a>       
</div> </span>   
<div class="tile_descr">        <div class="pl_photo_image_info oh">  
<span class="tf" style="color:gray;">

<?
if($post['count'] > 0){
?>
<span class="inl_bl"> <img class="m p16" src="/style/i/views_num_gray.png" alt=""> <span class="m"><?= $post['count']?></span> </span>
<?
}
if($comm > 0){
?>   
<span class="inl_bl"> <img class="m p16" src="/style/i/comm_num_gray.png" alt=""> <span class="m"><?= $comm?></span> </span> 
<?
}
?>  
</span>     
</div>   </div>  
</div> 
</div>
<?
}
?>
</div>
<?
}
if (isset($user) && (user_access('foto_alb_del') || $user['id'] == $ank['id'])){
?>
<div class="bottom_link_block lh_160">    
<a class="arrow_link" href="?edit=rename"> 
<img src="/style/i/edit.gif" alt="" class="icon p16"> <span>Редактировать папку</span> 
</a>  <br>        
</div>
<?
}
?>
<a href="/foto/<?= $ank['id']?>/" class="link darkblue return full_link">  
<span class="ico ico_arrow-back"></span>   Назад  
</a>
<?
	
	// Вывод страниц
	if ($k_page > 1)str('?', $k_page, $page); 
}


include_once '../sys/inc/tfoot.php';
exit;
?>