<?
if (!isset($user) && !isset($_GET['id_user'])){ header("Location: /foto/?".SID);exit; }
if (isset($user))$ank['id'] = $user['id'];
if (isset($_GET['id_user']))$ank['id'] = intval($_GET['id_user']);

// Автор альбома
$ank = get_user($ank['id']);

if (!$ank){header("Location: /foto/?".SID);exit;}

// Если вы в бане 
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `ban` WHERE `razdel` = 'foto' AND `id_user` = '$user[id]' AND (`time` > '$time' OR `view` = '0' OR `navsegda` = '1')"), 0)!=0)
{
	header('Location: /ban.php?'.SID);
	exit;
}

// заголовок страницы
$set['title'] = 'Фото : ' . $ank['nick']; 

// Это при создании нового альбома
include 'inc/gallery_act.php';

include_once '../sys/inc/thead.php';
title();
err();

// Создание альбомов
include 'inc/gallery_form.php'; 

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $ank['id']?>"><?= $ank['nick']?></a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/foto/<?= $ank['id']?>/">Фото</a> </span>       </div>
<?


if (isset($user) && $ank['id'] == $user['id']){
?>
<div class="wrapper">     
<a href="/foto/<?= $ank['id']?>/?act=create" class="link  blue   " style="text-align: center;"> 
<span>
<!--     --><img src="/style/i/ico/plus.png" alt="" class="m"> <!--   -->
<span class="m">Создать папку</span>
<!--   -->
</span>  
</a>    
</div>
<?
}

$set['p_str'] = '15';
$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `gallery` WHERE `id_user` = '$ank[id]'"),0);
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str']*$page-$set['p_str'];



if ($k_post == 0)
{
	echo '<div class="wrapper link">';
	echo 'Альбомов пока нет';
	echo '</div>';
}else{

?>
<div class="list_item lh_160">
<?

$q = mysql_query("SELECT * FROM `gallery` WHERE `id_user` = '$ank[id]' ORDER BY `time` DESC LIMIT $start, $set[p_str]");

while ($post = mysql_fetch_assoc($q))
{

// Cчетчик фотографий
$count = mysql_result(mysql_query("SELECT COUNT(*) FROM `gallery_foto` WHERE `id_gallery` = '$post[id]'"),0);

if($post['pass'] != null){
$iconka = '<img src="/style/i/folder_password.gif" alt="" class="icon icon_align p16">';
}else{
if($post['privat'] == 0){
$iconka = '<img src="/style/i/folder.gif" alt="" class="icon icon_align p16">';
}elseif($post['privat'] == 1){
$iconka = '<img src="/style/i/folder_user.gif" alt="" class="icon icon_align p16">';
}elseif($post['privat'] == 2){
$iconka = '<img src="/style/i/folder_locked.gif" alt="" class="icon icon_align p16">';
}
}

?>
<div>    
<a href="/foto/<?= $ank['id']?>/<?= $post['id']?>/" class="arrow_link break-word">    
<?= $iconka?> <span class="m"><?= text($post['name'])?></span> <small class="black m">(<?= $count?>)</small> 
</a>   
</div>
<?
}

?>
</div>
<?

// Вывод страниц
if ($k_page > 1)str('?', $k_page, $page); 
}
?>
<a href="/user/?id=<?= $ank['id']?>" class="link darkblue return full_link">  
<span class="ico ico_arrow-back"></span>   Назад  
</a>
<?

include_once '../sys/inc/tfoot.php';
exit;
?>