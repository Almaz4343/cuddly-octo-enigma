<?
if (isset($_GET['act']) && $_GET['act'] == 'rename')
{
?>
<div class="stnd_padd" style="padding-bottom:1px;"><b>Редактиров<span id="transmark" style="display: none; width: 0px; height: 0px;"></span>ать</b></div>

<form class="foot" action="?act=rename&amp;ok" method="post">

<div class="list_item light_border_bottom">  

<div class="image_limit"> 
<span class="pr">   
<div class="inl_bl relative"> 
<img src="/foto/pic200/<?= $foto['id']?>.p.201.200.0.<?= $foto['ras']?>" alt="" class="preview">   
</div>     
</span>
</div>
  
</div>

<div class="stnd_padd pdb js-toolbar_wrap"> 

<div style="padding-bottom:10px;"> 
<label for="new_filename" class="lbl"> Имя файла: </label> 
<input name="name" id="new_filename" maxlength="46" value="<?= text($foto['name'])?>" style="width:85%;margin-top:1px;" type="text">.jpg<br>  
</div> 

<div> 
<div class="oh" style="width:85%"> <div class="js-toolbar"> 
<label for="textarea" class="lbl left"> Описание (не более 3000 знаков): </label> 
</div> </div> 
<textarea id="textarea" name="opis" rows="6" cols="17" style="width:85%;margin-top:1px;"><?= text($foto['opis'])?></textarea><br>  
</div>  </div>

<div> <div>   <div class="block transpar"> 
<label class="input-checkbox"> 
<input value="1" name="metka" <?= ($foto['metka'] == 1 ? "checked='checked'" : null)?> class="m" type="checkbox"> 
<span class="m grey chb_lbl"><!--      --><span>Файл для взрослых <!--      --><span class=" red">(18+)</span><!--   --></span><!--   --></span> 
</label>    
</div>    </div>  </div>

<div class="list_item"> 
<input value="Сохранить" class="main_submit" id="mainSubmitForm" type="submit"> 
</div>

</form>

<div class="list_item"> 
<a href="?act=delete" class="arrow_link"> 
<img class="middle" src="/style/i/cross_r.gif" alt=""> <span class="middle">Удалить фото</span> 
</a> 
</div>

<a href="?" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?
include_once '../sys/inc/tfoot.php';
exit;
}

if (isset($_GET['act']) && $_GET['act'] == 'delete')
{
?>
<div class="list_item gradient_block1"> Вы уверены, что хотите удалить файл 
<b><?= text($foto['name'])?>.jpg</b>?<br> 
<a href="?act=delete&amp;ok"><span style="color:#990000">Да</span></a>&nbsp;&nbsp;&nbsp; 
<a href="?"><span style="color:green">Нет</span></a> 
</div>
<a href="?" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?
include_once '../sys/inc/tfoot.php';
exit;
}

