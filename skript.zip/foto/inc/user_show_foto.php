<?
if (!isset($user) && !isset($_GET['id_user'])){
	header("Location: /foto/?".SID);
	exit;
}
if (isset($user)){
	$ank['id'] = $user['id'];
}

if (isset($_GET['id_user'])){
	$ank['id'] = intval($_GET['id_user']);
}

$ank = get_user($ank['id']);

if (!$ank){
	header("Location: /foto/?".SID);
	exit;
}

/* Бан пользователя */ 
if (mysql_result(query("SELECT COUNT(*) FROM `ban` WHERE `razdel` = 'foto' AND `id_user` = '$user[id]' AND (`time` > '$time' OR `view` = '0' OR `navsegda` = '1')"), 0) != 0)
{
	header('Location: /ban.php?'.SID);
	exit;
}

$gallery['id'] = intval($_GET['id_gallery']);

if (mysql_result(query("SELECT COUNT(*) FROM `gallery` WHERE `id` = '$gallery[id]' AND `id_user` = '$ank[id]' LIMIT 1"),0)==0)
{
	header("Location: /foto/$ank[id]/?".SID);
	exit;
}

$gallery = mysql_fetch_assoc(query("SELECT * FROM `gallery` WHERE `id` = '$gallery[id]' AND `id_user` = '$ank[id]' LIMIT 1")); 

$foto['id'] = intval($_GET['id_foto']);

if (mysql_result(query("SELECT COUNT(*) FROM `gallery_foto` WHERE `id` = '$foto[id]' LIMIT 1"),0)==0)
{
	header("Location: /foto/$ank[id]/$gallery[id]/?".SID);
	exit;
}

$foto = mysql_fetch_assoc(query("SELECT * FROM `gallery_foto` WHERE `id` = '$foto[id]'  LIMIT 1"));

// Запись просмотра
if (isset($user) && $user['id'] != $ank['id']){
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `gallery_foto_count` WHERE `id_foto` = '".$foto['id']."' AND `id_user` = '".$user['id']."' LIMIT 1"),0)==0){
mysql_query("INSERT INTO `gallery_foto_count` (`id_foto`, `id_user`) VALUES ('$foto[id]', '$user[id]')");
mysql_query("UPDATE `gallery_foto` SET `count` = '".($foto['count']+1)."' WHERE `id` = '$foto[id]' LIMIT 1");
}
}



if (isset($user)){



// Лайк
if (isset($_GET['like']) && $_GET['like'] == 'up'){
// Запрещаем нам!
if ($user['id'] != $ank['id']){
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `gallery_like` WHERE `id_user` = '".$user['id']."' AND `id_photo` = '".$foto['id']."' LIMIT 1"),0) == 0)
{
mysql_query("INSERT INTO `gallery_like` (`id_photo`, `id_user`, `like`) VALUES ('$foto[id]', '$user[id]', '1')");
if (mysql_result(mysql_query("SELECT COUNT(`id`) FROM `bookmarks_like` WHERE `id_user` = '" . $user['id'] . "' AND `id_object` = '" . $foto['id'] . "' AND `type` = 'photo' LIMIT 1"),0) == 0)
{
mysql_query("INSERT INTO `bookmarks_like` (`type`,`id_object`, `id_user`, `time`) VALUES ('photo','$foto[id]', '$user[id]', '$time')");
}
}
else{
$_SESSION['err'] = 'Вы уже голосовали за фото.';
}
}
else{
$_SESSION['err'] = 'Вы не можете голосовать за себя.';
}
header("Location: ?");
exit;
}


// Добавляем в закладки
if (isset($_GET['fav']) && $_GET['fav'] == 1)
{ 
	if (mysql_result(mysql_query("SELECT COUNT(`id`) FROM `bookmarks` WHERE `id_user` = '" . $user['id'] . "' AND `id_object` = '" . $foto['id'] . "' AND `type` = 'foto' LIMIT 1"),0) == 0)
	{
		mysql_query("INSERT INTO `bookmarks` (`type`,`id_object`, `id_user`, `time`) VALUES ('foto','$foto[id]', '$user[id]', '$time')");
		$_SESSION['message'] = 'Закладка добавлена. '; 
		header("Location: /foto/$ank[id]/$gallery[id]/$foto[id]/?P=" . intval($_GET['page']));
		exit;
	}
}

// Удаляем из закладок
if (isset($_GET['fav']) && $_GET['fav'] == 0)
{ 
	if (mysql_result(mysql_query("SELECT COUNT(`id`) FROM `bookmarks` WHERE `id_user` = '" . $user['id'] . "' AND `id_object` = '".$foto['id']."' AND `type`='foto' LIMIT 1"),0) == 1)
	{
		mysql_query("DELETE FROM `bookmarks` WHERE `id_user` = '$ank[id]' AND  `id_object` = '$foto[id]' AND `type`='foto'");
		$_SESSION['message'] = 'Закладка удалена. '; 
		header("Location: /foto/$ank[id]/$gallery[id]/$foto[id]/?P=" . intval($_GET['page']));
		exit;
	}
}


}

$IS = GetImageSize(H.'sys/tpic/pictures/'.$foto['id'].'.0.'.$foto['ras']);
printf("", $IS[0], $IS[1]);
$w = $IS[0];
$h = $IS[1];

if ((user_access('foto_foto_edit')) || (isset($user) && $ank['id'] == $user['id'])){
	include 'inc/gallery_show_foto_act.php';
}


/*
==========================
Комментарий
==========================
*/

if (isset($_POST['msg']) && isset($user))
{
	$msg = $_POST['msg'];

	if ($mat)$err[] = 'В тексте сообщения обнаружен мат: '.$mat;
	if (strlen2($msg) > 1024 ){$err = 'Сообщение слишком длинное';}
	elseif (strlen2($msg) < 2 ){$err = 'Короткое сообщение';}
	elseif (mysql_result(query("SELECT COUNT(*) FROM `gallery_komm` WHERE `id_foto` = '$foto[id]' AND `id_user` = '$user[id]' AND `msg` = '".mysql_real_escape_string($msg)."' LIMIT 1"),0)!=0)
	{
		$err = 'Ваше сообщение повторяет предыдущее';
	}
	elseif(!isset($err))
	{		
		

//Уведомления об ответах
		
// jjjjjjj


// Отправляем автору

// jjjjjjj	
		
	query("INSERT INTO `gallery_komm` (`id_foto`, `id_user`, `time`, `msg`) values('$foto[id]', '$user[id]', '$time', '".my_esc($msg)."')");

	//$_SESSION['message'] = 'Сообщение успешно добавлено';
	header("Location: ?P=".intval($_GET['page']));
	exit;
	}
}


if ((user_access('foto_komm_del') || $ank['id'] == $user['id']) && isset($_GET['delete']) && mysql_result(query("SELECT COUNT(*) FROM `gallery_komm` WHERE `id`='".intval($_GET['delete'])."' AND `id_foto`='$foto[id]' LIMIT 1"),0)!=0)
{
	query("DELETE FROM `gallery_komm` WHERE `id`='".intval($_GET['delete'])."' LIMIT 1");
	$_SESSION['message'] = 'Комментарий успешно удален';
	header("Location: ?P=".intval($_GET['page']));
	exit;
}

$set['title'] = text($foto['name']) . '.' . $foto['ras'] . ' / ' . text($gallery['name']); // заголовок страницы
include_once '../sys/inc/thead.php';
title();



err();






// Настройки юзера
$uSet = mysql_fetch_array(mysql_query("SELECT * FROM `user_set` WHERE `id_user` = '$ank[id]'  LIMIT 1"));

// Статус друг ли вы
$frend = mysql_result(mysql_query("SELECT COUNT(*) FROM `frends` WHERE 
 (`user` = '$user[id]' AND `frend` = '$ank[id]') OR 
 (`user` = '$ank[id]' AND `frend` = '$user[id]') LIMIT 1"),0);

// Проверка завки в друзья
$frend_new = mysql_result(mysql_query("SELECT COUNT(*) FROM `frends_new` WHERE 
 (`user` = '$user[id]' AND `to` = '$ank[id]') OR 
 (`user` = '$ank[id]' AND `to` = '$user[id]') LIMIT 1"),0);

/*
* Если установлена приватность альбома
*/	
if ($gallery['privat'] == 1 && ($frend != 2 || !isset($user)) && $user['level'] <= $ank['level'] && $user['id'] != $ank['id'])
{
?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Ошибка</span> </span>       </div>
<div class="list_item error_block mb0"> <b>Ошибка</b><br> Доступ к альбому <b><?= text($gallery['name'])?></b> доступен только друзьям. </div>
<?

	$block_foto = true;
include_once '../sys/inc/tfoot.php';
exit;
}
elseif ($gallery['privat'] == 2 && $user['id'] != $ank['id'] && $user['level'] <= $ank['level'])
{
?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Ошибка</span> </span>       </div>
<div class="list_item error_block mb0"> <b>Ошибка</b><br> Доступ к альбому <b><?= text($gallery['name'])?></b> закрыт. </div>
<?
	
	$block_foto = true;
include_once '../sys/inc/tfoot.php';
exit;	
}

/*--------------------Альбом под паролем-------------------*/
if ($user['id'] != $ank['id'] && $gallery['pass'] != NULL)
{
	if (isset($_POST['password']))
	{
		$_SESSION['pass'] = my_esc($_POST['password']);
		
		if ($_SESSION['pass'] != $gallery['pass'])
		{
			$_SESSION['message'] = 'Неверный пароль'; 
			$_SESSION['pass'] = NULL;
		}
		header("Location: ?");
	}

if (!isset($_SESSION['pass']) || $_SESSION['pass'] != $gallery['pass'])
{
?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Ошибка</span> </span>       </div>

<div class="list_item error_block mb0"> 
<b>Ошибка</b><br> 
<form action="?" method="post">   
<div class="stnd_padd"> Альбом <b><?= text($gallery['name'])?></b> доступен только по паролю:<br>  Пароль: 
<input name="password" value="" type="text"> 
</div>           
<input value="OK" class="main_submit" id="mainSubmitForm" type="submit">     
</form> 
</div>

<?	

include_once '../sys/inc/tfoot.php';
exit;
}
}







if (!isset($block_foto))
{

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $ank['id']?>"><?= $ank['nick']?></a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/foto/<?= $ank['id']?>/">Фото</a> </span>   <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/foto/<?= $ank['id']?>/<?= $gallery['id']?>/"><?=  text($gallery['name'])?></a> </span>    </div>
<?

// Редактор фото
include 'inc/gallery_show_foto_form.php';



?>
<div class="list_item light_border_bottom"> 
<div class="file_name">  
<img src="/style/i/icon_img_jpg.gif" alt="" class="m p16">  
<span>  <b><?= text($foto['name'])?></b>.<span class="grey">jpg</span>  
<?
if ($foto['metka'] == 1){
?>
<img src="/style/i/adult_ico.png" alt="" class="m p16"> 
<?
}
?>
</span> 
</div>  

<div class="preview_block">  
<div class="pad_t_a">      
<a class="tdn" href="/foto/pic400/<?= $foto['id']?>.p.401.400.0.<?= $foto['ras']?>">   
<div class="inl_bl relative"> 
<img src="/foto/pic400/<?= $foto['id']?>.p.401.400.0.<?= $foto['ras']?>" alt="" class="preview">
<span id="transmark" style="display: none; width: 0px; height: 0px;"></span>   
</div>      
</a>        
</div>     <div class="pad_t_a">  </div>  </div>  
<?
if ($foto['opis'] != null){
?>
<div> <?= output_text($foto['opis'])?>  </div>     
<?
}
?>
</div>
<?


//if($ank['id'] == $user['id']){
$listr = mysql_fetch_assoc(query("SELECT * FROM `gallery_foto` WHERE `id_gallery` = '$gallery[id]' AND `id` < '$foto[id]' ORDER BY `id` DESC LIMIT 1"));
$list = mysql_fetch_assoc(query("SELECT * FROM `gallery_foto` WHERE `id_gallery` = '$gallery[id]' AND `id` > '$foto[id]' ORDER BY `id`  ASC LIMIT 1"));
$k_1 = mysql_result(query("SELECT COUNT(*) FROM `gallery_foto` WHERE `id` > '$foto[id]' AND `id_gallery` = '$gallery[id]'"),0) + 1;
$k_2 = mysql_result(query("SELECT COUNT(*) FROM `gallery_foto` WHERE `id_gallery` = '$gallery[id]'"),0);

?>
<div class="pag"> <div class="pgar oh font0"> 
<table class="table__wrap"> <tbody><tr> 

<td class="table__cell" width="35%"> 
<div class="pagw">  
<?
if($list['id']){
?>
<a href="/foto/<?= $ank['id']?>/<?= $gallery['id']?>/<?= $list['id']?>/"> ← Назад </a>
<?
}else{
?>
<a class="m grey">← Назад</a>
<?
}
?>
</div> 
</td> 

<td class="table__cell"> 
<div class="pagw pagwb"> <span class="blk"><?= $k_1?> из <?= $k_2?></span> </div> 
</td> 

<td class="table__cell" width="35%"> 
<div class="pagw">  
<?
if($listr['id']){
?>
<a href="/foto/<?= $ank['id']?>/<?= $gallery['id']?>/<?= $listr['id']?>/"> Вперёд → </a>
<?
}else{
?>
<a class="m grey">Вперёд →</a>
<?
}
?> 
</div> 
</td> 
</tr> </tbody></table> 
</div> </div>
<?
//}

if (($user['abuld'] == 1 || $foto['metka'] == 0 || $foto['id_user'] == $user['id']))
{

if($gallery['pass'] != null){
$iconka = '<img src="/style/i/folder_password.gif" alt="" class="icon icon_align p16">';
}else{
if($gallery['privat'] == 0){
$iconka = '<img src="/style/i/folder.gif" alt="" class="icon icon_align p16">';
}elseif($gallery['privat'] == 1){
$iconka = '<img src="/style/i/folder_user.gif" alt="" class="icon icon_align p16">';
}elseif($gallery['privat'] == 2){
$iconka = '<img src="/style/i/folder_locked.gif" alt="" class="icon icon_align p16">';
}
}
$like = mysql_result(mysql_query("SELECT COUNT(*) FROM `gallery_like` WHERE `like` = '1' AND `id_photo` = '".$foto['id']."' LIMIT 1"),0);
$us_like = mysql_result(mysql_query("SELECT COUNT(*) FROM `gallery_like` WHERE `like` = '1' AND `id_user` = '".$user['id']."' AND `id_photo` = '".$foto['id']."' LIMIT 1"),0);

?>
<div id="download_wrap">  <div class="list_item green_box"> 
<div class="lh_160">  <div>  
<a href="/sys/tpic/pictures/<?= $foto['id']?>.0.jpg" class="arrow_link m" id="download_link"> 
<img src="/style/i/dload.gif" alt="" class="m" width="12px" height="14px"> <span class="m">Скачать</span> 
</a>   
<span class="file_parameters m">(<!-- --><?= $w?>×<?= $h?>, <!-- --><?= size_file(filesize(H.'sys/tpic/pictures/'.$foto['id'].'.0.jpg'))?><!-- -->)</span>   
</div>    </div> 
</div>   </div>
<div class="list_item light_border_bottom ufi lh_160">

<div class="block_item">  <b>Просмотров:</b>  <?= $foto['count']?> </div>

<div class="block_item"> <span>Файл добавлен:</span>  <?= group($ank['id'])?> 
<a href="/user/?id=<?= $ank['id']?>" class="mysite-link"><b class="nick"><?= $ank['nick']?></b></a>   (<?= vremja($foto['time'])?>) 
</div>

<div class="block_item"> 
<span class="m">В альбом:</span> 
<span><a href="/foto/<?= $ank['id']?>/<?= $gallery['id']?>/" class="arrow_link break-word">   <?= $iconka?>  «<span class="m"><?= text($gallery['name'])?></span>»</a> </span> 
</div>
</div>

<div class="list_item light_border_bottom cf">
<div class="oh signature">     
<span class="right">  
<img class="m p16" src="/style/i/vote/up.png" alt="">  <span class="m lit voteUpInfo" id="vote_up_cnt"><?= $like?></span>     
</span> 
</div>
<?
if (isset($user))
{
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `gallery_like` WHERE `id_user` = '".$user['id']."' AND `id_photo` = '".$foto['id']."' LIMIT 1"),0) == 0){
$ico_vote_up = 'up.png';
}
else{
if($us_like){
$ico_vote_up = 'up_on.png';
}
}
?>
<div class=" lh_160"><div class="cf js-action_bar">

<div class="pad_t_a">   
<div class="oh pad_t_a">  
<a href="?like=up" class="arrow_link m btnb" id="like_up"> 
<img src="/style/i/vote/<?= $ico_vote_up?>" alt="" class="m p16"> 
</a> 
<span class="m green" id="like_cnt"><?= $like?></span>      
</div>     
</div>




<?
if (user_access('foto_foto_edit') && $ank['level'] < $user['level'] || isset($user) && $ank['id'] == $user['id']){
?>
<a href="?act=rename" class="arrow_link"> <img src="/style/i/edit_gray.png" alt="" class="p16 m"> <span class="m">Редактировать</span> </a>
<?
}
if (mysql_result(query("SELECT COUNT(*) FROM `bookmarks` WHERE `id_user` = '" . $user['id'] . "' AND `id_object` = '" . $foto['id'] . "' AND `type`='foto' LIMIT 1"),0) == 0){
?>
<br>
<a href="?fav=1" class="arrow_link"> 
<img src="/style/i/action_fav_gray.png" alt="" class="p16 m"> <span class="m">В закладки</span> 
</a>
<?
}else{
?>
<br>
<a href="?fav=0" class="arrow_link"> <img src="/style/i/action_fav_color.png" alt="" class="p16 m"> <span class="m">Удалить из закладок</span> </a>
<?
}
?>
</div></div>
<?
}
?>
</div>
<?
}


?>
<link rel="stylesheet" type="text/css" href="http://spac.me/css/custom/CommentWidget/CommentsWap.css?r=1445p" data-tmp_css="1" /> 
<a name="page-up"></a>
<?

	$k_post = mysql_result(query("SELECT COUNT(*) FROM `gallery_komm` WHERE `id_foto` = '$foto[id]'"),0);
	$k_page = k_page($k_post,$set['p_str']);
	$page = page($k_page);
	$start = $set['p_str']*$page-$set['p_str'];

?>
<div class="header oh text_left"> <b class="upcs m">Комментарии (<?= $k_post?>)</b>   </div>
<?

if ($k_post > 0)
{
		

}


$q = query("SELECT * FROM `gallery_komm` WHERE `id_foto` = '$foto[id]' ORDER BY `id` DESC LIMIT $start, $set[p_str]");

while ($post = mysql_fetch_assoc($q))
{
$ank2 = mysql_fetch_assoc(query("SELECT * FROM `user` WHERE `id` = '$post[id_user]' LIMIT 1"));
$postBan = mysql_result(query("SELECT COUNT(*) FROM `ban` WHERE (`razdel` = 'all' OR `razdel` = 'foto') AND `post` = '1' AND `id_user` = '$ank2[id]' AND (`time` > '$time' OR `navsegda` = '1')"), 0);

?>
<div id="<?= $ank2['id']?>" data-link="#page-up">
<?
// Блок сообщения
if ($postBan == 0) 
{
?> 
<div class="comm oh"> 
<?
}else{
?> 
<div class="comm oh comm_hidden">
<?
}
?>
<a name="com<?= $post['id']?>"></a>  

<div class="p40 left t-padd_right">      
<a class="tdn" href="/user/?id=<?= $ank2['id']?>">   
<div class="inl_bl relative"> <?= ava40($ank2['id'])?>   </div>      
</a>        
</div> 

<div class="oh">  
<div> 
 <span> 
<?= group($ank2['id'])?> <a href="/user/?id=<?= $ank2['id']?>" class="mysite-link"><b class="nick black"><?= unick($ank2['id'])?></b></a>    
</span> 
<div class="right">  
<a class="grey js-link_copy"> <span class="m">  <?= vremja($post['time'])?>  </span> </a>  
</div> 
</div>   
</div>  

<div class="comm_spoiler cl hide" id="m189852925"></div>   
<div class="cl">     
<div> 
<?
// Блок сообщения
if ($postBan == 0) 
{
?>
<?= output_text($post['msg'])?>
<?
}else{
?> 
<div class="cl">    <div>Комментарий скрыт</div>  </div>
<?
}
?>
</div>      
<div id="vote_err_44_189852925" class="hide comm-warn nl"></div>   
</div>  
<?
if (isset($user)){
?>
<div class="oh pad_t_a">  
<?
if($user['id'] != $ank2['id']){
?>
<a href="?response=<?= $ank2['id']?>&amp;P=<?= $page?>" class="link-grey js-comm_reply">Ответить</a>  
<?
if($user['id'] == $ank2['id']){
echo ' | ';
}
}
if (user_access('foto_komm_del') || $ank['id'] == $user['id']) {
?>
<span class="slb"><a href="?delete=<?= $post['id']?>">Удалить</a>  </span>
<?
}
?>
</div>
<?
}
?>
</div>   </div>
<?
		
}

?>
<a name="page-down"></a>
<?

if ($k_page > 1)str('?',$k_page,$page); // Вывод страниц



if (isset($user))
{
?>
<div class="comm_form">   
<div>  
<div id="comments_form_wrap">
<div id="comments_form">  
<form action="?P=<?=  $pageEnd?>&amp;<?= REPLY?>" method="post" name="message">  
<div class="wrapper block pd0">  
<?
if($insert != null){
?>
<div id="comments_form_reply" class="stnd_padd pdb"> 
<span class="grey">Ответить на комментарий</span> 
<span id="comments_form_user">
<a href="?" class="mysite-link">
<b class="nick black"><?= $insert?></b> </a> </span>: </div>
<? 
}
?>  
<div class="block  js-toolbar_wrap">  <div class="text-input__wrap"> 
<div class="cl" style="margin-bottom: 5px;"> <div class="relative">  
<div class="input-txt_wrapper"> 
<textarea class="input-txt" tabindex="1" name="msg" rows="4" id="textarea" data-maxlength="1000" data-toolbar="{hide:true,disable:{}}" cols="17" placeholder="Напишите комментарий"></textarea> 
</div> 
</div> </div>    
</div> </div>    

<div class="block wide pdt">   
<div class="cf pad_t_a"> 
<span class="form-tools__left left">  <!-- --><!-- --><!-- --><!-- --><!-- -->
<button name="smiles_btn" value="" class="  url-btn     " id="smiles_btn"><!--   -->
<img src="/style/i/ico/smile.png" alt="" class="m"> <!--   --><span class="m"> </span><!-- -->
</button><!-- --><!-- -->  </span>   
<span class="form-tools__left left"><span class="js-bb_toggle"> <!-- --><!-- --><!-- --><!-- --><!-- -->
<button name="response_btn" value="" class="  url-btn     " id="response_btn"><!--   -->
<img src="/style/i/a.png" alt="" class="m"> <!--   --><span class="m"> </span><!-- -->
</button><!-- --><!-- --> </span> 
</span>   
<input value="Отправить" class="main_submit right" type="submit">  
</div> </div> </div>   
</form> </div></div>  </div>   </div>
<?


}

}




include_once '../sys/inc/tfoot.php';
exit;
?>