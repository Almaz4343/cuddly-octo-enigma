<?
if (isset($user) && $user['id'] == $ank['id'])
{
	if (isset($_GET['act']) && $_GET['act']=='create' && isset($_GET['ok']) && isset($_POST['name']))
	{
		$name = my_esc($_POST['name']);
		if (strlen2($name) < 2)$err = 'Короткое название альбома.';
		if (strlen2($name) > 32)$err = 'Название превышает лимит в 32 символа.';
		$pass = $_POST['pass'];
		$pass = my_esc($pass);
		
		$privat = intval($_POST['privat']);
		$privat_komm = intval($_POST['privat_komm']);

		
		if (mysql_result(mysql_query("SELECT COUNT(*) FROM `gallery` WHERE `id_user` = '$ank[id]' AND `name` = '$name'"),0) != 0)
		$err = 'Альбом с таким названием уже существует';	
		
		if (!isset($err))
		{
			mysql_query("INSERT INTO `gallery` (`time_create`, `id_user`, `name`, `time`, `pass`, `privat`, `privat_komm`) values('$time', '$ank[id]', '$name', '$time', '$pass', '$privat', '$privat_komm')");
			$gallery_id = mysql_insert_id();
			$_SESSION['message'] = 'Папка '.$name.' создана ';
			header("Location: /foto/$ank[id]/$gallery_id/");
			exit;
		}
	}
}
?>