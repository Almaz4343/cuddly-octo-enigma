<?

/*
* Autor: Tw1nGo
* Modul: Ставим аватар как на Spaces.RU
* Date: 30.12.2016
*/

include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';
only_reg();

// Определяем uID юзера
if (isset($user))$ank['id'] = $user['id'];
if (isset($_GET['uid']))$ank['id'] = intval($_GET['uid']);

$ank = get_user($ank['id']);

if (!isset($_GET['uid']) || !$ank || $ank['id'] == 0 || $ank['id'] != $user['id']){
$_SESSION['err'] = 'Ошибка! Повторите попытку.';
header("Location: ?uid=".$user['id']."".SID);exit;
}

if (isset($_GET['Lt']) && ($_GET['Lt'] == '0' || $_GET['Lt'] == '1'))
{
if ($_GET['Lt'] == '0')
{
$_SESSION['avatar_sort'] = 0;
}
else if ($_GET['Lt'] == '1')
{
$_SESSION['avatar_sort'] = 1;
}
}

$dir_icon = array(
  '/foto/css/ico/folder.gif',
  '/foto/css/ico/folder_user.gif',
  '/foto/css/ico/folder_locked.gif'
);

$set['title'] = 'Фото : ' . text($ank['nick']);

include_once H.'sys/inc/thead.php';
title();


?>
<link rel="stylesheet" href="/foto/css/Tw1nGo_Photo_Style.css" type="text/css" />
<div class="BG_Fon" style="padding: 1px 0;">


<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $user['id']?>"> <?= $user['nick']?> </a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/foto/<?= $user['id']?>/">Фото</a> </span>   </div>
<?


if (isset($_GET['Dir_id'])) {
// Определяем ид папки
$Dir = (int) $_GET['Dir_id'];
$gallery = mysql_fetch_assoc(mysql_query("SELECT * FROM `gallery` WHERE `id` = '$Dir' AND `id_user` = '$ank[id]' LIMIT 1"));

?>
<a href="?uid=<?= $ank['id']?>&Lt=0&Dir=0" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>

<div>
<div class="list_item">
<b>   <img src="<?= $dir_icon[$gallery['privat']]?>" alt="" class="icon icon_align p16">   «<span><?= text($gallery['name'])?></span>» </b>
</div>
<div class="busi_switcher">  </div>
<?
    
$set['p_str'] = 16;
$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `gallery_foto` WHERE `id_user` = '$user[id]' AND `id_gallery` = '$Dir'"),0);
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str'] * $page - $set['p_str'];

if($k_post == 0){
?>
<div class="widgets-group wbg widgets-group_top-mrg"><div class="content-bl"> У вас нет загруженных фотографий. </div></div>
<?
}
else
{

$q = mysql_query("SELECT * FROM `gallery_foto` WHERE `id_user` = '$user[id]' AND `id_gallery` = '$Dir' ORDER BY `time` DESC LIMIT $start, $set[p_str]");

?>
<div id="sz_gallery_loader" data-type="user" class="stnd_padd light_border_bottom oh font0 bg-white">
<?

while ($post = mysql_fetch_assoc($q))
{
$ank = get_user($post['id_user']);

?> 





<div class="js-file_item  tiled_item tiled_item-200"> 
<div class="tiled_inner t_center relative">   
<span class="relative" style="display: inline-block;max-width: 100%; width: 100%;">  
<div class="tiled-preview">      
<a href="/foto/edit_photo/?avatar=<?= $post['id']?>">    
<img src="/foto/pic400/<?= $post['id']?>.p.401.400.0.<?= $post['ras']?>" alt="" class="preview s201_200"> 
<?
if($post['metka'] != 0){
?>
<img class="p16 f_18p" src="/foto/css/ico/adult.png" alt="">     
<?
}
?>       
</a>       
</div> </span>    
<div class="tf oh pad_t_a word_break"><span><?= text($post['name'])?></span></div>        
</div> </div> 
<!--   -->       
<?

}

?>
</div>
<?

if ($k_page > 1) {
      str('?uid=' . $ank['id'] . '&amp;Dir='.$Dir.'&amp;', $k_page, $page); 
}
} 
?>   
<a href="/foto/edit_photo/" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Отмена  </a>

<?
}elseif (isset($_GET['Dir']) && $_GET['Dir'] == '0'){

// ТОЛЬКО ПаПКИ
if($_SESSION['avatar_sort'] == 0){

?>
<div class="busi_switcher">   
<table width="100%"> <tbody><tr> 
<td><span class="active_item">Папки</span></td> 
<td><a href="?uid=<?= $user['id']?>&Lt=1&Dir=0">Все файлы</a></td>  
</tr> </tbody></table>   
</div>
<?

$set['p_str'] = '10';
$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `gallery` WHERE `id_user` = '$user[id]'"),0);
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str'] * $page-$set['p_str'];

if ($k_post == 0){
?>

<div class="widgets-group wbg widgets-group_top-mrg"> <div class="static-bl"> У вас нет альбомов. </div></div>
<?
}
else{
?>
<div>

<?



$q = mysql_query("SELECT * FROM `gallery` WHERE `id_user` = '$user[id]' ORDER BY `time` DESC LIMIT $start, $set[p_str]");

while ($post = mysql_fetch_assoc($q))
{
$count = mysql_result(mysql_query("SELECT COUNT(*) FROM `gallery_foto` WHERE `id_gallery` = '$post[id]'"), 0);

?>
<a href="?uid=<?= $user['id']?>&amp;Dir_id=<?= $post['id']?>" class="t-block_item t-padd_right light_border_bottom t-bg3 t-link_no_underline_block">  
<span class="t-block_item stnd_padd t-bg_arrow_next"> 
<img src="<?= $dir_icon[$post['privat']]?>" alt="" class="icon icon_align p16">    
<span class="m t-strong_item t-link_item_hover"> <?= text($post['name'])?> </span> 
<span class="m files_num">(<?= $count?>)</span> </span>  
</a>
<?
}
?>
</div>
<?

if ($k_page > 1) {
      str('?uid=' . $ank['id'] . '&amp;Lt=0&amp;Dir=0&amp;', $k_page, $page); 
}
} 

}elseif($_SESSION['avatar_sort'] == 1){
// ТОЛЬКО ФОТО

?>

<a href="?uid=<?= $ank['id']?>&Lt=0&Dir=0" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>


<div class="busi_switcher">  
<table width="100%"> <tbody><tr> 
<td width="50%"><a href="?uid=<?= $user['id']?>&Lt=0&Dir=0">папки</a></td> 
<td width="50%"><span class="active_item">все файлы</span></td> 
</tr> </tbody></table>  
</div>
<?


$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `gallery_foto` WHERE `id_user` = '$ank[id]'"),0);
$set['p_str'] = '16';
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str'] * $page-$set['p_str'];



if($k_post == 0){
?>
<div class="widgets-group wbg widgets-group_top-mrg"><div class="static-bl"> У вас нет загруженных фотографий. </div></div>
<?
}
else
{

$q = mysql_query("SELECT * FROM `gallery_foto` WHERE `id_user` = '$ank[id]' ORDER BY `time` DESC LIMIT $start, $set[p_str]");
	
?>
<div id="sz_gallery_loader" data-type="user" class="js-gallery_skip stnd_padd light_border_bottom oh font0 bg-white">
<?

while ($post = mysql_fetch_assoc($q))
{
$ank = get_user($post['id_user']);

?> 
<div class="js-file_item  tiled_item tiled_item-200"> 
<div class="tiled_inner t_center relative">   
<span class="relative" style="display: inline-block;max-width: 100%; width: 100%;">  
<div class="tiled-preview">      
<a href="/foto/edit_photo/?avatar=<?= $post['id']?>">    
<img src="/foto/pic400/<?= $post['id']?>.p.401.400.0.<?= $post['ras']?>" alt="" class="preview s201_200"> 
<?
if($post['metka'] != 0){
?>
<img class="p16 f_18p" src="/foto/css/ico/adult.png" alt="">     
<?
}
?>  
</a>       
</div> </span>    
<div class="tf oh pad_t_a word_break"><span><?= text($post['name'])?></span></div>        
</div> </div> 
<!--   -->       
<?

}

?>
</div>
<?

if ($k_page > 1) {
      str('?uid=' . $ank['id'] . '&amp;Lt=1&amp;Dir=0&amp;', $k_page, $page); 
}
} 
}
?>
<a href="/foto/edit_photo/?" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>  Отмена  </a>

<?
}
// ВЫБОР ФОТО  И ЗАГРУЗКА 
else{

?>

<div class="wrapper">    
<?

$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `gallery_foto` WHERE `id_user` = '$ank[id]'"),0);
if($k_post >= 4){
$divka = '';
}else{
$divka = 'border-bottom:0;';
}
if($k_post == 0){
?>
<div class="link darkblue"> У вас нет загруженных фотографий. </div>
<?
}
else
{
?>
<div class="block bord-botm"  style="<?=  $divka?>"> 
<div class="no_underline_block"> 
<?
$q = mysql_query("SELECT * FROM `gallery_foto` WHERE `id_user` = '$ank[id]' ORDER BY `time` DESC LIMIT 4");
	
?>
<span class="short_attach">
<?
while ($post = mysql_fetch_assoc($q))
{
$ank = get_user($post['id_user']);

?> 
<span class="short_attach">   
<span class="avatar_foto">   
<a href="/foto/edit_photo/?avatar=<?= $post['id']?>">    
<img src="/foto/pic80/<?= $post['id']?>.p.81.80.0.<?= $post['ras']?>" alt="" class="preview s80_81"> 
<?
if($post['metka'] != 0){
?>
<img class="p16 f_18p" src="/foto/css/ico/adult.png" alt="">     
<?
}
?>       
</a>       
</span>  </span>
<?
}
?>  
</span>
</div></div>
<?
if($k_post >= 4){
?>
<a href="?uid=<?= $ank['id']?>&amp;Lt=0&Dir=0" class="link blue full is_final">  Показать все  фото  »  </a>
<?
}
}
?>
</div>

<div class="oh">     
<a href="/user/?id=<?= $ank['id']?>" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>     
</div>
<?

}
?>  
</div>
<?
include_once H.'sys/inc/tfoot.php';
?>