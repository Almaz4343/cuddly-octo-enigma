<?
include_once '../sys/inc/start.php';
include_once '../sys/inc/compress.php';
include_once '../sys/inc/sess.php';
include_once '../sys/inc/home.php';
include_once '../sys/inc/settings.php';
include_once '../sys/inc/db_connect.php';
include_once '../sys/inc/ipua.php';
include_once '../sys/inc/fnc.php';
include_once '../sys/inc/user.php';


/* Бан пользователя */ 
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `ban` WHERE `razdel` = 'forum' AND `id_user` = '$user[id]' AND (`time` > '$time' OR `view` = '0' OR `navsegda` = '1')"), 0)!=0)
{
	header('Location: /ban.php?'.SID);
	exit;
}

// Заголовок страницы
$set['title'] = 'Новые : Форум';

include_once '../sys/inc/thead.php';
title();






$adm_add = NULL;
$adm_add2 = NULL;

if (!isset($user) || $user['level']==0)
{
	$q222 = mysql_query("SELECT * FROM `forum_f` WHERE `adm` = '1'");
	
	while ($adm_f = mysql_fetch_assoc($q222))
	{
		$adm_add[] = "`id_forum` <> '$adm_f[id]'";
	}
	if (sizeof($adm_add) != 0)
	$adm_add2 = ' WHERE'.implode(' AND ', $adm_add);
}

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/forum/">Форум</a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Новые</span> </span>       </div>

<div class="list_item oh"> 
<a class="arrow_link right" href="search.php"> <img src="/style/i/search.gif" alt="" class="m p16"> <span class="m">Поиск</span> </a> 
</div>

<div class="busi_switcher"> 
<table width="100%"> <tbody><tr>     
<td><a href="new.post.php">Последние</a></td>    
<td><span class="active_item">Новые</span></td>   
</tr> </tbody></table> 
</div>

<?



$set['p_str'] = '20';
$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_t`$adm_add2"),0);
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str'] * $page - $set['p_str'];




$q=mysql_query("SELECT * FROM `forum_t`$adm_add2 ORDER BY `time_create` DESC  LIMIT $start, $set[p_str]");


if ($k_post == 0){ 
?>
<div class="col_blocks block">  Новых тем не найдено.</div>
<?
}


while ($them = mysql_fetch_assoc($q))
{
// Определение подфорума
$forum = mysql_fetch_array(mysql_query("SELECT * FROM `forum_f` WHERE `id` = '$them[id_forum]' LIMIT 1"));
	
// Определение раздела
$razdel = mysql_fetch_array(mysql_query("SELECT * FROM `forum_r` WHERE `id` = '$them[id_razdel]' LIMIT 1"));
	
$ank = get_user($them['id_user']);
$post2 = mysql_fetch_assoc(mysql_query("SELECT * FROM `forum_p` WHERE `id_them` = '$them[id]' AND `id_razdel` = '$razdel[id]' AND `id_forum` = '$forum[id]' ORDER BY `time` DESC LIMIT 1"));
$ank2 = get_user($post2['id_user']);

$commentt = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_p` WHERE `id_forum` = '$forum[id]' AND `id_razdel` = '$razdel[id]' AND `id_them` = '$them[id]'"),0);

?>
<div class="light_border_bottom t-bg3 attaches_limiter"> 
<a href="/forum/<?= $forum['id']?>/<?= $razdel['id']?>/<?= $them['id']?>/" class="t-block_item stnd_padd t-link_no_underline_block"> 
<span class="t-block_item oh"> <span class="comment_date right_fix"><?= vremja($them['time_create'])?></span> 
<?
if($them['up'] == 1){
?> 
<img src="/style/i/stick.gif" alt="" class="p16">  
<?
}
?>
<span class="t-strong_item t-link_item_hover"><?= text($them['name'])?></span> <span class="grey">(<?= $commentt?>)</span>    
<?
if($them['close'] == 1){
?>
<img src="/style/i/topic_locked.gif" class="p16" alt="">
<?
}
if (mysql_result(mysql_query("SELECT COUNT(id) FROM `forum_filest` WHERE `id_post` = '$them[id]'"), 0) > 0){
?>
<img src="/style/i/skrepka.png" class="p16" alt="">
<?
}
?>  
<br> 
<span class="grey"><?= $ank['nick']?> 
<?
if ($ank2['id']){
?>
 / <?= $ank2['nick']?>  (<?= vremja($post2['time'])?>)
<?
}
?>
</span> </span> 
</a>   
</div>
<?

}



// Вывод cтраниц 
if ($k_page>1)str("?",$k_page,$page); 

?>
<a href="/forum/" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?

include_once '../sys/inc/tfoot.php';

?>