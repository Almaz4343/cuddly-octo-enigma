<?

$q_f=mysql_query("SELECT * FROM `forum_files` WHERE `id_post` = '$post[id]'");
while ($file = mysql_fetch_assoc($q_f))
{


$ras = $file['ras'];

?>
<div>  
<div class="font0">  

  
<?
if ($ras == 'png' || $ras == 'jpg' || $ras == 'jpeg' || $ras == 'gif'){
?>
<div class=" tiled_item tiled_item-200"> <div class="tiled_inner t_center relative">   
<span class="relative" style="display: inline-block;max-width: 100%; width: 100%; padding:5px;">   <span class="inl_bl">        
<a class="tdn gview_link" href="/forum/files/<?= $file['id']?>/<?= $file['name']?>.<?= $file['ras']?>"> 
<div class="inl_bl relative"> <img src="/forum/files/<?= $file['id']?>/<?= $file['name']?>.<?= $file['ras']?>" alt="" class="preview s201_200">   </div>      
</a>     
<?
if (isset($user) && $user['level']>2){
?>
<a href="/forum/files/delete/<?= $file['id']?>/"> 
<img src ="//c.spac.me/i/close2.png" style="text-decoration: none; position: absolute; top: 3px; right: 2px; background: center no-repeat !important;">
</a>
<?
}
?>        
</span>    </span>  </div>  </div>    
<?
}
if ($ras == 'png' || $ras == 'jpg' || $ras == 'jpeg' || $ras == 'gif'){
// Типо делаем не для картинок
}else{
?> 
<div class="tile_descr">   
<div class="tf oh pad_t_a word_break"><span>
<?

if (is_file(H.'style/themes/'.$set['set_them'].'/loads/14/'.$file['ras'].'.png'))
{
echo "<img src='/style/themes/$set[set_them]/loads/14/$file[ras].png' alt='$file[ras]' />\n";

}
else
{
echo "<img src='/style/themes/$set[set_them]/forum/14/file.png' alt='' />\n";

}

?>
<a class="tdn gview_link" href="/forum/files/<?= $file['id']?>/<?= $file['name']?>.<?= $file['ras']?>"> 
<?= $file['name']?>.<?= $ras?>
</a>
<?
if (isset($user) && $user['level']>2){
?>
<a href="/forum/files/delete/<?= $file['id']?>/"> 
<img src ="/style/icons/delete.png">
</a>
<?
}
?>
 </span></div>      
</div>    
<?
}



?>
</div>  
</div>
<?


}


?>