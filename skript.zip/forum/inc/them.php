<?



if (isset($user) && isset($_GET['f_del']) && is_numeric($_GET['f_del']) && isset($_SESSION['file'][$_GET['f_del']]))
{
    @unlink($_SESSION['file'][$_GET['f_del']]['tmp_name']);
}

// Закладки
if (isset($user) && isset($_GET['zakl']) && $_GET['zakl']==1)
{
if(mysql_result(mysql_query("SELECT COUNT(*) FROM `bookmarks` WHERE `id_user` = $user[id] AND `type` = 'forum' AND `id_object` = '$them[id]'"),0)!=0)

{
$err[]="Тема уже есть в ваших закладках!";
header("Location: ?P=".intval($_GET['page'])."");
exit;
}
else {
mysql_query("INSERT INTO `bookmarks` (`id_user`, `time`,  `id_object`, `type`) values('$user[id]', '$time', '$them[id]', 'forum')");

$err[]="Закладка добавлена.";
header("Location: ?P=".intval($_GET['page'])."");
exit;
}
}

elseif (isset($user) && isset($_GET['zakl']) && $_GET['zakl']==0)
{
mysql_query("DELETE FROM `bookmarks` WHERE `id_user` = '$user[id]' AND `type` = 'forum' AND `id_object` = '$them[id]'");
$err[]="Закладка удалена.";
header("Location: ?P=".intval($_GET['page'])."");
exit;

}
// Конец



if (isset($user) && isset($_GET['act']) && $_GET['act']=='new' && isset($_FILES['file_f']) && preg_match('#\.#', $_FILES['file_f']['name']) && isset($_POST['file_s']))
{
    copy($_FILES['file_f']['tmp_name'], H.'sys/tmp/'.$user['id'].'_'.md5_file($_FILES['file_f']['tmp_name']).'.forum.tmp');
    chmod(H.'sys/tmp/'.$user['id'].'_'.md5_file($_FILES['file_f']['tmp_name']).'.forum.tmp', 0777);

    if (isset($_SESSION['file']))
        $next_f=count($_SESSION['file']);
    else 
        $next_f=0;

    $file=esc(stripcslashes(htmlspecialchars($_FILES['file_f']['name'])));
    $_SESSION['file'][$next_f]['name']=preg_replace('#\.[^\.]*$#i', NULL, $file); // имя файла без расширения
    $_SESSION['file'][$next_f]['ras']=strtolower(preg_replace('#^.*\.#i', NULL, $file));
    $_SESSION['file'][$next_f]['tmp_name']=H.'sys/tmp/'.$user['id'].'_'.md5_file($_FILES['file_f']['tmp_name']).'.forum.tmp';
    $_SESSION['file'][$next_f]['size']=filesize(H.'sys/tmp/'.$user['id'].'_'.md5_file($_FILES['file_f']['tmp_name']).'.forum.tmp');
    $_SESSION['file'][$next_f]['type']=$_FILES['file_f']['type'];
}

if (isset($user) && ($them['close']==0  || $them['close']==1 && user_access('forum_post_close')) && isset($_GET['act']) && $_GET['act']=='new' && isset($_POST['msg']) && !isset($_POST['file_s']))
{
$msg=$_POST['msg'];
if (strlen2($msg)<2)$err='Короткое сообщение';
if (strlen2($msg)>1024)$err='Длина сообщения превышает предел в 1024 символа';

$mat=antimat($msg);
if ($mat)$err[]='В тексте сообщения обнаружен мат: '.$mat;

if (mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_p` WHERE `id_them` = '$them[id]' AND `id_forum` = '$forum[id]' AND `id_razdel` = '$razdel[id]' AND `id_user` = '$user[id]' AND `msg` = '".my_esc($msg)."' LIMIT 1"),0)!=0)$err='Ваше сообщение повторяет предыдущее';

if (!isset($err))
{
    if (isset($_POST['cit']) && is_numeric($_POST['cit']) && mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_p` WHERE `id` = '".intval($_POST['cit'])."' AND `id_them` = '".intval($_GET['id_them'])."' AND `id_razdel` = '".intval($_GET['id_razdel'])."' AND `id_forum` = '".intval($_GET['id_forum'])."'"),0)==1)
    $cit=intval($_POST['cit']); else $cit='null';

    mysql_query("UPDATE `forum_zakl` SET `time_obn` = '$time' WHERE `id_them` = '$them[id]'");
    mysql_query("INSERT INTO `forum_p` (`id_forum`, `id_razdel`, `id_them`, `id_user`, `msg`, `time`, `cit`) values('$forum[id]', '$razdel[id]', '$them[id]', '$user[id]', '".my_esc($msg)."', '$time', $cit)");

    $post_id=mysql_insert_id();

    if (isset($_SESSION['file']) && isset($user))
    {
        for ($i=0; $i<count($_SESSION['file']);$i++)
        {
            if (isset($_SESSION['file'][$i]) && is_file($_SESSION['file'][$i]['tmp_name']))
            {
                mysql_query("INSERT INTO `forum_files` (`id_post`, `name`, `ras`, `size`, `type`) values('$post_id', '".$_SESSION['file'][$i]['name']."', '".$_SESSION['file'][$i]['ras']."', '".$_SESSION['file'][$i]['size']."', '".$_SESSION['file'][$i]['type']."')");
                $file_id=mysql_insert_id();
                copy($_SESSION['file'][$i]['tmp_name'], H.'sys/forum/files/'.$file_id.'.frf');
                unlink($_SESSION['file'][$i]['tmp_name']);
            }
        }
        unset($_SESSION['file']);
    }

    unset($_SESSION['msg']);

    $ank = get_user($them['id_user']); // Определяем автора


    mysql_query("UPDATE `user` SET `rating_tmp` = '".($user['rating_tmp']+1)."' WHERE `id` = '$user[id]' LIMIT 1");
    mysql_query("UPDATE `forum_r` SET `time` = '$time' WHERE `id` = '$razdel[id]' LIMIT 1");
    mysql_query("UPDATE `forum_t` SET `time_create` = '$time' WHERE `id` = '$them[id]' LIMIT 1");


    /*
    ====================================
    Обсуждения
    ====================================
    */

    $q = mysql_query("SELECT * FROM `frends` WHERE `user` = '".$them['id_user']."' AND `i` = '1'");

    while ($f = mysql_fetch_array($q))
    {
        $a=get_user($f['frend']);
        $discSet = mysql_fetch_array(mysql_query("SELECT * FROM `discussions_set` WHERE `id_user` = '".$a['id']."' LIMIT 1")); // Общая настройка обсуждений

        if ($f['disc_forum']==1 && $discSet['disc_forum']==1) /* Фильтр рассылки */
        {
        	// друзьям автора
        	if (mysql_result(mysql_query("SELECT COUNT(*) FROM `discussions` WHERE `id_user` = '$a[id]' AND `type` = 'them' AND `id_sim` = '$them[id]' LIMIT 1"),0)==0)
        	{
            	if ($them['id_user']!=$a['id'] || $a['id'] != $user['id'])
            	mysql_query("INSERT INTO `discussions` (`id_user`, `avtor`, `type`, `time`, `id_sim`, `count`) values('$a[id]', '$them[id_user]', 'them', '$time', '$them[id]', '1')"); 
        	}
        	else
        	{
            	$disc = mysql_fetch_array(mysql_query("SELECT * FROM `discussions` WHERE `id_user` = '$a[id_user]' AND `type` = 'them' AND `id_sim` = '$them[id]' LIMIT 1"));
            	if ($them['id_user']!=$a['id'] || $a['id'] != $user['id'])
            	mysql_query("UPDATE `discussions` SET `count` = '".($disc['count']+1)."', `time` = '$time' WHERE `id_user` = '$a[id]' AND `type` = 'them' AND `id_sim` = '$them[id]' LIMIT 1");
        	}
        }
    }

    // отправляем автору
    if (mysql_result(mysql_query("SELECT COUNT(*) FROM `discussions` WHERE `id_user` = '$them[id_user]' AND `type` = 'them' AND `id_sim` = '$them[id]' LIMIT 1"),0)==0)
    {
        if ($them['id_user'] != $user['id'] && $them['id_user'] != $ank_otv['id'])
        mysql_query("INSERT INTO `discussions` (`id_user`, `avtor`, `type`, `time`, `id_sim`, `count`) values('$them[id_user]', '$them[id_user]', 'them', '$time', '$them[id]', '1')"); 
    }
    else
    {
        $disc = mysql_fetch_array(mysql_query("SELECT * FROM `discussions` WHERE `id_user` = '$them[id_user]' AND `type` = 'them' AND `id_sim` = '$them[id]' LIMIT 1"));
        if ($them['id_user'] != $user['id'] && $them['id_user'] != $ank_otv['id'] )
        mysql_query("UPDATE `discussions` SET `count` = '".($disc['count']+1)."', `time` = '$time' WHERE `id_user` = '$them[id_user]' AND `type` = 'them' AND `id_sim` = '$them[id]' LIMIT 1");
    }

    /*
    ==========================
    Уведомления об ответах
    ==========================
    */

    if (isset($user) && $respons==TRUE){
    $notifiacation=mysql_fetch_assoc(mysql_query("SELECT * FROM `notification_set` WHERE `id_user` = '".$ank_otv['id']."' LIMIT 1"));

    	if ($notifiacation['komm'] == 1)
    	mysql_query("INSERT INTO `notification` (`avtor`, `id_user`, `id_object`, `type`, `time`) VALUES ('$user[id]', '$ank_otv[id]', '$them[id]', 'them_komm', '$time')");
    }

    $_SESSION['message'] = 'Сообщение успешно добавлено';
    header("Location: ?P=".intval($_GET['page'])."");
    exit;
    }
}

/*
================================
Модуль жалобы на пользователя
и его сообщение либо контент
в зависимости от раздела
================================
*/

if (isset($_GET['spam']) && isset($user))
{
    $mess = mysql_fetch_assoc(mysql_query("SELECT * FROM `forum_p` WHERE `id` = '".intval($_GET['spam'])."' limit 1"));
    $spamer = get_user($mess['id_user']);

    if (mysql_result(mysql_query("SELECT COUNT(*) FROM `spamus` WHERE `id_user` = '$user[id]' AND `id_spam` = '$spamer[id]' AND `razdel` = 'forum' AND `spam` = '".$mess['msg']."'"),0)==0)
    {
        if (isset($_POST['spamus']))
        {
            if ($mess['id_user']!=$user['id'])
            {
                $msg=mysql_real_escape_string($_POST['spamus']);

                if (strlen2($msg)<3)$err='Укажите подробнее причину жалобы';
                if (strlen2($msg)>1512)$err='Длина текста превышает предел в 512 символов';

                if(isset($_POST['types'])) $types=intval($_POST['types']);
                else $types='0'; 
                if (!isset($err))
                {
                    mysql_query("INSERT INTO `spamus` (`id_object`, `id_user`, `msg`, `id_spam`, `time`, `types`, `razdel`, `spam`) values('$them[id]', '$user[id]', '$msg', '$spamer[id]', '$time', '$types', 'forum', '".my_esc($mess['msg'])."')");
                    $_SESSION['message'] = 'Заявка на рассмотрение отправлена'; 
                    header("Location: /forum/$forum[id]/$razdel[id]/$them[id]/?spam=$mess[id]&P=$pageEnd");
                    exit;
                }
            }
        }
    }


    err();

    if (mysql_result(mysql_query("SELECT COUNT(*) FROM `spamus` WHERE `id_user` = '$user[id]' AND `id_spam` = '$spamer[id]' AND `razdel` = 'forum'"),0)==0)
    {
        echo "<div class='mess'>Ложная информация может привести к блокировке ника. 
        Если вас постоянно достает один человек - пишет всякие гадости, вы можете добавить его в черный список.</div>";

        echo "<form class='nav1' method='post' action='/forum/$forum[id]/$razdel[id]/$them[id]/?spam=$mess[id]&amp;page=".intval($_GET['page'])."'>\n";
        echo "<b>Пользователь:</b> ";
        echo " ".avatar($spamer['id'])."  ".group($spamer['id'])." <a href=\"/user/?id=$spamer[id]\">$spamer[nick]</a>\n";
        echo "".medal($spamer['id'])." ".online($spamer['id'])." (".vremja($mess['time']).")<br />";
        echo "<b>Нарушение:</b> <font color='green'>".output_text($mess['msg'])."</font><br />";
        echo "Причина:<br />\n<select name='types'>\n";
        echo "<option value='1' selected='selected'>Спам/Реклама</option>\n";
        echo "<option value='2' selected='selected'>Мошенничество</option>\n";
        echo "<option value='3' selected='selected'>Оскорбление</option>\n";
        echo "<option value='0' selected='selected'>Другое</option>\n";
        echo "</select><br />\n";
        echo "Комментарий:";
        echo $tPanel."<textarea name=\"spamus\"></textarea><br />";
        echo "<input value=\"Отправить\" type=\"submit\" />\n";
        echo "</form>\n";
    }else{
        echo "<div class='mess'>Жалоба на <font color='green'>$spamer[nick]</font> будет рассмотрена в ближайшее время.</div>";
    }

    echo "<div class='foot'>\n";
    echo "<img src='/style/icons/str2.gif' alt='*'> <a href='?page=".intval($_GET['page'])."'>Назад</a><br />\n";
    echo "</div>\n";
    include_once '../sys/inc/tfoot.php';
    exit;
}





$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_p` WHERE `id_them` = '$them[id]' AND `id_forum` = '$forum[id]' AND `id_razdel` = '$razdel[id]'"),0);
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str']*$page-$set['p_str'];


?>
<a name="page-up"></a>
<div class="lc_br wbg font0 relative oh" id="header_path">  
<a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/forum/">Форум</a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> 
<a href="/forum/<?= $forum['id']?>/"><?= text($forum['name'])?></a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> 
<a href="/forum/<?= $forum['id']?>/<?= $razdel['id']?>/"><?= text($razdel['name'])?></a> </span>      </div>
<?



err();



/*
======================================
Перемещение темы
======================================
*/

if (isset($_GET['act']) && $_GET['act']=='mesto' && (user_access('forum_them_edit') || $ank2['id']==$user['id']))
{
    echo "<form method=\"post\" action=\"/forum/$forum[id]/$razdel[id]/$them[id]/?act=mesto&amp;ok\">\n";
    echo "<div class='mess'>";
    echo "Перемещение темы <b>".output_text($them['name'])."</b>\n";
    echo "</div>";

    echo "<div class='main'>";
    echo "Раздел:<br />\n";
    echo "<select name=\"razdel\">\n";

    if (user_access('forum_them_edit')){
        $q = mysql_query("SELECT * FROM `forum_f` ORDER BY `pos` ASC");

        while ($forums = mysql_fetch_assoc($q))
        {
            echo "<optgroup label='$forums[name]'>\n";
            $q2 = mysql_query("SELECT * FROM `forum_r` WHERE `id_forum` = '$forums[id]' ORDER BY `time` DESC");
            
            while ($razdels = mysql_fetch_assoc($q2))
            {
                echo "<option".($razdel['id']==$razdels['id']?' selected="selected"':null)." value=\"$razdels[id]\">" . text($razdels['name']) . "</option>\n";
            }
            echo "</optgroup>\n";
        }
    }
    else
    {
        $q2 = mysql_query("SELECT * FROM `forum_r` WHERE `id_forum` = '$forum[id]' ORDER BY `time` DESC");
        while ($razdels = mysql_fetch_assoc($q2))
        {
            echo "<option".($razdel['id']==$razdels['id']?' selected="selected"':null)." value='$razdels[id]'>" . text($razdels['name']) . "</option>\n";
        }
    }
    echo "</select><br />\n";

    echo "<input value=\"Переместить\" type=\"submit\" /> \n";
    echo "<img src='/style/icons/delete.gif' alt='*'> <a href='/forum/$forum[id]/$razdel[id]/$them[id]/'>Отмена</a><br />\n";
    echo "</form>\n";
    echo "</div>";

    echo "<div class='foot'>";
    echo "<img src='/style/icons/str2.gif' alt='*'> <a href='/forum/$forum[id]/$razdel[id]/$them[id]/?'>В тему</a><br />\n";
    echo "</div>";

    include_once '../sys/inc/tfoot.php';
    exit;
}

/*
======================================
Редактирование темы
======================================
*/

if (isset($_GET['act']) && $_GET['act']=='set' && (user_access('forum_them_edit') || $ank2['id']==$user['id']))
{
    echo "<form method='post' action='/forum/$forum[id]/$razdel[id]/$them[id]/?act=set&amp;ok'>\n";
    echo "<div class='mess'>";
    echo "Редактирование темы <b>".output_text($them['name'])."</b>\n";
    echo "</div>";

    echo "<div class=\"main\">\n";
    echo "Название:<br />\n";
    echo "<input name='name' type='text' maxlength='32' value='".text($them['name'])."' /><br />\n";

    echo "Сообщение:$tPanel<textarea name=\"msg\">".text($them['text'])."</textarea><br />\n";

    if ($user['level']>0){
        
        if ($them['up']==1)
            $check=' checked="checked"';
        else 
            $check=NULL;
        
        echo "<label><input type=\"checkbox\"$check name=\"up\" value=\"1\" /> Всегда наверху</label><br />\n";
    }

    if ($them['close']==1)
        $check=' checked="checked"';
    else 
        $check=NULL;

    echo "<label><input type=\"checkbox\"$check name=\"close\" value=\"1\" /> Закрыть</label><br />\n";

    if ($ank2['id']!=$user['id']){
        echo "<label><input type=\"checkbox\" name=\"autor\" value=\"1\" /> Забрать у автора права</label><br />\n";
    }

    echo "<input value=\"Изменить\" type=\"submit\" /> \n";
    echo "<img src='/style/icons/delete.gif' alt='*'> <a href='/forum/$forum[id]/$razdel[id]/$them[id]/'>Отмена</a><br />\n";
    echo "</form>\n";
    echo "</div>";

    echo "<div class='foot'>";
    echo "<img src='/style/icons/str2.gif' alt='*'> <a href='/forum/$forum[id]/$razdel[id]/$them[id]/?'>В тему</a><br />\n";
    echo "</div>";

    include_once '../sys/inc/tfoot.php';
    exit;
}

if (user_access('forum_post_ed') && isset($_GET['del'])) // удаление поста
{
	mysql_query("DELETE FROM `forum_p` WHERE `id` = '" . intval($_GET['del']) . "' LIMIT 1");
	$_SESSION['message'] = 'Сообщение успешно удалено'; 
	header("Location: /forum/$forum[id]/$razdel[id]/$them[id]/?page=" . intval($_GET['page']) . "");
	exit;
}

/*
======================================
Удаление темы
======================================
*/

if (isset($_GET['act']) && $_GET['act']=='del' && user_access('forum_them_del') && ($ank2['level']<=$user['level'] || $ank2['id']==$user['id']))
{
    echo "<div class=\"mess\">\n";
    echo "Подтвердите удаление темы <b>".output_text($them['name'])."</b><br />\n";
    echo "</div>\n";

    echo "<div class=\"main\">\n";
    echo "[<a href=\"/forum/$forum[id]/$razdel[id]/$them[id]/?act=delete&amp;ok\"><img src='/style/icons/ok.gif' alt='*'> Да</a>] [<a href=\"/forum/$forum[id]/$razdel[id]/$them[id]/\"><img src='/style/icons/delete.gif' alt='*'> Нет</a>]<br />\n";
    echo "</div>\n";

    echo "<div class='foot'>";
    echo "<img src='/style/icons/fav.gif' alt='*'> <a href='/forum/$forum[id]/$razdel[id]/$them[id]/?'>В тему</a><br />\n";
    echo "</div>";

    include_once '../sys/inc/tfoot.php';
    exit;
}



/*
=-=-=
Содержание темы :))
=-=-=
*/

$kf_autor = get_user($them['id_user']);

?>
<a href="/forum/<?= $forum['id']?>/<?= $razdel['id']?>/" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   <?= text($razdel['name'])?>  </a>

<div>
<div class="list_item light_border_bottom">  
<div class="left font0 avatar_wrap" style="padding-right: 7px;">       
<div class="inl_bl relative"> <?= ava40($kf_autor['id'])?>   </div>      
</div>  
<div class="overfl_hid"> 
<span class="user__nick"> <?= group($kf_autor['id'])?> 
<a href="/user/?id=<?= $kf_autor['id']?>"  class="mysite-link">
<b class="nick black"> <?= $kf_autor['nick']?></b>
</a> <?= medal($kf_autor['id'])?>     
</span> 
<span class="comment_date right_fix"><?= vremja($them['time'])?></span>  
<span class="b"><?= text($them['name'])?></span>   
<?
// Если закрыта, то показуем замок
if ($them['close'] == 1)$err = '<img src="/style/i/topic_locked.gif" alt="" class="p16">';
?>
</div> 
<div class="cl"></div> 
<?
if (mysql_result(mysql_query("SELECT COUNT(id) FROM `forum_filest` WHERE `id_post` = '$them[id]'"), 0) > 0){

$ft = mysql_fetch_assoc(mysql_query("SELECT * FROM `forum_filest` WHERE `id_post` = '$them[id]'"));

?>

<div id="mainAttachWidgets" class="attaches-fixer" style="margin-top: 3px;">     
<div class="AttachRender">   <div class="inl_bl">        
<a class="tdn gview_link" href="/sys/tpic/forums/files/<?= $ft['id']?>.<?= $ft['ras']?>">   
<div class="inl_bl relative"> 
<img src="/sys/tpic/forums/files/<?= $ft['id']?>.<?= $ft['ras']?>" alt="" class="preview s0_360">   
</div>      
</a>             
</div>     
<div class="cl"></div> </div>  <div class="cl"></div>   
</div>
<?
}else{
?>
<div id="mainAttachWidgets" class="attaches-fixer" style="margin-top: 3px;"></div> 
<?
}
?>
<div id="previewText" class="oh"> <?= output_text($them['text'])?> <br> </div>    
</div>
</div>
<?
$edit_autor = get_user($them['id_edit']);
if($them['id_edit'] != null && $them['close'] == 1){
?>
<div class="list_item light_border_bottom grey">
<?
if ($them['close'] == 1){
?>
Тема закрыта <a href="" class="light_service_link"><?= $edit_autor['nick']?></a> <br>
<?
}
if($them['id_edit'] != null){
?>
Последний раз редактировалось   
<a href="" class="light_service_link"><?= $edit_autor['nick']?></a>  <?= vremja($them['time_create'])?>
<?
}
?>
</div>
<?
}
if (isset($user))
{
?>
<div class="list_item light_border_bottom oh">       
<div class="lh_160">    <div class="cf js-action_bar">              
<div>    
<?
if (isset($user) && (((!isset($_GET['act']) || $_GET['act']!='post_delete') && (user_access('forum_post_ed') || $ank2['id']==$user['id']))
|| ((user_access('forum_them_edit') || $ank2['id']==$user['id']))
|| (user_access('forum_them_del') || $ank2['id']==$user['id']))){
if (user_access('forum_them_edit') || $ank2['id']==$user['id']){
?>
<a href="?act=set" class="arrow_link"> 
<img src="/style/i/edit_gray.png" alt="" class="p16 m"> <span class="m">Редактировать</span> 
</a><br>
<?
}
}

$markinfo = mysql_result(mysql_query("SELECT COUNT(`id`) FROM `bookmarks` WHERE `id_object` = '".$them['id']."' AND `type` = 'forum'"),0);
if (mysql_result(mysql_query("SELECT COUNT(`id`) FROM `bookmarks` WHERE `id_object` = '$them[id]' AND `id_user` = '$user[id]' AND `type`='forum'"),0)==0){
?>
<a href="?P=<?= $page?>&amp;zakl=1" class="arrow_link"> 
<img src="/style/i/action_fav_gray.png" alt="" class="p16 m"> <span class="m">В закладки</span> </a><br> 
<?
}
else
{
mysql_query("UPDATE `forum_zakl` SET `time` = '".time()."' WHERE `id_them` = '$them[id]' AND `id_user` = '$user[id]'");
?>
<a href="?P=<?= $page?>&amp;zakl=0" class="arrow_link"> 
<img src="/style/i/action_fav_color.png" alt="" class="p16 m"> <span class="m">Удалить из закладок</span> 
</a><br>
<?
}
?>       
</div>   </div>  
</div> </div>
<?
}





/*
Кнопки действия с темой
*/
/*
if (isset($user) && (((!isset($_GET['act']) || $_GET['act']!='post_delete') && (user_access('forum_post_ed') || $ank2['id']==$user['id']))
|| ((user_access('forum_them_edit') || $ank2['id']==$user['id']))
|| (user_access('forum_them_del') || $ank2['id']==$user['id']))){
        
    echo "<div class=\"foot\">\n";

    if (user_access('forum_them_edit') || $ank2['id']==$user['id']){
        echo "<a href='/forum/$forum[id]/$razdel[id]/$them[id]/?act=mesto'><img src='/style/forum/inc/perem.png' alt='*'></a> | \n";
    }

    if (user_access('forum_them_del') || $ank2['id']==$user['id']){
        //echo " | <a href='/forum/$forum[id]/$razdel[id]/$them[id]/?act=del'><img src='/style/forum/inc/udl.png' alt='*'></a>\n";
    }
    echo "</div>\n";
}
*/


?>
<link rel="stylesheet" type="text/css" href="http://spac.me/css/custom/CommentWidget/CommentsWap.css?r=1446p" data-tmp_css="1" /> 
<div class="header oh text_left"> <b class="upcs m">Комментарии (<?= $k_post?>)</b>     </div>
<?

/*
if (isset($user)) 
{
    echo "<div id='comments' class='menus'>";
    echo "<div class='webmenu'>";
    echo "<a href='/forum/$forum[id]/$razdel[id]/$them[id]/?page=$page&amp;sort=1' class='".($user['sort']==1?'activ':'')."'>Внизу</a>";
    echo "</div>"; 
    echo "<div class='webmenu'>";
    echo "<a href='/forum/$forum[id]/$razdel[id]/$them[id]/?page=$page&amp;sort=0' class='".($user['sort']==0?'activ':'')."'>Вверху</a>";
    echo "</div>"; 
    echo "</div>";
}
*/

if ((user_access('forum_post_ed') || isset($user) && $ank2['id']==$user['id']) && isset($_GET['act']) && $_GET['act']=='post_delete'){
    $lim=NULL;
} else {
    $lim=" LIMIT $start, $set[p_str]";
}


$q=mysql_query("SELECT * FROM `forum_p` WHERE `id_them` = '$them[id]' AND `id_forum` = '$forum[id]' AND `id_razdel` = '$razdel[id]' ORDER BY `time` DESC $lim");


while ($post = mysql_fetch_assoc($q))
{

$ank = get_user($post['id_user']);
$postBan = mysql_result(mysql_query("SELECT COUNT(*) FROM `ban` WHERE (`razdel` = 'all' OR `razdel` = 'forum') AND `post` = '1' AND `id_user` = '$post[id_user]' AND (`time` > '$time' OR `navsegda` = '1')"), 0);
$cit = mysql_fetch_assoc(mysql_query("SELECT * FROM `forum_p` WHERE `id` = '$post[cit]' LIMIT 1"));
$ank_c = get_user($cit['id_user']);



?>
<div id="<?= $post['id']?>"> 
<div class="comm oh">  
<?
if($ank['id'] != 0){
?>
<div class="p40 left t-padd_right">      
<a class="tdn" href="/user/?id=<?= $ank['id']?>">   <div class="inl_bl relative"> <?= ava40($ank['id'])?>   </div> </a>       
</div>  
<div class="oh">  
<div>  
<span> 
<?
if ((user_access('forum_post_ed') || isset($user) && $ank2['id']==$user['id']) && isset($_GET['act']) && $_GET['act']=='post_delete')
{
echo '<input type="checkbox" name="post_'.$post['id'].'" value="1" />';
}
?>
<?= group($ank['id'])?>
<a href="/user/?id=<?= $ank['id']?>" class="mysite-link"><b class="nick black"><?= $ank['nick']?></b></a> 
<?= medal($ank['id'])?>     
</span> 
<div class="right">  
<a class="grey js-link_copy"> <span class="m">  <?= vremja($post['time'])?> </span> </a>  
</div> 
</div>
<?
# Цитирование поста
if ($post['cit']!=NULL && mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_p` WHERE `id` = '$post[cit]'"),0)==1)
{
?>
<div class="grey gl">ответил<?= ($ank['pol'] == 1 ? '' : 'а')?>  
<a class="b" href="/user/?id=<?= $ank_c['id']?>"><?= $ank_c['nick']?></a>  
</div>
<?
}
?>
</div>  
   <div class="cl"> 
<?

if ($postBan == 0) // Блок сообщения
{
?>    
<div><?= output_text($post['msg'])?></div>  
<?
include H.'/forum/inc/file.php'; // Прекрепленные файлы
?>
<?
}else{
?>    
<div><?= output_text($banMess)?></div>  
<?
}
?>       
</div>
<?
if (isset($user)){
?>
<div class="oh pad_t_a">
<?
if ($them['close'] == 0){
if (isset($user) &&  $user['id'] != $post['id_user'] && $post['id_user'] != 0){
?>
<a href="<?= $post['id']?>/cit/" class="link-grey js-comm_reply">Ответить</a>    
<?
}
}
if (user_access('forum_post_ed') && ($ank['level']<=$user['level'] || $ank['level']==$user['level'] &&  $post['id_user']==$user['id'])) {
?>
<span class="slb"><a href="<?= $post['id']?>/edit/" title="Изменить"> Изменить</a></span>
<?
}elseif ($user['id']==$post['id_user'] && $post['time']>time()-600){ 
?>
<span class="slb"><a href="<?= $post['id']?>/edit/" title="Изменить"> Изменить</a> <?= ($post['time']+600-time())?> сек.</span>
<?
}
if (user_access('forum_post_ed')) 
{
?>
 | <a href="?del=<?= $post['id']?>&amp;P=<?= $page?>" class="link-grey js-comm_reply">Удалить</a>    
<?
}
?>
</div>  
<?
}
}else{
?>
<div class="cl t_center">     <div class="grey"><?= output_text($post['msg'])?> (<?= vremja($post['time'])?>)</div> </div> 
<?
}


?>
</div> </div> 





<?



    if (isset($user))
    {


/*
    	if ($user['id']!= $post['id_user'] &&  $post['id_user']!=0) 
    	{
    		echo "<a href=\"/forum/$forum[id]/$razdel[id]/$them[id]/?spam=$post[id]&amp;page=$page\" title='Это спам'  class='link_s'><img src='/style/icons/blicon.gif' alt='*' title='Это спам'></a>\n";
    	}
*/


    }

}

if ((user_access('forum_post_ed') || isset($user) && $ank2['id']==$user['id']) && isset($_GET['act']) && $_GET['act']=='post_delete'){}
elseif ($k_page>1)str("/forum/$forum[id]/$razdel[id]/$them[id]/?",$k_page,$page); 

if ((user_access('forum_post_ed') || isset($user) && $ank2['id']==$user['id']) && isset($_GET['act']) && $_GET['act']=='post_delete'){}
elseif (isset($user) && ($them['close']==0 || $them['close']==1 && user_access('forum_post_close')))
{
?>
<a name="page-down"></a>
<div class="comm_form"> <div id="comments_form_wrap"><div id="comments_form"> 
<?

    if ($user['set_files']==1)
    echo "<form method='post' name='message' enctype='multipart/form-data' action='/forum/$forum[id]/$razdel[id]/$them[id]/new?page=$page&amp;$passgen&amp;".$go_otv."'>\n";
    else
    echo "<form method='post' name='message' action='/forum/$forum[id]/$razdel[id]/$them[id]/new?page=$page&amp;$passgen&amp;".$go_otv."'>\n";
 	
 	if (isset($_POST['msg']) && isset($_POST['file_s']))
    	$msg2=output_text($_POST['msg'],false,true,false,false,false); else $msg2=NULL;
?>
<div class="wrapper block pd0">

<div class="block  js-toolbar_wrap">  <div class="text-input__wrap"> 
<div class="cl" style="margin-bottom: 5px;"> <div class="relative">  
<div class="input-txt_wrapper"> 
<textarea class="input-txt" tabindex="1" name="msg" rows="4" id="textarea" data-maxlength="2000" data-toolbar="{hide:true,disable:{}}" cols="17" placeholder="Напишите комментарий"><?= $msg2?></textarea> 
</div> </div> </div>    </div> </div>

<div class="block wide pdt"><div class="cf">
<?

   

    if ($user['set_files']==1)
    {
        if (isset($_SESSION['file']))
        {
            echo "Прикрепленные файлы:<br />\n";
            for ($i=0; $i<count($_SESSION['file']);$i++)
            {
                if (isset($_SESSION['file'][$i]) && is_file($_SESSION['file'][$i]['tmp_name']))
                {
                    echo "<img src='/style/themes/$set[set_them]/forum/14/file.png' alt='' />\n";
                    echo $_SESSION['file'][$i]['name'].'.'.$_SESSION['file'][$i]['ras'].' (';
                    echo size_file($_SESSION['file'][$i]['size']);
                    echo ") <a href='/forum/$forum[id]/$razdel[id]/$them[id]/d_file$i' title='Удалить из списка'><img src='/style/themes/$set[set_them]/forum/14/del_file.png' alt='' /></a>\n";
                    echo "<br />\n";
                }
            }
        }

        echo "<input name='file_f' type='file' /><br />\n";
        echo "<input name='file_s' value='Прикрепить файл' type='submit' class='main_submit'/><br />\n";
    }


?>
          
<input name="post" value="Отправить" class="main_submit right" type="submit">  
</div> </div>
</div>
</form>
</div></div></div>
<?
}