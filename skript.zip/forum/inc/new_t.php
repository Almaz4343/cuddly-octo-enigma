<?
$set['title'] = 'Новая тема : '.text($forum['name']).' : '.text($razdel['name']).' : Форум'; // заголовок страницы
include_once '../sys/inc/thead.php';
title();

if (isset($_POST['name']) && isset($_POST['msg']))
{

if (isset($_SESSION['time_c_t_forum']) && $_SESSION['time_c_t_forum']>$time-600 && $user['level']==0)$err='Нельзя так часто создавать темы';

$name=my_esc($_POST['name']);

if (strlen2($name)<3)$err[] = 'Короткое название для темы';
if (strlen2($name)>32)$err[] = 'Название темы не должно быть длиннее 32-х символов';

$mat = antimat($name);
if ($mat)$err[] = 'В названии темы обнаружен мат: '.$mat;


$msg = $_POST['msg'];
if (strlen2($msg)<10)$err[]='Короткое сообщение';
if (strlen2($msg)>30000)$err[]='Длина сообщения превышает предел в 30 000 символа';

$mat = antimat($msg);
if ($mat)$err[]='В тексте сообщения обнаружен мат: '.$mat;

$msg = my_esc($msg);

if (!isset($err))
{
$_SESSION['time_c_t_forum']=$time;

mysql_query("INSERT INTO `forum_t` (`id_forum`, `id_razdel`, `time_create`, `id_user`, `name`, `time`, `text`) values('$forum[id]', '$razdel[id]', '$time', '$user[id]', '$name', '$time', '$msg')");
$them['id'] = mysql_insert_id();

// Выгрузка файла 
if (isset($_FILES['forum_upload'])){
$name = my_esc(preg_replace('#\.[^\.]*$#', NULL, $_FILES['forum_upload']['name']));
$ras = my_esc(strtolower(preg_replace('#^.*\.#', NULL, $_FILES['forum_upload']['name'])));
		
if ($ras == 'png' || $ras == 'jpg' ||$ras == 'jpeg' ||$ras == 'gif'){

mysql_query("INSERT INTO `forum_filest` (`id_post`, `name`, `ras`) VALUES ('$them[id]', '$name', '$ras')");
$ID_FILE = mysql_insert_id();
		
if (move_uploaded_file($_FILES['forum_upload']['tmp_name'], H.'sys/tpic/forums/files/' . $ID_FILE . '.'.$ras)) {
	
if ($imgc = @imagecreatefromstring(file_get_contents(H.'sys/tpic/forums/files/' . $ID_FILE . '.'.$ras))){

$img_x = imagesx($imgc);
$img_y = imagesy($imgc);
				
if ($img_x == $img_y)
{
$dstW = 150; // ширина
$dstH = 150; // высота 
}	
elseif ($img_x > $img_y){		
$prop = $img_x / $img_y;
$dstW = 150;
$dstH = ceil($dstW/$prop);
}	
else{
$prop = $img_y/$img_x;
$dstH = 150;
$dstW = ceil($dstH/$prop);
}
			
			
			
	$screen = imagecreatetruecolor($dstW, $dstH);
	imagecopyresampled($screen, $imgc, 0, 0, 0, 0, $dstW, $dstH, $img_x, $img_y);
	imagedestroy($imgc);
	//$screen=img_copyright($screen); // наложение копирайта
	imagegif($screen,H."sys/tpic/forums/screen/$ID_FILE.$ras");
	@chmod(H.'sys/tpic/forums/screen/' . $ID_FILE . '.'.$ras, 0777);
	imagedestroy($screen);
			
}
@chmod(H.'sys/tpic/forums/files/' . $ID_FILE . '.dat', 0777);
} 
else 
{
// Если файл не был загружен, удаляем запись..
mysql_query("DELETE FROM `forum_filest` WHERE `id` = '" . $ID_FILE . "'");
}
}
}
// end

$q = mysql_query("SELECT * FROM `frends` WHERE `user` = '".$user['id']."' AND `i` = '1'");
while ($f = mysql_fetch_array($q))
{
$a=get_user($f['frend']);
$lentaSet = mysql_fetch_array(mysql_query("SELECT * FROM `tape_set` WHERE `id_user` = '".$a['id']."' LIMIT 1")); // Общая настройка ленты
if ($f['lenta_forum'] == 1 && $lentaSet['lenta_forum'] == 1)
mysql_query("INSERT INTO `tape` (`id_user`, `avtor`, `type`, `time`, `id_file`) values('$a[id]', '$user[id]', 'them', '$time', '$them[id]')"); 
}

// Активность
mysql_query("INSERT INTO `user_activity` (`id_user`, `avtor`, `type`, `time`, `id_file`) values('$user[id]', '$user[id]', 'them', '$time', '$them[id]')"); 



mysql_query("UPDATE `forum_r` SET `time` = '$time' WHERE `id` = '$razdel[id]' LIMIT 1");
$_SESSION['message'] = 'Тема успешно создана';
header("Location: /forum/$forum[id]/$razdel[id]/$them[id]/");
exit;
}

}

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  
<a href="/" style="font-size:0;"> <img src="//c.spac.me/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/forum/">Форум</a> </span>     <span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> 
<a href="/forum/<?= $forum['id']?>/"><?= text($forum['name'])?></a> </span>     <span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> 
<a href="/forum/<?= $forum['id']?>/<?= $razdel['id']?>/"><?= text($razdel['name'])?></a> </span>     <span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Новая тема</span> </span>       </div>
<?

err();

?>
<div class="wrapper">
<?
if ($user['set_files'] == 1)
echo "<form method=\"post\" name='message'  enctype='multipart/form-data' action=\"/forum/$forum[id]/$razdel[id]/?act=new\">"; 
else
echo "<form method=\"post\" name='message' action=\"/forum/$forum[id]/$razdel[id]/?act=new\">";

?>
<div class="wbg">  
<div class="block"> 
<label class="lbl"> Тема (32 знаков): </label> 
<div class="input-txt_wrapper"> <input class="input-txt" name="name" id="subject" maxlength="32" value="" type="text"> </div>  
</div>  
<div class="block  js-toolbar_wrap">  
<label class="lbl">Запись (30000 знаков):</label>  
<div class="text-input__wrap"> <div class="cl" style="margin-bottom: 5px;"> 
<div class="relative">  <div class="input-txt_wrapper"> 
<textarea class="input-txt" tabindex="1" name="msg" rows="5" id="textarea" data-maxlength="30000" data-toolbar="{activeAttaches:true,disable:{&quot;bgcolor&quot;:1}}" cols="17"></textarea> 
</div> </div> 
</div>  </div> 
</div>       </div>
<?
if ($user['set_files'] == 1){
?>
<div class="block">  
<div> Прикрепить:
<input name="forum_upload" type="file" multiple accept="image/*,image/jpeg"/>
</div>    
<div>  
</div> </div>
<?
}

?>
<div class="block">  <div> <input value="Добавить" class="main_submit" id="mainSubmitForm" type="submit"> </div>  </div>
<div class="block pdt text_right"> 
<div class="grey"> Помощь: 
<a href="/plugins/smiles/?">Смайлы</a> |  
<a href="/plugins/rules/bb-code.php">Теги</a> 
</div>  
</div>
</form>
</div>

<a href="/forum/<?= $forum['id']?>/<?= $razdel['id']?>/" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?



?>