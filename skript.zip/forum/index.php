<?

include_once '../sys/inc/start.php';

include_once '../sys/inc/compress.php';

include_once '../sys/inc/sess.php';

include_once '../sys/inc/home.php';

include_once '../sys/inc/settings.php';

include_once '../sys/inc/db_connect.php';

include_once '../sys/inc/ipua.php';

include_once '../sys/inc/fnc.php';

include_once '../sys/inc/user.php';



/* Бан пользователя */ 

if (mysql_result(mysql_query("SELECT COUNT(*) FROM `ban` WHERE `razdel` = 'forum' AND `id_user` = '$user[id]' AND (`time` > '$time' OR `view` = '0' OR `navsegda` = '1')"), 0)!=0)
{
header('Location: /ban.php?'.SID);exit;
}







if (isset($_GET['id_forum']) && mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_f` WHERE".((!isset($user) || $user['level']==0)?" `adm` = '0' AND":null)." `id` = '".intval($_GET['id_forum'])."'"),0)==1

&& isset($_GET['id_razdel']) && mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_r` WHERE `id` = '".intval($_GET['id_razdel'])."' AND `id_forum` = '".intval($_GET['id_forum'])."'"),0)==1

&& isset($_GET['id_them']) && mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_t` WHERE `id` = '".intval($_GET['id_them'])."' AND `id_razdel` = '".intval($_GET['id_razdel'])."' AND `id_forum` = '".intval($_GET['id_forum'])."'"),0)==1

&& isset($_GET['id_post']) && mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_p` WHERE `id` = '".intval($_GET['id_post'])."' AND `id_them` = '".intval($_GET['id_them'])."' AND `id_razdel` = '".intval($_GET['id_razdel'])."' AND `id_forum` = '".intval($_GET['id_forum'])."'"),0)==1

)

{

$forum=mysql_fetch_assoc(mysql_query("SELECT * FROM `forum_f` WHERE `id` = '".intval($_GET['id_forum'])."' LIMIT 1"));

$razdel=mysql_fetch_assoc(mysql_query("SELECT * FROM `forum_r` WHERE `id` = '".intval($_GET['id_razdel'])."' AND `id_forum` = '".intval($_GET['id_forum'])."' LIMIT 1"));

$them=mysql_fetch_assoc(mysql_query("SELECT * FROM `forum_t` WHERE `id` = '".intval($_GET['id_them'])."' AND `id_razdel` = '".intval($_GET['id_razdel'])."' AND `id_forum` = '".intval($_GET['id_forum'])."' LIMIT 1"));

$post=mysql_fetch_assoc(mysql_query("SELECT * FROM `forum_p` WHERE `id` = '".intval($_GET['id_post'])."' AND `id_them` = '".intval($_GET['id_them'])."' AND `id_razdel` = '".intval($_GET['id_razdel'])."' AND `id_forum` = '".intval($_GET['id_forum'])."' LIMIT 1"));

$post2=mysql_fetch_assoc(mysql_query("SELECT * FROM `forum_p` WHERE `id_them` = '".intval($_GET['id_them'])."' AND `id_razdel` = '".intval($_GET['id_razdel'])."' AND `id_forum` = '".intval($_GET['id_forum'])."' ORDER BY `id` DESC LIMIT 1"));

if (isset($user)){

$ank=get_user($post['id_user']);



if (isset($_GET['act']) && $_GET['act']=='edit' && isset($_POST['msg']) && isset($_POST['post']) &&

 // редактирование поста

(

(user_access('forum_post_ed')) 

// права группы на редактирование

||

(isset($user) && $user['id']==$post['id_user'] && $post['time']>time()-600 && $post['id_user']==$post2['id_user']) 

// право на редактирование своего поста, если он поседний в теме

)

)

{





$msg=$_POST['msg'];

if (isset($_POST['translit']) && $_POST['translit']==1)$msg=translit($msg);

if (strlen2($msg)<2)$err[]='Короткое сообщение';

if (strlen2($msg)>1024)$err[]='Длина сообщения превышает предел в 1024 символа';



$mat=antimat($msg);

if ($mat)$err[]='В тексте сообщения обнаружен мат: '.$mat;



if (!isset($err))mysql_query("UPDATE `forum_p` SET `msg` = '".my_esc($msg)."' WHERE `id` = '$post[id]' LIMIT 1");

}

elseif (isset($_GET['act']) && $_GET['act']=='edit' && (user_access('forum_post_ed') && ($ank['level']<$user['level'] || $ank['level']==$user['level'] && $ank['id']==$user['id']) || isset($user) && $post['id']==$post2['id'] && $post['id_user']==$user['id'] && $post['time']>time()-600)){



$set['title']='Форум - редактирование поста'; // заголовок страницы

include_once '../sys/inc/thead.php';

title();





echo "<form method='post' name='message' action='/forum/$forum[id]/$razdel[id]/$them[id]/$post[id]/edit'>\n";

$msg2=output_text($post['msg'],false,true,false,false,false);

if ($set['web'] && is_file(H.'style/themes/'.$set['set_them'].'/altername_post_form.php'))

include_once H.'style/themes/'.$set['set_them'].'/altername_post_form.php';

else

echo "Сообщение:<br />\n<textarea name=\"msg\">".$msg2."</textarea><br />\n";

echo "<input name='post' value='Изменить' type='submit' /><br />\n";

echo "</form>\n";

echo "<div class=\"foot\">\n";

echo "<img src='/style/icons/str2.gif' alt='*'> <a href=\"/forum/$forum[id]/$razdel[id]/$them[id]/?page=end\" title='Вернуться в тему'>В тему</a><br />\n";

echo "<img src='/style/icons/str2.gif' alt='*'> <a href=\"/forum/$forum[id]/$razdel[id]/\" title='В раздел'>" . text($razdel['name']) . "</a><br />\n";

echo "<img src='/style/icons/str2.gif' alt='*'> <a href=\"/forum/$forum[id]/\" title='В подфорум'>" . text($forum['name']) . "</a><br />\n";

echo "<img src='/style/icons/str2.gif' alt='*'> <a href=\"/forum/\">Форум</a><br />\n";

echo "</div>\n";

include_once '../sys/inc/tfoot.php';

}

elseif (isset($_GET['act']) && $_GET['act']=='delete' && isset($user) && $them['close']==0 && ((user_access('forum_post_ed') && ($ank['level']<=$user['level'] || $ank['level']==$user['level'] && $ank['id']==$user['id'])) || $post['id']==$post2['id'] && $post['id_user']==$user['id'] && $post['time']>time()-600)){

mysql_query("DELETE FROM `forum_p` WHERE `id` = '".intval($_GET['id_post'])."' AND `id_them` = '".intval($_GET['id_them'])."' AND `id_razdel` = '".intval($_GET['id_razdel'])."' AND `id_forum` = '".intval($_GET['id_forum'])."' LIMIT 1");

}

elseif (isset($_GET['act']) && $_GET['act']=='msg' && $them['close']==0 && isset($user)){

$ank=get_user($post['id_user']);

$set['title']='Форум - '.text($them['name']); // заголовок страницы

include_once '../sys/inc/thead.php';

title();

aut();





echo "<form method='post' name='message' action='/forum/$forum[id]/$razdel[id]/$them[id]/new'>\n";

echo "<a href='/user/?id=$ank[id]'>Посмотреть анкету</a><br />\n";

$msg2=$ank['nick'].', ';

if ($set['web'] && is_file(H.'style/themes/'.$set['set_them'].'/altername_post_form.php'))

include_once H.'style/themes/'.$set['set_them'].'/altername_post_form.php';

else

echo "Сообщение:<br />\n<textarea name=\"msg\">$ank[nick], </textarea><br />\n";

echo "<input name='post' value='Отправить сообщение' type='submit' /><br />\n";

echo "</form>\n";

echo "<div class=\"foot\">\n";

echo "<img src='/style/icons/str.gif' alt='*'> <a href=\"/smiles.php\">Смайлы</a><br />\n";

echo "<img src='/style/icons/str.gif' alt='*'> <a href=\"/rules.php\">Правила</a><br />\n";

echo "</div>\n";



echo "<div class=\"foot\">\n";

echo "<img src='/style/icons/str2.gif' alt='*'> <a href=\"/forum/$forum[id]/$razdel[id]/$them[id]/?page=end\" title='Вернуться в тему'>В тему</a><br />\n";

echo "<img src='/style/icons/str2.gif' alt='*'> <a href=\"/forum/$forum[id]/$razdel[id]/\" title='В раздел'>" . text($razdel['name']) . "</a><br />\n";

echo "<img src='/style/icons/str2.gif' alt='*'> <a href=\"/forum/$forum[id]/\" title='В подфорум'>" . text($forum['name']) . "</a><br />\n";

echo "<img src='/style/icons/str2.gif' alt='*'> <a href=\"/forum/\">Форум</a><br />\n";



echo "</div>\n";

include_once '../sys/inc/tfoot.php';

}

elseif (isset($_GET['act']) && $_GET['act']=='cit' && $them['close']==0 && isset($user)){

//$ank=mysql_fetch_assoc(mysql_query("SELECT * FROM `user` WHERE `id` = $post[id_user] LIMIT 1"));

$ank=get_user($post['id_user']);

$set['title']='Форум - '.text($them['name']); // заголовок страницы

include_once '../sys/inc/thead.php';

title();

aut();

echo "Будет процетировано сообщение:<br />\n";



echo "<div class='cit'>\n";

echo output_text($post['msg'])."<br />\n";

echo "</div>\n";

echo "<form method='post' name='message' action='/forum/$forum[id]/$razdel[id]/$them[id]/new'>\n";

echo "<input name='cit' value='$post[id]' type='hidden' />";

$msg2=$ank['nick'].', ';

if ($set['web'] && is_file(H.'style/themes/'.$set['set_them'].'/altername_post_form.php'))

include_once H.'style/themes/'.$set['set_them'].'/altername_post_form.php';

else

echo "Сообщение:<br />\n<textarea name=\"msg\">$ank[nick], </textarea><br />\n";

echo "<input name='post' value='Отправить сообщение' type='submit' /><br />\n";

echo "</form>\n";





echo "<div class=\"foot\">\n";

echo "<img src='/style/icons/str2.gif' alt='*'> <a href=\"/forum/$forum[id]/$razdel[id]/$them[id]/?page=end\" title='Вернуться в тему'>В тему</a><br />\n";

echo "<img src='/style/icons/str2.gif' alt='*'> <a href=\"/forum/$forum[id]/$razdel[id]/\" title='В раздел'>" . text($razdel['name']) . "</a><br />\n";

echo "<img src='/style/icons/str2.gif' alt='*'> <a href=\"/forum/$forum[id]/\" title='В подфорум'>" . text($forum['name']) . "</a><br />\n";

echo "<img src='/style/icons/str2.gif' alt='*'> <a href=\"/forum/\">Форум</a><br />\n";

echo "</div>\n";

include_once '../sys/inc/tfoot.php';

}



}





}















if (isset($_GET['id_forum']) && mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_f` WHERE".((!isset($user) || $user['level']==0)?" `adm` = '0' AND":null)." `id` = '".intval($_GET['id_forum'])."'"),0)==1

&& isset($_GET['id_razdel']) && mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_r` WHERE `id` = '".intval($_GET['id_razdel'])."' AND `id_forum` = '".intval($_GET['id_forum'])."'"),0)==1

&& isset($_GET['id_them']) && mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_t` WHERE `id` = '".intval($_GET['id_them'])."' AND `id_razdel` = '".intval($_GET['id_razdel'])."' AND `id_forum` = '".intval($_GET['id_forum'])."'"),0)==1 )

{

$forum=mysql_fetch_assoc(mysql_query("SELECT * FROM `forum_f` WHERE `id` = '".intval($_GET['id_forum'])."' LIMIT 1"));

$razdel=mysql_fetch_assoc(mysql_query("SELECT * FROM `forum_r` WHERE `id` = '".intval($_GET['id_razdel'])."' AND `id_forum` = '".intval($_GET['id_forum'])."' LIMIT 1"));

$them=mysql_fetch_assoc(mysql_query("SELECT * FROM `forum_t` WHERE `id` = '".intval($_GET['id_them'])."' AND `id_razdel` = '".intval($_GET['id_razdel'])."' AND `id_forum` = '".intval($_GET['id_forum'])."' LIMIT 1"));

/*
===============================
Помечаем уведомление прочитанным
===============================
*/

	mysql_query("UPDATE `notification` SET `read` = '1' WHERE `id_object` = '$them[id]' AND `type` = 'them_komm' AND `id_user` = '$user[id]'");

	/*------------очищаем счетчик этого обсуждения-------------*/

	if (isset($user)){

		mysql_query("UPDATE `discussions` SET `count` = '0' WHERE `id_user` = '$user[id]' AND `type` = 'them' AND `id_sim` = '$them[id]' LIMIT 1");
	}

	/*---------------------------------------------------------*/

$set['title']='Форум - '.text($them['name']); // заголовок страницы

include_once '../sys/inc/thead.php';

title();

$ank2=get_user($them['id_user']);





include 'inc/set_them_act.php';



include 'inc/them.php';





include 'inc/set_them_form.php';




// Низ темы
include_once '../sys/inc/tfoot.php';

}



if (isset($_GET['id_forum']) && mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_f` WHERE".((!isset($user) || $user['level']==0)?" `adm` = '0' AND":null)." `id` = '".intval($_GET['id_forum'])."'"),0)==1

&& isset($_GET['id_razdel']) && mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_r` WHERE `id` = '".intval($_GET['id_razdel'])."' AND `id_forum` = '".intval($_GET['id_forum'])."'"),0)==1)

{

$forum=mysql_fetch_assoc(mysql_query("SELECT * FROM `forum_f` WHERE `id` = '".intval($_GET['id_forum'])."' LIMIT 1"));

$razdel=mysql_fetch_assoc(mysql_query("SELECT * FROM `forum_r` WHERE `id` = '".intval($_GET['id_razdel'])."' AND `id_forum` = '".intval($_GET['id_forum'])."' LIMIT 1"));



if (isset($user) && isset($_GET['act']) && $_GET['act']=='new' && (!isset($_SESSION['time_c_t_forum']) || $_SESSION['time_c_t_forum']<$time-600 || $user['level']>0))

include 'inc/new_t.php'; // создание новой темы

else

{

$set['title'] = text($forum['name']).' : '.text($razdel['name']).' : Форум'; // заголовок страницы

include_once '../sys/inc/thead.php';

title();



if (user_access('forum_razd_edit'))include 'inc/set_razdel_act.php';


?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/forum/">Форум</a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/forum/<?= $forum['id']?>/"><?= text($forum['name'])?></a> </span>   <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/forum/<?= $forum['id']?>/<?= $razdel['id']?>/"><?= text($razdel['name'])?></a> </span>    </div>
<?

err();



if (isset($user) && (!isset($_SESSION['time_c_t_forum']) || $_SESSION['time_c_t_forum'] < $time-600 || $user['level'] > 0))
{
?>
<div class="bottom_link_block ">  
<a href="?act=new" class="arrow_link"><img src="/style/i/lj.gif" alt="" class="m p16"> <span class="middle">Новая тема</span></a>  
</div>
<?
}

$set['p_str'] = '20';
$k_post=mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_t` WHERE `id_forum` = '$forum[id]' AND `id_razdel` = '$razdel[id]'"),0);
$k_page=k_page($k_post,$set['p_str']);
$page=page($k_page);
$start=$set['p_str']*$page-$set['p_str'];





$q=mysql_query("SELECT * FROM `forum_t` WHERE `id_forum` = '$forum[id]' AND `id_razdel` = '$razdel[id]' ORDER BY `up` DESC,`time` DESC  LIMIT $start, $set[p_str]");

if (mysql_num_rows($q)==0) 
{
?>
<div class="col_blocks block">  Раздел <b><?= text($razdel['name'])?></b> пуст.</div>
<?
}	

while ($them = mysql_fetch_assoc($q))
{

$ank = get_user($them['id_user']);
$post2 = mysql_fetch_assoc(mysql_query("SELECT * FROM `forum_p` WHERE `id_them` = '$them[id]' AND `id_razdel` = '$razdel[id]' AND `id_forum` = '$forum[id]' ORDER BY `time` DESC LIMIT 1"));
$ank2 = get_user($post2['id_user']);

$commentt = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_p` WHERE `id_forum` = '$forum[id]' AND `id_razdel` = '$razdel[id]' AND `id_them` = '$them[id]'"),0);

?>
<div class="light_border_bottom t-bg3 attaches_limiter"> 
<a href="<?= $them['id']?>/" class="t-block_item stnd_padd t-link_no_underline_block"> 
<span class="t-block_item oh"> <span class="comment_date right_fix"><?= vremja($them['time_create'])?></span> 
<?
if($them['up'] == 1){
?> 
<img src="/style/i/stick.gif" alt="" class="p16">  
<?
}
?>
<span class="t-strong_item t-link_item_hover"><?= text($them['name'])?></span> <span class="grey">(<?= $commentt?>)</span>    
<?
if($them['close'] == 1){
?>
<img src="/style/i/topic_locked.gif" class="p16" alt="">
<?
}
if (mysql_result(mysql_query("SELECT COUNT(id) FROM `forum_filest` WHERE `id_post` = '$them[id]'"), 0) > 0){
?>
<img src="/style/i/skrepka.png" class="p16" alt="">
<?
}
?>  
<br> 
<span class="grey"><?= $ank['nick']?> 
<?
if ($ank2['id']){
?>
 / <?= $ank2['nick']?>  (<?= vremja($post2['time'])?>)
<?
}
?>
</span> </span> 
</a>   
</div>
<?

}


if ($k_page>1)str("/forum/$forum[id]/$razdel[id]/?",$k_page,$page); // Вывод страниц







if (user_access('forum_razd_edit')){

?>
<div class="bottom_link_block lh_160"> 
 
<a href="?act=set" class="arrow_link">
<img src="/style/i/edit.gif" alt="" class="m p16"> <span class="middle">Параметры раздела</span>
</a>  <br>
<a href="?act=mesto" class="arrow_link">
<img src="/style/i/move.png" alt="" class="m p16"> <span class="middle">Переместить раздел</span>
</a>   <br>
<a href="?act=del" class="arrow_link">
<img src="/style/i/cross_r.gif" alt="" class="m p16"> <span class="middle">Удалить раздел</span>
</a>  


</div>
<?

include 'inc/set_razdel_form.php';
}


?>
<a href="/forum/<?= $forum['id']?>/" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?

}





include_once '../sys/inc/tfoot.php';

}



if (isset($_GET['id_forum']) && mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_f` WHERE".((!isset($user) || $user['level']==0)?" `adm` = '0' AND":null)." `id` = '".intval($_GET['id_forum'])."'"),0)==1)

{

$forum = mysql_fetch_assoc(mysql_query("SELECT * FROM `forum_f` WHERE `id` = '".intval($_GET['id_forum'])."' LIMIT 1"));



$set['title'] = text($forum['name']) . ' : Форум';

include_once '../sys/inc/thead.php';

title();



include 'inc/set_forum_act.php'; // действия над подфорумом


?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/forum/">Форум</a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/forum/<?= $forum['id']?>/"><?= text($forum['name'])?></a> </span>       </div>
<?

err();




$set['p_str'] = '20';
$k_post=mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_r` WHERE `id_forum` = '$forum[id]'"),0);
$k_page=k_page($k_post,$set['p_str']);
$page=page($k_page);
$start=$set['p_str']*$page-$set['p_str'];



$q=mysql_query("SELECT * FROM `forum_r` WHERE `id_forum` = '$forum[id]' ORDER BY `time` DESC LIMIT $start, $set[p_str]");

if (mysql_num_rows($q)==0) {
?>
<div class="col_blocks block">  Разделы не найдены.  </div>
<?
}	

while ($razdel = mysql_fetch_assoc($q))
{

$coll_for = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_p` WHERE `id_forum` = '$forum[id]' AND `id_razdel` = '$razdel[id]'"),0).'/'.mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_t` WHERE `id_forum` = '$forum[id]' AND `id_razdel` = '$razdel[id]'"),0);

?>
<div class="light_border_bottom oh t-bg3">  
<a href="/forum/<?= $forum['id']?>/<?= $razdel['id']?>/" class="t-block_item t-padd_right t-link_no_underline_block oh"> 
<span class="t-block_item stnd_padd t-bg_arrow_next">  <span class="oh inl_bl m"> 
<span class="t-strong_item t-link_item_hover"><?= text($razdel['name'])?></span> 
<span style="color: #000000;"> [<?= $coll_for?>] </span>   
</span>  
<?
if($razdel['opis'] != null){
?>
<br><span class="grey"><?= output_text($razdel['opis'])?></span> 
<?
}
?> 
</span> 
</a> 
</div>
<?

}

if ($k_page>1)str("/forum/$forum[id]/?",$k_page,$page); // Вывод страниц

if (user_access('forum_razd_create') || user_access('forum_for_edit') || user_access('forum_for_delete'))
{
?>
<div class="bottom_link_block lh_160">   
<?

if(user_access('forum_razd_create')){
?> 
<a class="arrow_link" href="?act=new"> 
<img src="/style/i/lj.gif" alt="" class="icon p16"> <span>Новый раздел</span> 
</a>  <br>  
<?
}


if(user_access('forum_for_edit')){
?> 
<a class="arrow_link" href="?act=set"> 
<img src="/style/i/edit.gif" alt="" class="icon p16"> <span>Параметры форума</span> 
</a>  <br>  
<?
}

if(user_access('forum_for_delete')){
?> 
<a class="arrow_link" href="?act=del"> 
<img src="/style/i/cross_r.gif" alt="" class="icon p16"> <span>Удалить форум</span> 
</a>  <br>  
<?
} 

?>
</div>
<?
}


?>
<a href="/forum/" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?

include 'inc/set_forum_form.php'; // формы действий над подфорумом







include_once '../sys/inc/tfoot.php';

}





$set['title'] = 'Форум : Разделы'; // заголовок страницы
include_once '../sys/inc/thead.php';
title();

// Создание раздела
if (user_access('forum_for_create') && isset($_GET['act']) && isset($_GET['ok']) && $_GET['act']=='new' && isset($_POST['name']) && isset($_POST['opis']) && isset($_POST['pos']))
{

$name = my_esc($_POST['name']);

if (strlen2($name)<3){
	$err='Короткое название раздела';
}
if (strlen2($name)>32){
	$err='Днинное название раздела';
}

$opis = $_POST['opis'];

if (strlen2($opis)>512){
	$err='Длинное описание раздела';
}
$opis = my_esc($opis);



$pos = intval($_POST['pos']);

if (!isset($err)){

admin_log('Форум','Подфорумы',"Создание подфорума '$name'");

mysql_query("INSERT INTO `forum_f` (`opis`, `name`, `pos`) values('$opis', '$name', '$pos')");

msg('Раздел успешно создан');

}

}







err();


if (user_access('forum_for_create') && (isset($_GET['act']) && $_GET['act'] == 'new' || mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_f`"),0)==0))
{

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/forum/">Форум</a> </span>          </div>

<a href="/forum/" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>

<div class="wrapper">  
<div class="block pdb t_center"> <div class="upcs b"> Новый раздел </div> </div>  
<form method="post" action="?act=new&amp;ok">

<div class="block pdb"> <div> <div class="input-txt_wrapper"> 
<label class="lbl">Название:</label> 
<input class="input-txt" name="name" maxlength="32" value="" type="text">  
</div> </div> </div>

<div class="block pdb"> <div> <div class="input-txt_wrapper"> 
<label class="lbl">Описание:</label>  
 
<textarea placeholder="Введите описание" class="input-txt" rows="5" cols="17" name="opis" maxlength="512"></textarea>  
</div>   </div>   </div>
<?

$pos = mysql_result(mysql_query("SELECT MAX(`pos`) FROM `forum_f`"), 0)+1;

?>
<div class="block pdb"> <div> <div class="input-txt_wrapper"> 
<label class="lbl">Порядок (от 0 до <?= $pos?>):</label> 
<input class="input-txt" name="pos" size="3" value="<?= $pos?>" type="text">  
</div> </div> </div>

<div class="block"> <input value="Сохранить" class="main_submit" type="submit"> </div>

</form>
</div> 

<a href="/forum/" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?


include_once '../sys/inc/tfoot.php';
exit;

}else{





?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/forum/">Форум</a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Разделы</span> </span>       </div>

<div class="list_item oh"> 
<a class="arrow_link right" href="search.php"> <img src="/style/i/search.gif" alt="" class="m p16"> <span class="m">Поиск</span> </a> 
</div>

<div class="busi_switcher" style="border-left:0px;"> 
<table width="100%"> <tbody><tr>     
<td><a href="new.post.php">Последние</a></td>    
<td><a href="new.them.php">Новые</a></td>   
</tr> </tbody></table> 
</div>

<div>
<?






$q=mysql_query("SELECT * FROM `forum_f`".((!isset($user) || $user['level']==0)?" WHERE `adm` = '0'":null)." ORDER BY `pos` ASC");

if (mysql_num_rows($q)==0) {
?>
<div class="col_blocks block">  Подфорумы не найдены.  </div>
<?
}

while ($forum = mysql_fetch_assoc($q))

{
?>
<div class="light_border_bottom t-bg3 oh">  
<a href="/forum/<?= $forum['id']?>/" class="t-block_item t-padd_right t-link_no_underline_block oh"> 
<span class="t-block_item stnd_padd t-bg_arrow_next"> 
<b class="t-strong_item t-link_item_hover"><?= text($forum['name'])?></b>
<?
if ($forum['opis']!=NULL){
?> 
<br><span class="grey"><?= output_text($forum['opis'])?></span> </span>
<?
}
?> 
</a> 
</div>
<?
}

?>
</div>
<?



if (user_access('forum_for_create') && mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_f`"),0) > 0){
?>
<div class="bottom_link_block lh_160">  
<a href="?act=new" class="arrow_link">   
<img class="m p16" style="margin:0 1px;" src="/style/i/lj.gif" alt="">   <span class="m">Новый форум</span> 
</a>
<?
}
include_once '../sys/inc/tfoot.php';


}


?>