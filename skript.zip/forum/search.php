<?
include_once '../sys/inc/start.php';
include_once '../sys/inc/compress.php';
include_once '../sys/inc/sess.php';
include_once '../sys/inc/home.php';
include_once '../sys/inc/settings.php';
include_once '../sys/inc/db_connect.php';
include_once '../sys/inc/ipua.php';
include_once '../sys/inc/fnc.php';
include_once '../sys/inc/user.php';


/* Бан пользователя */ 
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `ban` WHERE `razdel` = 'forum' AND `id_user` = '$user[id]' AND (`time` > '$time' OR `view` = '0' OR `navsegda` = '1')"), 0)!=0){
	header('Location: /ban.php?'.SID);
	exit;
}


$searched = &$_SESSION['searched'];

if (!isset($searched) || isset($_GET['newsearch']) || isset($_GET['null']))
{
	// зануляем весь запрос
	$searched['in'] = array('m'=>null);
	$searched['text'] = null;
	$searched['query'] = null;
	$searched['sql_query'] = null;
	$searched['result'] = array();
	$searched['mark'] = array();
}


if (isset($_GET['newsearch']))
include 'inc/search_act.php';

// Заголовок страницы
$set['title']='Поиск по форуму : Форум';

include_once '../sys/inc/thead.php';
title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/forum/">Форум</a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Поиск по форуму</span> </span>       </div>
<?



err();

if (isset($_GET['newsearch']))
{
	if (count($searched['result'])!=0){
	?>
	<div class="stnd_padd light_border_bottom"> <b>Вы искали:</b> <span style="color:darkgreen"><?= htmlentities($searched['text'], ENT_QUOTES, 'UTF-8')?></span><br>  </div>
	<?
	}elseif(!isset($err)){
	?>
	<div class="stnd_padd light_border_bottom"> <b>Вы искали:</b> <span style="color:darkgreen"><?= htmlentities($searched['text'], ENT_QUOTES, 'UTF-8')?></span><br></div>
	<div class="list_item">По вашему запросу ничего не найдено.</div>
	<?
	}
}

$res = $searched['result'];

if (count($res)!=0)
{
	$k_post = count($res);
	$k_page = k_page($k_post,$set['p_str']);
	$page = page($k_page);
	$start = $set['p_str'] * $page-$set['p_str'];
	$end = min($set['p_str'] * $page,$k_post);
	
	echo '<table class="post">';
		
	for($i = $start; $i < $end; $i++)
	{
		$them = $res[$i];
	
		if (mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_p` WHERE `id_them` = '$them[id]'"),0) == $them['k_post'])
		{
			// Определение подфорума
			$forum = mysql_fetch_array(mysql_query("SELECT * FROM `forum_f` WHERE `id` = '$them[id_forum]' LIMIT 1"));
			
			// Определение раздела
			$razdel = mysql_fetch_array(mysql_query("SELECT * FROM `forum_r` WHERE `id` = '$them[id_razdel]' LIMIT 1"));
			// Счетчик
			$lolo = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_p` WHERE `id_forum` = '$forum[id]' AND `id_razdel` = '$razdel[id]' AND `id_them` = '$them[id]'"),0);
			
			
?>
<div class="stnd_padd light_border_bottom overfl_hid">  
<a href="/forum/<?= $forum['id']?>/<?= $razdel['id']?>/<?= $them['id']?>/"><?= text($them['name'])?></a> 
<span class="grey">(<?= $lolo?>)</span>  
</div>
<?

			

		}
		
	}
	
	echo '</table>';
	
	if ($k_page > 1)str('?',$k_page,$page); // Вывод страниц
?>
<a href="?" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Новый поиск  </a>
<?	
}
else
{
?>
<div class="stnd_padd light_border_bottom suggest_parent"> 
<form method="post" action="?newsearch=<?= $passgen?>"> 
<label for="word">Искать:</label> <br>
<input name="text" id="word" value="<?= htmlentities($searched['text'], ENT_QUOTES, 'UTF-8')?>" class="search_suggest" maxlength="64" type="text"><br>

<div class="pad_t_a">
<label for="word">Место поиска:</label> <br>
<select name="in">
<option value="">Везде</option>
<?

$q = mysql_query("SELECT `id`,`name` FROM `forum_f`".((!isset($user) || $user['level']==0)?" WHERE `adm` = '0'":null)." ORDER BY `pos` ASC");
while ($forums = mysql_fetch_assoc($q))
{
	echo "<option value='f$forums[id]'".(($searched['in']['m']=='f' && $searched['in']['id']==$forums['id'])?" selected='selected'":null).">&gt;&gt; " . htmlspecialchars($forums['name']) . "</option>\n";
	
	$q2 = mysql_query("SELECT `id`,`name` FROM `forum_r` WHERE `id_forum` = '$forums[id]' ORDER BY `time` DESC");
	
	while ($razdels = mysql_fetch_assoc($q2))
	{
		echo "<option value='r$razdels[id]'".(($searched['in']['m']=='r' && $searched['in']['id']==$razdels['id'])?" selected='selected'":null).">&gt; " . htmlspecialchars($razdels['name']) . "</option>\n";
	}
}
?>
</select></div>
<div class="pad_t_a"> <input value="Искать" class="main_submit" type="submit"> </div>
</form>
</div>
<?
}




include_once '../sys/inc/tfoot.php';
?>