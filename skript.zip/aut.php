<?

include_once 'sys/inc/start.php';
include_once 'sys/inc/compress.php';
include_once 'sys/inc/sess.php';
include_once 'sys/inc/home.php';
include_once 'sys/inc/settings.php';
include_once 'sys/inc/db_connect.php';
include_once 'sys/inc/ipua.php';
include_once 'sys/inc/fnc.php';

$show_all = true; // показ для всех

include_once 'sys/inc/user.php';

only_unreg();

if (isset($_GET['pass']) && $_GET['pass']='ok')
$_SESSION['message'] = 'Пароль отправлен вам на E-mail';


$set['title']='Вход';
include_once 'sys/inc/thead.php';
title();

if ((!isset($_SESSION['refer']) || $_SESSION['refer']==NULL)
&& isset($_SERVER['HTTP_REFERER']) && $_SERVER['HTTP_REFERER']!=NULL &&
!preg_match('#mail\.php#',$_SERVER['HTTP_REFERER']))
$_SESSION['refer']=str_replace('&','&amp;',preg_replace('#^http://[^/]*/#','/', $_SERVER['HTTP_REFERER']));


?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Вход</span> </span>       </div>
<div class="tabs_block oh">    
<div class="tab_item left tab_active black" style="padding: 12px 9px 8px 9px">  Вход  </div>   
<a href="/reg.php" class="tab_item left" style="padding: 12px 9px 8px 9px">  Регистрация  </a>   
</div>

<div class="wrapper"> 
<form action="/login.php" method="post" class="no_ajax">  
<div class="block error_wrapper first pdb">  <div>   <div class="input-txt_wrapper">  
<input placeholder="Ваш ник" class="input-txt" name="nick" value="" maxlength="87" type="text">  
</div>   </div>   </div> 
<div class="block error_wrapper pdb"> <div class="">  
<label class="lbl"> Введите пароль: </label>  
<div class="input-txt_wrapper"> 
<input maxlength="30" class="input-txt" name="pass" value="" type="password"> 
</div>   </div>  </div>  
<div class="block"> <div> 
<!-- --><!-- --><!-- --><!-- --><!-- -->
<button type="submit" value="Войти" class="  submit_link    link full  green-full   " id="cfms">
<!--   -->
<img src="/style/i/key_white.png" alt="" class="m"> <!--   --><span class="m"> Войти</span>
<!-- -->
</button><!-- --><!-- --> 
</div></div> 
</form>          
</div>

<div class="wrapper"> <div class="list f-c_fll">       
<a href="/pass.php" class="link  darkblue     "> 
<span> <img src="/style/i/lock_darkblue.png" alt="" class="m">      <span class="m">  Не можете войти? </span>          </span>  
</a>      
</div>       </div>
<?

include_once 'sys/inc/tfoot.php';
?>