<?
list($msec, $sec) = explode(chr(32), microtime());

?>
<div style="height: 1px;"></div> 
<?

if(isset($user)){
$style_panel2 = ' background: #'.$user['panelka_st'].';';
}else{
$style_panel2 = '';
}
if ($_SERVER['PHP_SELF'] == '/index.php') 
{
?>
<div class="list_item unauth_header ucsep vlight_border_bottom small lh_160" style="height:auto;<?= $style_panel2?>"> <a href="#">Контакты</a> · <a href="#">О нас</a> · <a href="#">Реклама</a> · <a href="/plugins/rules/">Правила</a> · <a href="#">Тех.поддержка</a> </div>
<?
}


?>  
</div>
<?


if ($_SERVER['PHP_SELF'] != '/index.php') 
{
// #677fb2; - это стандарт
$style_panel = ' style="background: #'.$user['panelka_st'].';"';
if(isset($user)){
?>
<div id="navi_footer" class="stnd_padd lh_160 ucsep"<?= $style_panel?>>  
<?
$links = mysql_query("SELECT * FROM `links_niz_user` WHERE `id_user` = '$user[id]' ORDER BY `id` ASC");
while ($post = mysql_fetch_array($links))
{
$link = mysql_fetch_array(mysql_query("SELECT * FROM `links_niz` WHERE `id` = '$post[id_link]' LIMIT 1"));
if($post['id_link'] == 1 || $post['id_link'] == 2){
$id = $user['id'];
}else{
$id = '';
}
?>
<a href="<?= $link['url'].$id?>"><?= text($link['mini_name'])?></a>  
<?
if($link > 0){
?> |  <?
}
}
?>
<a href="/user/settings/navi.php"> + </a>
</div>
<?
}
else{
?>
<div id="navi_footer" class="stnd_padd lh_160 ucsep">  
<a href="/">Главная</a> |  
<a href="/aut.php">Вход</a> |
<a href="/online.php">Онлайн</a> |     
<a href="/user/users.php">Люди</a>
</div>
<?
}
}

?>
</div>
</body>
</html>
<?
exit;
?>