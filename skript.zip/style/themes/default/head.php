<?
$set['web'] = false;
//header("Content-type: application/vnd.wap.xhtml+xml");
//header("Content-type: application/xhtml+xml");
header("Content-type: text/html");
echo '<?xml version="1.0" encoding="utf-8"?>';
?>
 <!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">   
<html xmlns="http://www.w3.org/1999/xhtml"> <head><title><?= $set['title']?></title>
<link rel="stylesheet" type="text/css" href="/style/themes/<?=$set['set_them']?>/touch_light_cache_r1364p.css" main_css="1"/>
<?
if(!isset($user)){
?>
<link rel="stylesheet" type="text/css" href="/style/themes/<?=$set['set_them']?>/not_auth_14_221_2_r1364p.css" main_css="1"/>
<?
}else{
?>
<link rel="stylesheet" type="text/css" href="/style/themes/<?=$set['set_them']?>/1404905599_r1364p.css" main_css="1"/>
<?
}
?>
<link rel="stylesheet" type="text/css" href="/style/themes/<?=$set['set_them']?>/AboutLite.css?r=1364p" data-tmp_css="1" />
<link rel="stylesheet" type="text/css" href="/style/themes/<?=$set['set_them']?>/Tile.css?r=1364p" data-tmp_css="1" />
<link rel="stylesheet" type="text/css" href="/style/themes/<?=$set['set_them']?>/ShrifT.css?r=1364p" data-tmp_css="1" />
<?
if ($_SERVER['PHP_SELF'] == '/user/blogs/index.php'){
?>
<link rel="stylesheet" type="text/css" href="/style/themes/<?=$set['set_them']?>/SubTabsWap.css?r=1364p" data-tmp_css="1" />
<?
}
if ($_SERVER['PHP_SELF'] == '/konts.php' || $_SERVER['PHP_SELF'] == '/new_mess.php'){
?>
<link rel="stylesheet" type="text/css" href="/style/themes/<?=$set['set_them']?>/MailMainMobile.css?r=1440p" data-tmp_css="1" />
<?
}
// Это для юзера шрифт, который он выбрал
if (isset($user)){
if($user['user_shrift']==0){ $Tw1nGo_ShrifT = '13';
}elseif($user['user_shrift']==1){ $Tw1nGo_ShrifT = '14';
}elseif($user['user_shrift']==2){ $Tw1nGo_ShrifT = '16';
}elseif($user['user_shrift']==3){ $Tw1nGo_ShrifT = '18';
}elseif($user['user_shrift']==4){ $Tw1nGo_ShrifT = '20';
}elseif($user['user_shrift']==5){ $Tw1nGo_ShrifT = '22';
}elseif($user['user_shrift']==6){ $Tw1nGo_ShrifT = '24'; }
}else{
// Это для гостя шрифт, стандарт 14, можете сменить на свой размер
$Tw1nGo_ShrifT = '14';
}
?>
</head><body  class="js-off font_<?= $Tw1nGo_ShrifT?> touch_light">
<div id="main_wrap" style="max-width:680px;margin: 0 auto;">
<?
if(!isset($user)){
?>
<div class="unauth_header"> 
<table width="100%" class="unauth_header" cellspacing="0" cellpadding="0"> <tr> 
<td class="to"> 
<a href="#" id="home_link" class="unauth_header__link unauth_header__link_menu"> 
<span class="m">Меню</span> </a> 
</td> <td class="to" style="width: 100%;"> 
<a href="/" class="unauth_header__link unauth_header__link_logo t_center">     
<img src="//c.spac.me/i/spaces.ru_logo_white.png" alt="" class="m" />     </a> 
</td> <td class="to"> 
<a href="/aut.php" class="unauth_header__link unauth_header__link_enter"> 
<span class="m">Вход</span> </a> 
</td> 
</tr> </table> 
</div>
<?
}

?>