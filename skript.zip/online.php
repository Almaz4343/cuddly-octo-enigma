<?
include_once 'sys/inc/start.php';
include_once 'sys/inc/compress.php';
include_once 'sys/inc/sess.php';
include_once 'sys/inc/home.php';
include_once 'sys/inc/settings.php';
include_once 'sys/inc/db_connect.php';
include_once 'sys/inc/ipua.php';
include_once 'sys/inc/fnc.php';
include_once 'sys/inc/user.php';


$set['title'] = 'Люди : Онлайн'; // заголовок страницы
include_once 'sys/inc/thead.php';
?>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
<script type="text/javascript">

$(document).ready(function () {
	$('[data-toggle]').on('click', function (e) {
		e.preventDefault();
		var $el = $(this);
		if ($el.hasClass('hide')) {
			$('#' + $el.attr('data-toggle')).hide();
			$el.removeClass('hide');
		}
		else {
			$el.addClass('hide');
			$('#' + $el.attr('data-toggle')).show();
		}
	})
});
</script>
<?

title();


$set['p_str'] = '15';
$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `user`"), 0);
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str']*$page-$set['p_str'];

$q = mysql_query("SELECT * FROM `user` ORDER BY `date_last` DESC LIMIT $start, $set[p_str]");

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/users.php">Люди</a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Онлайн</span> </span>       </div>

<div class="tabs_block oh">    
<a href="/user/users.php" class="tab_item left" style="padding: 12px 9px 8px 9px">  Популярные   </a>    
<div class="tab_item left tab_active black" style="padding: 12px 9px 8px 9px">  Онлайн  </div>   
<a href="/user/users.php?results_list" class="tab_item left" style="padding: 12px 9px 8px 9px">  Поиск  </a>  
</div>
<?

if ($k_post == 0)
{
?>
<div class="wrapper block">Нет онлайн людей</div>
<?
}

while ($ank = mysql_fetch_assoc($q))
{
$ank = get_user($ank['id']);

// Определяем сколько лет	
$ank['ank_age'] = null;
if ($ank['ank_d_r'] != NULL && $ank['ank_m_r'] != NULL && $ank['ank_g_r'] != NULL){
	$ank['ank_age'] = date("Y")-$ank['ank_g_r'];
	if (date("n") < $ank['ank_m_r'])
	$ank['ank_age'] = $ank['ank_age'] - 1;
	elseif (date("n") == $ank['ank_m_r']&& date("j") < $ank['ank_d_r'])
	$ank['ank_age'] = $ank['ank_age'] - 1;
}

$uSet = mysql_fetch_array(mysql_query("SELECT * FROM `user_set` WHERE `id_user` = '$ank[id]'  LIMIT 1"));
$frend = mysql_result(mysql_query("SELECT COUNT(*) FROM `frends` WHERE (`user` = '$user[id]' AND `frend` = '$ank[id]') OR (`user` = '$ank[id]' AND `frend` = '$user[id]') LIMIT 1"),0);
$frend_new = mysql_result(mysql_query("SELECT COUNT(*) FROM `frends_new` WHERE (`user` = '$user[id]' AND `to` = '$ank[id]') OR (`user` = '$ank[id]' AND `to` = '$user[id]') LIMIT 1"),0);

?>
<div class="js-row block bord-botm oh grey relative block-cntrl">      
  
<div class="left font0">   
<a href="/user/?id=<?= $ank['id']?>" class="tdn">       
<span class="pr">   <div class="inl_bl relative"> <?= ava80($ank['id'])?> </div>     </span>        
</a>  
</div> 
 
<div class="pre_content_wrap break-word"> 
<?= group($ank['id'])?>   
<a href="/user/?id=<?= $ank['id']?>" class="black full_link">   <b><?= unick($ank['id'])?></b>  </a>   <?= medal($ank['id'])?>       
<?
if($ank['rating'] > 0){
?>
<div class="inl_bl m">  <span class="bordered grey"> <?= $ank['rating']?> </span>  </div>  
<?
}
$rTime = time() - 600;
if($ank['date_last'] < $rTime){
?>
<span class="grey">(<?= vremja($ank['date_last'])?>)</span>       
<?
}
?>
<div class="grey">
<?
if($ank['ank_name'] != null OR $ank['ank_family'] != null){
?>
<div class="break-word">
<?
}
if($ank['ank_name'] != null){
?>  
<?= text($ank['ank_name'])?>
<?
}
if($ank['ank_family'] != null){
?>  
<?= text($ank['ank_family'])?>
<?
}
if($ank['ank_name'] != null OR $ank['ank_family'] != null){
?>
</div>
<?
}
// Вывод возвраста
if ($ank['ank_d_r'] != NULL && $ank['ank_m_r'] != NULL && $ank['ank_g_r'] != NULL){
$my_age_day = array('год', 'года', 'лет');
?>    
<?= des2num($ank['ank_age'], $my_age_day)?>
<? 
if ($ank['ank_city'] != NULL){
?>, <?
} 
}
if ($ank['ank_city'] != NULL){
?>
<?= text($ank['ank_city'])?>
<?
}
?>
</div>
<?
if ($ank['group_access'] > 1){
?>
<div class="blue"><div class="break-word"><?= $ank['group_name']?></div> </div>
<?
}
?>  
</div>   
<?

if($user['id'] != $ank['id']){
?>  
<div class="menu_btn" onclick="Spoilers_Tw1nGo(<?= $ank['id']?>)" title="Действия" data-toggle="more_menu_<?= $ank['id']?>"> 
<img src="/style/i/arrow_bottom.png" data-hide="arrow_up.png" data-show="arrow_bottom.png" id="more_menu_<?= $ank['id']?>-icon" alt="" class="p16">
</div> 
<?
} 
?>
</div>  
<?
if($user['id'] != $ank['id']){
?> 
<div class="js-row wrap_list wbg  hide" id="more_menu_<?= $ank['id']?>">  
<div>    
<a href="/mail.php?id=<?= $ank['id']?>" class="link       "> <span>        
<img src="/style/i/mail_grey.png" alt="" class="m">      <span class="m">  Написать </span>          </span>  
</a>    
</div> 
<?
if(isset($user)){
?>
<div>
<?
if ($frend_new == 0 && $frend==0){
?> 
<a href="/user/frends/create.php?add=<?= $ank['id']?>" class="link blue">          
<img src="/style/i/befriends.png" alt="" class="m">      <span class="m">  Дружить </span>          
<!-- --><!-- --><!-- --></a><!-- -->
<?
}elseif ($frend_new == 1){
?>  
<a href="/user/frends/create.php?otm=<?= $ank['id']?>" class="link blue">          
<img src="/style/i/befriends_inprocess.png" alt="" class="m">      <span class="m">  Запрошено </span>          
<!-- --><!-- --><!-- --></a><!-- -->
<?
}elseif ($frend == 2){
?> 
<span data-action="friends_delete" class="link green">          
<img src="/style/i/befriends_on.png" alt="" class="m">      <span class="m">  Дружите </span>          
<!-- --><!-- --><!-- --></span><!-- -->
<?
}
?>          
</div>  <div>    
<div class="js-subscr_link" data-user="<?= $ank['nick']?>">     
<a href="/user/gifts/?id=<?= $ank['id']?>" class="link      js-action_link "> 
<span> <img src="/style/i/gifts_grey.png" alt="" class="m">      <span class="m">  Подарок </span>  </span>  
</a>    
</div> 
</div>  
<?
if (user_access('user_prof_edit') && $user['level'] > $ank['level']){
?>
<a class="link      js-action_link " href="/adm_panel/user.php?id=<?= $ank['id']?>"> 
<span> <img src="/style/i/edit_info.png" alt="" class="m">     <span class="m">  Изменить профиль </span>  </span>  
</a>
<?
}
}
?>
</div>
<?
}
}


if ($k_page>1)str("?",$k_page,$page); // Вывод страниц


include_once 'sys/inc/tfoot.php';
?>