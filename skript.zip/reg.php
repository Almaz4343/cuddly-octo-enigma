<?
//include_once 'sys/inc/mp3.php';
//include_once 'sys/inc/zip.php';
include_once 'sys/inc/start.php';
include_once 'sys/inc/compress.php';
include_once 'sys/inc/sess.php';
include_once 'sys/inc/home.php';
include_once 'sys/inc/settings.php';
include_once 'sys/inc/db_connect.php';
include_once 'sys/inc/ipua.php';
include_once 'sys/inc/fnc.php';
include_once 'sys/inc/shif.php';
$show_all=true; // показ для всех
include_once 'sys/inc/user.php';
only_unreg();
$set['title']='Регистрация';
include_once 'sys/inc/thead.php';
title();


if ((!isset($_SESSION['refer']) || $_SESSION['refer']==NULL)
&& isset($_SERVER['HTTP_REFERER']) && $_SERVER['HTTP_REFERER']!=NULL &&
!preg_match('#mail\.php#',$_SERVER['HTTP_REFERER']))
$_SESSION['refer']=str_replace('&','&amp;',preg_replace('#^http://[^/]*/#','/', $_SERVER['HTTP_REFERER']));
if ($set['reg_select']=='close')
{
	$err='Регистрация временно приостановлена';
	err();

	echo "<a href='/aut.php'>Авторизация</a><br />\n";
	include_once 'sys/inc/tfoot.php';
}
elseif($set['reg_select']=='open_mail' && isset($_GET['id']) && isset($_GET['activation']) && $_GET['activation']!=NULL)
{
	if (mysql_result(mysql_query("SELECT COUNT(*) FROM `user` WHERE `id` = '".intval($_GET['id'])."' AND `activation` = '".my_esc($_GET['activation'])."'"),0)==1)
	{

	mysql_query("UPDATE `user` SET `activation` = null WHERE `id` = '".intval($_GET['id'])."' LIMIT 1");
	$user = mysql_fetch_assoc(mysql_query("SELECT * FROM `user` WHERE `id` = '".intval($_GET['id'])."' LIMIT 1"));
	mysql_query("INSERT INTO `reg_mail` (`id_user`,`mail`) VALUES ('$user[id]','$user[ank_mail]')");
	msg('Ваш аккаунт успешно активирован');

	$_SESSION['id_user']=$user['id'];
	include_once 'sys/inc/tfoot.php';
	}
}

if (isset($_SESSION['step']) && $_SESSION['step']==1 && mysql_result(mysql_query("SELECT COUNT(*) FROM `user` WHERE `nick` = '".$_SESSION['reg_nick']."'"),0)==0 && isset($_POST['pass1']) && $_POST['pass1']!=NULL && $_POST['pass2'] && $_POST['pass2']!=NULL)
{

if ($set['reg_select']=='open_mail')
{
if (!isset($_POST['ank_mail']) || $_POST['ank_mail']==NULL)$err[]='Неоходимо ввести Email';
elseif (!preg_match('#^[A-z0-9-\._]+@[A-z0-9]{2,}\.[A-z]{2,4}$#ui',$_POST['ank_mail']))$err[]='Неверный формат Email';
elseif(mysql_result(mysql_query("SELECT COUNT(*) FROM `reg_mail` WHERE `mail` = '".my_esc($_POST['ank_mail'])."'"),0)!=0)
{
$err[]="Пользователь с этим E-mail уже зарегистрирован";
}
}if (strlen2($_POST['pass1'])<6)$err[]='По соображениям безопасности пароль не может быть короче 6-ти символов';
if (strlen2($_POST['pass1'])>32)$err[]='Длина пароля превышает 32 символа';
if ($_POST['pass1']!=$_POST['pass2'])$err[]='Пароли не совпадают';
if (!isset($_SESSION['captcha']) || !isset($_POST['chislo']) || $_SESSION['captcha']!=$_POST['chislo']){$err[]='Неверное проверочное число';}

if (!isset($err))
{
if ($set['reg_select']=='open_mail')
{
$activation=md5(passgen());

mysql_query("INSERT INTO `user` (`nick`, `pass`, `date_reg`, `date_last`, `pol`, `activation`, `ank_mail`) values('".$_SESSION['reg_nick']."', '".shif($_POST['pass1'])."', '$time', '$time', '".intval($_POST['pol'])."', '$activation', '".my_esc($_POST['ank_mail'])."')",$db);

$id_reg=mysql_insert_id();
$subject = "Активация аккаунта";
$regmail = "Здравствуйте $_SESSION[reg_nick]<br />
Для активации Вашего аккаунта перейдите по ссылке:<br />
<a href='http://$_SERVER[HTTP_HOST]/reg.php?id=$id_reg&amp;activation=$activation'>http://$_SERVER[HTTP_HOST]/reg.php?id=".mysql_insert_id()."&amp;activation=$activation</a><br />
Если аккаунт не будет активирован в течении 24 часов, он будет удален<br />
С уважением, администрация сайта<br />
";
$adds="From: \"password@$_SERVER[HTTP_HOST]\" <password@$_SERVER[HTTP_HOST]>\n";
//$adds = "From: <$set[reg_mail]>\n";
//$adds .= "X-sender: <$set[reg_mail]>\n";
$adds .= "Content-Type: text/html; charset=utf-8\n";
mail($_POST['ank_mail'],'=?utf-8?B?'.base64_encode($subject).'?=',$regmail,$adds);

}
else
mysql_query("INSERT INTO `user` (`nick`, `pass`, `date_reg`, `date_last`, `pol`) values('".$_SESSION['reg_nick']."', '".shif($_POST['pass1'])."', '$time', '$time', '".intval($_POST['pol'])."')",$db);

$user = mysql_fetch_assoc(mysql_query("SELECT * FROM `user` WHERE `nick` = '".my_esc($_SESSION['reg_nick'])."' AND `pass` = '".shif($_POST['pass1'])."' LIMIT 1"));

/*
========================================
Создание настроек юзера 
========================================
*/

mysql_query("INSERT INTO `user_set` (`id_user`) VALUES ('$user[id]')");
mysql_query("INSERT INTO `discussions_set` (`id_user`) VALUES ('$user[id]')");
mysql_query("INSERT INTO `tape_set` (`id_user`) VALUES ('$user[id]')");
mysql_query("INSERT INTO `notification_set` (`id_user`) VALUES ('$user[id]')");


if (isset($_SESSION['http_referer']))
mysql_query("INSERT INTO `user_ref` (`time`, `id_user`, `type_input`, `url`) VALUES ('$time', '$user[id]', 'reg', '".my_esc($_SESSION['http_referer'])."')");

$_SESSION['id_user']=$user['id'];
setcookie('id_user', $user['id'], time()+60*60*24*365);
setcookie('pass', cookie_encrypt($_POST['pass1'],$user['id']), time()+60*60*24*365);

if ($set['reg_select']=='open_mail')
{
msg('Вам необходимо активировать Ваш аккаунт по ссылке, высланной на Email');
}
else
{
	
	$_SESSION['message'] = 'Добро пожаловать на сайт :)';
	header("Location: /user/?id=$user[id]");
	exit;
}

echo "Если Ваш браузер не поддерживает Cookie, Вы можете создать закладку для автовхода<br />\n";
echo "<input type='text' value='http://$_SERVER[SERVER_NAME]/login.php?id=$user[id]&amp;pass=".htmlspecialchars($_POST['pass1'])."' /><br />\n";
if ($set['reg_select']=='open_mail')unset($user);

include_once 'sys/inc/tfoot.php';
}
}
elseif (isset($_POST['nick']) && $_POST['nick']!=NULL )
{
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `user` WHERE `nick` = '".my_esc($_POST['nick'])."'"),0)==0)
{
$nick = my_esc($_POST['nick']);

if( !preg_match("#^([A-zА-я0-9\-\_\ ])+$#ui", $_POST['nick']))$err[]='В нике присутствуют запрещенные символы';
if (preg_match("#[a-z]+#ui", $_POST['nick']) && preg_match("#[а-я]+#ui", $_POST['nick']))$err[]='Разрешается использовать символы только русского или только английского алфавита';
if (preg_match("#(^\ )|(\ $)#ui", $_POST['nick']))$err[]='Запрещено использовать пробел в начале и конце ника';
if (strlen2($nick)<3)$err[]='Короткий ник';
if (strlen2($nick)>32)$err[]='Длина ника превышает 32 символа';
}
else $err[]='Ник "'.stripcslashes(htmlspecialchars($_POST['nick'])).'" уже зарегистрирован';

if (!isset($err)){
$_SESSION['reg_nick'] = $nick;
$_SESSION['step'] = 1;
}
}

// 2 страница регистрации
if (isset($_SESSION['step']) && $_SESSION['step']==1)
{
?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Ввод данных</span> </span>       </div>
<?

err();

?>
<div class="tabs_block oh">    <a href="/aut.php" class="tab_item left" style="padding: 12px 9px 8px 9px">  Вход  </a>   <div class="tab_item left tab_active black" style="padding: 12px 9px 8px 9px">  Регистрация  </div>   </div>

<div class="wrapper"> 
<form action="/reg.php?<?= $passgen?>" method="post" class="no_ajax">  
<div class="block error_wrapper first pdb">  <div>   <div class="input-txt_wrapper">  
<input placeholder="Ваш ник" class="input-txt" name="nick" value="<?= $_SESSION['reg_nick']?>" maxlength="87" type="text">  
</div>  </div> 
<div class="pad_t_a"  style="padding-bottom: 10px;"> <input value="Другой" class="main_submit" type="submit"> </div>
</div>   
</form> </div> 

<div class="wrapper"> 
<form action="/reg.php?<?= $passgen?>" method="post" class="no_ajax"> 
<div class="stnd_padd"> <label class="lbl">Ваш пол:</label>  
<select name="pol" class="select">
<option value="1">Мужской</option><option value="0">Женский</option>
</select>
</div>
<?
if ($set['reg_select'] == 'open_mail') 
{
?>
<div class="stnd_padd" style="padding-top: 0px;">  <div>  
<label class="lbl">  E-mail:  </label>   
<div class="input-txt_wrapper">  
<input placeholder="Введите ваш E-mail" class="input-txt" name="ank_mail" value="" maxlength="50" type="text">  
</div> 
<label class="lbl">* Указывайте ваш реальный адрес E-mail. На него придет код для активации аккаунта.</label>     
</div>    </div>
<?
}
?>
<div class="block error_wrapper " style="padding-top: 0px;"> <div class="">  
<label class="lbl"> Введите пароль (6-32 символов): </label>  
<div class="input-txt_wrapper"> 
<input maxlength="30" class="input-txt" name="pass1" value="" type="password"> 
</div>   </div>  </div> 
<div class="block error_wrapper " style="padding-top: 0px;"> <div class="">  
<label class="lbl"> Повторите пароль: </label>  
<div class="input-txt_wrapper"> 
<input maxlength="30" class="input-txt" name="pass2" value="" type="password"> 
</div>   </div>  </div>
<div class="block error_wrapper " style="padding-top: 0px;"> <div class="">  
<label class="lbl"> <img style="margin-left: -8px;" src="/captcha.php?<?= $passgen?>&amp;SESS=<?= $sess?>" width="100" height="29" alt="Проверочное число" /> </label>  
<div class="input-txt_wrapper"> 
<input maxlength="5" size="5" class="input-txt" name="chislo" value="" type="password"> 
</div>   </div>  </div>

<div class="block"> <div> 
<!-- --><!-- --><!-- --><!-- --><!-- -->
<button type="submit" value="Войти" class="  submit_link    link full  green-full   " id="cfms">
<!--   -->
<img src="/style/i/shared_white.png" alt="" class="m"> <!--   --><span class="m"> Завершить</span>
<!-- -->
</button><!-- --><!-- --> 
</div></div> 
</form><div class="block grey t_center">Регистрируясь, Вы автоматически соглашаетесь с <a href='/rules.php'>правилами</a> сайта</div>
</div>
<?
}
else
{
// 1 страница регистрации
?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Регистрация</span> </span>       </div>
<div class="tabs_block oh">    <a href="/aut.php" class="tab_item left" style="padding: 12px 9px 8px 9px">  Вход  </a>   <div class="tab_item left tab_active black" style="padding: 12px 9px 8px 9px">  Регистрация  </div>   </div>
<?
err();
?>
<div class="wrapper">         
<form class="no_ajax" action="?" method="post"> 
<div class="block error_wrapper">  <div>   <div class="input-txt_wrapper">  
<input placeholder="Введите ник" class="input-txt" name="nick" value="" maxlength="87" type="text">  
</div>   </div>   </div>  
<div class="block pdb pdt"> 
<!-- --><!-- --><!-- --><!-- --><!-- -->
<button type="submit" value="Продолжить" class="  submit_link    link full  green-full   " id="cfms">
<!--   --><img src="/style/i/shared_white.png" alt="" class="m"> <!--   --><span class="m"> Продолжить</span>
<!-- -->
</button><!-- --><!-- --> 
</div>  
</form> 
<div class="block grey t_center"> Регистрируясь, вы соглашаетесь с <a href="/rules.php">правилами сайта</a>. </div>  
</div>
<div class="wrapper"> 
<div class="list f-c_fll">       
<a href="/pass.php" class="link  darkblue     "> 
<span>        <img src="/style/i/lock_darkblue.png" alt="" class="m">  <span class="m">  Не можете войти? </span>          </span>  
</a>      
</div>       
</div>
<?
}


include_once 'sys/inc/tfoot.php';
?>