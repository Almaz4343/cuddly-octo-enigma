<?

include_once '../../sys/inc/start.php';
include_once '../../sys/inc/compress.php';
include_once '../../sys/inc/sess.php';
include_once '../../sys/inc/home.php';
include_once '../../sys/inc/settings.php';
include_once '../../sys/inc/db_connect.php';
include_once '../../sys/inc/ipua.php';
include_once '../../sys/inc/fnc.php';
include_once '../../sys/inc/adm_check.php';
include_once '../../sys/inc/user.php';

$my = null;
$frend = null;
$all = null;

only_reg();
	
/* Класс к статусу */

if (isset($_GET['likestatus']))
{

	// Статус пользователя
	$status = mysql_fetch_assoc(mysql_query("SELECT * FROM `status` WHERE `id` = '".intval($_GET['likestatus'])."' LIMIT 1"));
	$ank = get_user($status['id_user']);
	if ($user['id']!=$ank['id'] && mysql_result(mysql_query("SELECT COUNT(*) FROM `status_like` WHERE `id_status` = '$status[id]' AND `id_user` = '$user[id]' LIMIT 1"),0)==0)
	{
		mysql_query("INSERT INTO `status_like` (`id_user`, `time`, `id_status`) values('$user[id]', '$time', '$status[id]')");
		/*
		===================================
		Лента
		===================================
		*/

		$q = mysql_query("SELECT * FROM `frends` WHERE `user` = '" . $user['id'] . "' AND `i` = '1'");

		while ($f = mysql_fetch_array($q))
		{
			$a = get_user($f['frend']);
			
			$lentaSet = mysql_fetch_array(mysql_query("SELECT * FROM `tape_set` WHERE `id_user` = '".$a['id']."' LIMIT 1")); // Общая настройка ленты
			if ($a['id'] != $ank['id'] && $f['lenta_status_like']==1 && $lentaSet['lenta_status_like']==1)
			mysql_query("INSERT INTO `tape` (`id_user`,`ot_kogo`,  `avtor`, `type`, `time`, `id_file`) values('$a[id]', '$user[id]', '$status[id_user]', 'status_like', '$time', '$status[id]')"); 

		}

		header("Location: ?P=" . intval($_GET['page']));
		exit;
	}
}


$set['title'] = 'Лента : ' . $user['nick'];
include_once '../../sys/inc/thead.php';

// Очищение списка непрочитанных
if (isset($_GET['read']) && $_GET['read']=='all')
{
	if (isset($user))
	{
		mysql_query("UPDATE `tape` SET `read` = '1' WHERE `id_user` = '$user[id]'");
		$_SESSION['message'] = 'Список непрочитанных очищен';
		header("location:  " . htmlspecialchars($_SERVER['HTTP_REFERER']) . "");
		exit;
	}
}


// Полная очистка ленты
if (isset($_GET['delete']) && $_GET['delete']=='all')
{
	if (isset($user))
	{
		mysql_query("DELETE FROM `tape` WHERE `id_user` = '$user[id]'");
		$_SESSION['message'] = 'Лента успешно очищена';
		header("Location: ?");
		exit;
	}
}

if (isset($_GET['del']))  {
  if (isset($user)) {
    $id = (int) $_GET['del'];
  	if (mysql_result(query("SELECT COUNT(*) FROM `tape`  WHERE `id_user` = '$user[id]' AND `id` = '$id'"),0) == 1) {
    	query("DELETE FROM `tape` WHERE `id_user` = '$user[id]' AND `id` = '$id' LIMIT 1");
    	$_SESSION['message'] = 'Уведомление удалено';
    	header('Location: ?P=' . $id);
    	exit;
  	}
  }
}

title();
err();



?>


<div class="lc_br wbg fonto0 relative oh" id="header_path">  
<a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     
<span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> 
<a href="/user/?id=<?= $user['id']?>"><?= $user['nick']?></a> 
</span>     
<span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/lenta/">Лента</a> </span>       
</div>
<?



/*******************************/
/* ВЫВОД ВСЕГО СРАЗУ */
/*******************************/
if (!isset($_GET['type'])){

$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `tape`  WHERE `id_user` = '$user[id]' "),0);
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str'] * $page-$set['p_str'];
	
?>
<div>
<div class="tabs_block oh">     
<div class="tab_item left tab_active black" style="padding: 12px 9px 8px 9px">  Все  </div>  
<a href="/user/lenta/?type=photo" class="tab_item left" style="padding: 12px 9px 8px 9px">  Фото  </a>   
<a href="/user/lenta/?type=file" class="tab_item left" style="padding: 12px 9px 8px 9px">  Файл  </a>   
<a href="/user/lenta/?type=blog" class="tab_item left" style="padding: 12px 9px 8px 9px">  Блог  </a>   
<?
/*  
<a href="/user/lenta/?type=other" class="tab_item left" style="padding: 12px 9px 8px 9px">  Прочее  </a> 
*/
?>   
</div>
<div class="wrapper block"> 
<a href="?read=all" class="grey_important">  
<img src="/style/i/eye.png" alt="" class="p16 m">  <span class="m"> Пометить всё прочитанным </span> </a>  
</div>
</div>
<?		
	

$q = mysql_query("SELECT * FROM `tape` WHERE `id_user` = '$user[id]' ORDER BY `time` DESC LIMIT $start, $set[p_str]");

if ($k_post == 0)
{
?>
<div class="wrapper block"> Список пуст. </div>
<?
}

while ($post = mysql_fetch_assoc($q))
{
$type = $post['type'];
$avtor = get_user($post['avtor']);
$name = null;
if ($post['count'] > 4){
$dop_div = ' bord-botm';
}
else
{
$dop_div = '';
}
?>
<div class="wrapper"> 
<div class="block oh <?= $dop_div?>">   
<div class="no-borders">  
<a class="right" href="?del=<?= $post['id']?>"><img class="m p16" src="/style/i/cross_light.png" alt=""></a> 
<?	

if ($post['read'] == 0){
$s1 = "<font color='red'>";
$s2 = "</font>";
mysql_query("UPDATE `tape` SET `read` = '1' WHERE `id` = '$post[id]'");
}else{
$s1 = null;$s2 = null;
}

//Помечаем сообщение прочитанным
$d = opendir('inc/');

while($dname = readdir($d)){
if ($dname != '.' && $dname != '..'){
	include 'inc/' . $dname;
}
}
echo '</div>';
}

if ($k_page>1)str('?',$k_page,$page); 

if ($k_post > 0){
?>
<div class="wrapper wrap_list"> 
<a href="?P=<?= $page?>&amp;delete=all" class="link        "> 
<span><!--     --><img src="/style/i/mail/garbage.png" alt="" class="m"> <!--   --><span class="m">Очистить ленту</span><!--   --></span> 
</a>   
</div> 
<? 
}	


}else

/*******************************/
/* Вывод новых фото и аватарок */
/*******************************/

if (isset($_GET['type']) && $_GET['type'] == 'photo'){

$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `tape`  WHERE `type` = 'album' AND `id_user` = '$user[id]'"),0);
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str'] * $page-$set['p_str'];
	
?>
<div>
<div class="tabs_block oh">    
<a href="/user/lenta/?" class="tab_item left" style="padding: 12px 9px 8px 9px">  Все  </a>   
<div class="tab_item left tab_active black" style="padding: 12px 9px 8px 9px">  Фото  </div>   
<a href="/user/lenta/?type=file" class="tab_item left" style="padding: 12px 9px 8px 9px">  Файл  </a>   
<a href="/user/lenta/?type=blog" class="tab_item left" style="padding: 12px 9px 8px 9px">  Блог  </a>   
<?
/*  
<a href="/user/lenta/?type=other" class="tab_item left" style="padding: 12px 9px 8px 9px">  Прочее  </a> 
*/
?>    
</div>
<div class="wrapper block"> 
<a href="?type=photo&read=all" class="grey_important">  
<img src="/style/i/eye.png" alt="" class="p16 m">  <span class="m"> Пометить всё прочитанным </span> </a>  
</div>
</div>
<?	



$q = mysql_query("SELECT * FROM `tape` WHERE `type` = 'album' AND `id_user` = '$user[id]' ORDER BY `time` DESC LIMIT $start, $set[p_str]");

if ($k_post == 0)
{
?>
<div class="wrapper block"> Список пуст. </div>
<?
}

while ($post = mysql_fetch_assoc($q))
{
$type = $post['type'];
$avtor = get_user($post['avtor']);
$name = null;
if ($post['count'] > 4){
$dop_div = ' bord-botm';
}
else
{
$dop_div = '';
}

?>
<div class="wrapper"> 
<div class="block oh <?= $dop_div?>">   
<div class="no-borders">  
<a class="right" href="?type=photo&del=<?= $post['id']?>"><img class="m p16" src="/style/i/cross_light.png" alt=""></a> 
<?

//Помечаем сообщение прочитанным	
if ($post['read'] == 0){
$s1 = "<font color='red'>";$s2 = "</font>";
mysql_query("UPDATE `tape` SET `read` = '1' WHERE `id` = '$post[id]'");
}else{
$s1 = null;$s2 = null;
}

	include 'inc/foto.php';

echo '</div>';
}

if ($k_page>1)str('?type=photo&',$k_page,$page); 
}
else

/*******************************/
/****** ВВЫВОД БЛОГОВ ******** */
/*******************************/

if (isset($_GET['type']) && $_GET['type'] == 'blog'){

$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `tape`  WHERE `type` = 'notes' AND `id_user` = '$user[id]'"),0);
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str'] * $page-$set['p_str'];
	
?>
<div>
<div class="tabs_block oh">    
<a href="/user/lenta/?" class="tab_item left" style="padding: 12px 9px 8px 9px">  Все  </a>   
<a href="/user/lenta/?type=photo" class="tab_item left" style="padding: 12px 9px 8px 9px">  Фото  </a>   
<a href="/user/lenta/?type=file" class="tab_item left" style="padding: 12px 9px 8px 9px">  Файл  </a> 
<div class="tab_item left tab_active black" style="padding: 12px 9px 8px 9px">  Блог  </div>   
<?
/*  
<a href="/user/lenta/?type=other" class="tab_item left" style="padding: 12px 9px 8px 9px">  Прочее  </a> 
*/
?>  
</div>
<div class="wrapper block"> 
<a href="?type=photo&read=all" class="grey_important">  
<img src="/style/i/eye.png" alt="" class="p16 m">  <span class="m"> Пометить всё прочитанным </span> </a>  
</div>
</div>
<?	



$q = mysql_query("SELECT * FROM `tape` WHERE `type` = 'notes' AND `id_user` = '$user[id]' ORDER BY `time` DESC LIMIT $start, $set[p_str]");

if ($k_post == 0)
{
?>
<div class="wrapper block"> Список пуст. </div>
<?
}

while ($post = mysql_fetch_assoc($q))
{
$type = $post['type'];
$avtor = get_user($post['avtor']);
$name = null;

?>
<div class="wrapper"> 
<div class="block oh">   
<div class="no-borders">  
<a class="right" href="?type=blog&del=<?= $post['id']?>"><img class="m p16" src="/style/i/cross_light.png" alt=""></a> 
<?

//Помечаем сообщение прочитанным	
if ($post['read'] == 0){
$s1 = "<font color='red'>";$s2 = "</font>";
mysql_query("UPDATE `tape` SET `read` = '1' WHERE `id` = '$post[id]'");
}else{
$s1 = null;$s2 = null;
}

	include 'inc/notes.php';

echo '</div>';
}

if ($k_page>1)str('?type=blog&',$k_page,$page); 
}
else

/*******************************/
/****** ВВЫВОД ФАЙЛОВ ******** */
/*******************************/

if (isset($_GET['type']) && $_GET['type'] == 'file'){

$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `tape`  WHERE `type` = 'files' AND `id_user` = '$user[id]'"),0);
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str'] * $page-$set['p_str'];
	
?>
<div>
<div class="tabs_block oh">    
<a href="/user/lenta/?" class="tab_item left" style="padding: 12px 9px 8px 9px">  Все  </a>   
<a href="/user/lenta/?type=photo" class="tab_item left" style="padding: 12px 9px 8px 9px">  Фото  </a> 
<div class="tab_item left tab_active black" style="padding: 12px 9px 8px 9px">  Файл  </div>  
<a href="/user/lenta/?type=blog" class="tab_item left" style="padding: 12px 9px 8px 9px">  Блог  </a>  
<?
/*  
<a href="/user/lenta/?type=other" class="tab_item left" style="padding: 12px 9px 8px 9px">  Прочее  </a> 
*/
?> 
</div>
<div class="wrapper block"> 
<a href="?type=photo&read=all" class="grey_important">  
<img src="/style/i/eye.png" alt="" class="p16 m">  <span class="m"> Пометить всё прочитанным </span> </a>  
</div>
</div>
<?	



$q = mysql_query("SELECT * FROM `tape` WHERE `type` = 'files' AND `id_user` = '$user[id]' ORDER BY `time` DESC LIMIT $start, $set[p_str]");

if ($k_post == 0)
{
?>
<div class="wrapper block"> Список пуст. </div>
<?
}

while ($post = mysql_fetch_assoc($q))
{
$type = $post['type'];
$avtor = get_user($post['avtor']);
$name = null;

?>
<div class="wrapper"> 
<div class="block oh">   
<div class="no-borders">  
<a class="right" href="?type=file&del=<?= $post['id']?>"><img class="m p16" src="/style/i/cross_light.png" alt=""></a> 
<?

//Помечаем сообщение прочитанным	
if ($post['read'] == 0){
$s1 = "<font color='red'>";$s2 = "</font>";
mysql_query("UPDATE `tape` SET `read` = '1' WHERE `id` = '$post[id]'");
}else{
$s1 = null;$s2 = null;
}

	include 'inc/files.php';

echo '</div>';
}

if ($k_page>1)str('?type=blog&',$k_page,$page); 
}




include_once H.'sys/inc/tfoot.php';
?>