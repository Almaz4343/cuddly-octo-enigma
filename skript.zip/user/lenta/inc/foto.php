<?
/*
* $name описание действий объекта 
*/
if ($type == 'album' && $post['avtor'] != $user['id'])
{
	$name = 'новые фото в альбоме';
}

/*
* Вывод блока с содержимым 
*/
if ($type  ==  'album')
{
$gallery = mysql_fetch_assoc(mysql_query("SELECT * FROM `gallery` WHERE `id` = '".$post['id_file']."' LIMIT 1"));
	
if ($post['count'] > 4){
	$kol = '4';
	$kol2 = $post['count'] - 4;
	$dop_div = ' bord-botm';
}
else
{
	$kol = $post['count'];
	$kol2 = null;
	$dop_div = '';
}
	
if ($gallery['id'])
{
$as = mysql_query("SELECT * FROM `gallery_foto` WHERE `id_gallery` = '$gallery[id]' ORDER BY `id` DESC LIMIT $kol");
?>  
<div>   
<?= group($avtor['id'])?> 
<a href="/user/lenta/subscr/?uid=<?=  $avtor['id']?>" class="mysite-link"><b class="nick"><?= $avtor['nick']?></b></a>
<?= medal($avtor['id'])?> 
<span class="grey">  добавил<?= ($avtor['pol'] == 1 ? '' : 'а')?>  <?= $post['count']?> фото в папку  </span> 
<a href="/foto/<?= $avtor['id']?>/<?= $gallery['id']?>/" class="arrow_link break-word">  «<span><?= text($gallery['name'])?></span>»</a>   
</div> 
<div class="grey small cl"><?= $s1 . vremja($post['time']) . $s2?></div>
<div class="list_item font0"> 
<?

while ($xx = mysql_fetch_assoc($as))
{
?>     
<div class=" tiled_item tiled_item-80"> 
<div class="tiled_inner t_center relative">   
<span class="relative" style="display: inline-block;max-width: 100%; padding:2px;">   
<span class="inl_bl">        
<a class="tdn gview_link" href="/foto/<?= $gallery['id_user']?>/<?= $gallery['id']?>/<?= $xx['id']?>/" >   
<div class="inl_bl relative">
<img src="/foto/pic80/<?= $xx['id']?>..p.81.80.0.jpg" alt="" class="preview"> 
<?
if($xx['metka'] != 0){
?>
<img class="p16 f_18p" src="/style/i/adult_ico.png" alt="">  
<?
}
?>
</div>      
</a>             
</span>    
</span>       
</div> 
</div>    
<?
}
?>
</div></div></div> 
<?
if (isset($kol2)){
?>
<a href="/foto/<?= $avtor['id']?>/<?= $gallery['id']?>/" class="link    is_final   " style="border-top: 1px solid #c5d3e1;"> 
<span>        
<img src="/style/i/down.png" alt="" class="m">      <span class="m">  Посмотреть ещё <?= $kol2?> фото </span>          
</span>  
</a>
<?
}
	
}
else
{
?>
<div class="wrapper"> <div class="block oh">  <b class="grey">Объект удалён</b>  </div>  </div>
<?
query("DELETE FROM `tape` WHERE `id_user` = '$user[id]' AND `id` = '$post[id]' LIMIT 1");
}
}
?>