<?
/*
* $name описание действий объекта 
*/
if ($type == 'obmen' && $post['avtor'] != $user['id'])
{
	$name = 'новые файлы в папке';
}

/*
* Вывод блока с содержимым 
*/
if ($type == 'obmen')
{
$dir = mysql_fetch_assoc(mysql_query("SELECT * FROM `user_files` WHERE `id` = '" . $post['id_file'] . "' LIMIT 1"));
	
	if ($post['count'] > 5)
	{
		$kol = '5';
		$kol2 = $post['count'] - 5;
	}
	else
	{
		$kol = $post['count'];
		$kol2 = null;
	}
	
?>
<div class="wrapper"> 
<div class="block oh">   
<div class="no-borders">  
<a class="right" href="?type=blog&del=<?= $post['id']?>"><img class="m p16" src="//c.spac.me/i/cross_light.png" alt=""></a>    
<div>   
<?= group($avtor['id'])?> 
<a href="/info.php?id=<?=  $avtor['id']?>" class="mysite-link"><b class="nick"><?= $avtor['nick']?></b></a>
<?= medal($avtor['id'])?>      
<span class="grey">  <?= $name?>  </span>   
</div> 
<div class="grey small cl"> <?= $s1 . vremja($post['time']) . $s2?> </div>  
<?

$files = mysql_query("SELECT * FROM `obmennik_files` WHERE `my_dir` = '$dir[id]' ORDER BY `id` DESC LIMIT $kol");
	
	while ($file = mysql_fetch_assoc($files))
	{
		if ($file['id'])
		{
			$ras = $file['ras'];
			
			if (is_file(H.'style/themes/' . $set['set_them'] . '/loads/14/' . $ras . '.png')) // Иконка файла
				echo '<img src="/style/themes/' . $set['set_them'] . '/loads/14/' . $ras . '.png" alt="*" /> ';
			else 
				echo '<img src="/style/themes/' . $set['set_them'] . '/loads/14/file.png" alt="*" /> ';

		echo '<a href="/user/personalfiles/' . $file['id_user'] . '/' . $dir['id'] . '/?id_file=' . $file['id'] . '&amp;page=1"><b>' . text($file['name']) . '.' . $ras . '</b></a> (' . size_file($file['size']) . ')<br />';
		}
		else
		{
			echo user::avatar($avtor['id']) . user::nick($avtor['id'], 1, 1, 1) . '  <a href="user.settings.php?id=' . $avtor['id'] . '">[!]</a><br />';
			echo 'Файл уже удален =(<br />';
		}
	}
?>
</div></div></div> 
<?
if (isset($kol2)){
?>
<a href="/user/personalfiles/<?= $file['id_user']?>/<?= $dir['id']?>/" class="link    is_final   "> 
<span>        
<img src="//c.spac.me/i/down.png" alt="" class="m">      <span class="m">  Посмотреть ещё <?= $kol2?> фото </span>          
</span>  
</a>
<?
}	
	if (isset($kol2))echo 'и еще ' . $kol2 . ' файлов';
}
?>