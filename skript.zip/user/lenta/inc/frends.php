<?
/*
* $name описание действий объекта 
*/

$name = 'добавил' . ($avtor['pol'] == 1 ? null : "а") . ' в друзья';


/*
* Вывод блока с содержимым 
*/
if ($type == 'frends')
{
	$frend = get_user($post['id_file']);
	
if ($frend['id'])
{
?>
<div>   
<?= group($avtor['id'])?> 
<a href="/user/lenta/subscr/?uid=<?=  $avtor['id']?>" class="mysite-link"><b class="nick"><?= $avtor['nick']?></b></a> 
<?= medal($avtor['id'])?>      
<span class="grey">  <?= $name?>  </span>  
<?= group($frend['id'])?> 
<a href="/user/?id=<?=  $frend['id']?>" class="mysite-link"><b class="nick"><?= $frend['nick']?></b></a> 
<?= medal($frend['id'])?>    
</div> 
<div class="grey small cl"> <?= $s1 . vremja($post['time']) . $s2?> </div>  
</div>  </div>  
<?


}
else
{


}
}
?>