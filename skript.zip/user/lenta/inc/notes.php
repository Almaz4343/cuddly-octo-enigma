<?
/*
* $name описание действий объекта 
*/
if ($type == 'notes' && $post['avtor'] != $user['id']) // дневники
{
	$name = 'добавил' . ($avtor['pol'] == 1 ? null : "а") . ' запись';
}

/*
* Вывод блока с содержимым 
*/
if ($type  ==  'notes')
{
$notes = mysql_fetch_assoc(mysql_query("SELECT * FROM `notes` WHERE `id` = '" . $post['id_file'] . "' LIMIT 1"));
$comm = mysql_result(mysql_query("SELECT COUNT(*) FROM `notes_komm` WHERE `id_notes` = '$notes[id]'"),0);

$_msg = text($notes['msg']);

if (iconv_strlen($_msg, 'UTF-8') > 500) {
        $_msg= iconv_substr($_msg, 0, 497, 'UTF-8');
        $_msg = $_msg.'... <div class="pad_t_a"><a href="/user/blogs/read/?id='.$notes['id'].'"> <b> Читать полностью.. </b> </a></div>';
}

if ($notes['id'])
{
?>
<div>   
<?= group($avtor['id'])?> 
<a href="/user/lenta/subscr/?uid=<?=  $avtor['id']?>" class="mysite-link"><b class="nick"><?= $avtor['nick']?></b></a>
<?= medal($avtor['id'])?>      
<span class="grey">  <?= $name?>  </span>   
</div> 
<div class="grey small cl"> <?= $s1 . vremja($post['time']) . $s2?> </div>     
<div class="action-item-wrap">     
<div class="block bord-botm relative"> 
<div class="oh">   
<div class="cl"></div>   
<div class="oh arrow_link"> 
<a class="arrow_link full_link" href="/user/blogs/read/?id=<?= $notes['id']?>"> <b>  <?= text($notes['name'])?>  </b> </a>  
<div> <?= $_msg?>  </div>  
</div>   
</div> <div>  
<div class="oh">   <div class="cl"></div> </div>    
</div> <div class="cl"></div> </div>     
</div>  </div>  </div>  
<?
}
else
{
?>
<div class="wrapper"> <div class="block oh">  <b class="grey">Блог удалён</b>  </div>  </div>  
<?
query("DELETE FROM `tape` WHERE `id_user` = '$user[id]' AND `id` = '$post[id]' LIMIT 1");
}
}
?>