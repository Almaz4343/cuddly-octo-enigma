<?
/*
* $name описание действий объекта 
*/
if ($type=='avatar' && $post['avtor'] != $user['id']) // аватар
{
	if ($post['avatar'])
	$name = 'сменил' . ($avtor['pol'] == 1 ? null : "а") . ' аватар на странице';
	else
	$name = 'установил' . ($avtor['pol'] == 1 ? null : "а") . ' фото на странице';	
}

/*
* Вывод блока с содержимым 
*/
if ($type == 'avatar')
{
$foto = mysql_fetch_assoc(mysql_query("SELECT * FROM `gallery_foto` WHERE `id` = '".$post['id_file']."' LIMIT 1"));
$avatar = mysql_fetch_assoc(mysql_query("SELECT * FROM `gallery_foto` WHERE `id` = '".$post['avatar']."' LIMIT 1"));
$gallery = mysql_fetch_assoc(mysql_query("SELECT * FROM `gallery` WHERE `id` = '".$foto['id_gallery']."' LIMIT 1"));
$gallery2 = mysql_fetch_assoc(mysql_query("SELECT * FROM `gallery` WHERE `id` = '".$avatar['id_gallery']."' LIMIT 1"));
$comm = mysql_result(mysql_query("SELECT COUNT(*) FROM `gallery_komm` WHERE `id_foto` = '$foto[id]'"),0);

?>   
<div> 
<?= group($avtor['id'])?> 
<a href="/user/lenta/subscr/?uid=<?=  $avtor['id']?>" class="mysite-link"><b class="nick"><?= $avtor['nick']?></b></a>
<?= medal($avtor['id'])?>
<span class="grey">  <?= $name?>  </span>   
</div> 
<div class="grey small cl"> <?= $s1 . vremja($post['time']) . $s2?> </div> 
<div class="attaches_limiter pad_t_a">       
<a class="tdn gview_link" href="">   
<div class="inl_bl relative"> 
<?
if ($post['avatar'])
{
if (!is_file(H.'foto/pic80/'.$post['avatar'].'.p.81.80.jpg')) {
?>
<img src="/foto/foto128/<?=  $post['avatar']?>.jpg"  class="preview" alt="">
<?
}else{
?>
<div class="oh">  <b class="grey">Фотография удалена</b>  </div>
<?
}
}else{
if ($foto['id'])echo '<a href="/foto/' . $avtor['id'] . '/' . $gallery['id'] . '/' . $foto['id'] . '/">';
if (!is_file(H.'foto/foto128/'.$post['id_file'].'.jpg')) {
echo '<img src="/foto/foto128/' . $post['id_file'] . '.jpg"  alt="">';
if ($foto['id'])echo '</a>';
}else{
?>
<div class="oh">  <b class="grey">Фотография удалена</b>  </div>
<?
}
}

?>
</div>      
</a>         
</div>
</div> </div> 
<?



}
?>