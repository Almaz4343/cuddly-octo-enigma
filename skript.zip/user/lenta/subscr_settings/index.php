<?
include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/adm_check.php';
include_once H.'sys/inc/user.php';

if (isset($user)){
	$ank['id'] = $user['id']; 
}
if (isset($_GET['uid'])){
	$ank['id'] = intval($_GET['uid']); 
}

$ank = get_user($ank['id']);
 
// Запрет если Система или не юзер!
if(!$ank || $ank['id'] == 0){
	header("Location: /?".SID);
	exit;
}

// Запрет если пробуем просмотреть у себя)
if($user['id'] == $ank['id']){
	header("Location: /user/lenta/".SID);
	exit;
}

only_reg();

$frend = mysql_fetch_array(mysql_query("SELECT * FROM `frends` WHERE `user` = '".$user['id']."' AND `frend` = '$ank[id]' AND `i` = '1'")); 

if (isset($_POST['cfms'])){ 

// Блог
if (isset($_POST['l_blog']) && $_POST['l_blog'] == 1){
$frend['lenta_notes'] = 1;
mysql_query("UPDATE `frends` SET `lenta_notes` = '1' WHERE `user` = '$user[id]' AND `frend` = '$ank[id]' LIMIT 1"); 
}
else{
$frend['lenta_notes'] = 0;
mysql_query("UPDATE `frends` SET `lenta_notes` = '0' WHERE `user` = '$user[id]' AND `frend` = '$ank[id]' LIMIT 1");
}

// Форум
if (isset($_POST['l_forum']) && $_POST['l_forum'] == 1){
$frend['lenta_forum'] = 1;
mysql_query("UPDATE `frends` SET `lenta_forum` = '1' WHERE `user` = '$user[id]' AND `frend` = '$ank[id]' LIMIT 1"); 
}
else{
$frend['lenta_forum'] = 0;
mysql_query("UPDATE `frends` SET `lenta_forum` = '0' WHERE `user` = '$user[id]' AND `frend` = '$ank[id]' LIMIT 1");
}

// Фото
if (isset($_POST['l_photo']) && $_POST['l_photo'] == 1){
$frend['lenta_foto'] = 1;
mysql_query("UPDATE `frends` SET `lenta_foto` = '1' WHERE `user` = '$user[id]' AND `frend` = '$ank[id]' LIMIT 1"); 
}
else{
$frend['lenta_foto'] = 0;
mysql_query("UPDATE `frends` SET `lenta_foto` = '0' WHERE `user` = '$user[id]' AND `frend` = '$ank[id]' LIMIT 1");
}

// Файлы
if (isset($_POST['l_file']) && $_POST['l_file'] == 1){
$frend['lenta_obmen'] = 1;
mysql_query("UPDATE `frends` SET `lenta_obmen` = '1' WHERE `user` = '$user[id]' AND `frend` = '$ank[id]' LIMIT 1"); 
}
else{
$frend['lenta_obmen'] = 0;
mysql_query("UPDATE `frends` SET `lenta_obmen` = '0' WHERE `user` = '$user[id]' AND `frend` = '$ank[id]' LIMIT 1");
}

// Друзья
if (isset($_POST['l_friend']) && $_POST['l_friend'] == 1){
$frend['lenta_frends'] = 1;
mysql_query("UPDATE `frends` SET `lenta_frends` = '1' WHERE `user` = '$user[id]' AND `frend` = '$ank[id]' LIMIT 1"); 
}
else{
$frend['lenta_frends'] = 0;
mysql_query("UPDATE `frends` SET `lenta_frends` = '0' WHERE `user` = '$user[id]' AND `frend` = '$ank[id]' LIMIT 1");
}
/*
// Статус
if (isset($_POST['l_status']) && $_POST['l_status'] == 1){
$frend['lenta_status'] = 1;
mysql_query("UPDATE `frends` SET `lenta_status` = '1' WHERE `user` = '$user[id]' AND `frend` = '$ank[id]'"); 
}
else{
$frend['lenta_status'] = 0;
mysql_query("UPDATE `frends` SET `lenta_status` = '0' WHERE `user` = '$user[id]' AND `frend` = '$ank[id]'");
}

// Аватар
if (isset($_POST['l_ava']) && $_POST['l_ava'] == 1){
$frend['lenta_avatar'] = 1;
mysql_query("UPDATE `frends` SET `lenta_avatar` = '1' WHERE `user` = '$user[id]' AND `frend` = '$ank[id]' LIMIT 1"); 
}
else{
$frend['lenta_avatar'] = 0;
mysql_query("UPDATE `frends` SET `lenta_avatar` = '0' WHERE `user` = '$user[id]' AND `frend` = '$ank[id]' LIMIT 1");
}
*/


$_SESSION['message'] = 'Настройки уведомлений сохранены. '; 
//header('Location: /user/lenta/subscr/?uid='.$ank['id'].''); 
//exit;
}



$set['title'] = 'Настройки уведомлений : ' .$ank['nick'] . ' : Лента : ' . $user['nick'];
include_once H.'sys/inc/thead.php';

title();
err();



?>
<div class="lc_br wbg fonto0 relative oh" id="header_path">  
<a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     
<span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> 
<a href="/user/?id=<?= $user['id']?>"><?= $user['nick']?></a> 
</span>     
<span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/lenta/">Лента</a> </span>
<span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep">
<a href="/user/lenta/subscr/?uid=<?= $ank['id']?>"><?= $ank['nick']?></a>
</span>  
<span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Настройки уведомлений</span> </span>     
</div>

<div class="wrapper"> 
<div class="block pdb b"> Уведомления от <?= $ank['nick']?> </div>  
<form method="post" action="/user/lenta/subscr_settings/?uid=<?= $ank['id']?>"> 
<div class="bord-botm">    

<div class="block transpar"> 
<label> 
<input value="1" name="l_blog" <?= ($frend['lenta_notes']==1?' checked="checked"':null)?> class="m" type="checkbox"> 
<span class="m grey chb_lbl">        
<img src="/style/i/blog.png" alt="" class="m">      <span class="m">  Записи в блоге </span>          
</span> 
</label>
</div>

<div class="block transpar"> 
<label> 
<input value="1" name="l_forum" <?= ($frend['lenta_forum']==1?' checked="checked"':null)?> class="m" type="checkbox"> 
<span class="m grey chb_lbl">        
<img src="/style/i/forum.png" alt="" class="m">      <span class="m">  Темы в форуме  </span>          
</span> 
</label> 
</div>

<div class="block transpar"> 
<label> 
<input value="1" name="l_photo" <?= ($frend['lenta_foto']==1?' checked="checked"':null)?> class="m" type="checkbox"> 
<span class="m grey chb_lbl">        
<img src="/style/i/photo.png" alt="" class="m p16">      <span class="m">  Новые фото  </span>          
</span> 
</label> 
</div>

<div class="block transpar"> 
<label> 
<input value="1" name="l_file" class="m" <?= ($frend['lenta_obmen']==1?' checked="checked"':null)?> type="checkbox"> 
<span class="m grey chb_lbl">        
<img src="/style/i/file.png" alt="" class="m p16">      <span class="m">  Новые файлы </span>          
</span> 
</label>    
</div>

<div class="block transpar"> 
<label> 
<input value="1" name="l_friend" class="m" <?= ($frend['lenta_frends']==1?' checked="checked"':null)?> type="checkbox"> 
<span class="m grey chb_lbl">        
<img src="/style/i/friends.png" alt="" class="m p16">      <span class="m">  Новые друзья </span>          
</span> 
</label>    
</div>






</div>
<table class="table__wrap"> <tbody><tr> 
<td class="table__cell" width="50%"> 
<!-- --><!-- --><!-- --><!-- --><!-- -->
<button name="cfms" value="Сохранить" class="  link  blue full is_final    " id="cfms">
<!--   -->
<img src="/style/i/ok_blue.png" alt="" class="m"> 
<!--   -->
<span class="m"> Сохранить</span>
<!-- -->
</button>
<!-- --><!-- --> 
</td> 
<td class="table__cell table__cell_last" width="50%">     
<a href="/user/lenta/subscr/?uid=<?= $ank['id']?>" class="link         "> <span> <span>  Отменить </span> </span>  </a>    
</td> 
</tr> </tbody></table>
</form>

</div>
<?













include_once H.'sys/inc/tfoot.php';
?>