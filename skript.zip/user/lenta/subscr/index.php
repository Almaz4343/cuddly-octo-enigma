<?
include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/adm_check.php';
include_once H.'sys/inc/user.php';

if (isset($user)){
	$ank['id'] = $user['id']; 
}
if (isset($_GET['uid'])){
	$ank['id'] = intval($_GET['uid']); 
}

$ank = get_user($ank['id']);
 
// Запрет если Система или не юзер!
if(!$ank || $ank['id'] == 0){
	header("Location: /?".SID);
	exit;
}

// Запрет если пробуем просмотреть у себя)
if($user['id'] == $ank['id']){
	header("Location: /user/lenta/".SID);
	exit;
}

// Полная очистка ленты c определенным юзером
if (isset($_GET['delete']) && $_GET['delete'] == 'all')
{
	if (isset($user))
	{
		mysql_query("DELETE FROM `tape` WHERE `avtor` = '$ank[id]' AND `id_user` = '$user[id]'");
		$_SESSION['message'] = 'Записи пользователя удалены. ';
		header("Location: ?uid=".$ank['id']."");
		exit;
	}
}

// Удаление выбранного
if (isset($_GET['del']))  {
  if (isset($user) && $ank['id'] != $user['id']) {
    $id = (int) $_GET['del'];
  	if (mysql_result(query("SELECT COUNT(*) FROM `tape`  WHERE `id_user` = '$user[id]' AND `id` = '$id'"),0) == 1) {
    	query("DELETE FROM `tape` WHERE `id_user` = '$user[id]' AND `id` = '$id' LIMIT 1");
    	header("Location: ?uid=" . $ank['id'] . "");
    	exit;
  	}
  }
}

only_reg();

$set['title'] = $ank['nick'] . ' : Лента : ' . $user['nick'];
include_once H.'sys/inc/thead.php';

title();
err();



$frend = mysql_result(mysql_query("SELECT COUNT(*) FROM `frends` WHERE (`user` = '$user[id]' AND `frend` = '$ank[id]') OR (`user` = '$ank[id]' AND `frend` = '$user[id]') LIMIT 1"),0);


?>
<div class="lc_br wbg fonto0 relative oh" id="header_path">  
<a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     
<span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> 
<a href="/user/?id=<?= $user['id']?>"><?= $user['nick']?></a> 
</span>     
<span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/lenta/">Лента</a> </span>
<span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text"><?= $ank['nick']?></span> </span>       
</div>

<div class="wrapper">  
<div class="js-row block oh grey relative">        
<div class="left fonto0">   
<a href="/user/?id=<?= $ank['id']?>" class="tdn">       
<span class="pr">   <div class="inl_bl relative"> <?= avatar($ank['id'],false,50,40)?>   </div>     </span>        
</a>  
</div> 
<?
if ($frend == 2){
?>    
<div class="btn-tools_centered btn-tools_centered-indent">     
<a href="/user/lenta/subscr_settings/?uid=<?=  $ank['id']?>" class="link      icon-link     "> 
<span>     
<div class="no-text">   <img src="/style/i/settings.png" alt="" class="m">   </div>     
</span>  
</a>    
</div>
<?
}
?>
<div class="pre_content_wrap break-word"> 
<?= group($ank['id'])?>  
<a href="/user/?id=<?= $ank['id']?>" class="black full_link">   <b><?= $ank['nick']?></b>  </a>      
<span class="grey">(<?= vremja($ank['date_last'])?>)</span> 
<?

if($ank['ank_name'] != NULL && $ank['ank_family'] != NULL){
?>
<div class="grey">  <div class="break-word">
<?

if($ank['ank_name'] != NULL){
?>      
<?= text($ank['ank_name'])?>  
<?
}
if($ank['ank_family'] != NULL){
?>      
<?= text($ank['ank_family'])?> 
<?
}
?>            
</div>     </div>    
<?
}
?>            
</div>     </div>       </div>
<?

$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `tape`  WHERE `avtor` = '$ank[id]' AND `id_user` = '$user[id]' "),0);
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str'] * $page-$set['p_str'];

if ($k_post == 0)
{
?>
<div class="wrapper block"> Список пуст. </div>
<?
}

$q = mysql_query("SELECT * FROM `tape` WHERE `avtor` = '$ank[id]' AND `id_user` = '$user[id]' ORDER BY `time` DESC LIMIT $start, $set[p_str]");

while ($post = mysql_fetch_assoc($q))
{
$type = $post['type'];
$avtor = get_user($post['avtor']);
$name = null;

if ($post['count'] > 4){
$dop_div = ' bord-botm';
}else{
$dop_div = '';
}
?>
<div class="wrapper"> 
<div class="block oh <?= $dop_div?>">   
<div class="no-borders">  
<a class="right" href="?uid=<?= $ank['id']?>&del=<?= $post['id']?>"><img class="m p16" src="/style/i/cross_light.png" alt=""></a> 
<?

if ($post['read'] == 0){
$s1 = "<font color='red'>";
$s2 = "</font>";
mysql_query("UPDATE `tape` SET `read` = '1' WHERE `id` = '$post[id]'");
}else{
$s1 = null;$s2 = null;
}

//Помечаем сообщение прочитанным
$d = opendir(H.'user/lenta/inc/');

while($dname = readdir($d)){
if ($dname != '.' && $dname != '..'){
	include H.'user/lenta/inc/' . $dname;
}
}
echo '</div>';
}



if ($k_page > 1)str('?uid='.$ank['id'].'&',$k_page,$page); 

if ($k_post > 0){
?>
<div class="wrapper">       
<a href="?uid=<?= $ank['id']?>&delete=all" class="link    grey     "> 
<span>  <img src="/style/i/remove.png" alt="" class="m">      <span class="m">  Удалить все записи автора </span>          </span>  
</a>    
</div>
<?
}	


include_once H.'sys/inc/tfoot.php';
?>