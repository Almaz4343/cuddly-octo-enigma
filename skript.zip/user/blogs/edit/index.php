<?

/**
 * & Author   :: Igor Slepko
 * & Nick     :: Tw1nGo
 * & Contacts :: http://gix.su/user/Tw1nGo
 */

include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';

// Если юзер в Бане
if (isset($user) && mysql_result(mysql_query("SELECT COUNT(*) FROM `ban` WHERE `razdel` = 'notes' AND `id_user` = '$user[id]' AND (`time` > '$time' OR `view` = '0' OR `navsegda` = '1')"), 0) != 0){
header('Location: /ban.php?'.SID);
exit;
}

only_reg();

$uid = intval($_GET['id']);
$blog = mysql_fetch_assoc(mysql_query("SELECT * FROM `notes` WHERE `id` = '". $uid ."' LIMIT 1"));

if (mysql_result(mysql_query("SELECT COUNT(*) FROM `notes` WHERE `id` = '$blog[id]' LIMIT 1", $db), 0) == 0){
header("Location: /user/blogs/".SID);exit;
}

if (isset($_GET['dell'])){
$avt_us = get_user($blog['id_user']);

if (isset($user) && (user_access('notes_delete') || $user['id'] == $avt_us['id'])){ 

mysql_query("DELETE FROM `notes` WHERE `id` = '$blog[id]'"); 
mysql_query("DELETE FROM `notes_count` WHERE `id_notes` = '$blog[id]'"); 
mysql_query("DELETE FROM `notes_komm` WHERE `id_notes` = '$blog[id]'"); 

if (mysql_result(mysql_query("SELECT COUNT(*) FROM `bookmarks` WHERE `id_object` = '$blog[id]' AND `type` = 'notes' LIMIT 1", $db), 0) == 1){
mysql_query("DELETE FROM `bookmarks` WHERE `id_user` > '0' AND `id_object` = '$blog[id]' AND `type` = 'notes' LIMIT 1");
}

if (mysql_result(mysql_query("SELECT COUNT(*) FROM `bookmarks_like` WHERE `id_object` = '$blog[id]' AND `type` = 'blog' LIMIT 1", $db), 0) == 1){
mysql_query("DELETE FROM `bookmarks_like` WHERE `id_user` > '0' AND `id_object` = '$blog[id]' AND `type` = 'blog' LIMIT 1");
}

if (is_file(H."user/blogs/files/".$blog['id'].".dat"))
{
unlink(H."user/blogs/files/".$blog['id'].".dat");
}

$_SESSION['message'] = 'Вы успешно удалили блог.'; 
header("Location: /user/blogs/view/?id=".$avt_us['id']."".SID); 
exit; 
} 

}




if (user_access('notes_edit') || $user['id'] == $blog['id_user']){

$avtor = get_user($blog['id_user']);


if (isset($_POST['del_file']) && $blog['file_ves']!=0 && $blog['file_raz']!=NULL)
{
if (is_file(H."user/blogs/files/".$blog['id'].".dat"))
{
unlink(H."user/blogs/files/".$blog['id'].".dat");
}
mysql_query("UPDATE `diary_diarys` SET `file_raz` = '' WHERE `id` = '".$blog['id']."' LIMIT 1");
mysql_query("UPDATE `diary_diarys` SET `file_ves` = '0' WHERE `id` = '".$blog['id']."' LIMIT 1");
$_SESSION['message']="Файл успешно удален!";
header("Location: /user/blogs/edit/?id=".$blog['id']."");
exit;
}


if (isset($_POST['cfms']))
{

if (strlen2($_POST['tema']) < 3){
$err = 'Вы ввели короткое название';
}
else if (strlen2($_POST['tema']) > 100)
{
$err = 'Превышен лимит. max 100 символов.';
}
else if (strlen2($_POST['subject'])<5)
{
$err = 'Короткий Текст.';
}
else if (strlen2($_POST['subject'])>10000)
{
$err = 'Превышен лимит. max 10000 символов.';
}



$type = 0;



$id_dir = intval($_POST['chanel']);
$privat = intval($_POST['access']);
$privat_komm = intval($_POST['access_comm']);


if (!isset($err))
{

if ($blog['file_ves']==0 || $blog['file_raz']==NULL || !is_file(H."user/blogs/files/".$blog['id'].".dat"))
{
if (isset($_FILES['filik']) && isset($_FILES['filik']['tmp_name']))
{
$file=esc(stripcslashes(htmlspecialchars($_FILES['filik']['name'])));
$file=preg_replace('(\#|\?)', NULL, $file);
$name=preg_replace('#\.[^\.]*$#', NULL, $file);
$ras=strtolower(preg_replace('#^.*\.#', NULL, $file));
$size=filesize($_FILES['filik']['tmp_name']);
copy($_FILES['filik']['tmp_name'], H."user/blogs/files/".$blog['id'].".dat");
chmod(H."user/blogs/files/".$blog['id'].".dat", 0666);
}else{
$ras=NULL;
$size=0;
}
}else{
$ras=$blog['file_raz'];
$size=$blog['file_ves'];
}


mysql_query("UPDATE `notes` SET `msg` = '".my_esc($_POST['subject'])."' WHERE `id` = '".$blog['id']."' LIMIT 1");
mysql_query("UPDATE `notes` SET `adult` = '".intval($_POST['Adult'])."' WHERE `id` = '".$blog['id']."' LIMIT 1");
mysql_query("UPDATE `notes` SET `name` = '".my_esc($_POST['tema'])."' WHERE `id` = '".$blog['id']."' LIMIT 1");
mysql_query("UPDATE `notes` SET `file_raz` = '".$ras."' WHERE `id` = '".$blog['id']."' LIMIT 1");
mysql_query("UPDATE `notes` SET `file_ves` = '".$size."' WHERE `id` = '".$blog['id']."' LIMIT 1");

mysql_query("UPDATE `notes` SET `type` = '$type', `id_dir` = '$id_dir', `private` = '$privat', `private_komm` = '$privat_komm' WHERE `id`='".intval($_GET['id'])."'");

$_SESSION['message'] = 'Изменения успешно приняты';
header("Location: /user/blogs/read/?id=".$blog['id']."".SID);
exit;
}
}

$set['title'] = 'Редактирование записи : Блог : ' . $avtor['nick'];
include_once H.'sys/inc/thead.php';
title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  
<a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     
<span class="lc_brw"> 
<img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $avtor['id']?>"><?= $avtor['nick']?></a> 
</span>     
<span class="lc_brw"> 
<img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/blogs/view/?id=<?= $avtor['id']?>">Блог</a> 
</span>     
<span class="lc_brw"> 
<img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Редактирование записи</span> 
</span>       
</div>
<?

err();

?>
<form action="?id=<?= $blog['id']?>&amp;<?= $passgen?>"  enctype="multipart/form-data" method="post">  
<div class="wrapper"> 

<div class="block">  
<div>  
<label class="lbl">  Тема   (100 знаков): </label>   
<div class="input-txt_wrapper">  
<input placeholder="Введите тему записи" class="input-txt" name="tema" value="<?= htmlspecialchars($blog['name'])?>" maxlength="100" type="text">  
</div>   
</div>   
</div> 
 
<div class="block mail__form-item suggest_parent js-toolbar_wrap js-input_error_wrap " data-inner="1"> 
<label class="label text">  <label class="lbl">  Запись:</label>  </label>   
<div class="text-input__wrap"> 
<div class="cl" style="margin-bottom: 5px;"> <div class="relative"> <div class="input-txt_wrapper"> 
<textarea class="input-txt" tabindex="1" name="subject" rows="5" id="textarea" data-maxlength="10000" cols="17" placeholder="Введите текст записи">
<?= text($blog['msg'])?>
</textarea> 
</div> </div> </div>    
</div> </div>   
</div>     
<div class="wrapper"> 
<div class="block"> 

<div class="cl"> 
<?
if ($blog['file_ves']!=0 && $blog['file_raz']!=NULL && is_file(H."user/blogs/files/".$blog['id'].".dat"))
{
?>
<label class="lbl"> Вложения </label>
<?
echo "File.".$blog['file_raz']." (".size_file($blog['file_ves']).") ";
?>
<div style="margin-top: 10px;">
<input type="submit" name="del_file" value="Удалить файл" class="main_submit"/>
</div>
<?
}else{
?>
<label class="lbl"> Файл </label> 
<?
echo "<input name='filik' type='file' />";
}


?>
</div> </div>   
</div> 
 
<div class="wrapper"> 
<div class="block"> 

<div class="cl" style="margin-bottom: 10px;">
<label class="label text">  <label class="lbl"> Кто видит запись: </label>  </label>  
<label for="am_na_2_1"> 
<input name="access" id="am_na_2_1" type="radio" <?= ($blog['private']==0?' checked="checked"':null)?> value="0" />
<img class="m p16" src="/style/i/mode_na.png" alt="Все"> <span class="m">&nbsp;Все</span> 
</label><br />
<label for="am_na_2_2"> 
<input name="access" id="am_na_2_2" type="radio" <?= ($blog['private']==1?' checked="checked"':null)?> value="1" />
<img class="m p16" src="/style/i/mode_fronl.png" alt="Друзья"><span class="m">&nbsp;Друзья </span> 
</label><br />
<label for="am_na_2_3"> 
<input name="access" id="am_na_2_3" type="radio" <?= ($blog['private']==2?' checked="checked"':null)?> value="2" />
<img class="m p16" src="/style/i/mode_ownonl.png" alt="Только я"> <span class="m">&nbsp;Только я</span> 
</label>
</div>

<div class="cl" style="margin-bottom: 10px;">
<label class="label text">  <label class="lbl"> Кто может комментировать:</label>  </label>  
<label for="am_na_3_1"> 
<input name="access_comm" id="am_na_3_1" type="radio" <?= ($blog['private_komm']==0?' checked="checked"':null)?> value="0" />
<img class="m p16" src="/style/i/mode_na.png" alt="Все"> <span class="m">&nbsp;Все</span> 
</label><br />
<label for="am_na_3_2"> 
<input name="access_comm" id="am_na_3_2" type="radio" <?= ($blog['private_komm']==1?' checked="checked"':null)?> value="1" />
<img class="m p16" src="/style/i/mode_fronl.png" alt="Друзья"><span class="m">&nbsp;Друзья </span> 
</label><br />
<label for="am_na_3_3"> 
<input name="access_comm" id="am_na_3_3" type="radio" <?= ($blog['private_komm']==2?' checked="checked"':null)?> value="2" />
<img class="m p16" src="/style/i/mode_ownonl.png" alt="Только я"> <span class="m">&nbsp;Только я</span> 
</label>
</div>

<div class="cl" style="margin-bottom: 10px;"> 
<label class="label text">  <label class="lbl">  Канал: </label>  </label>
<select name="chanel">
<?
$q = mysql_query("SELECT * FROM `notes_dir` ORDER BY `id` DESC");
?>
<option value="0" <?= (!$blog['id_dir'] ? " selected='selected'":null)?>><span class="m">&nbsp;Без категории</span>
</option>
<?
while ($post = mysql_fetch_assoc($q))
{
?>
<option value="<?= $post['id']?>" <?= ($blog['id_dir'] == $post['id'] ?" selected='selected'":null)?>>
&nbsp;<?= text($post['name'])?>
</option>
<?
}
?>
</select>
</div>
<label> 
<input value="1" <?=($blog['adult'] == 1 ? "checked='checked'" : null)?> name="Adult" class="m" type="checkbox"> <span class="m grey chb_lbl">Только для взрослых <span class=" red">  (18+) </span>          </span> 
</label> 
</div>  
   
</div>             

<div class="wrapper">
<!-- --><!-- -->
<button value="Сохранить запись" class="  link  blue full is_final    " name = "cfms" id="cfms">
<!--   -->
<img src="/style/i/ok_blue.png" alt="" class="m"> <!--   --><span class="m"> Сохранить запись</span>
<!-- -->
</button>
<!-- --><!-- -->
</div>
</form>

<div class="wrapper">     
<a href="?id=<?= $blog['id']?>&dell" class="link  red     "> 
<span>        <img src="/style/i/delete.png" alt="" class="m">      <span class="m">  Удалить запись </span>          </span>  
</a>    
</div>


<a href="/user/blogs/read/?id=<?= $blog['id']?>" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?






include_once H.'sys/inc/tfoot.php';

}