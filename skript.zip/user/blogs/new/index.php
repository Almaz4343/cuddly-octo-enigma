<?

/**
 * & Author   :: Igor Slepko
 * & Nick     :: Tw1nGo
 * & Contacts :: http://gix.su/user/Tw1nGo
 */

include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';

// Если юзер в Бане
if (isset($user) && mysql_result(mysql_query("SELECT COUNT(*) FROM `ban` WHERE `razdel` = 'notes' AND `id_user` = '$user[id]' AND (`time` > '$time' OR `view` = '0' OR `navsegda` = '1')"), 0) != 0){
header('Location: /ban.php?'.SID);
exit;
}

if (!isset($user))header("location: /user/blogs/");


if (isset($_POST['cfms']))
{

if (strlen2($_POST['tema'])<2)
{
$err = 'Вы ввели короткое название.';
}
else if (strlen2($_POST['tema'])>100)
{
$err = 'Название превышает лимит 100 символов.';
}
else if (strlen2($_POST['subject'])<2)
{
$err = "Короткая запись!";
}
else if (strlen2($_POST['subject'])>10000)
{
$err = 'Превышен лимит. max 10000 символов.';
}


$type = 0;




if (!isset($err))
{
if (isset($_FILES['filik']) && isset($_FILES['filik']['tmp_name']))
{
$file=esc(stripcslashes(htmlspecialchars($_FILES['filik']['name'])));
$file=preg_replace('(\#|\?)', NULL, $file);
$name=preg_replace('#\.[^\.]*$#', NULL, $file);
$ras=strtolower(preg_replace('#^.*\.#', NULL, $file));
$size=filesize($_FILES['filik']['tmp_name']);
}else{
$ras=NULL;
$size=0;
}



mysql_query("INSERT INTO `notes` (`time`, `msg`, `name`, `id_user`, `private`, `adult`, `private_komm`, `id_dir`, `type`, `file_ves`, `file_raz`) values('$time', '".my_esc($_POST['subject'])."', '".my_esc($_POST['tema'])."', '$user[id]', '".intval($_POST['access'])."', '".intval($_POST['Adult'])."', '".intval($_POST['access_comm'])."', '".intval($_POST['chanel'])."', '$type', '".intval($size)."', '".my_esc($ras)."')");
$st = mysql_insert_id();

if (isset($_FILES['filik']) && isset($_FILES['filik']['tmp_name']))
{
copy($_FILES['filik']['tmp_name'], H."user/blogs/files/".$st.".dat");
chmod(H."user/blogs/files/".$st.".dat", 0666);
}

//Активность
mysql_query("INSERT INTO `user_activity` (`id_user`,`avtor`, `type`, `time`, `id_file`) values('$user[id]', '$user[id]', 'notes', '$time', '$st')"); 



// Лента
$q = mysql_query("SELECT * FROM `frends` WHERE `user` = '".$user['id']."' AND `i` = '1'");
while ($f = mysql_fetch_array($q))
{
$a = get_user($f['frend']);
// Общая настройка ленты
$lentaSet = mysql_fetch_array(mysql_query("SELECT * FROM `tape_set` WHERE `id_user` = '".$a['id']."' LIMIT 1")); 
// фильтр рассылки
if ($f['lenta_notes'] == 1 && $lentaSet['lenta_notes'] == 1 ) 
mysql_query("INSERT INTO `tape` (`id_user`,`avtor`, `type`, `time`, `id_file`) values('$a[id]', '$user[id]', 'notes', '$time', '$st')"); 
}
		   
mysql_query("OPTIMIZE TABLE `notes`");


$_SESSION['message'] = 'Изменения успешно приняты';
header("Location: /user/blogs/read/?id=".$st."".SID);
exit;
}
}

if (isset($_GET['id_dir']))
$id_dir=intval($_GET['id_dir']);
else
$id_dir=0;
$set['title'] = 'Новая запись : Блог : ' . $user['nick'];
include_once H.'sys/inc/thead.php';
title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  
<a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     
<span class="lc_brw"> 
<img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $user['id']?>"><?= $user['nick']?></a> 
</span>     
<span class="lc_brw"> 
<img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/blogs/view/?id=<?= $user['id']?>">Блог</a> 
</span>     
<span class="lc_brw"> 
<img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Новая запись</span> 
</span>       
</div>
<?

err();


?>
<form action="?" method="post" enctype="multipart/form-data">  
<div class="wrapper"> 

<div class="block">  <div>  
<label class="lbl">  Тема   (100 знаков): </label>   
<div class="input-txt_wrapper">  
<input placeholder="Введите тему записи" class="input-txt" name="tema" value="" maxlength="100" type="text">  
</div>   
</div>   </div>  
<div class="block mail__form-item suggest_parent js-toolbar_wrap js-input_error_wrap " data-inner="1"> 
<label class="label text">  <label class="lbl">  Запись:</label>  </label>   
<div class="text-input__wrap"> 
<div class="cl" style="margin-bottom: 5px;"> <div class="relative"> <div class="input-txt_wrapper"> 
<textarea class="input-txt" tabindex="1" name="subject" rows="5" id="textarea" data-maxlength="10000" cols="17" placeholder="Введите текст записи">
</textarea> 
</div> </div> </div>    
</div> </div>   
</div>    
 
<div class="wrapper"> 
<div class="block"> 
<div> 
<label class="lbl"> Файл: </label>  <input name="filik" type="file" />
</div> </div>   
</div> 

 
<div class="wrapper"> 
<div class="block"> 

<div class="cl" style="margin-bottom: 10px;">
<label class="label text">  <label class="lbl"> Кто видит запись: </label>  </label>  
<label for="am_na_2_1"> 
<input name="access" id="am_na_2_1" type="radio" selected="selected" value="0" />
<img class="m p16" src="/style/i/mode_na.png" alt="Все"> <span class="m">&nbsp;Все</span> 
</label><br />
<label for="am_na_2_2"> 
<input name="access" id="am_na_2_2" type="radio" value="1" />
<img class="m p16" src="/style/i/mode_fronl.png" alt="Друзья"><span class="m">&nbsp;Друзья </span> 
</label><br />
<label for="am_na_2_3"> 
<input name="access" id="am_na_2_3" type="radio" value="2" />
<img class="m p16" src="/style/i/mode_ownonl.png" alt="Только я"> <span class="m">&nbsp;Только я</span> 
</label>
</div>

<div class="cl" style="margin-bottom: 10px;">
<label class="label text">  <label class="lbl"> Кто может комментировать:</label>  </label>  
<label for="am_na_3_1"> 
<input name="access_comm" id="am_na_3_1" type="radio" selected="selected" value="0" />
<img class="m p16" src="/style/i/mode_na.png" alt="Все"> <span class="m">&nbsp;Все</span> 
</label><br />
<label for="am_na_3_2"> 
<input name="access_comm" id="am_na_3_2" type="radio" value="1" />
<img class="m p16" src="/style/i/mode_fronl.png" alt="Друзья"><span class="m">&nbsp;Друзья </span> 
</label><br />
<label for="am_na_3_3"> 
<input name="access_comm" id="am_na_3_3" type="radio" value="2" />
<img class="m p16" src="/style/i/mode_ownonl.png" alt="Только я"> <span class="m">&nbsp;Только я</span> 
</label>
</div>

<div class="cl" style="margin-bottom: 10px;"> 
<label class="label text">  <label class="lbl">  Добавить в канал: </label>  </label>
<select name="chanel">
<?
$q = mysql_query("SELECT * FROM `notes_dir` ORDER BY `id` DESC");
?>
<option value="0" <?= ($id_dir==0?" selected='selected'":null)?>><span class="m">&nbsp;Не выбран</span>
</option>
<?
while ($post = mysql_fetch_assoc($q))
{
?>
<option value="<?= $post['id']?>" <?= ($id_dir == $post['id']?" selected='selected'" : null)?>>
&nbsp;<?= text($post['name'])?>
</option>
<?
}
?>
</select>
</div>
<label> 
<input value="1" name="Adult" class="m" type="checkbox"> <span class="m grey chb_lbl">Только для взрослых <span class=" red">  (18+) </span>          </span> 
</label> 
</div>  
   
</div>             

<div class="wrapper">
<!-- --><!-- -->
<button value="Сохранить запись" class="  link  blue full is_final    " id="cfms" name="cfms">
<!--   -->
<img src="/style/i/ok_blue.png" alt="" class="m"> <!--   --><span class="m"> Сохранить запись</span>
<!-- -->
</button>
<!-- --><!-- -->
</div>
</form>

<a href="/user/?id=<?= $user['id']?>" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?



include_once H.'sys/inc/tfoot.php';  
?>