<? 

include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';

if (isset($_GET['comment']) && mysql_result(mysql_query("SELECT COUNT(*) FROM `notes_komm` WHERE `id` = '".intval($_GET['comment'])."'"),0)==1) 
{ 
$posts = mysql_fetch_assoc(mysql_query("SELECT * FROM `notes_komm` WHERE `id` = '".intval($_GET['comment'])."' LIMIT 1")); 
$notes = mysql_fetch_assoc(mysql_query("SELECT * FROM `notes` WHERE `id` = '$posts[id_notes]' LIMIT 1")); 
$anks = mysql_fetch_assoc(mysql_query("SELECT * FROM `user` WHERE `id` = $notes[id_user] LIMIT 1")); 

 

if (isset($user) && (user_access('notes_delete') || $user['id'] == $anks['id'])){ 

mysql_query("DELETE FROM `notes_komm` WHERE `id` = '$posts[id]'"); 

$_SESSION['message']='Комментарий успешно удален'; 
header("Location: /user/blogs/read/?id=$notes[id]"); 
exit; 

}
else{
$_SESSION['err'] = 'Такой умный? Свои коменты удаляй!'; 	
header("Location: " . htmlspecialchars($_SERVER['HTTP_REFERER'])); 
exit; 
} 

}else{ 
$_SESSION['err'] = 'Такой умный? Свои коменты удаляй!'; 	
header("Location: " . htmlspecialchars($_SERVER['HTTP_REFERER'])); 
exit; 
} 

 

 

 

if (isset($_GET['dir']) && mysql_result(mysql_query("SELECT COUNT(*) FROM `notes_dir` WHERE `id` = '".intval($_GET['dir'])."'"),0)==1) 

{ 

 

if (isset($user) && user_access('notes_delete')){ 

 

$q = mysql_query("SELECT * FROM `notes_dir` WHERE `id` = '".intval($_GET['dir'])."' LIMIT 1"); 

 

while ($post = mysql_fetch_assoc($q)) 

{ 

$notes=mysql_fetch_assoc(mysql_query("SELECT * FROM `notes` WHERE `id_dir` = '$post[id]'")); 

mysql_query("DELETE FROM `notes_count` WHERE `id_notes` = '$notes[id]'"); 

mysql_query("DELETE FROM `notes_komm` WHERE `id_notes` = '$notes[id]'"); 

mysql_query("DELETE FROM `mark_notes` WHERE `id_list` = '$notes[id]'"); 

} 

 

$post = mysql_fetch_assoc(mysql_query("SELECT * FROM `notes_dir` WHERE `id` = '".intval($_GET['dir'])."' LIMIT 1")); 

mysql_query("DELETE FROM `notes_count` WHERE `id_notes` = '$notes[id]'"); 

mysql_query("DELETE FROM `notes_komm` WHERE `id_notes` = '$notes[id]'"); 

mysql_query("DELETE FROM `mark_notes` WHERE `id_list` = '$notes[id]'"); 

mysql_query("DELETE FROM `notes` WHERE `id_dir` = '$post[id]'"); 

mysql_query("DELETE FROM `notes_dir` WHERE `id` = '$post[id]'"); 

 

$_SESSION['message']='Категория успешно удалена'; 

header("Location: " . htmlspecialchars($_SERVER['HTTP_REFERER'])); 

exit; 

 

}else{ 

echo output_text('А как ты сюда попал? .дум.'); 

} 

 

}else{ 

echo output_text('А как ты сюда попал? .дум.'); 

} 

 

 

 

 

 

?>