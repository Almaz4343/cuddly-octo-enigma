<?

/**
 * & Author   :: Igor Slepko
 * & Nick     :: Tw1nGo
 * & Contacts :: http://gix.su/user/Tw1nGo
 */

include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';

// Если юзер в Бане
if (isset($user) && mysql_result(mysql_query("SELECT COUNT(*) FROM `ban` WHERE `razdel` = 'notes' AND `id_user` = '$user[id]' AND (`time` > '$time' OR `view` = '0' OR `navsegda` = '1')"), 0) != 0){
header('Location: /ban.php?'.SID);
exit;
}

only_reg();

$uid = intval($_GET['id']);
$blog = mysql_fetch_assoc(mysql_query("SELECT * FROM `notes` WHERE `id` = '". $uid ."' LIMIT 1"));

if (mysql_result(mysql_query("SELECT COUNT(*) FROM `notes` WHERE `id` = '$blog[id]' LIMIT 1", $db), 0) == 0){
header("Location: /user/blogs/".SID);exit;
}

if (user_access('notes_edit') || $user['id'] == $blog['id_user']){

$avtor = get_user($blog['id_user']);

if (isset($_POST['cfms'])){

$privat = intval($_POST['access']);

if (!isset($err))
{
mysql_query("UPDATE `notes` SET `private` = '$privat' WHERE `id` = '".$blog['id']."'");

$_SESSION['message'] = 'Изменения успешно приняты';
header("Location: /user/blogs/read/?id=".$blog['id']."".SID);
exit;
}
}

$set['title'] = 'Настройки доступа  : Блог : ' . $avtor['nick'];
include_once H.'sys/inc/thead.php';
title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  
<a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     
<span class="lc_brw"> 
<img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $avtor['id']?>"><?= $avtor['nick']?></a> 
</span>     
<span class="lc_brw"> 
<img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/blogs/view/?id=<?= $avtor['id']?>">Блог</a> 
</span>     
<span class="lc_brw"> 
<img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Настройки доступа</span> 
</span>       
</div>
<?

err();

?>
<div class="strong_border"> 
<form action="?id=<?= $blog['id']?>" method="post">  
<div>  

<div class="vlight_border_bottom stnd_padd pdb vlight_border_bottom"> 
<label class="lbl">Кто видит запись:</label> 
</div> 
  
<div> 
<label for="am_na_2055153074_9" class="t-block_item stnd_padd vlight_border_bottom"> 
<input name="access" id="am_na_2055153074_9" value="0" <?= ($blog['private']==0?' checked="checked"':null)?> class="m" checked="checked" type="radio"> 
<img class="m p16" src="//c.spac.me/i/ico/ac_all_darkblue.png" alt="Все"> <span class="m">&nbsp;Все</span> 
</label> 
</div>
   
<div> 
<label for="am_oo_2055153074_9" class="t-block_item stnd_padd vlight_border_bottom"> 
<input name="access" id="am_oo_2055153074_9" value="2" <?= ($blog['private']==2?' checked="checked"':null)?> class="m" type="radio"> 
<img class="m p16" src="//c.spac.me/i/ico/ac_user_red.png" alt="Только я"> <span class="m">&nbsp;Только я</span> 
</label> 
</div>   

<div> 
<label for="am_fo_2055153074_9" class="t-block_item stnd_padd vlight_border_bottom"> 
<input name="access" id="am_fo_2055153074_9" value="1" <?= ($blog['private']==1?' checked="checked"':null)?> class="m" type="radio"> 
<img class="m p16" src="//c.spac.me/i/ico/ac_friends_green.png" alt="Мои друзья"> <span class="m">&nbsp;Мои друзья</span> 
</label> 
</div>              
<!-- ПК и ТАЧИ --> 
</div>       
<input style="margin:10px !important;" name="cfms" value="Сохранить" class="main_submit" id="mainSubmitForm" type="submit">        

</form> 
</div>

<a href="/user/blogs/read/?id=<?= $blog['id']?>" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?






include_once H.'sys/inc/tfoot.php';

}
else{
header("Location: /user/blogs/".SID); 
exit; 
}

?>