<?

/**
 * & Author   :: Igor Slepko
 * & Nick     :: Tw1nGo
 * & Contacts :: http://gix.su/user/Tw1nGo
 */

include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';

// Если юзер в Бане
if (isset($user) && mysql_result(mysql_query("SELECT COUNT(*) FROM `ban` WHERE `razdel` = 'notes' AND `id_user` = '$user[id]' AND (`time` > '$time' OR `view` = '0' OR `navsegda` = '1')"), 0) != 0){
header('Location: /ban.php?'.SID);
exit;
}


$act = isset($_GET['List']) ? my_esc($_GET['List']) : null;

switch ($act) {

// Стандарт
default:
if(!isset($_GET['Category'])){
$set['title'] = 'Блоги';
include_once H.'sys/inc/thead.php';
title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="//c.spac.me/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/blogs/">Блоги</a> </span>       </div>

<div class="wrapper-nobg">   
<form action="/user/blogs/" method="get">  
<table class="table__wrap search-wrap input-txt_grid"> <tbody><tr> 
<td class="input-txt_grid_input"> 
<div class="input-txt_wrapper_search relative"> <input class="input-txt" name="query" value="" maxlength="250" type="text"> </div> 
</td> 
<td class="input-txt_grid_sep"></td> 
<td class="input-txt_grid_btn"> <input class="search__btn" value="Найти" name="cfms" type="submit"> </td> 
</tr> </tbody></table>     
</form>   
</div>

<div class="tabs_block oh">    
<div class="tab_item left tab_active black" style="padding: 12px 9px 8px 9px">  Каналы  </div>   
<a href="/user/blogs/?List=0" class="tab_item left" style="padding: 12px 9px 8px 9px">  Популярные  </a>   
<a href="/user/blogs/?List=1" class="tab_item left" style="padding: 12px 9px 8px 9px">  Новые  </a>   
</div>
<?
$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `notes_dir` "),0);

if($k_post == 0){
?>
<div class="wrapper"> <div class="link"> Каналов нет. </div> </div>
<?
}
else{
?>
<div class="wrapper"> <div class="list f-c_fll">
<?
$q = mysql_query("SELECT * FROM `notes_dir` ORDER BY `id` ASC");

while ($post = mysql_fetch_assoc($q))
{

?>
<a href="?Category=<?= $post['id']?>" class="link  darkblue arrow    "> 
<span> 
<img src="/style/i/blogs/<?= $post['icon']?>" alt="" class="m">      <span class="m">  <?= text($post['name'])?> </span>          
</span>  
</a>
<?
}

?>
</div> </div>
<?
}
?>
<div class="lc_br wbg font0 relative oh" id="footer_path">  <a href="/" style="font-size:0;"> <img src="//c.spac.me/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/blogs/">Блоги</a> </span>     </div>
<?
include_once H.'sys/inc/tfoot.php';
}
else{
// ЕСЛИ ВЫБРАЛИ КАНАЛ 

$uid_dir = intval($_GET['Category']);
$kanal = mysql_fetch_assoc(mysql_query("SELECT * FROM `notes_dir` WHERE `id` = '".$uid_dir."' LIMIT 1"));

if(!$uid_dir || !$kanal){
$set['title'] = 'Ошибка!';
include_once H.'sys/inc/thead.php';
title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  
<a href="/" style="font-size:0;"> <img src="//c.spac.me/i/lb/home.png" alt=""> </a>
<span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Ошибка</span> </span>
</div>
<div class="wrapper"> <div class="link"> Канал не найден. </div> </div>
<?
include_once H.'sys/inc/tfoot.php';
exit;
}

$set['title'] = 'Блоги';
include_once H.'sys/inc/thead.php';
title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  
<a href="/" style="font-size:0;"> <img src="//c.spac.me/i/lb/home.png" alt=""> </a>     
<span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/blogs/">Блоги</a> </span>       
<span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text"><?= text($kanal['name'])?></span> </span>
</div>
<?
$set['p_str'] = '10';
$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `notes`  WHERE `id_dir` = '$kanal[id]'"),0);
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str']*$page-$set['p_str'];

if ($k_post ==  0){
?>
<div class="wrapper"> <div class="link"> Блоги не найдены. </div> </div>
<?
}
else{

?>
<div class="wrapper bb0">
<?

if(isset($user) && $user['level'] >= 3){
$komu_vidno = "";
}
else{
$komu_vidno = " AND `private` != '2'";
}


$q = mysql_query("SELECT * FROM `notes` WHERE `id_dir` = '$kanal[id]'$komu_vidno ORDER BY `time` LIMIT $start, $set[p_str]");

while ($post = mysql_fetch_assoc($q))
{
$ank = get_user($post['id_user']);
$koment = mysql_result(mysql_query("SELECT COUNT(*) FROM `notes_komm` WHERE `id_notes` = '".$post['id']."'"), 0);
$kan_post = mysql_fetch_assoc(mysql_query("SELECT * FROM `notes_dir` WHERE `id` = '".$post['id_dir']."' LIMIT 1"));
$_msg = text($post['msg']);
if (iconv_strlen($_msg, 'UTF-8') > 50) {
        $_msg= iconv_substr($_msg, 0, 200, 'UTF-8');
        $_msg = $_msg.'...';
}
?>
<div class="block bord-botm relative attaches_limiter"> 
<div class="oh">   
<span class="right"> <span class="grey m"><?= vremja($post['time'])?></span>   </span>
<div class="grey"> <?= group($ank['id'])?> <?= unick($ank['id'])?> </div>     
<div class="cl pad_t_a"></div>  
<?
if ($post['file_ves'] != 0 && $post['file_raz'] != NULL && is_file(H."user/blogs/files/".$post['id'].".dat"))
{
if ($post['file_raz'] == 'png' || $post['file_raz'] == 'gif' || $post['file_raz'] == 'jpg' || $post['file_raz'] == 'jpeg')
{
?>
<div class="left t-padd_right">     
<div>  
<span class="short_attach">   
<div class="inl_bl">        
<span class="pr">   
<div class="inl_bl relative"> 
<img src="/user/blogs/file/<?= $post['id']?>.<?= $post['file_raz']?>" alt="" class="preview s81_80"  style="width:80px;height:80px;">   
</div>     
</span>             
</div>     
</span>  
</div>    
</div>
<?
}
}
?>     
<div class="oh"> 
<a class="arrow_link full_link" href="/user/blogs/read/?id=<?= $post['id']?>"> <b> <?= text($post['name'])?> </b> </a>  <div> <?= $_msg?> </div>  
</div>   </div> 
<?
if($koment > 0 OR $kan_post['name'] != null){
?>
<div>  
<div class="oh">   
<div class="oh cl grey pad_t_a">  
<?
if($koment > 0){
?> 
<span class="left"> 
<img src="//c.spac.me/i/comm_ico.png" class="m p16" alt=""> 
<span class="m"><?= $koment?></span> 
</span>  
<?
}
if($kan_post['name'] != null){
?> 
<span class="m right"> <?= text($kan_post['name'])?> </span>  
<?
}
?> 
</div>  <div class="cl"></div> </div> </div>    
<?
}
?>
<div class="cl"></div> 
</div>
<?
}

?>
</div>
<?

}
if ($k_page > 1)str("?Category=".$kanal['id']."&amp;",$k_page,$page); // Вывод страниц
include_once H.'sys/inc/tfoot.php';
}


break;



// ПОПУЛЯРНЫЕ
case '0':
$set['title'] = 'Блоги';
include_once H.'sys/inc/thead.php';
title();

if (isset($_GET['Filter']) && ($_GET['Filter'] == '0' || $_GET['Filter'] == '1' || $_GET['Filter'] == '2'))
{
if ($_GET['Filter'] == '0')
{
$_SESSION['diary_sort'] = 1;
}
else if ($_GET['Filter'] == '1')
{
$_SESSION['diary_sort'] = 2;
}
else if ($_GET['Filter'] == '2')
{
$_SESSION['diary_sort'] = 3;
}
/*
header("Location: /user/blogs/");
exit;
*/
}


?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="//c.spac.me/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/blogs/">Блоги</a> </span>       </div>

<div class="wrapper-nobg">   
<form action="/user/blogs/" method="get">  
<table class="table__wrap search-wrap input-txt_grid"> <tbody><tr> 
<td class="input-txt_grid_input"> 
<div class="input-txt_wrapper_search relative"> <input class="input-txt" name="query" value="" maxlength="250" type="text"> </div> 
</td> 
<td class="input-txt_grid_sep"></td> 
<td class="input-txt_grid_btn"> <input class="search__btn" value="Найти" name="cfms" type="submit"> </td> 
</tr> </tbody></table>     
</form>   
</div>

<div class="tabs_block oh">    
<a href="/user/blogs/" class="tab_item left" style="padding: 12px 9px 8px 9px">  Каналы</a>      
<div class="tab_item left tab_active black" style="padding: 12px 9px 8px 9px">  Популярные    </div>
<a href="/user/blogs/?List=1" class="tab_item left" style="padding: 12px 9px 8px 9px">  Новые  </a>   
</div>

<div class="wrapper"> 
<table class="table__wrap table_no_borders nowrap"> <tbody><tr>  
<?
if (!isset($_SESSION['diary_sort']) || $_SESSION['diary_sort'] == NULL || $_SESSION['diary_sort'] == 0 || !is_numeric($_SESSION['diary_sort']) || !isset($user)){
?>
<td class="table__cell" width="33%">  <div class="link sub_selected b"> Новые   </div>  </td>  
<td class="table__cell" width="33%">  
<a href="/user/blogs/?Filter=1&amp;List=0" class="link b"> За месяц   </a>  
</td>  
<td class="table__cell" width="33%">  
<a href="/user/blogs/?Filter=2&amp;List=0" class="link b"> Все   </a>  
</td>  
<?
}
else{
if ($_SESSION['diary_sort'] == 1){
?>
<td class="table__cell" width="33%">  <div class="link sub_selected b"> Новые   </div>  </td>  
<td class="table__cell" width="33%">  
<a href="/user/blogs/?Filter=1&amp;List=0" class="link b"> За месяц   </a>  
</td>  
<td class="table__cell" width="33%">  
<a href="/user/blogs/?Filter=2&amp;List=0" class="link b"> Все   </a>  
</td> 
<?
}
else if ($_SESSION['diary_sort'] == 2){
?>
<td class="table__cell" width="33%">  
<a href="/user/blogs/?Filter=0&amp;List=0" class="link b"> Новые   </a>  
</td>  
<td class="table__cell" width="33%">  <div class="link sub_selected b"> За месяц   </div>  </td>  
<td class="table__cell" width="33%">  
<a href="/user/blogs/?Filter=2&amp;List=0" class="link b"> Все   </a>  
</td>
<?
}
else if ($_SESSION['diary_sort'] == 3){
?>
<td class="table__cell" width="33%">  
<a href="/user/blogs/?Filter=0&amp;List=0" class="link b"> Новые   </a>  
</td>  
<td class="table__cell" width="33%">  
<a href="/user/blogs/?Filter=1&amp;List=0" class="link b"> За месяц   </a>  
</td>  
<td class="table__cell" width="33%">  <div class="link sub_selected b"> Все   </div>  </td>
<?
}

}
?>
</tr> </tbody></table> 
</div>
<?

if(isset($user) && $user['level'] >= 3){
$komu_vidn = "";
$komu_vidn2 = "";
}
else{
$komu_vidn = " WHERE `private` != '2'";
$komu_vidn2 = " AND `private` != '2'";
}


$diary_time = time()-2592000;
$set['p_str'] = '10';

if (!isset($_SESSION['diary_sort']) || $_SESSION['diary_sort'] == NULL || $_SESSION['diary_sort'] == 0 || !is_numeric($_SESSION['diary_sort']) || !isset($user)){
$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `notes`$komu_vidn ORDER BY `time`"), 0);
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str']*$page-$set['p_str'];
$q = mysql_query("SELECT * FROM `notes`$komu_vidn ORDER BY `time` DESC LIMIT $start, $set[p_str]");
}
else{
if ($_SESSION['diary_sort'] == 1){
$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `notes` WHERE `time`$komu_vidn2 ORDER BY `time`"), 0);
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str']*$page-$set['p_str'];
$q = mysql_query("SELECT * FROM `notes` WHERE `time`$komu_vidn2 ORDER BY `time` DESC LIMIT $start, $set[p_str]");
}
else if ($_SESSION['diary_sort'] == 2){
$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `notes` WHERE `time` > '".$diary_time."'$komu_vidn2 ORDER BY `time`,`count`"), 0);
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str']*$page-$set['p_str'];
$q = mysql_query("SELECT * FROM `notes` WHERE `time` > '".$diary_time."'$komu_vidn2 ORDER BY `time`,`count` DESC LIMIT $start, $set[p_str]");
}
else if ($_SESSION['diary_sort'] == 3){
$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `notes` WHERE `time`$komu_vidn2 ORDER BY `count`"), 0);
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str']*$page-$set['p_str'];
$q = mysql_query("SELECT * FROM `notes` WHERE `time`$komu_vidn2 ORDER BY `count` DESC LIMIT $start, $set[p_str]");
}
}

if ($k_post == 0){
echo "<div class='error'>";
echo "Блоги отсутствуют!";
echo "</div>";
}
else{

?>
<div class="wrapper bb0">
<?

while ($post = mysql_fetch_assoc($q))
{
$us_ank = get_user($post['id_user']);
$koment = mysql_result(mysql_query("SELECT COUNT(*) FROM `notes_komm` WHERE `id_notes` = '".$post['id']."'"), 0);
$kan_post = mysql_fetch_assoc(mysql_query("SELECT * FROM `notes_dir` WHERE `id` = '".$post['id_dir']."' LIMIT 1"));
$_msg = text($post['msg']);
if (iconv_strlen($_msg, 'UTF-8') > 50) {
        $_msg= iconv_substr($_msg, 0, 200, 'UTF-8');
        $_msg = $_msg.'...';
}
?>
<div class="block bord-botm relative attaches_limiter"> 
<div class="oh">
<span class="right"> <span class="grey m"><?= vremja($post['time'])?></span>   </span>
<div class="grey"> <?= group($us_ank['id'])?> <?= unick($us_ank['id'])?> </div>     
<div class="cl pad_t_a"></div>   
<?
if ($post['file_ves'] != 0 && $post['file_raz'] != NULL && is_file(H."user/blogs/files/".$post['id'].".dat"))
{
if ($post['file_raz'] == 'png' || $post['file_raz'] == 'gif' || $post['file_raz'] == 'jpg' || $post['file_raz'] == 'jpeg')
{
?>
<div class="left t-padd_right">     
<div>  
<span class="short_attach">   
<div class="inl_bl">        
<span class="pr">   
<div class="inl_bl relative"> 
<img src="/user/blogs/file/<?= $post['id']?>.<?= $post['file_raz']?>" alt="" class="preview s81_80"  style="width:80px;height:80px;">   
</div>     
</span>             
</div>     
</span>  
</div>    
</div>
<?
}
}
?>
<div class="oh"> 
<a class="arrow_link full_link" href="/user/blogs/read/?id=<?= $post['id']?>"> 
<b>  <?= text($post['name'])?>  </b> 
</a>  
<div> <?= $_msg?> </div>  
</div>   </div> 
<?
if($koment > 0 OR $kan_post['name'] != null){
?>
<div>  
<div class="oh">   
<div class="oh cl grey pad_t_a">  
<?
if($koment > 0){
?> 
<span class="left"> 
<img src="//c.spac.me/i/comm_ico.png" class="m p16" alt=""> 
<span class="m"><?= $koment?></span> 
</span>  
<?
}
if($kan_post['name'] != null){
?> 
<span class="m right"> <?= text($kan_post['name'])?> </span>  
<?
}
?> 
</div>  <div class="cl"></div> </div> </div>    
<?
}
?>
<div class="cl"></div> 
</div>
<?
}
?>
</div>
<?



}
if ($k_page > 1)str("?List=0&amp;",$k_page,$page); // Вывод страниц

include_once H.'sys/inc/tfoot.php';


break;



// НОВЫЕ

case '1':
$set['title'] = 'Блоги';
include_once H.'sys/inc/thead.php';
?>

<?
title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="//c.spac.me/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/blogs/">Блоги</a> </span>       </div>

<div class="wrapper-nobg">   
<form action="/user/blogs/" method="get">  
<table class="table__wrap search-wrap input-txt_grid"> <tbody><tr> 
<td class="input-txt_grid_input"> 
<div class="input-txt_wrapper_search relative"> <input class="input-txt" name="query" value="" maxlength="250" type="text"> </div> 
</td> 
<td class="input-txt_grid_sep"></td> 
<td class="input-txt_grid_btn"> <input class="search__btn" value="Найти" name="cfms" type="submit"> </td> 
</tr> </tbody></table>     
</form>   
</div>

<div class="tabs_block oh">    
<a href="/user/blogs/" class="tab_item left" style="padding: 12px 9px 8px 9px">  Каналы</a>      
<a href="/user/blogs/?List=0" class="tab_item left" style="padding: 12px 9px 8px 9px">  Популярные  </a>   
<div class="tab_item left tab_active black" style="padding: 12px 9px 8px 9px">  Новые  </div>  
</div>
<?

if(isset($user) && $user['level'] >= 3){
$komu_vidn3 = "";
}
else{
$komu_vidn3 = " AND `private` != '2'";
}


$set['p_str'] = '10';

$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `notes` WHERE `id`$komu_vidn3 ORDER BY `time`"), 0);
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str']*$page-$set['p_str'];
$q = mysql_query("SELECT * FROM `notes` WHERE `id`$komu_vidn3 ORDER BY `time` DESC LIMIT $start, $set[p_str]");

if ($k_post == 0){
echo "<div class='error'>";
echo "Блоги отсутствуют!";
echo "</div>";
}
else{

?>
<div class="wrapper bb0">
<?

while ($post = mysql_fetch_assoc($q))
{
$us_ank = get_user($post['id_user']);
$koment = mysql_result(mysql_query("SELECT COUNT(*) FROM `notes_komm` WHERE `id_notes` = '".$post['id']."'"), 0);
$kan_post = mysql_fetch_assoc(mysql_query("SELECT * FROM `notes_dir` WHERE `id` = '".$post['id_dir']."' LIMIT 1"));
$_msg = text($post['msg']);
if (iconv_strlen($_msg, 'UTF-8') > 50) {
        $_msg= iconv_substr($_msg, 0, 200, 'UTF-8');
        $_msg = $_msg.'...';
}
?>
<div class="block bord-botm relative attaches_limiter"> 
<div class="oh">
<span class="right"> <span class="grey m"><?= vremja($post['time'])?></span>   </span>
<div class="grey"> <?= group($us_ank['id'])?> <?= unick($us_ank['id'])?> </div>     
<div class="cl pad_t_a"></div>  
<?
if ($post['file_ves'] != 0 && $post['file_raz'] != NULL && is_file(H."user/blogs/files/".$post['id'].".dat"))
{
if ($post['file_raz'] == 'png' || $post['file_raz'] == 'gif' || $post['file_raz'] == 'jpg' || $post['file_raz'] == 'jpeg')
{
?>
<div class="left t-padd_right">     
<div>  
<span class="short_attach">   
<div class="inl_bl">        
<span class="pr">   
<div class="inl_bl relative"> 
<img src="/user/blogs/file/<?= $post['id']?>.<?= $post['file_raz']?>" alt="" class="preview s81_80"  style="width:80px;height:80px;">   
</div>     
</span>             
</div>     
</span>  
</div>    
</div>
<?
}
}
?> 
<div class="oh"> 
<a class="arrow_link full_link" href="/user/blogs/read/?id=<?= $post['id']?>"> 
<b>  <?= text($post['name'])?>  </b> 
</a>  
<div> <?= $_msg?> </div>  
</div>   </div> 
<?
if($koment > 0 OR $kan_post['name'] != null){
?>
<div>  
<div class="oh">   
<div class="oh cl grey pad_t_a">  
<?
if($koment > 0){
?> 
<span class="left"> 
<img src="//c.spac.me/i/comm_ico.png" class="m p16" alt=""> 
<span class="m"><?= $koment?></span> 
</span>  
<?
}
if($kan_post['name'] != null){
?> 
<span class="m right"> <?= text($kan_post['name'])?> </span>  
<?
}
?> 
</div>  <div class="cl"></div> </div> </div>    
<?
}
?>
<div class="cl"></div> 
</div>
<?
}
?>
</div>
<?


if ($k_page > 1)str("?List=1&amp;",$k_page,$page); // Вывод страниц

}



include_once H.'sys/inc/tfoot.php';

break;
}