<?

/**
 * & Author   :: Igor Slepko
 * & Nick     :: Tw1nGo
 * & Contacts :: http://gix.su/user/Tw1nGo
 */

include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';

// Если юзер в Бане
if (isset($user) && mysql_result(mysql_query("SELECT COUNT(*) FROM `ban` WHERE `razdel` = 'notes' AND `id_user` = '$user[id]' AND (`time` > '$time' OR `view` = '0' OR `navsegda` = '1')"), 0) != 0){
header('Location: /ban.php?'.SID);
exit;
}

if (isset($user)){
	$ank['id'] = $user['id'];
}

if (isset($_GET['id'])){
	$ank['id'] = intval($_GET['id']);
}

$ank = get_user($ank['id']);

if ($ank['id'] == 0 || !$ank){
$set['title'] = 'Ошибка!';
include_once H.'sys/inc/thead.php';
title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  
<a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>
<span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Ошибка</span> </span>
</div>
<div class="wrapper"> <div class="link"> Пользователь не найден. </div> </div>
<?
include_once H.'sys/inc/tfoot.php';
exit;
}


// Приветствие
if (isset($_POST['welcome_msg']) && isset($user) && $user['id'] == $ank['id'])
{
$msg = $_POST['welcome_msg'];
$mat = antimat($msg);
if ($mat)$err[] = 'В тексте приветствия обнаружен мат: '.$mat;

if (strlen2($msg) > 250){
$err = 'Приветствие не должно быть больше 2500 символов.';
}elseif (strlen2($msg) == 1){
$err = 'Слишком короткое приветствие.';
}

if($msg == null){
$ijha = null;
}elseif($msg > 1){
$ijha = my_esc($msg);
}else{
$ijha = my_esc($msg);
}

if(!isset($err)){
mysql_query("UPDATE `user` SET `ank_blogs` = '".$ijha."' WHERE `id` = '$user[id]'");
header("Location: ?id=$ank[id]");
exit;
} 
}


$set['title'] = 'Блог : ' . $ank['nick'];
include_once H.'sys/inc/thead.php';
title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  
<a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     
<span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> 
<a href="/user/?id=<?= $ank['id']?>"><?= $ank['nick']?></a> 
</span>     
<span class="lc_brw"> 
<img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> 
<a href="/user/blogs/view/?id=<?= $ank['id']?>">Блог</a> 
</span>       
</div>
<?

err();

if(isset($user) && $user['id'] == $ank['id'])
{
?>
<div class="wrapper"> <div class="bubble mt_0 mb0 word_break">  
<a class="right" href="?id=<?= $ank['id']?>&welcome=new" style="margin-left: 5px;"><img src="/style/i/edit_info.png" alt="" class="p16"></a> 
<div class="oh"> 
<?
if($ank['ank_blogs'] == null){
?> 
<span class="grey">Описание не добавлено.</span>  
<?
}else{
?> 
<span class="grey"> <?= text($ank['ank_blogs'])?></span>  
<?
}
?>
</div>  </div></div>
<?




if (isset($user) && isset($_GET['welcome']) && $_GET['welcome'] == 'new'){

?>
 
<div class="wrapper" style="margin-top:0;"> 
<form action="?id=<?= $ank['id']?>" method="post"> 
<div class="block bord-botm">  
<div>   <div class="input-txt_wrapper">  <textarea class="input-txt" rows="5" cols="17" name="welcome_msg" maxlength="512"><?=text($ank['ank_blogs'])?></textarea>  </div>   </div>  
</div>  
<table class="table__wrap"> <tbody><tr> 
<td class="table__cell" width="50%"> 
<!-- --><!-- --><!-- --><!-- --><!-- -->
<button type="submit" value="Сохранить" class="  link  blue full is_final    " id="cfms">
<!--   -->
<img src="/style/i/ok_blue.png" alt="" class="m"> 
<!--   -->
<span class="m"> Сохранить</span>
<!-- -->
</button>
<!-- --><!-- --> 
</td> 
<td class="table__cell table__cell_last" width="50%">     
<a href="?id=<?= $ank['id']?>" class="link         "> <span>Отменить</span>  </a>    
</td> 
</tr> </tbody></table> 
</form> 
</div>  
<?
}
?>
<div class="wrapper bb0">  <div class="bord-botm">     
<a href="/user/blogs/new/?" class="link         "> 
<span> <img src="/style/i/blog.png" alt="" class="m"> <span class="m">  Написать в Блог </span> </span>  
</a>     
</div>    </div>
<?
}else{

if($ank['ank_blogs'] != null){
?>
<div class="wrapper"> <div class="bubble mt_0 mb0 word_break">  
<div class="oh"> 
<span class="grey"> <?= text($ank['ank_blogs'])?></span>  
</div>  
</div> </div>
<?
}
}


if(isset($user) && $user['id'] == $ank['id'] || $user['level'] >= 3){
$komu_vidno = "";
}
else{
$komu_vidno = " AND `private` != '2'";
}


$set['p_str'] = '10';
$k_post=mysql_result(mysql_query("SELECT COUNT(*) FROM `notes` WHERE `id_user` = '$ank[id]' $komu_vidno"),0);
$k_page=k_page($k_post,$set['p_str']);
$page=page($k_page);
$start=$set['p_str']*$page-$set['p_str'];

$q = mysql_query("SELECT * FROM `notes` WHERE `id_user` = '$ank[id]' $komu_vidno order by `time` desc LIMIT $start, $set[p_str]");

if ($k_post == 0){
?>
<div class="wrapper"> <div class="link"> Блоги не найдены. </div> </div>
<?
}
else{
?>
<div class="wrapper bb0">
<?

while ($post = mysql_fetch_assoc($q))
{
$us_ank = get_user($post['id_user']);
$koment = mysql_result(mysql_query("SELECT COUNT(*) FROM `notes_komm` WHERE `id_notes` = '".$post['id']."'"), 0);
$kan_post = mysql_fetch_assoc(mysql_query("SELECT * FROM `notes_dir` WHERE `id` = '".$post['id_dir']."' LIMIT 1"));
$_msg = text($post['msg']);
if (iconv_strlen($_msg, 'UTF-8') > 50) {
        $_msg= iconv_substr($_msg, 0, 200, 'UTF-8');
        $_msg = $_msg.'...';
}

if($post['private'] == 1)$ico_privat = '<img src="//c.spac.me/i/ico/mode_fronl.png" alt="" class="m p16" title="Доступно друзьям">  ';
elseif($post['private'] == 2)$ico_privat = '<img src="//c.spac.me/i/ico/mode_ownonl.png" alt="" class="m p16" title="">  ';
else
$ico_privat = '<img src="//c.spac.me/i/ico/mode_na.png" alt="" class="m p16" title="Доступно всем">  ';

?>
<div class="block bord-botm relative attaches_limiter"> 
<div class="oh">

<span class="right"> 
<span class="grey m"><?= vremja($post['time'])?></span>
<?
if($post['adult'] == 1){
?>  
<img src="/style/i/adult_ico.png" alt="" class="m p16" title="Только для взрослых">  
<?
}
?>
<!--     -->
<?= $ico_privat?>
<!--   --><!--   --> 
</span>

<div class="grey"> <?= group($us_ank['id'])?> <?= unick($us_ank['id'])?> </div>     
<div class="cl pad_t_a"></div>   
<?
if ($post['file_ves'] != 0 && $post['file_raz'] != NULL && is_file(H."user/blogs/files/".$post['id'].".dat"))
{
if ($post['file_raz'] == 'png' || $post['file_raz'] == 'gif' || $post['file_raz'] == 'jpg' || $post['file_raz'] == 'jpeg')
{
?>
<div class="left t-padd_right">     
<div>  
<span class="short_attach">   
<div class="inl_bl">        
<span class="pr">   
<div class="inl_bl relative"> 
<img src="/user/blogs/file/<?= $post['id']?>.<?= $post['file_raz']?>" alt="" class="preview s81_80"  style="width:80px;height:80px;">   
</div>     
</span>             
</div>     
</span>  
</div>    
</div>
<?
}
}
?>
<div class="oh"> 
<a class="arrow_link full_link" href="/user/blogs/read/?id=<?= $post['id']?>"> 
<b>  <?= text($post['name'])?>  </b> 
</a>  
<div> <?= $_msg?> </div>  
</div>   </div> 
<?
if($koment > 0 OR $kan_post['name'] != null){
?>
<div>  
<div class="oh">   
<div class="oh cl grey pad_t_a">  
<?
if($koment > 0){
?> 
<span class="left"> 
<img src="//c.spac.me/i/comm_ico.png" class="m p16" alt=""> 
<span class="m"><?= $koment?></span> 
</span>  
<?
}
if($kan_post['name'] != null){
?> 
<span class="m right"> <?= text($kan_post['name'])?> </span>  
<?
}
?> 
</div>  <div class="cl"></div> </div> </div>    
<?
}
?>
<div class="cl"></div> 
</div>
<?
}
?>
</div>
<?
}
?>
<a href="/user/?id=<?= $ank['id']?>" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?

include_once H.'sys/inc/tfoot.php';
?>