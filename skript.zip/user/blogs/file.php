<?

define("H", $_SERVER["DOCUMENT_ROOT"].'/');
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';
include_once H.'sys/inc/downloadfile.php';
if (isset($_GET['id']))
{
$it=intval($_GET['id']);
$diary=mysql_fetch_array(mysql_query("SELECT * FROM `notes` WHERE `id` = '".$it."' LIMIT 1"));
}
if (!isset($_GET['id']) || !$diary || $diary['id']==0 || $diary['file_ves']==0 || $diary['file_raz']==NULL || !is_file(H."user/blogs/files/".$diary['id'].".dat"))
{
header('Location: /err.php');
exit;
}else{
$filer="/user/blogs/files/".$diary['id'].".dat";
$namee="file";
$ras=$diary['file_raz'];
DownloadFile(H.''.$filer.'', ''.$namee.'.'.$ras.'', ras_to_mime($ras));
exit;
}
?>