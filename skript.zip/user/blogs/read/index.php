<?

/**
 * & Author   :: Igor Slepko
 * & Nick     :: Tw1nGo
 * & Contacts :: http://gix.su/user/Tw1nGo
 * & Date     :: 15.05.2017
 */

include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';

// Если юзер в Бане
if (isset($user) && mysql_result(mysql_query("SELECT COUNT(*) FROM `ban` WHERE `razdel` = 'notes' AND `id_user` = '$user[id]' AND (`time` > '$time' OR `view` = '0' OR `navsegda` = '1')"), 0) != 0){
header('Location: /ban.php?'.SID);
exit;
}


$uid = intval($_GET['id']);
$blog = mysql_fetch_assoc(mysql_query("SELECT * FROM `notes` WHERE `id` = '". $uid ."' LIMIT 1"));
$kanal = mysql_fetch_assoc(mysql_query("SELECT * FROM `notes_dir` WHERE `id` = '".$blog['id_dir']."' LIMIT 1"));


$ank = get_user($blog['id_user']);

$markinfo = mysql_result(mysql_query("SELECT COUNT(*) FROM `bookmarks` WHERE `id_object` = '".$blog['id']."' AND `type` = 'notes'"),0);

if(!isset($blog['id'])){
$set['title'] = 'Ошибка!';
include_once H.'sys/inc/thead.php';
title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  
<a href="/" style="font-size:0;"> <img src="//c.spac.me/i/lb/home.png" alt=""> </a>
<span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Ошибка</span> </span>
</div>
<div class="wrapper"> <div class="link"> Блог не найден. </div> </div>
<?
include_once H.'sys/inc/tfoot.php';
exit;
}

// Запись просмотра
if (isset($user) && mysql_result(mysql_query("SELECT COUNT(*) FROM `notes_count` WHERE `id_user` = '".$user['id']."' AND `id_notes` = '".$blog['id']."' LIMIT 1"),0) == 0){
mysql_query("INSERT INTO `notes_count` (`id_notes`, `id_user`) VALUES ('$blog[id]', '$user[id]')");
mysql_query("UPDATE `notes` SET `count` = '".($blog['count']+1)."' WHERE `id` = '$blog[id]' LIMIT 1");
}



if (isset($_POST['smiles'])){
header("Location: /plugins/smiles/".SID);
exit;
}
if (isset($_POST['bb_teg'])){
header("Location: /plugins/rules/bb-code.php".SID);
exit;
}

// Отправка Смс
if (isset($_POST['text']) && isset($user))  
{  
$msg = $_POST['text'];  
  
if (strlen2($msg) > 1000){
$err = 'Сообщение слишком длинное';
}elseif (strlen2($msg) < 2){
$err = 'Короткое сообщение';
}  
  
elseif (mysql_result(mysql_query("SELECT COUNT(*) FROM `notes_komm` WHERE `id_notes` = '$blog[id]' AND `id_user` = '$user[id]' AND `msg` = '".my_esc($msg)."' LIMIT 1"),0)!=0){
$err='Ваше сообщение повторяет предыдущее';
}  
  
elseif(!isset($err)){  
  
/*
Уведомления об ответах   
*/  
//if (isset($user) && $respons==TRUE){  
$notifiacation=mysql_fetch_assoc(mysql_query("SELECT * FROM `notification_set` WHERE `id_user` = '".$ank_otv['id']."' LIMIT 1"));  
			  
if ($ank['id'] != $user['id']){
$mgsw = "Пользователь оставил комментарий к вашему блогу ".($blog['name'])."!";
mysql_query("INSERT INTO `journal` (`user`, `time`, `act`, `opis`, `ank`, `url`) VALUES ('".$user['id']."', '".$time."', 'blogs', '".$mgsw."', '".$ank['id']."', '/user/blogs/read/?id=".$blog['id']."')");
}  
//}
 
mysql_query("INSERT INTO `notes_komm` (`id_user`, `time`, `msg`, `id_notes`) values('$user[id]', '$time', '".my_esc($msg)."', '".$blog['id']."')");   
$_SESSION['message'] = 'Сообщение успешно отправлено';  
header("Location: ?id=$blog[id]&P=".intval($_GET['page'])."");  
exit;  
}  
} 



if (isset($user))
{
// Запрещаем нам!
if ($user['id'] != $ank['id']){

// Лайк
if (isset($_GET['like']) && $_GET['like'] == 'up'){
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `notes_like` WHERE `id_user` = '".$user['id']."' AND `id_notes` = '".$blog['id']."' LIMIT 1"),0) == 0){
mysql_query("INSERT INTO `notes_like` (`id_notes`, `id_user`, `like`) VALUES ('$blog[id]', '$user[id]', '1')");
$mgs_like = "<b>".$user['nick']."</b> понравился ваш блог!";
mysql_query("INSERT INTO `journal` (`user`, `time`, `act`, `opis`, `ank`, `url`) VALUES ('".$user['id']."', '".$time."', 'blogs', '".$mgs_like."', '".$ank['id']."', '/user/blogs/read/?id=".$blog['id']."')");
// Выводим в списке понравившихся в закладках
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `bookmarks_like` WHERE `id_user` = '".$user['id']."' AND `id_object` = '".$blog['id']."' AND `type` = 'blog' LIMIT 1"),0) == 0){
mysql_query("INSERT INTO `bookmarks_like` (`type`,`id_object`, `id_user`, `time`) VALUES ('blog','$blog[id]', '$user[id]', '$time')");
}

}
else{
$_SESSION['err'] = 'Вы уже голосовали за блог.';
}
header("Location: ?id=$blog[id]");
exit;
}
// Дизлайк
if (isset($_GET['like']) && $_GET['like'] == 'down'){
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `notes_like` WHERE `id_user` = '".$user['id']."' AND `id_notes` = '".$blog['id']."' LIMIT 1"),0) == 0){
mysql_query("INSERT INTO `notes_like` (`id_notes`, `id_user`, `like`) VALUES ('$blog[id]', '$user[id]', '0')");
}
else{
$_SESSION['err'] = 'Вы уже голосовали за блог.';
}
header("Location: ?id=$blog[id]");
exit;
}

}
	
// Добавляем в закладки
if (isset($_GET['bookmarks']) && $_GET['bookmarks'] == 'add'){
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `bookmarks` WHERE `id_user` = '".$user['id']."' AND `id_object` = '".$blog['id']."' AND `type` = 'notes' LIMIT 1"),0) == 0){
mysql_query("INSERT INTO `bookmarks` (`type`,`id_object`, `id_user`, `time`) VALUES ('notes','$blog[id]', '$user[id]', '$time')");
$_SESSION['message'] = 'Блог добавлен в закладки.';
header("Location: ?id=$blog[id]");
exit;
}
}

// Удаляем из закладок
if (isset($_GET['bookmarks']) && $_GET['bookmarks'] == 'dell'){
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `bookmarks` WHERE `id_user` = '".$user['id']."' AND `id_object` = '".$blog['id']."' AND `type` = 'notes' LIMIT 1"),0) == 1){
mysql_query("DELETE FROM `bookmarks` WHERE `id_user` = '$user[id]' AND `id_object` = '$blog[id]' AND `type` = 'notes' ");
$_SESSION['message'] = 'Блог удален из закладок.';
header("Location: ?id=$blog[id]");
exit;
}
}
	
}

$set['title'] = text($blog['name']) . ' : ' . $ank['nick'];
include_once H.'sys/inc/thead.php';
title();

$lolsms = $blog['msg'];

// количество слов выводится в зависимости от браузера
if (!$set['web'])
$mn = 50;
else 
$mn = 150; 

// деление статьи на отдельные слова
$stat = explode(' ', $lolsms);

$k_page =k_page(count($stat),$set['p_str']*$mn);
$page =page($k_page);
$start =$set['p_str']*$mn*($page-1);
$stat_1 = NULL;

for ($i=$start; $i < $set['p_str']*$mn*$page && $i < count($stat); $i++){
$stat_1.=$stat[$i].' ';
}

if($blog['private'] == 1)$ico_privat = '<img src="//c.spac.me/i/ico/mode_fronl.png" alt="" class="m p16">  ';
elseif($blog['private'] == 2)$ico_privat = '<img src="//c.spac.me/i/ico/mode_ownonl.png" alt="" class="m p16">  ';
else
$ico_privat = '<img src="//c.spac.me/i/ico/mode_na.png" alt="" class="m p16">  ';
?>
<div class="lc_br wbg font0 relative oh" id="header_path">  
<a href="/" style="font-size:0;"> <img src="//c.spac.me/i/lb/home.png" alt=""> </a>     
<span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> 
<a href="/user/?id=<?= $ank['id']?>"><?= $ank['nick']?></a> 
</span>     
<span class="lc_brw"> 
<img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> 
<a href="/user/blogs/view/?id=<?= $ank['id']?>">Блог</a> 
</span>       
</div>
<?

err();

?>
<div>

<div class="list_item light_border_bottom"> <div class="oh">  

<span class="m right">   <span class="m grey"><?= vremja($blog['time'])?></span> 
<?
if($blog['adult'] != 0){
?>          
<img src="/style/i/adult_ico.png" alt="" class="m p16">
<?
}
if(isset($user) && $ank['id'] == $user['id']){
?>
<a href="/user/blogs/editaccess/?id=<?= $blog['id']?>" class="inl-link ">       
<div class="no-text">  <?= $ico_privat?> </div>     <!-- --><!-- --><!-- -->
</a>
<?
}else{
?>
<?= $ico_privat?>         
<?
}
?>
</span>  
    
<?= group($ank['id'])?> 
<a href="/user/?id=<?= $ank['id']?>" class="mysite-link"><b class="nick"><?= unick($ank['id'])?></b></a>  
<?= medal($ank['id'])?>     : <b style="color: #069"><?= text($blog['name'])?></b>  
<div class="cl"></div>   

<div class="image_limit">  
<?
if ($blog['file_ves'] != 0 && $blog['file_raz'] != NULL && is_file(H."user/blogs/files/".$blog['id'].".dat"))
{
if ($blog['file_raz'] == 'png' || $blog['file_raz'] == 'gif' || $blog['file_raz'] == 'jpg' || $blog['file_raz'] == 'jpeg')
{
?>
<div class="MainAttachWidget attaches-fixer pad_b_a">      
<div class="AttachRender">   
<div class="inl_bl">        
<a class="tdn gview_link" href="/user/blogs/file/<?= $blog['id']?>.<?= $blog['file_raz']?>">   
<div class="inl_bl relative"> 
<?
if ($webbrowser == 'web')
{
?>
<img src="/user/blogs/file/<?= $blog['id']?>.<?= $blog['file_raz']?>" alt="" class="preview s0_360"  style="max-width: 240px; max-height: 320px;">   
<?
}
else{
?>
<img src="/user/blogs/file/<?= $blog['id']?>.<?= $blog['file_raz']?>" alt="" class="preview s0_360"  style="max-width: 160px; max-height: 140px;">   
<?
}
?>
</div>      
</a>             
</div>     
<div class="cl"></div> </div>  
<div class="cl"></div>    </div>
<?
}
}

?> 
<div>   
<div id="previewText" class="oh pad_b_a"> 
<?
// вывод статьи со всем форматированием
echo output_text($stat_1) , ' ';
?> 
<br>  
</div>   
</div>     
</div> 
</div> </div>
<?

if ($k_page > 1)str("?id=$blog[id]&amp;",$k_page,$page); // Вывод страниц

$like = mysql_result(mysql_query("SELECT COUNT(*) FROM `notes_like` WHERE `like` = '1' AND `id_notes` = '".$blog['id']."' LIMIT 1"),0);
$dlike = mysql_result(mysql_query("SELECT COUNT(*) FROM `notes_like` WHERE `like` = '0' AND `id_notes` = '".$blog['id']."' LIMIT 1"),0);
$us_like = mysql_result(mysql_query("SELECT COUNT(*) FROM `notes_like` WHERE `like` = '1' AND `id_user` = '".$user['id']."' AND `id_notes` = '".$blog['id']."' LIMIT 1"),0);
$us_dlike = mysql_result(mysql_query("SELECT COUNT(*) FROM `notes_like` WHERE `like` = '0' AND `id_user` = '".$user['id']."' AND `id_notes` = '".$blog['id']."' LIMIT 1"),0);

if($kanal['id'] != 0){
?>
<div class="wbg">   
<div class="list_item light_border_bottom lh_160">  Канал: 
<a href="/user/blogs/?Category=<?= $kanal['id']?>"><?= text($kanal['name'])?></a>   </div>     </div>
<?
}

?>
<div class="list_item light_border_bottom oh">   

<div class="oh signature">  
<img class="m p16" src="//c.spac.me/i/views_num_gray.png" alt=""> 
<span class="m lit"><?= $blog['count']?></span> 
<span class="right">  
<img class="m p16" src="//c.spac.me/i/vote_up.png" alt="">  
<span class="m lit voteUpInfo" id="vote_up"><?= $like?></span>   &nbsp;  
<img class="m p16" src="//c.spac.me/i/vote_down.png" alt="">
<span class="m lit voteDownInfo" id="vote_down"><?= $dlike?></span>  
</span> 
</div> 
<?

if (mysql_result(mysql_query("SELECT COUNT(*) FROM `notes_like` WHERE `id_user` = '".$user['id']."' AND `id_notes` = '".$blog['id']."' LIMIT 1"),0) == 0){
$ico_vote_up = 'vote_up.png';
$ico_vote_down = 'vote_down.png';
}
else{
if($us_like){
$ico_vote_up = 'vote_up_on.png';
$ico_vote_down = 'vote_down.png';
}elseif($us_dlike){
$ico_vote_up = 'vote_up.png';
$ico_vote_down = 'vote_down_on.png';
}
}
?>
<div class="lh_160">   
<div class="cf">  
<?
if (isset($user) && $user['id'] != $ank['id']){
?> 
<div class="pad_t_a">
<span>  
<span class="bmc t-padd_right"> 
<a href="?id=<?= $blog['id']?>&like=up" class="arrow_link m btnb" id="like_up" > 
<img src="//c.spac.me/i/<?= $ico_vote_up?>" alt="" class="m p16"> </a>  
</span>      
</span> 
<span>   
<span class="bmc"> 
<a href="?id=<?= $blog['id']?>&like=down" class="arrow_link m btnb" id="like_down"> 
<img src="//c.spac.me/i/<?= $ico_vote_down?>" alt="" class="m p16"> </a>  
</span>   
</span>    
</div>   
<?
}elseif (isset($user) && $user['id'] == $ank['id']){
?>
<a href="/user/blogs/edit/?id=<?= $blog['id']?>" class="arrow_link"> <img src="//c.spac.me/i/edit_gray.png" alt="" class="p16 m"> <span class="m">Редактировать</span> </a>
<?
}
if (isset($user)){
?>
<div> 
<?
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `bookmarks` WHERE `id_user` = '".$user['id']."' AND `id_object` = '".$blog['id']."' AND `type` = 'notes' LIMIT 1"),0) == 0){
?>  
<a href="?id=<?= $blog['id']?>&bookmarks=add" class="arrow_link"> 
<img src="//c.spac.me/i/action_fav_gray.gif" alt="" class="p16 m"> <span class="m">В закладки</span> 
</a>
<?
}
else{
?>
<a href="?id=<?= $blog['id']?>&bookmarks=dell" class="arrow_link"> 
<img src="//c.spac.me/i/action_fav_color.gif" alt="" class="p16 m"> <span class="m">Удалить из закладок</span> 
</a>
<?
}
?>
<br>     
</div>
<?
}
?>
</div>  

</div>
</div>
<?

$prev = mysql_fetch_assoc(mysql_query("SELECT * FROM `notes` WHERE `id` < '$blog[id]' ORDER BY `id` DESC LIMIT 1"));
$next = mysql_fetch_assoc(mysql_query("SELECT * FROM `notes` WHERE `id` > '$blog[id]' ORDER BY `id` ASC LIMIT 1"));

if($next['id'] OR $prev['id']){
?>
<div class="list_item gradient_block1" style="text-align:center">  
<?
if($next['id']){
if($prev['id']){
$lol = ' | ';
}
else{
$lol = '';
}
}
else{
if($next['id']){
$lol = ' | ';
}
else{
$lol = '';
}
}
?>
<?= ($next['id'] ? '<a class="arrow_link" href="?id='.$next['id'].'">← <span>Пред.</span></a> ' : '')?>
<?= ($prev['id'] ? ' '.$lol.' <a class="arrow_link" href="?id='.$prev['id'].'"><span>След.</span> →</a> ' : '')?> 
</div>
<?
}
?>






</div>
<link rel="stylesheet" type="text/css" href="http://spac.me/css/custom/CommentWidget/CommentsWap.css?r=1446p" data-tmp_css="1" /> 
<?



$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `notes_komm` WHERE `id_notes` = '".$blog['id']."'"),0);  
$k_page = k_page($k_post,$set['p_str']);  
$page = page($k_page);  
$start = $set['p_str']*$page-$set['p_str'];

?>
<a name="page-up"></a>
<div class="header oh text_left"> <b class="upcs m">Комментарии (<?= $k_post?>)</b>  </div>
<?

$q = mysql_query("SELECT * FROM `notes_komm` WHERE `id_notes` = '".$blog['id']."' ORDER BY `time` DESC LIMIT $start, $set[p_str]");  

while ($post = mysql_fetch_assoc($q))  
{  
$ank = get_user($post['id_user']);
$postBan = mysql_result(mysql_query("SELECT COUNT(*) FROM `ban` WHERE (`razdel` = 'all' OR `razdel` = 'notes') AND `post` = '1' AND `id_user` = '$ank[id]' AND (`time` > '$time' OR `navsegda` = '1')"), 0);  

if ($postBan == 0){
$dop_divka = '';
}else{
$dop_divka = ' comm_hidden';
}
?>
<div id="<?= $post['id']?>"> 
<div class="comm oh<?= $dop_divka?>">
<div class="p40 left t-padd_right">      
<a class="tdn" href="/user/?id=<?= $ank['id']?>">   
<div class="inl_bl relative"> <?= ava40($ank['id'])?>  </div>      
</a>        
</div>  
<div class="oh">  <div>  
<span> 
<?= group($ank['id'])?> <a href="/user/?id=<?= $ank['id']?>" class="mysite-link"><b class="nick black"><?= unick($ank['id'])?></b></a>    
</span> 
<div class="right">  
<span class="m"> <?= vremja($post['time'])?> </span>  
</div> 
</div>   </div>     
<div class="cl">     
<div> 
<?
if ($postBan == 0){	  
?>
<?= output_text($post['msg'])?>
<?
}else{  
?>
<?= output_text($banMess)?>
<?
} 
?>  
</div>      
</div>  
<div class="oh pad_t_a">  
<?
if (isset($user) && $ank['id'] != $user['id']){
?>
<a href="?id=<?= $blog['id']?>&amp;response=<?= $ank['id']?>" class="link-grey js-comm_reply">Ответить</a> 
<?
if (isset($user) && (user_access('notes_delete') || $user['id'] == $blog['id_user'])){
?> 
<span class="slb">     |  
<a href="">Удалить</a>  
</span>  
<?
}
}
if (isset($user) && ($user['id'] == $blog['id_user'])){
?> 
<span class="slb">
<a href="/user/blogs/delete/?comment=<?= $post['id']?>">Удалить</a>  
</span>  
<?
}
?>
</div>   
</div> </div>
<?
}


?>
<a name="page-down"></a>
<?

if (isset($user)){
	$frend = mysql_result(mysql_query("SELECT COUNT(*) FROM `frends` WHERE (`user` = '$user[id]' AND `frend` = '$ank[id]') OR (`user` = '$ank[id]' AND `frend` = '$user[id]') LIMIT 1"),0);  
}

// Коменты полностью запрет
if ($blog['private_komm'] == 2 && $user['id'] != $ank['id'] && !user_access('notes_delete')){
?>
<div class="comm_form">  <div class="oh t_center busi">Автор ограничил комментирование этой записи.</div>   </div>
<?
include_once H.'sys/inc/tfoot.php';  
exit; 
}
// Только друзьям коменты
if ($blog['private_komm'] == 1 && $user['id'] != $ank['id'] && $frend != 2  && !user_access('notes_delete')){
?>
<div class="comm_form">  <div class="oh t_center busi">Автор ограничил комментирование, доступно только друзьям.</div>   </div>
<?
include_once H.'sys/inc/tfoot.php'; 
exit; 
}

if (isset($user))  
{ 

?>
<div class="comm_form"> <div id="comments_form_wrap"><div id="comments_form">  
<form action="?id=<?= $blog['id']?>&P=<?= $page?><?= $go_otv?>" method="post" name="message">  
<div class="wrapper block pd0">    
<div class="block  js-toolbar_wrap">  <div class="text-input__wrap"> 
<div class="cl" style="margin-bottom: 5px;"> <div class="relative">  <div class="input-txt_wrapper"> 
<textarea class="input-txt" tabindex="1" name="text" rows="4" id="textarea" data-maxlength="1000" data-toolbar="{hide:true,disable:{}}" cols="17" placeholder="Напишите комментарий"><?= $otvet?></textarea> 
</div> </div> </div>    
</div> </div>    
<div class="block wide pdt">   
<div class="cf pad_t_a"> 
<span class="form-tools__left left">  
<!-- --><!-- --><!-- --><!-- --><!-- -->
<button name="smiles" value="" class="  url-btn     " id="smiles_btn">
<!--   -->
<img src="//c.spac.me/i/ico/smile.png" alt="" class="m"> <!--   --><span class="m"> </span>
<!-- -->
</button>
<!-- --><!-- -->  
</span>   
<span class="form-tools__left left"><span class="js-bb_toggle"> 
<!-- --><!-- --><!-- --><!-- --><!-- -->
<button name="bb_tag" value="" class="  url-btn     " id="response_btn">
<!--   -->
<img src="//c.spac.me/i/a.png" alt="" class="m"> <!--   --><span class="m"> </span>
<!-- -->
</button>
<!-- --><!-- --> 
</span> </span>   
<input value="Отправить" class="main_submit right" type="submit">  
</div> </div> </div>       
</form> 
</div></div> </div>
<?
}

include_once H.'sys/inc/tfoot.php';
?>