<?
include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';

$set['title'] = 'Рейтиг : Люди';

include_once H.'sys/inc/thead.php';

?>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="http://spac.me/css/custom/Search/Results.css?r=1445p" data-tmp_css="1" />
<script type="text/javascript">

$(document).ready(function () {
	$('[data-toggle]').on('click', function (e) {
		e.preventDefault();
		var $el = $(this);
		if ($el.hasClass('hide')) {
			$('#' + $el.attr('data-toggle')).hide();
			$el.removeClass('hide');
		}
		else {
			$el.addClass('hide');
			$('#' + $el.attr('data-toggle')).show();
		}
	})
});
</script>
<?

title();


$usearch = NULL;

if (isset($_SESSION['us'])){
	$usearch = $_SESSION['us'];
}
if (isset($_POST['us'])){
	$usearch = $_POST['us'];
}
if ($usearch == NULL){
	unset($_SESSION['us']);
	}
	else
	{
	$_SESSION['us'] = $usearch;
}
$usearch = preg_replace("#( ){1,}#","",$usearch);


?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/users.php">Люди</a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Рейтинг</span> </span>       </div>

<div class="wrapper-nobg"> 
<form method="post" action="?results_list">   
<table class="table__wrap search-wrap input-txt_grid"> <tbody><tr> 
<td class="input-txt_grid_input"> 
<div class="input-txt_wrapper_search relative"> <input class="input-txt" name="us" value="" maxlength="64" type="text">  </div> 
</td> 
<td class="input-txt_grid_sep"></td> 
<td class="input-txt_grid_btn"> <input class="search__btn" value="Найти" name="cfms" type="submit"> </td> 
</tr> </tbody></table>     
</form> 
</div>
<?

if (isset($_GET['results_list']) && $usearch == NULL){

?>
<div class="tabs_block oh">    
<a href="/user/users.php" class="tab_item left" style="padding: 12px 9px 8px 9px">  Популярные  </a>   
<a href="/online.php" class="tab_item left" style="padding: 12px 9px 8px 9px">  Онлайн  </a>   
<div class="tab_item left tab_active black" style="padding: 12px 9px 8px 9px">  Поиск  </div>   
</div>
<div class="wrapper block">Вы не ввели информацию о пользователе. </div> 
<?
}
if (!isset($_GET['results_list'])){
?>
<div class="tabs_block oh">    
<div class="tab_item left tab_active black" style="padding: 12px 9px 8px 9px">  Популярные  </div>   
<a href="/online.php" class="tab_item left" style="padding: 12px 9px 8px 9px">  Онлайн  </a>     
<a href="?results_list" class="tab_item left" style="padding: 12px 9px 8px 9px">  Поиск  </a>  
</div>
<?

// Заменяем стандарт вывода на странице
$set['p_str'] = '10';

$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `user`"),0);
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str']*$page-$set['p_str'];



if ($k_post == 0){
?>
<div class="wrapper block">Нет результатов</div>
<?
}else{

?>
<div>
<?

$q = mysql_query("SELECT `user`.`id` FROM `user` LEFT JOIN `user_group` ON `user`.`group_access` = `user_group`.`id` ORDER BY `user`.`rating` DESC LIMIT $start, $set[p_str]");

while ($ank = mysql_fetch_assoc($q))
{
$ank = get_user($ank['id']);

// Определяем сколько лет	
$ank['ank_age'] = null;
if ($ank['ank_d_r'] != NULL && $ank['ank_m_r'] != NULL && $ank['ank_g_r'] != NULL){
	$ank['ank_age'] = date("Y")-$ank['ank_g_r'];
	if (date("n") < $ank['ank_m_r'])
	$ank['ank_age'] = $ank['ank_age'] - 1;
	elseif (date("n") == $ank['ank_m_r']&& date("j") < $ank['ank_d_r'])
	$ank['ank_age'] = $ank['ank_age'] - 1;
}

$uSet = mysql_fetch_array(mysql_query("SELECT * FROM `user_set` WHERE `id_user` = '$ank[id]'  LIMIT 1"));
$frend = mysql_result(mysql_query("SELECT COUNT(*) FROM `frends` WHERE (`user` = '$user[id]' AND `frend` = '$ank[id]') OR (`user` = '$ank[id]' AND `frend` = '$user[id]') LIMIT 1"),0);
$frend_new = mysql_result(mysql_query("SELECT COUNT(*) FROM `frends_new` WHERE (`user` = '$user[id]' AND `to` = '$ank[id]') OR (`user` = '$ank[id]' AND `to` = '$user[id]') LIMIT 1"),0);

?>
<div class="js-row block bord-botm oh grey relative block-cntrl">      
  
<div class="left font0">   
<a href="/user/?id=<?= $ank['id']?>" class="tdn">       
<span class="pr">   <div class="inl_bl relative"> <?= ava80($ank['id'])?> </div>     </span>        
</a>  
</div> 
 
<div class="pre_content_wrap break-word"> 
<?= group($ank['id'])?>   
<a href="/user/?id=<?= $ank['id']?>" class="black full_link">   <b><?= unick($ank['id'])?></b>  </a>   <?= medal($ank['id'])?>       
<?
if($ank['rating'] > 0){
?>
<div class="inl_bl m">  <span class="bordered grey"> <?= $ank['rating']?> </span>  </div>  
<?
}
$rTime = time() - 600;
if($ank['date_last'] < $rTime){
?>
<span class="grey">(<?= vremja($ank['date_last'])?>)</span>       
<?
}
?>
<div class="grey">
<?
if($ank['ank_name'] != null OR $ank['ank_family'] != null){
?>
<div class="break-word">
<?
}
if($ank['ank_name'] != null){
?>  
<?= text($ank['ank_name'])?>
<?
}
if($ank['ank_family'] != null){
?>  
<?= text($ank['ank_family'])?>
<?
}
if($ank['ank_name'] != null OR $ank['ank_family'] != null){
?>
</div>
<?
}
// Вывод возвраста
if ($ank['ank_d_r'] != NULL && $ank['ank_m_r'] != NULL && $ank['ank_g_r'] != NULL){
$my_age_day = array('год', 'года', 'лет');
?>    
<?= des2num($ank['ank_age'], $my_age_day)?>
<? 
if ($ank['ank_city'] != NULL){
?>, <?
} 
}
if ($ank['ank_city'] != NULL){
?>
<?= text($ank['ank_city'])?>
<?
}
?>
</div>
<?
if ($ank['group_access'] > 1){
?>
<div class="blue"><div class="break-word"><?= $ank['group_name']?></div> </div>
<?
}
?>  
</div>   
<?

if($user['id'] != $ank['id']){
?>  
<div class="menu_btn" onclick="Spoilers_Tw1nGo(<?= $ank['id']?>)" title="Действия" data-toggle="more_menu_<?= $ank['id']?>"> 
<img src="/style/i/arrow_bottom.png" data-hide="arrow_up.png" data-show="arrow_bottom.png" id="more_menu_<?= $ank['id']?>-icon" alt="" class="p16">
</div> 
<?
} 
?>
</div>  
<?
if($user['id'] != $ank['id']){
?> 
<div class="js-row wrap_list wbg  hide" id="more_menu_<?= $ank['id']?>">  
<div>    
<a href="/mail.php?id=<?= $ank['id']?>" class="link       "> <span>        
<img src="/style/i/mail_grey.png" alt="" class="m">      <span class="m">  Написать </span>          </span>  
</a>    
</div> 
<?
if(isset($user)){
?>
<div>
<?
if ($frend_new == 0 && $frend==0){
?> 
<a href="/user/frends/create.php?add=<?= $ank['id']?>" class="link blue">          
<img src="/style/i/befriends.png" alt="" class="m">      <span class="m">  Дружить </span>          
<!-- --><!-- --><!-- --></a><!-- -->
<?
}elseif ($frend_new == 1){
?>  
<a href="/user/frends/create.php?otm=<?= $ank['id']?>" class="link blue">          
<img src="/style/i/befriends_inprocess.png" alt="" class="m">      <span class="m">  Запрошено </span>          
<!-- --><!-- --><!-- --></a><!-- -->
<?
}elseif ($frend == 2){
?> 
<span data-action="friends_delete" class="link green">          
<img src="/style/i/befriends_on.png" alt="" class="m">      <span class="m">  Дружите </span>          
<!-- --><!-- --><!-- --></span><!-- -->
<?
}
?>          
</div>  <div>    
<div class="js-subscr_link" data-user="<?= $ank['nick']?>">     
<a href="/user/gifts/?id=<?= $ank['id']?>" class="link      js-action_link "> 
<span> <img src="/style/i/gifts_grey.png" alt="" class="m">      <span class="m">  Подарок </span>  </span>  
</a>    
</div> 
</div>  
<?
if (user_access('user_prof_edit') && $user['level'] > $ank['level']){
?>
<a class="link      js-action_link " href="/adm_panel/user.php?id=<?= $ank['id']?>"> 
<span> <img src="/style/i/edit_info.png" alt="" class="m">     <span class="m">  Изменить профиль </span>  </span>  
</a>
<?
}
}
?>
</div>
<?
}


}

?>
</div>
<?

if ($k_page>1)str("users.php?",$k_page,$page); // Вывод страниц
}
}

// Начинается поиск ниже :D
if (isset($_GET['results_list']) && $usearch != NULL){

$set['p_str'] = '10';

$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `user` WHERE `nick` 
	like '%".mysql_real_escape_string($usearch)."%' 
	OR `id` = '".intval($usearch)."'
	OR `ank_family` like '%".mysql_real_escape_string($usearch)."%'
	OR `ank_name` like '%".mysql_real_escape_string($usearch)."%'"),0);
	
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str']*$page-$set['p_str'];



if ($k_post == 0){
?>
<div class="wrapper block">Пользователей не найдено. </div>
<?
}
else
{
?>
<div class="tabs_block oh">    
<a href="/user/users.php" class="tab_item left" style="padding: 12px 9px 8px 9px">  Популярные  </a>   
<a href="/online.php" class="tab_item left" style="padding: 12px 9px 8px 9px">  Онлайн  </a>   
<div class="tab_item left tab_active black" style="padding: 12px 9px 8px 9px">  Поиск  </div>   
</div>
<form method="post" action="?results_list"> 
<div class="wrapper block oh" style="margin-top:0px;"> 
<input name="us" value="<?= $usearch?>" type="hidden">  
<span class="s-property">
<div class="s-property__inner"><?= $usearch?>
<input name="us" class="ico delete-btn" value="." type="submit">
</div>
</span>  
</div>   
</form>         




<div class="start_page_padd light_blue_bg blue_border_bottom oh"> <b class="grey">Подходящие люди</b> (<?= $k_post?>) </div>
<?
$q = mysql_query("SELECT `id` FROM `user` WHERE `nick` 
	like '%".mysql_real_escape_string($usearch)."%' 
	OR `ank_name` like '%".mysql_real_escape_string($usearch)."%'
	OR `ank_family` like '%".mysql_real_escape_string($usearch)."%'
	OR `id` = '".intval($usearch)."' ORDER BY `rating` DESC LIMIT $start, $set[p_str]");

while ($ank = mysql_fetch_assoc($q))
{
$ank = get_user($ank['id']);

// Определяем сколько лет	
$ank['ank_age'] = null;
if ($ank['ank_d_r'] != NULL && $ank['ank_m_r'] != NULL && $ank['ank_g_r'] != NULL){
	$ank['ank_age'] = date("Y")-$ank['ank_g_r'];
	if (date("n") < $ank['ank_m_r'])
	$ank['ank_age'] = $ank['ank_age'] - 1;
	elseif (date("n") == $ank['ank_m_r']&& date("j") < $ank['ank_d_r'])
	$ank['ank_age'] = $ank['ank_age'] - 1;
}

$uSet = mysql_fetch_array(mysql_query("SELECT * FROM `user_set` WHERE `id_user` = '$ank[id]'  LIMIT 1"));
$frend = mysql_result(mysql_query("SELECT COUNT(*) FROM `frends` WHERE (`user` = '$user[id]' AND `frend` = '$ank[id]') OR (`user` = '$ank[id]' AND `frend` = '$user[id]') LIMIT 1"),0);
$frend_new = mysql_result(mysql_query("SELECT COUNT(*) FROM `frends_new` WHERE (`user` = '$user[id]' AND `to` = '$ank[id]') OR (`user` = '$ank[id]' AND `to` = '$user[id]') LIMIT 1"),0);

?>
<div class="js-row block bord-botm oh grey relative block-cntrl">      
  
<div class="left font0">   
<a href="/user/?id=<?= $ank['id']?>" class="tdn">       
<span class="pr">   <div class="inl_bl relative"> <?= ava80($ank['id'])?> </div>     </span>        
</a>  
</div> 
 
<div class="pre_content_wrap break-word"> 
<?= group($ank['id'])?>   
<a href="/user/?id=<?= $ank['id']?>" class="black full_link">   <b><?= unick($ank['id'])?></b>  </a>   <?= medal($ank['id'])?>       
<?
if($ank['rating'] > 0){
?>
<div class="inl_bl m">  <span class="bordered grey"> <?= $ank['rating']?> </span>  </div>  
<?
}
$rTime = time() - 600;
if($ank['date_last'] < $rTime){
?>
<span class="grey">(<?= vremja($ank['date_last'])?>)</span>       
<?
}
?>
<div class="grey">
<?
if($ank['ank_name'] != null OR $ank['ank_family'] != null){
?>
<div class="break-word">
<?
}
if($ank['ank_name'] != null){
?>  
<?= text($ank['ank_name'])?>
<?
}
if($ank['ank_family'] != null){
?>  
<?= text($ank['ank_family'])?>
<?
}
if($ank['ank_name'] != null OR $ank['ank_family'] != null){
?>
</div>
<?
}
// Вывод возвраста
if ($ank['ank_d_r'] != NULL && $ank['ank_m_r'] != NULL && $ank['ank_g_r'] != NULL){
$my_age_day = array('год', 'года', 'лет');
?>    
<?= des2num($ank['ank_age'], $my_age_day)?>
<? 
if ($ank['ank_city'] != NULL){
?>, <?
} 
}
if ($ank['ank_city'] != NULL){
?>
<?= text($ank['ank_city'])?>
<?
}
?>
</div>
<?
if ($ank['group_access'] > 1){
?>
<div class="blue"><div class="break-word"><?= $ank['group_name']?></div> </div>
<?
}
?>  
</div>   
<?

if($user['id'] != $ank['id']){
?>  
<div class="menu_btn" onclick="Spoilers_Tw1nGo(<?= $ank['id']?>)" title="Действия" data-toggle="more_menu_<?= $ank['id']?>"> 
<img src="/style/i/arrow_bottom.png" data-hide="arrow_up.png" data-show="arrow_bottom.png" id="more_menu_<?= $ank['id']?>-icon" alt="" class="p16">
</div> 
<?
} 
?>
</div>  
<?
if($user['id'] != $ank['id']){
?> 
<div class="js-row wrap_list wbg  hide" id="more_menu_<?= $ank['id']?>">  
<div>    
<a href="/mail.php?id=<?= $ank['id']?>" class="link       "> <span>        
<img src="/style/i/mail_grey.png" alt="" class="m">      <span class="m">  Написать </span>          </span>  
</a>    
</div> 
<?
if(isset($user)){
?>
<div>
<?
if ($frend_new == 0 && $frend==0){
?> 
<a href="/user/frends/create.php?add=<?= $ank['id']?>" class="link blue">          
<img src="/style/i/befriends.png" alt="" class="m">      <span class="m">  Дружить </span>          
<!-- --><!-- --><!-- --></a><!-- -->
<?
}elseif ($frend_new == 1){
?>  
<a href="/user/frends/create.php?otm=<?= $ank['id']?>" class="link blue">          
<img src="/style/i/befriends_inprocess.png" alt="" class="m">      <span class="m">  Запрошено </span>          
<!-- --><!-- --><!-- --></a><!-- -->
<?
}elseif ($frend == 2){
?> 
<span data-action="friends_delete" class="link green">          
<img src="/style/i/befriends_on.png" alt="" class="m">      <span class="m">  Дружите </span>          
<!-- --><!-- --><!-- --></span><!-- -->
<?
}
?>          
</div>  <div>    
<div class="js-subscr_link" data-user="<?= $ank['nick']?>">     
<a href="/user/gifts/?id=<?= $ank['id']?>" class="link      js-action_link "> 
<span> <img src="/style/i/gifts_grey.png" alt="" class="m">      <span class="m">  Подарок </span>  </span>  
</a>    
</div> 
</div>  
<?
if (user_access('user_prof_edit') && $user['level'] > $ank['level']){
?>
<a class="link      js-action_link " href="/adm_panel/user.php?id=<?= $ank['id']?>"> 
<span> <img src="/style/i/edit_info.png" alt="" class="m">     <span class="m">  Изменить профиль </span>  </span>  
</a>
<?
}
}
?>
</div>
<?
}


}


if ($k_page>1)str("users.php?results_list&amp;",$k_page,$page); // Вывод страниц
}


}
include_once '../sys/inc/tfoot.php';

?>