<?
include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';

only_reg();

$set['title'] = 'Старт : ' . $user['nick'];

include_once H.'sys/inc/thead.php';
title();


$i = 0;

$frend = mysql_result(mysql_query("SELECT COUNT(*) FROM `frends` WHERE `user` = '$user[id]' AND `i` = '1'"), 0);
$frend_onl = mysql_query("select `frend` from `frends` WHERE `user` = '$user[id]' AND `i` = '1'");
$frend_new = mysql_result(mysql_query("SELECT COUNT(id) FROM `frends_new` WHERE `to` = '$user[id]' LIMIT 1"), 0);

$zayavok = array('заявка', 'заявки', 'заявок');

while ($frend = mysql_fetch_array($frend_onl)){
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `user` WHERE `id` = '$frend[frend]' && `date_last` > '".(time()-600)."'"),0) != 0)$i++;
}



?>
<div class="lc_br wbg font0 relative oh" id="header_path">  
<a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     
<span class="lc_brw"> 
<img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $user['id']?>"><?= $user['nick']?></a> 
</span>     
<span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Старт</span> </span>       
</div>
<?
// Показуемодин раз при входе, если обновить, то исчезнет :)
if (isset($user) && !isset($_SESSION['action'])) {
$_SESSION['action'] = 1;
?>
<div class="list_item"> Привет, <b><?= $user['nick']?></b>!<br> 
<a href="/user/loghist.php" class="arrow_link"><span>История входов</span></a>: последний раз вы заходили <span style="color:darkgreen"><?= vremja($user['date_last'])?></span> 
</div>
<?
}
?>
<!-- Startpage -->  

<div class="wrapper-nobg"> 
<form action="/plugins/search/?search" method="post">     
<table class="table__wrap search-wrap input-txt_grid"> <tbody><tr> 
<td class="input-txt_grid_input"> 
<div class="input-txt_wrapper_search relative"> <input class="input-txt" name="search" value="" maxlength="64" type="text">  </div> 
</td> 
<td class="input-txt_grid_sep"></td> 
<td class="input-txt_grid_btn"> <input class="search__btn" name="cfms" value="Найти" type="submit"> </td> 
</tr> </tbody></table>     
</form> 
</div>

<div class="list_item grey_bg b"> Разделы сайта </div>

<a href="/user/dating/" class="link darkblue"> <img src="/style/i/love_bright_m.png" alt="" class="m p16"> <span class="m">Знакомства</span> </a>
<a href="/user/blogs/" class="link darkblue"> <img src="/style/i/diary_bright_m.png" alt="" class="m p16"> <span class="m">Блоги</span> </a>
<a href="/forum/?" class="link darkblue"> <img src="/style/i/forum_bright_m.png" alt="" class="m p16"> <span class="m">Форум</span> </a>
<a href="#" class="link darkblue"> <img src="/style/i/chat_bright_m.png" alt="" class="m p16"> <span class="m">Чат</span> </a>
<a href="/user/users.php" class="link darkblue"> <img src="/style/i/people_bright_m.png" alt="" class="m p16"> <span class="m">Люди</span> </a>
<a href="/plugins/rules/?" class="link darkblue bord-botm"> <img src="/style/i/info_bright_m.png" alt="" class="m p16"> <span class="m">Информация</span> </a>

<div class="list_item grey_bg b"> Мои разделы </div>

<a href="/user/blogs/view/?id=<?= $user['id']?>" class="link darkblue"> <img src="/style/i/diary_bright_m.png" alt="" class="m p16"> <span class="m">Мой блог</span>  </a>
<a href="/user/friends/?uid=<?= $user['id']?>" class="link darkblue"> <img src="/style/i/friends_bright_m.png" alt="" class="m p16"> <span class="m">Друзья</span>  
<?
if($i > 0){
?>
<span class="m green"> <?= $i?> онлайн</span>  
<?
}
if($frend_new > 0){
?>
<span class="m red b"> <?= des2num($frend_new, $zayavok)?></span>
<?
}
?>
</a>
<a href="/foto/<?= $user['id']?>/" class="link darkblue"> <img src="/style/i/photos_bright_m.png" alt="" class="m p16"> <span class="m">Мои фото</span>  </a>
<a href="/user/guestbook/?uid=<?= $user['id']?>" class="link darkblue bord-botm"> <img src="/style/i/guestbook_bright_m.png" alt="" class="m p16"> <span class="m">Гостевая</span>  </a>
<a href="/user/bookmarks/?id=<?= $user['id']?>" class="link darkblue"> <img src="/style/i/favorites_bright_m.png" alt="" class="m p16"> <span class="m">Закладки</span>  </a>

<div class="list_item grey_bg b"> Настройки </div>

<a href="/user/services/" class="link darkblue"> <img src="/style/i/allservices_gray_bright_m.png" alt="" class="m p16"> <span class="m">Дополнительные услуги</span> </a>
<a href="/user/settings/" class="link darkblue"> <img src="/style/i/options_bright_m.png" alt="" class="m p16"> <span class="m">Настройки</span> </a>
<a href="/plugins/online_help.php" class="link darkblue"> <img src="/style/i/help_bright_m.png" alt="" class="m p16"> <span class="m">Помощь</span> </a>
<a href="/exit.php" class="link darkblue"> <img src="/style/i/exit_bright_m.png" alt="" class="m p16"> <span class="m">Выход</span> </a>
<div class="cl"></div>
<?

include_once H.'sys/inc/tfoot.php';
?>