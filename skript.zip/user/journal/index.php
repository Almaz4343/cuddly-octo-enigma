<?
include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';

only_reg();

$set['title'] = 'Журнал : ' . $user['nick'];
include_once H.'sys/inc/thead.php';
title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="//c.spac.me/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $user['id']?>"><?= $user['nick']?></a> </span>     <span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/journal/">Журнал</a> </span>       </div>
<?

err();


if(isset($_GET['mode']))
{

?>
<div class="list_item"> <b>Отключенные уведомления</b> </div>
<?

  
$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `journal_ban` WHERE `user` = '$user[id]'"),0);
$k_page=k_page($k_post,$set['p_str']);
$page=page($k_page);
$start=$set['p_str']*$page-$set['p_str'];


//$q = mysql_query("SELECT * FROM `journal_ban` WHERE `user` = '$user[id]' ORDER BY `time` ASC LIMIT $start, $set[p_str]");

if($k_post == 0)echo "<div class='block'>Отключенных уведомлений нет.</div>";

if (!empty($_GET['del'])){
	mysql_query("DELETE FROM `journal_ban` WHERE `ank` = {$user['id']} and `user` = ".intval($_GET['del']));
}




$q = mysql_query("SELECT * FROM `journal_ban` WHERE  `ank` = ".$user['id']." ORDER BY `id` DESC LIMIT $start, $set[p_str]");
	
while ($post = mysql_fetch_assoc($q))
{

$ank = get_user($post['user']);


?>
<div class="light_border_bottom t-bg3 oh">
<div class="right stnd_padd">  
<a href="?mode=1&del=<?= $ank['id']?>" class="t_center t-block_item t-link_no_underline_block round_corners myc-button_link">
<span class="t-strong_special t-link_item_hover">Вкл.</span>
</a>  
</div>
<a href="/user/?id=<?= $ank['id']?>" class="t-block_item  t-link_no_underline_block oh"> 
<span class="t-block_item stnd_padd "> <?= group($ank['id'])?> <span class="t-strong_item t-link_item_hover"><?= $ank['nick']?></span>			
</span>  </span> 
</a>			
</div>			
<?
}

	if ($k_page>1)str("?type={$type}&sub={$sub}&",$k_page,$page);


	include_once H.'sys/inc/tfoot.php';
}


$sub_arr =  array(
	'all' => 'Все',
	'file' => 'Файл',
	'dnew' => 'Днев',
	'other' => 'Прочее'
);

$type = $_GET['type'];
$sub = $_GET['sub'];
$panel = $user['wall'];


if (!empty($_GET['otkl'])){
	$tmp = get_user($_GET['otkl']);
	echo '
	<div class="busi"><div class="i_busi">
		Вы уверены, что не хотите больше получать уведомления от '.$tmp['nick'].'?
		<br>
		<a href="?type='.$type.'&sub='.$sub.'&otkl='.$tmp['id'].'&yes"><span style="color:green">Да</span></a>&nbsp;&nbsp;&nbsp;
		<a href="?type='.$type.'&sub='.$sub.'">Нет</span></a>                        
	</div></div>
	';

	if (isset($_GET['yes'])){
		mysql_query("INSERT INTO journal_ban (ank, user) VALUES ({$user['id']}, {$tmp['id']})");
		header('Location: ?');
	}

}


if (!empty($_GET['delete']) and array_key_exists($_GET['delete'], $sub_arr)){
	echo '
	<div class="busi"><div class="i_busi">
		Вы уверены, что хотите полностью очистить журнал?
		<br>
		<a href="?type='.$type.'&sub='.$sub.'&delete='.$sub.'&yes"><span style="color:green">Да</span></a>&nbsp;&nbsp;&nbsp;
		<a href="?type='.$type.'&sub='.$sub.'">Нет</span></a>                        
	</div></div>
	';

	if (isset($_GET['yes'])){
		mysql_query("DELETE FROM `journal` WHERE `ank` = {$user['id']}".($sub == "all" ? null : " and `act` = {$sub}"));
		header('Location: ?');
	}

}

if (!empty($_GET['to']) && $id = (int) $_GET['to']) {
	$refresh = mysql_fetch_array(mysql_query("SELECT `url` FROM `journal` WHERE `id`= {$id} LIMIT 1"));
	mysql_query("update `journal` set `read` = '1' where `id` = {$id}");
	header('Location: '.$refresh['url']);
	die;
}


if (!array_key_exists($_GET['sub'], $sub_arr) or !array_key_exists($_GET['type'], array('all'=>1, 'new'=>1)))
	header('Location: ?sub=all&type=new');


if (!$panel)$sub = 'all';


?>
<div class="busi_switcher mb0"> 
<table width="100%"> <tbody><tr>  
<td> 
<?= ($type == 'new' ? '<span class="active_item">Новые</span>' : '<a href="?sub='.$sub.'&type=new">Новые</a>')?>
</td>
<td> 
<?= ($type == 'new' ? '<a href="?sub='.$sub.'&type=all">Все</a>' : '<span class="active_item">Все</span>')?>
</td>  
</tr> </tbody></table>
</div>
<?

$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `journal` WHERE ".($sub != 'all' ? "`act` = '{$sub}' and" : null)." ".($type=="new" ? "`read` = '0' and" : null)."  `ank` = ".$user['id']),0);
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str']*$page-$set['p_str'];

if ($k_post == 0)
{
echo '<div class="list_item">Записей нет.<br>В журнале будут отображаться все ответы на ваши комментарии или записи.</div>';
}

$q = mysql_query("SELECT * FROM `journal` WHERE ".($sub != 'all' ? "`act` = '{$sub}' and" : null)." ".($type=="new" ? "`read` = '0' and" : null)." `ank` = ".$user['id']." ORDER BY `id` DESC LIMIT $start, $set[p_str]");


while ($post = mysql_fetch_assoc($q))
{
$ank = get_user($post['user']);
		
	/*
echo'<div class="block _touch-block _touch-list _touch-block-bn line_175"><div>
<div class="right stnd_padd">
<a href="'."?type={$type}&sub={$sub}&otkl={$ank['id']}".'" class="t_center t-block_item t-link_no_underline_block round_corners myc-button_link">
<span class="t-strong_red t-link_item_hover">Откл.</span>
</a>
			</div>
		
		<a href="?to='.$post['id'].'"><span class="m">'.output_text($post['opis']).'</span>
		 <span style="color:green;">
				'.($post['count'] ? '(+'.$post['count'].') ' : null).'
			</span>
			<br>
		<span class="blue">'.$ank['nick'].'</span> <span class="grey">('.vremja($post['time']).')</span>
				
		
		</a></div></div>';
*/




	
		
	echo '
		<div class="light_border_bottom t-bg3 overfl_hid">
			<div class="right stnd_padd">
				<a href="'."?type={$type}&sub={$sub}&otkl={$ank['id']}".'" class="t_center t-block_item t-link_no_underline_block round_corners myc-button_link"><span class="t-strong_red t-link_item_hover">Откл.</span></a>
			</div>
					
			<a href="?to='.$post['id'].'" class="t-block_item  t-link_no_underline_block overfl_hid">
			<span class="t-block_item stnd_padd">
					<span class="t-strong_item t-link_item_hover">'.output_text($post['opis']).'</span>
						 <span style="color:green;">
				'.($post['count'] ? '(+'.$post['count'].') ' : null).'
			</span>
			<br>
			<span class="blue">'.$ank['nick'].'</span> <span class="grey">('.vremja($post['time']).')</span>
				
			</span>
			</a>         
		</div>
		';
	}

if ($k_page>1)str("?type={$type}&sub={$sub}&",$k_page,$page);

$otkl = mysql_result(mysql_query("SELECT COUNT(*) FROM `journal_ban` WHERE `ank` = '$user[id]'"),0);
$delka = mysql_result(mysql_query("SELECT COUNT(*) FROM `journal` WHERE `ank` = '$user[id]'"),0);

?>
<div class="list_item blue_wrap_block lh_160"> 
<?
if($delka > 0){
?>
<a href="?type=<?= $type?>&sub=<?= $sub?>&delete=<?= $sub?>" class="arrow_link">
<img class="m p16" src="/style/i/cross_r.gif" alt=""> <span class="m">Очистить</span>
</a>
<br>
<?
}
?>
<a href="?mode=1" class="arrow_link"> 
<img class="m p16" src="/style/i/speaker.gif" alt=""> <span class="m">Отключенные уведомления</span>
</a>
<span class="m"> (<?= $otkl?>)</span>
</div>
<?






include_once H.'sys/inc/tfoot.php';
?>