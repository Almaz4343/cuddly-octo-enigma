<?
/**
* Комментарии у файла
*/

$file = mysql_fetch_assoc(query("SELECT * FROM `obmennik_files` WHERE `id` = '" . $post['id_object'] . "' LIMIT 1"));
$dir = mysql_fetch_assoc(query("SELECT * FROM `user_files` WHERE `id` = '" . $file['my_dir'] . "' LIMIT 1"));
$ras = $file['ras'];

if ($file['id']) {
  ?>
  <?= $avtor['avatar'] . $avtor['icon'] . $avtor['link'] . $avtor['medal'] . $avtor['online']?> <?= __('ответил') . ($avtor['pol'] == 1 ? "" : "а") . __(' вам в комментариях к файлу')?> 
  <img src="/style/icons/d.gif" alt="*" /> <a href="/user/personalfiles/<?= $file['id_user']?>/<?= $dir['id']?>/?id_file=<?= $file['id']?>&amp;page=<?= $pageEnd?>"><?= text($file['name'])?>.<?= $ras?></a> 
  <?  
} else {
  echo __('Этот файл уже удален =(');
}
?> 