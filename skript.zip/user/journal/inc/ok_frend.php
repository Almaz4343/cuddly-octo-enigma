<?
/**
* Принятые заявки в друзья
*/

if ($avtor['id']) {
  ?>
  <?= $avtor['avatar'] . $avtor['icon'] . $avtor['link'] . $avtor['medal'] . $avtor['online']?> <?= __(' стал') . ($avtor['pol'] == 1 ? "" : "а") . __(' вашим другом')?> 
  <?  
} else {
  echo __('Этот друг уже удален =)');
}
?>