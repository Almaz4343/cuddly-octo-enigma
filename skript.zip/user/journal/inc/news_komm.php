<?
/**
* Комментарии у новости
*/

$news = mysql_fetch_assoc(query("SELECT * FROM `news` WHERE `id` = '" . $post['id_object'] . "' LIMIT 1"));

if ($news['id']) {
  ?>
  <?= $avtor['avatar'] . $avtor['icon'] . $avtor['link'] . $avtor['medal'] . $avtor['online']?> <?= __('ответил') . ($avtor['pol'] == 1 ? "" : "а") . __(' вам в комментариях к новости')?> 
  <img src="/style/icons/news.png" alt="*" /> <a href="/news/news.php?id=<?= $news['id']?>&amp;page=<?= $pageEnd?>"><?= text($news['title'])?></a> 
  <?  
} else {
  echo __('Эта новость уже удалена =(');
}
?>