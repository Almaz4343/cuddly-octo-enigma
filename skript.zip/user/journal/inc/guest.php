<?
/**
* Комментарии из гостевой
*/

?>
<?= $avtor['avatar'] . $avtor['icon'] . $avtor['link'] . $avtor['medal'] . $avtor['online']?> <?= __('ответил') . ($avtor['pol'] == 1 ? "" : "а") . __(' вам в ')?> 
<img src="/style/icons/guest.png" alt="*" /> <a href="/guest/?page=<?= $pageEnd?>"><?= __('гостевой')?></a> 