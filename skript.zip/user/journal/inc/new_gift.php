<?
/**
* Новый подарок
*/

$id_gift =  mysql_fetch_assoc(query("SELECT id, id_gift FROM `gifts_user` WHERE `id` = '$post[id_object]' LIMIT 1"));
$gift =  mysql_fetch_assoc(query("SELECT id, name FROM `gift_list` WHERE `id` = '$id_gift[id_gift]' LIMIT 1"));

?>
<?= $avtor['avatar'] . $avtor['icon'] . $avtor['link'] . $avtor['medal'] . $avtor['online']?> <?= __('сделал') . ($avtor['pol'] == 1 ? "" : "а") . __(' вам подарок')?> 
<a href="/user/gift/gift.php?id=<?= $id_gift['id']?>"><img src="/sys/gift/<?= $gift['id']?>.png" style="max-width: <?= $width?>px;" alt="*" /> <?= text($gift['name'])?></a> 