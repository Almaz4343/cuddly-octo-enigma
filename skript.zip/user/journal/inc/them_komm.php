<?
/**
* Комментарии форума 
*/

$them = mysql_fetch_assoc(query("SELECT * FROM `forum_t` WHERE `id` = '" . $post['id_object'] . "' LIMIT 1"));

if ($them['id']) {
  ?>
  <?= $avtor['avatar'] . $avtor['icon'] . $avtor['link'] . $avtor['medal'] . $avtor['online']?> <?= __('ответил') . ($avtor['pol'] == 1 ? "" : "а") . __(' вам в теме')?> 
  <img src="/style/themes/<?= $set['set_them']?>/forum/14/them_<?= $them['up'] . $them['close']?>.png" alt="*" /> <a href="/forum/<?= $them['id_forum']?>/<?= $them['id_razdel']?>/<?= $them['id']?>/?page=<?= $pageEnd?>"><?= text($them['name'])?></a> 
  <?  
} else {
  echo __('Эта тема форума уже удалена =(');
}
?> 