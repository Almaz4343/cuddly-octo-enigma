<?
/**
* Удаление из друзей
*/

if ($avtor['id']) {
  ?>
  <?= $avtor['avatar'] . $avtor['icon'] . $avtor['link'] . $avtor['medal'] . $avtor['online']?> <?= __(' к сожалению удалил') . ($avtor['pol'] == 1 ? "" : "а") . __(' вас из списка друзей')?> 
  <?  
} else {
  echo __('Этот друг уже удален =)');
}
?>