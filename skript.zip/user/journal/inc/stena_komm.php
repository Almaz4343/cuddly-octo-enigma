<?
/**
* Комментарии стены
*/

if ($post['id_object'] == $user['id']) { $sT = 'вашей'; }
elseif ($post['id_object'] == $avtor['id']) { $sT = 'своей'; }
else { $sT = null; }
?>
<?= $avtor['avatar'] . $avtor['icon'] . $avtor['link'] . $avtor['medal'] . $avtor['online']?> <?= __('ответил') . ($avtor['pol'] == 1 ? "" : "а") . __(' вам на ' . $sT . ' стене')?> <?= user::avatar($post['id_object'], 0)?> <?= user::nick($post['id_object'], 1, 1, 1)?> 