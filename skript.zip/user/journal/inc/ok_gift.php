<?
/**
* Принимаем подарок
*/

$gift =  mysql_fetch_assoc(query("SELECT id, name FROM `gift_list` WHERE `id` = '$post[id_object]' LIMIT 1"));

?>
<?= $avtor['avatar'] . $avtor['icon'] . $avtor['link'] . $avtor['medal'] . $avtor['online']?> <?= __('принял') . ($avtor['pol'] == 1 ? "" : "а") . __(' ваш подарок')?> 
<img src="/sys/gift/<?= $gift['id']?>.png" style="max-width: <?= $width?>px;" alt="*" /> <?= text($gift['name'])?> 