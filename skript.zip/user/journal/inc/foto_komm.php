<?
/**
* Комментарии у фото
*/

$foto = mysql_fetch_assoc(query("SELECT * FROM `gallery_foto` WHERE `id` = '" . $post['id_object'] . "' LIMIT 1"));

if ($foto['id']) {
  ?>
  <?= $avtor['avatar'] . $avtor['icon'] . $avtor['link'] . $avtor['medal'] . $avtor['online']?> <?= __('ответил') . ($avtor['pol'] == 1 ? "" : "а") . __(' вам в комментариях к фотографии')?> 
  <img src="/style/icons/foto.png" alt="*" /> <a href="/foto/<?= $foto['id_user']?>/<?= $foto['id_gallery']?>/<?= $foto['id']?>/?page=<?= $pageEnd?>"><?= text($foto['name'])?></a> 
  <?  
} else {
  echo __('Это фото уже удалено =(');
}
?> 