<?
/**
* Комментарии из админ чата
*/

?>
<?= $avtor['avatar'] . $avtor['icon'] . $avtor['link'] . $avtor['medal'] . $avtor['online']?> <?= __('ответил') . ($avtor['pol'] == 1 ? "" : "а") . __(' вам в ')?> 
<img src="/style/icons/chat.gif" alt="*" /> <a href="/plugins/admin/chat/?page=<?= $pageEnd?>"><?= __('админ чате')?></a> 