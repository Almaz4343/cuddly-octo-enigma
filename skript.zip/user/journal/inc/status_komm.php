<?
/**
* Комментарии у статуса
*/

$status = mysql_fetch_assoc(query("SELECT * FROM `status` WHERE `id` = '" . $post['id_object'] . "' LIMIT 1"));

if ($status['id']) {
  ?>
  <?= $avtor['avatar'] . $avtor['icon'] . $avtor['link'] . $avtor['medal'] . $avtor['online']?> <?= __('ответил') . ($avtor['pol'] == 1 ? "" : "а") . __(' вам в комментариях этого')?> 
  <img src="/style/icons/comment.png" alt="*" /> <a href="/user/status/komm.php?id=<?= $status['id']?>&amp;page=<?= $pageEnd?>"><?= __('статуса')?></a> 
  <?  
} else {
  echo __('Этот статус уже удален =(');
}
?> 