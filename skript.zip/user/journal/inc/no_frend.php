<?
/**
* Отказ в друзья
*/

if ($avtor['id']) {
  ?>
  <?= $avtor['avatar'] . $avtor['icon'] . $avtor['link'] . $avtor['medal'] . $avtor['online']?> <?= __('к сожалению отказал') . ($avtor['pol'] == 1 ? "" : "а") . __(' вам в дружбе')?> 
  <?  
} else {
  echo __('Этот друг уже удален =)');
}
?>