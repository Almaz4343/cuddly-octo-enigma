<?
/**
* Комментарии у дневника
*/

$notes = mysql_fetch_assoc(query("SELECT * FROM `notes` WHERE `id` = '".$post['id_object']."' LIMIT 1"));

if ($notes['id']) {
  ?>
  <?= $avtor['avatar'] . $avtor['icon'] . $avtor['link'] . $avtor['medal'] . $avtor['online']?> <?= __('ответил') . ($avtor['pol'] == 1 ? "" : "а") . __(' вам в комментариях к дневнику')?> 
  <img src="/style/icons/zametki.gif" alt="*" /> <a href="/plugins/notes/list.php?id=<?= $notes['id']?>&amp;page=<?= $pageEnd?>"><?= text($notes['name'])?></a> 
  <?  
} else {
  echo __('Этот дневник уже удален =(');
}
?> 