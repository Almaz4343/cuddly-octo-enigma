<?
include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';
only_reg();

$tmp = mysql_fetch_array(query("SELECT * FROM `notification_set` WHERE `id_user` = '" . $user['id'] . "' LIMIT 1"));

if (isset($_POST['save'])) {
  $tmp['komm'] = ($_POST['komm'] == 1 ? 1 : 0);
  
  query("UPDATE `notification_set` SET `komm` = '$tmp[komm]' WHERE `id_user` = '$user[id]'");
  
  $_SESSION['message'] = __('Изменения успешно приняты');
  header('Location: settings.php');
  exit;
}

$set['title'] = __('Настройка уведомлений');
include_once H.'sys/inc/thead.php';
title();
aut();
err();
?>
<div id="comments" class="menus">
  <div class="webmenu">
    <a href="/user/info/settings.php"><?= __('Общие')?></a>
  </div> 

  <div class="webmenu last">
    <a href="/user/tape/settings.php"><?= __('Лента')?></a>
  </div> 

  <div class="webmenu last">
    <a href="/user/discussions/settings.php"><?= __('Обсуждения')?></a>
  </div> 

  <div class="webmenu last">
    <a href="/user/notification/settings.php" class="activ"><?= __('Уведомления')?></a>
  </div> 
  
  <div class="webmenu last">
    <a href="/user/info/settings.privacy.php" ><?= __('Приватность')?></a>
  </div> 

  <div class="webmenu last">
    <a href="/user/info/secure.php" ><?= __('Пароль')?></a>
  </div> 
</div>

<form action="?" method="post">
  <div class="mess">
    <?= __('Уведомления о ответах в комментариях')?>
  </div>

  <div class="nav1">
    <input name="komm" type="radio" <?= ($tmp['komm'] == 1 ? ' checked="checked"' : '')?> value="1" /> <?= __('Да')?>
    <input name="komm" type="radio" <?= ($tmp['komm'] == 0 ? ' checked="checked"' : '')?> value="0" /> <?= __('Нет')?>
  </div>

  <div class="main">
    <input type="submit" name="save" value="<?= __('Сохранить')?>" />
  </div>
</form>

<div class="foot">
  <img src="/style/icons/str2.gif" alt="*" /> <a href="index.php"><?= __('Уведомления')?></a> | <b><?= __('Настройки')?></b><br />
</div>
<?
include_once H.'sys/inc/tfoot.php';
?>