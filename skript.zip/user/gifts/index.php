<?

include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';

//only_reg();

$width = ($webbrowser == 'web' ? '100' : '70'); // Размер подарков при выводе в браузер

if (isset($_GET['id'])){
	$ank['id'] = intval($_GET['id']);
}

$ank = get_user($ank['id']);

if(!$ank || $ank['id'] == 0 || !isset($_GET['id'])){ 
	header("Location: /?".SID); 
	exit; 
}

if(!isset($user)){ 
	$_SESSION['err'] = 'Cделать подарок <b>'.$ank['nick'].'</b> могут только авторизованные пользователи.';
	header("Location: /aut.php".SID); 
	exit; 
}

$set['title'] = 'Сделать подарок : ' . $ank['nick'];
include_once H.'sys/inc/thead.php';

?>
<link rel="stylesheet" type="text/css" href="http://spac.me/css/custom/Files/Tile.css?r=1364p" data-tmp_css="1">
<?

title();

	
/*
==================================
Дарим подарок
==================================
*/
if (isset($_GET['gift']) && isset($_GET['isort']))
{
// Категория
$category = mysql_fetch_assoc(mysql_query("SELECT * FROM `gift_categories` WHERE `id` = '" . intval($_GET['isort']) . "' LIMIT 1"));

// Подарок
$gift = mysql_fetch_assoc(mysql_query("SELECT * FROM `gift_list` WHERE `id` = '" . intval($_GET['gift']) . "' LIMIT 1"));

if (isset($_POST['cfms']))
{
if ($user['money'] >= $gift['money']){	
		
$msg = my_esc($_POST['msg']);  // Комментарий
			
mysql_query("UPDATE `user` SET `money` = '" . ($user['money'] - $gift['money']) . "' WHERE `id` = '$user[id]'");

if($_POST['mode'] == 2 || $_POST['mode'] == 3)$type = intval($_POST['mode']);
else 
$type = 1;		
mysql_query("INSERT INTO `gifts_user` (`id_user`, `id_ank`, `id_gift`, `coment`, `time`, `status`, `type`) values('$ank[id]', '$user[id]', '$gift[id]', '$msg', '$time', '1', '$type')");

$id_gift = mysql_insert_id();

// Уведомления о подарках в почту
$msg_gift = "У Вас новый подарок! [url=/user/gifts/user_list/?id=".$ank['id']."]Открыть подарки.[/url]";
mysql_query("INSERT INTO `mail` (`id_user`, `id_kont`, `time`, `msg`, `read`) VALUES ('0', '".$ank['id']."', '".$time."', '".my_esc($msg_gift)."', '0')");

// Отправляем в журнал операций
$msg_journal = "Отправлен подарок пользователю ".$ank['nick'].".";
mysql_query("INSERT INTO `money` (`id_user`, `money`, `minus_plus`, `msg`, `time`) values('$user[id]', '$gift[money]', '0', '$msg_journal', '$time')");


	
$_SESSION['message'] = 'Ваш подарок успешно отправлен';
header("Location: /user/?id=$ank[id]");
exit;
}
else{
$err = 'У вас не достаточно средств на счету';
}
		
}


?>
<div class="lc_br wbg font0 relative oh" id="header_path">  
<a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     
<span class="lc_brw"> 
<img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/gifts/?id=<?= $ank['id']?>">Подарки</a> 
</span>     
<span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Отправка</span> </span>       
</div>
<?


err(); 
$casess = array('монета', 'монеты', 'монет');

?>
<div class="list_item light_border_bottom"> Подарок для  <?= group($ank['id'])?> 
<a href="info.php?id=<?= $ank['id']?>" class="mysite-link"><b class="nick"><?= unick($ank['id'])?></b></a>  
<br> <img src="/sys/gift/<?= $gift['id']?>.png" alt="">
<br> Стоимость: <span style="color:green"><b><?= intval($gift['money'])?></b></span> монет
<br> У вас на счету:  <span style="color:red"><?= des2num($user['money'], $casess)?></span> 
<br> <img src="/style/i/coins.png" alt="" class="m p16"> <a href="/user/money/" class="service_link m">Пополнить счет</a> 
</div>

<div class="list_item"> 
<form method="post" action="/user/gifts/?gift=<?= $gift['id']?>&amp;id=<?= $ank['id']?>&isort=<?= $category['id']?>" id="buy_form"> 
<b>Тип подарка:</b><br>  
<div style="padding-bottom:1px;"> 
<input name="mode" value="1" checked="checked" id="mode0" type="radio"> 
<label for="mode0">Публичный<br> <span class="grey">Все будут видеть Ваш подарок, сообщение и Ник.</span> </label> 
</div>  
<div style="padding-bottom:1px;"> 
<input name="mode" value="2" id="mode1" type="radio"> 
<label for="mode1">Личный<br> <span class="grey">Все будут видеть ваш подарок, но только получатель сможет видеть ваш Ник и сообщение.</span> </label> 
</div>  
<div> <input name="mode" value="3" id="mode2" type="radio"> 
<label for="mode2">Анонимный<br> <span class="grey">Все будут видеть ваш подарок. Только получатель увидит ваше сообщение. Никто не увидит ваш Ник.</span> </label> 
</div>   
<br> <div class="js-toolbar_wrap"> 
<textarea name="msg" rows="5" cols="17" style="width: 96%;" id="textarea" maxlength="220">Лови подарок!</textarea>
<br> 
</div> 
<input value="Отправить" class="main_submit" id="mainSubmitForm" type="submit" name="cfms"> 
</form> 
</div>
<a href="/user/gifts/?id=<?= $ank['id']?>" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?

echo '<form action="?category=' . $category['id'] . '&amp;gift=' . $gift['id'] . '&amp;id=' . $ank['id'] . '&amp;ok" method="post">';
	
 

}
else
	
// Список подарков
if (isset($_GET['isort']))
{

// Категория
$category = mysql_fetch_assoc(mysql_query("SELECT * FROM `gift_categories` WHERE `id` = '" . intval($_GET['isort']) . "' LIMIT 1"));

if (!$category) 
{  
	$_SESSION['message'] = 'Нет такой категории';
	header("Location: /?");
	exit;
}

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  
<a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     
<span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> 
<a href="/user/?id=<?= $ank['id']?>"><?= $ank['nick']?></a> </span>     
<span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Сделать подарок</span> </span>       
</div>
<div class="list_item light_blue"> Выберите подарок для <b class="un"><?= $ank['nick']?></b> </div>
<?




$k_post1 = mysql_result(mysql_query("SELECT COUNT(id) FROM `gift_categories`"),0);
$k_page1=k_page($k_post1,$set['p_str']);
$page1=page($k_page1);
$start1=$set['p_str']*$page1-$set['p_str'];

$q1 = mysql_query("SELECT name,id FROM `gift_categories` ORDER BY `id`");

?>
<div class="list_item oh light_border_bottom lh_160">  
<?

while ($post1 = mysql_fetch_assoc($q1))
{
if($post1['id'] == $category['id']){
?>   
<span href="/user/gifts/?id=<?= $ank['id']?>&amp;isort=<?= $category['id']?>" class="b"><span><?= text($post1['name'])?></span></span> 
<?
}else{
?>   
<a href="/user/gifts/?id=<?= $ank['id']?>&amp;isort=<?= $post1['id']?>" class="arrow_link"><span><?= text($post1['name'])?></span></a> 
<?
}
if($post1['id'] != $k_post1){
?> 
<span class="service_links_block">|</span> 
<?
}
}
?>
</div>
<?

$k_post = mysql_result(mysql_query("SELECT COUNT(id) FROM `gift_list` WHERE `id_category` = '$category[id]'"),0);

if ($k_post == 0)
{
?>
<div class="list_item">  Нет подарков в категории.</div>
<?
}
else{
$set['p_str'] = '18';
$k_page=k_page($k_post,$set['p_str']);
$page=page($k_page);
$start=$set['p_str']*$page-$set['p_str'];
$q = mysql_query("SELECT name,id,money FROM `gift_list` WHERE `id_category` = '$category[id]' ORDER BY `id` LIMIT $start, $set[p_str]");

?>
<div class="stnd_padd light_border_bottom oh font0 bg-white">
<?

while ($post = mysql_fetch_assoc($q))
{
?>
<div class="tiled_item tiled_item-128 bg-white"> 
<div class="tiled_inner"> 
<div class="tiled_image-wrap tiled_image-wrap_l_100 relative"> 
<div class="tiled_image"> 
<a href="/user/gifts/?gift=<?= $post['id']?>&amp;id=<?= $ank['id']?>&amp;isort=<?= $category['id']?>"> 
<img src="/sys/gift/<?= $post['id']?>.png" alt="" class="main_image"> 
<img title="" alt="" src="/style/i/transparent.gif" width="100%"> 
</a> 
</div> </div> 
<div class="font_medium t_center gr"><small><?= intval($post['money'])?> монет</small></div> 
</div> </div>
<?
}
?>
</div>
<?

if ($k_page > 1)str('?id=' . $ank['id'] . '&amp;isort=' . intval($_GET['isort']) . '&amp;',$k_page,$page); // Вывод страниц

}
?>
<a href="/user/?id=<?= $ank['id']?>" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?
}
else
{
// Вывод категорий
?>
<div class="lc_br wbg font0 relative oh" id="header_path">  
<a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     
<span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> 
<a href="/user/?id=<?= $ank['id']?>"><?= $ank['nick']?></a> </span>     
<span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Сделать подарок</span> </span>       
</div>
<div class="list_item light_blue"> Выберите подарок для <b class="un"><?= $ank['nick']?></b> </div>
<?

?>
<div class="list_item oh light_border_bottom lh_160">   
<?

$k_post1 = mysql_result(mysql_query("SELECT COUNT(id) FROM `gift_categories`"),0);
$k_page1=k_page($k_post1,$set['p_str']);
$page1=page($k_page1);
$start1=$set['p_str']*$page1-$set['p_str'];

$q1 = mysql_query("SELECT name,id FROM `gift_categories` ORDER BY `id`");



while ($post1 = mysql_fetch_assoc($q1))
{
if($post1['id'] == 5){
?>   
<span href="/user/gifts/?id=<?= $ank['id']?>&amp;isort=<?= $category['id']?>" class="b"><span><?= text($post1['name'])?></span></span> 
<?
}else{
?>   
<a href="/user/gifts/?id=<?= $ank['id']?>&amp;isort=<?= $post1['id']?>" class="arrow_link"><span><?= text($post1['name'])?></span></a> 
<?
}
if($post1['id'] != 5){
?> 
<span class="service_links_block">|</span> 
<?
}
}
?>
</div>
<?

$set['p_str'] = '18';
$k_post = mysql_result(mysql_query("SELECT COUNT(id) FROM `gift_list` WHERE `id_category` = '5'"),0);
$k_page=k_page($k_post,$set['p_str']);
$page=page($k_page);
$start=$set['p_str']*$page-$set['p_str'];


if ($k_post == 0)
{
?>
<div class="list_item">  Нет подарков в категории.</div>
<?
}
else{

$q = mysql_query("SELECT name,id,money FROM `gift_list` WHERE `id_category` = '5' ORDER BY `id` LIMIT $start, $set[p_str]");


?>
<div class="stnd_padd light_border_bottom oh font0 bg-white">
<?

while ($post = mysql_fetch_assoc($q))
{
?>
<div class="tiled_item tiled_item-128 bg-white"> 
<div class="tiled_inner"> 
<div class="tiled_image-wrap tiled_image-wrap_l_100 relative"> 
<div class="tiled_image"> 
<a href="/user/gifts/?gift=<?= $post['id']?>&amp;id=<?= $ank['id']?>&amp;isort=5"> 
<img src="/sys/gift/<?= $post['id']?>.png" alt="" class="main_image"> 
<img title="" alt="" src="/style/i/transparent.gif" width="100%"> 
</a> 
</div> </div> 
<div class="font_medium t_center gr"><small><?= intval($post['money'])?> монет</small></div> 
</div> </div>
<?
}
?>
</div>
<?
if ($k_page > 1)str('?id=' . $ank['id'] . '&amp;',$k_page,$page); // Вывод страниц

}

?>
<a href="/user/?id=<?= $ank['id']?>" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?
}

include_once H.'sys/inc/tfoot.php';
?>