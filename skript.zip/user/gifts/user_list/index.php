<?

include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';

if (isset($_GET['id'])){
	$ank['id'] = intval($_GET['id']);
}

$ank = get_user($ank['id']);

if(!$ank || $ank['id'] == 0 || !isset($_GET['id'])){ 
	header("Location: /?".SID); 
	exit; 
}



// Подробнее о подарке
if (isset($_GET['details']))
{

// Определяем подарок
$gift_post = mysql_fetch_assoc(mysql_query("SELECT id,status,coment,id_gift,id_ank,id_user,time,type FROM `gifts_user` WHERE `id` = '" . intval($_GET['details']) . "' LIMIT 1"));

// Если записи нет кидаем на главную
if (!$gift_post['id']){ 
	$_SESSION['err'] = 'Ошибка! Подарок не найден.';
	header("Location: ?id=".$ank['id'].""); 
}

// Сам Подарок 
$gift_id = mysql_fetch_assoc(mysql_query("SELECT id,name FROM `gift_list` WHERE `id` = '" . $gift_post['id_gift'] . "' LIMIT 1"));

// Кто подарил
$ank_gift = get_user($gift_post['id_ank']);

// Удаление подарка
if (isset($_GET['dell']) && (isset($user) && $ank['id'] == $user['id']  || $user['level'] >= 3)){
	// Запрос удаления
	mysql_query("DELETE FROM `gifts_user` WHERE `id` = '$gift_post[id]' LIMIT 1");
	header("Location: ?id=".$ank['id'].""); 
	exit;
}

$set['title'] = 'Подробности : Подарки : ' . $ank['nick'];
include_once H.'sys/inc/thead.php';

?>
<link rel="stylesheet" type="text/css" href="http://spac.me/css/custom/Files/Tile.css?r=1364p" data-tmp_css="1">
<?

title();



//<div class="oh"><b class="service_item">Сообщение:</b> '. output_text($gift_post['coment']).'</div> 
if($gift_post['type'] == 1){ 
$type = ''.group($ank_gift['id']).' <a href="/user/?id='.$ank_gift['id'].'" class="mysite-link"><b class="nick">'.unick($ank_gift['id']).'</b></a>';
$tip = 'Публичный';
$tip_msg = '<div class="oh pad_t_a"> <b class="grey">Сообщение:</b> '. output_text($gift_post['coment']).'</div> ';
}elseif($gift_post['type'] == 2){ 
// Видит хозяин и Админы
if ($ank['id'] == $user['id'] || $user['level']  >= 3){
$type = ''.group($ank_gift['id']).' <a href="/user/?id='.$ank_gift['id'].'" class="mysite-link"><b class="nick">'.unick($ank_gift['id']).'</b></a>';
$tip_msg = '<div class="oh pad_t_a"> <b class="grey">Сообщение:</b> '. output_text($gift_post['coment']).'</div> ';
}
// Видит так обычный юзер
elseif ($ank['id'] != $user['id']){
$type = '<b>Неизвестный</b>';
$tip_msg = '';
}
$tip = 'Личный';
}elseif($gift_post['type'] == 3){
if (isset($user) && $ank['id'] != $user['id'] && $user['level'] >= 3){
$type = ''.group($ank_gift['id']).' <a href="/user/?id='.$ank_gift['id'].'" class="mysite-link"><b class="nick">'.unick($ank_gift['id']).'</b></a>';
$tip_msg = '<div class="oh pad_t_a"> <b class="grey">Сообщение:</b> '. output_text($gift_post['coment']).'</div> ';
}elseif (isset($user) && $ank['id'] == $user['id']  && $user['level'] >= 3){
$type = ''.group($ank_gift['id']).' <a href="/user/?id='.$ank_gift['id'].'" class="mysite-link"><b class="nick">'.unick($ank_gift['id']).'</b></a>';
$tip_msg = '<div class="oh pad_t_a"> <b class="grey">Сообщение:</b> '. output_text($gift_post['coment']).'</div> ';
}else{
$type = '<b>Неизвестный</b>';
$tip_msg = '';
}
$tip = 'Анонимный';
}  

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  
<a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     
<span class="lc_brw"> 
<img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $ank['id']?>"><?= $ank['nick']?></a> 
</span>     
<span class="lc_brw"> 
<img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/gifts/user_list/?id=<?= $ank['id']?>">Подарки</a> 
</span>     
<span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Подробности</span> </span>       
</div>

<div class="wrapper block"> 

<img src="/sys/gift/<?= $gift_id['id']?>.png" alt=""><br> 


<div class="pad_t_a"> <b class="grey">Подарил:</b> <?= $type?> <br> </div>

<div class="pad_t_a"> <b class="grey">Дата:</b> <?= vremja($gift_post['time'])?> <br> </div>

<div class="pad_t_a"> <b class="grey">Тип подарка:</b> <?= $tip?> </div>  

<?= $tip_msg?>
</div>
<?
if(isset($user) && $ank['id'] == $user['id']){
?>
<div class="bottom_link_block lh_160"> 
<?
if($ank_gift['id'] != $user['id']){
if($gift_post['type'] != 3){ 
?>
<a href="/user/gifts/?id=<?= $ank_gift['id']?>" class="arrow_link"> <img class="m p16" src="/style/i/sendgift.gif" alt=""> <span class="m">Ответить</span> </a><br>     
<?
}
}
?>
<a href="/user/gifts/user_list/?details=<?= $gift_post['id']?>&dell&id=<?= $ank['id']?>" class="arrow_link"> <img class="m p16" src="/style/i/cross_r.gif" alt=""> <span class="m">Удалить подарок</span> </a> 
</div>
<?
}
elseif(isset($user) && $ank['id'] != $user['id'] || $user['level'] >= 3){
?>
<div class="bottom_link_block lh_160"> 
<a href="/user/gifts/user_list/?details=<?= $gift_post['id']?>&dell&id=<?= $ank['id']?>" class="arrow_link"> <img class="m p16" src="/style/i/cross_r.gif" alt=""> <span class="m">Удалить подарок</span> </a> 
</div>

<?
}

?>
<a href="/user/gifts/user_list/?id=<?= $ank['id']?>" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?

include_once H.'sys/inc/tfoot.php';
exit;
}
// ВЫВОД ПОДАРКОВ
else{

$set['title'] = 'Подарки : ' . $ank['nick'];
include_once H.'sys/inc/thead.php';

?>
<link rel="stylesheet" type="text/css" href="http://spac.me/css/custom/Files/Tile.css?r=1364p" data-tmp_css="1">
<?

title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $ank['id']?>"><?= $ank['nick']?></a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Подарки</span> </span>       </div>
<?

$set['p_str'] = '15';
$k_post = mysql_result(mysql_query("SELECT COUNT(id) FROM `gifts_user` WHERE `id_user` = '$ank[id]' AND `status` = '1'"),0);

?>
<div class="header upcs">       <b class="m">Подарки</b> 
<?
if($k_post > 0){
?>
<span class="cnt m"><?= $k_post?></span> 
<?
}
?>
</div>
<?

$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str']*$page-$set['p_str'];


?>
<div class="wrapper">     
<a href="/user/gifts/?id=<?= $ank['id']?>" class="link  blue     "> 
<span> <img src="/style/i/gifts_blue.png" alt="" class="m">      <span class="m">  Сделать подарок <?= $ank['nick']?> </span> </span>  
</a>    
</div>
<?

if($k_post == 0){
?>
<div class="wrapper">   <div class="block"> Список пуст. </div>     </div>
<?
}
else{

$q = mysql_query("SELECT id,status,type,coment,id_gift,id_ank,time FROM `gifts_user` WHERE `id_user` = '$ank[id]' AND `status` = '1' ORDER BY `time` DESC LIMIT $start, $set[p_str]");


?>
<div class="wrapper" style="border-bottom:0;"> 
<div class="list f-c_fll">
<?

// Неизвестный
while ($post = mysql_fetch_assoc($q)){

$gift = mysql_fetch_assoc(mysql_query("SELECT id,name FROM `gift_list` WHERE `id` = '$post[id_gift]' LIMIT 1"));
$anketa = get_user($post['id_ank']);

if($post['type'] == 1){ 
$type = ''.group($anketa['id']).' <a href="/user/?id='.$anketa['id'].'" class="mysite-link"><b class="nick">'.unick($anketa['id']).'</b></a>';
}elseif($post['type'] == 2){ 
// Видит хозяин и Админы
if ($ank['id'] == $user['id'] || $user['level']  >= 3){
$type = ''.group($anketa['id']).' <a href="/user/?id='.$anketa['id'].'" class="mysite-link"><b class="nick">'.unick($anketa['id']).'</b></a>';
}
// Видит так обычный юзер
elseif ($ank['id'] != $user['id']){
$type = '<b>Неизвестный</b>';
}
}elseif($post['type'] == 3){
if (isset($user) && $ank['id'] != $user['id'] && $user['level'] >= 3){
$type = ''.group($anketa['id']).' <a href="/user/?id='.$anketa['id'].'" class="mysite-link"><b class="nick">'.unick($anketa['id']).'</b></a>';
}elseif (isset($user) && $ank['id'] == $user['id']  && $user['level'] >= 3){
$type = ''.group($anketa['id']).' <a href="/user/?id='.$anketa['id'].'" class="mysite-link"><b class="nick">'.unick($anketa['id']).'</b></a>';
}else{
$type = '<b>Неизвестный</b>';
}
}

?>
<div class="block oh relative bord-botm"> 
<div class="left dot_pic"> <img alt="" src="/sys/gift/<?= $gift['id']?>.png" class="p40"> </div> 
<div class="oh"> 
<div class="grey right"><?= vremja($post['time'])?></div>  
<?= $type?>   
</div> 
<div class="pad_t_a"> 
<a href="/user/gifts/user_list/?details=<?= $post['id']?>&id=<?= $ank['id']?>" class=" full_link"> Подробнее </a> 
</div> 
</div>
<?
}

?>
</div>
</div>
<?

}

if ($k_page > 1)str('?id=' . $ank['id'] . '&amp;',$k_page,$page); // Вывод страниц


$frend = mysql_result(mysql_query("SELECT COUNT(*) FROM `frends` WHERE (`user` = '$user[id]' AND `frend` = '$ank[id]') OR (`user` = '$ank[id]' AND `frend` = '$user[id]') LIMIT 1"),0);
$frend_new = mysql_result(mysql_query("SELECT COUNT(*) FROM `frends_new` WHERE (`user` = '$user[id]' AND `to` = '$ank[id]') OR (`user` = '$ank[id]' AND `to` = '$user[id]') LIMIT 1"),0);

if(isset($user)){
$dipi_div = '';
}else{
$dipi_div = ' table__cell_last';
}

if($ank['id'] != $user['id']){
?>
<div class="wrapper wbg">   
<table class="table__wrap"> <tbody><tr>  
<td class="table__cell<?= $dipi_div?>" width="50%">     
<a href="/mail.php?id=<?= $ank['id']?>" class="link         "> 
<span>        <img src="/style/i/mail_grey.png" alt="" class="m">      <span class="m">  Написать </span>          </span>  
</a>     
</td> 
<?
if(isset($user)){
?>  
<td class="table__cell table__cell_last" width="50%">    
<?
if ($frend_new == 0 && $frend==0){
?> 
<a href="/user/frends/create.php?add=<?= $ank['id']?>" class="link blue">          
<img src="/style/i/befriends.png" alt="" class="m">      <span class="m">  Дружить </span>          
<!-- --><!-- --><!-- --></a><!-- -->
<?
}elseif ($frend_new == 1){
?>  
<a href="/user/frends/create.php?otm=<?= $ank['id']?>" class="link blue"  title="Отменить заявку">          
<img src="/style/i/befriends_inprocess.png" alt="" class="m">      <span class="m">  Запрошено </span>          
<!-- --><!-- --><!-- --></a><!-- -->
<?
}elseif ($frend == 2){
?> 
<a href="/user/frends/create.php?del=<?= $ank['id']?>" data-action="friends_delete" class="link green" title="Удалить из друзей">          
<img src="/style/i/befriends_on.png" alt="" class="m">      <span class="m">  Дружите </span>          
<!-- --><!-- --><!-- --></a><!-- -->
<?
}
?>
</td>  
<?
}
?>      
</tr> </tbody></table>    
</div>
<?
}


?>
<a href="/user/?id=<?= $ank['id']?>" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?

include_once H.'sys/inc/tfoot.php';
}

?>