<?

include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';

if (!isset($user)){
	header("Location: /" . SID);
	exit;
}


$set['title'] = 'Закладки : ' . $user['nick']; // заголовок страницы
include_once H.'sys/inc/thead.php';
title();


?>
<div class="lc_br wbg font0 relative oh" id="header_path">  
<a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     
<span class="lc_brw"> 
<img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $user['id']?>"><?= $user['nick']?></a> 
</span>     
<span class="lc_brw"> 
<img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Закладки</span> 
</span>       
</div>

<div class="tabs_block oh">    
<div class="tab_item left tab_active black" style="padding: 12px 9px 8px 9px">  Закладки  </div>   
<a href="index/" class="tab_item left" style="padding: 12px 9px 8px 9px">  Метки  </a> 
<a href="/user/bookmarks/likes/" class="tab_item left">  Понравилось  </a> 
</div>
<?

$k_post=mysql_result(mysql_query("SELECT COUNT(id_object) FROM `bookmarks` WHERE `id_user` = '$user[id]'"),0);
$k_page=k_page($k_post,$set['p_str']);
$page=page($k_page);
$start=$set['p_str']*$page-$set['p_str'];

if($k_post == 0){
?>
<div class="wrapper link"> Список пуст. </div>
<?
}else{

?>
<div class="wrapper wbg bb0">
<?

$q = mysql_query("SELECT * FROM `bookmarks` WHERE `id_user` = '$user[id]' ORDER BY `time` DESC LIMIT $start,$set[p_str]");
while($post = mysql_fetch_assoc($q)){
// Вывод людей
if($post['type'] == 'people'){
$people = get_user($post['id_object']);
?>
<div class="list_item"> <div class="bookmark">  
<span class="iwb"> 
<?= group($people['id'])?> 
<a href="/user/?id=<?= $people['id']?>" class="mysite-link"><b class="nick"><?= unick($people['id'])?></b></a> 
<?= medal($people['id'])?>
</span>  
</div>   </div>
<?
}elseif($post['type'] == 'foto'){
$photo = mysql_fetch_assoc(mysql_query("SELECT * FROM `gallery_foto` WHERE `id` = '$post[id_object]' LIMIT 1"));
?>
<div class="list_item"> 
<div class="bookmark">  
<div> 
<div class="list_item bookmark_block js-file_item oh">    
<div class="left font0 relative" style="margin-right:5px;">      
<a class="tdn gview_link" href="/foto/<?= $photo['id_user']?>/<?= $photo['id_gallery']?>/<?= $photo['id']?>/">   
<div class="inl_bl relative"> <img src="/foto/pic50/<?= $photo['id']?>.p.51.50.0.<?= $photo['ras']?>" alt="" class="preview">   </div>      
</a>         
</div>  
<div class="oh">   
<a href="/foto/<?= $photo['id_user']?>/<?= $photo['id_gallery']?>/<?= $photo['id']?>/" class="arrow_link strong_link">   
<img src="/style/i/icon_img_jpg.gif" alt="" class="m p16">  <span class="m"><?= text($photo['name'])?></span></a>
<span style="color:gray;" class="m">.<?= $photo['ras']?></span>         
<span class="file_size m"> <?= size_file(filesize(H.'sys/tpic/pictures/'.$photo['id'].'.0.jpg'))?> </span>     <br>     
<div class="clear"></div> 
</div> <div class="clear"></div>  </div>   
</div>  </div>   
</div>
<?
}if($post['type'] == 'notes'){
$diary = mysql_fetch_assoc(mysql_query("SELECT * FROM `notes` WHERE `id` = '$post[id_object]' LIMIT 1"));
?>
<div class="list_item"> <div class="bookmark">  
<span class="iwb">  <span style="display:inline-block;max-width:100%;" class="m oh diary_inline">   
<a class="arrow_link strong_link" href="/user/blogs/read/?id=<?= $diary['id']?>">  <span><?= text($diary['name'])?></span>  
</a>   
</span>   </span>  
</div>   </div>
<?
}elseif($post['type'] == 'forum'){
$them = mysql_fetch_assoc(mysql_query("SELECT * FROM `forum_t` WHERE `id`='$post[id_object]' LIMIT 1"));
?>
<div class="list_item"> <div class="bookmark">  
<span class="iwb"> 
<img src="/style/i/Forum.gif" alt="" class="m p16">  
<a class="" href="/forum/<?= $them['id_forum']?>/<?= $them['id_razdel']?>/<?= $them['id']?>/"><?= text($them['name'])?></a>    
</span>  
</div>   </div>
<?
}elseif($post['type'] == 'file'){
$file_id = mysql_fetch_assoc(mysql_query("SELECT id_dir,id,name,ras  FROM `obmennik_files` WHERE `id` = '" . $post['id_object'] . "'  LIMIT 1"));
$dir = mysql_fetch_array(mysql_query("SELECT `dir` FROM `obmennik_dir` WHERE `id` = '$file_id[id_dir]' LIMIT 1"));
?>
<div class="list_item"> <div class="bookmark">  
<div> <div class="list_item bookmark_block js-file_item oh">    
<div class="left font0 relative" style="margin-right:5px;">         </div>  
<div class="oh"> 
<a href="/obmen<?= $dir['dir']?> . $file_id['id']?>.<?= $file_id['ras']?>?showinfo" class="arrow_link strong_link">   
<img src="/style/i/files_bright_m.png" alt="" class="m p16">  <span class="m"><?= text($file_id['name'])?></span>
</a>
<span style="color:gray;" class="m">.<?= $file_id['ras']?></span>         <br>     
<div class="clear"></div> </div> <div class="clear"></div>  
</div>   
</div>  </div>   </div>
<?
}


}

?>
</div>
<?


}

?>
<a href="/user/?id=<?= $user['id']?>" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?

include_once H.'sys/inc/tfoot.php';
?>