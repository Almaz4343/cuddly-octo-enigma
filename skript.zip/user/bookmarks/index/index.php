<?

include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';

if (!isset($user)){
	header("Location: /" . SID);
	exit;
}

/*********************/
/* ВЫВОД МЕТОК СРАЗУ */
/*********************/
if (!isset($_GET['type'])){

$set['title'] = 'Метки : Закладки : ' . $user['nick']; // заголовок страницы
include_once H.'sys/inc/thead.php';
title();

$vse = mysql_result(mysql_query("SELECT COUNT(id_object) FROM `bookmarks` WHERE `id_user` = '$user[id]'"),0);
$people = mysql_result(mysql_query("SELECT COUNT(id_object) FROM `bookmarks` WHERE `id_user` = '" . $user['id'] . "' AND `type` = 'people'"),0);
$files = mysql_result(mysql_query("SELECT COUNT(id_object) FROM `bookmarks` WHERE `id_user` = '" . $user['id'] . "' AND `type` = 'file'"),0);
$foto = mysql_result(mysql_query("SELECT COUNT(id_object) FROM `bookmarks` WHERE `id_user` = '" . $user['id'] . "' AND `type` = 'foto'"),0);
$forum = mysql_result(mysql_query("SELECT COUNT(id_object) FROM `bookmarks` WHERE `id_user` = '" . $user['id'] . "' AND `type` = 'forum'"),0);
$notes = mysql_result(mysql_query("SELECT COUNT(id_object) FROM `bookmarks` WHERE `id_user` = '" . $user['id'] . "' AND `type` = 'notes'"),0);

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  
<a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     
<span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $user['id']?>"><?= $user['nick']?></a> </span>     
<span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="?id=<?= $user['id']?>">Закладки</a> </span>  
<span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Метки</span> </span>  
</div>

<div class="tabs_block oh">   
<a href="/user/bookmarks/" class="tab_item left" style="padding: 12px 9px 8px 9px">  Закладки  </a>  
<div class="tab_item left tab_active black" style="padding: 12px 9px 8px 9px">  Метки  </div>   
<a href="/user/bookmarks/likes/" class="tab_item left">  Понравилось  </a>     
</div>


<div class="wrapper wbg"> 
   
<?

if($vse == 0){
?>
<div class="block"> Вы не добавили ни одной метки. </div>
<?
}

if($people > 0){
?>     
<a href="/user/bookmarks/index/?type=people" class="link darkblue"> 
<img src="/style/i/People.gif" alt="" class="m p16"> <span class="m">Люди</span> <span class="grey m">(<?= $people?>)</span> 
</a>
<?
}
/*
<a href="/user/bookmarks/files.php?id=<?= $user['id']?>" class="link darkblue"> 
<img src="/style/i/files_bright_m.png" alt="" class="m p16"> <span class="m">Файлы</span> <span class="grey m">(<?= $files?>)</span> 
</a>
*/
if($foto > 0){
?>
<a href="/user/bookmarks/index/?type=photo" class="link darkblue"> 
<img src="/style/i/PhotoIcon.gif" alt="" class="m p16"> <span class="m">Фото</span> <span class="grey m">(<?= $foto?>)</span> 
</a>
<?
}
if($forum > 0){
?>
<a href="/user/bookmarks/index/?type=forum" class="link darkblue"> 
<img src="/style/i/Forum.gif" alt="" class="m p16"> <span class="m">Темы форума</span> <span class="grey m">(<?= $forum?>)</span> 
</a>
<?
}
if($notes > 0){
?>
<a href="/user/bookmarks/index/?type=blog" class="link darkblue"> 
<img src="/style/i/diary.gif" alt="" class="m p16"> <span class="m">Блоги</span> <span class="grey m">(<?= $notes?>)</span> 
</a>
<?
}
?>
</div>
<?

}else

/*******************************/
/* Вывод ЛЮДЕЙ */
/*******************************/

if (isset($_GET['type']) && $_GET['type'] == 'people'){

if (isset($user) && isset($_GET['del'])){
mysql_query("DELETE FROM `bookmarks` WHERE `id` = '" . intval($_GET['del']) . "' AND `id_user` = '$user[id]' AND `type` = 'people' LIMIT 1");
$_SESSION['message'] = 'Закладка удалена.';
header("Location: ?type=people&P=" . intval($_GET['page']) . "" . SID);
exit;
}

$set['title'] = 'Закладки : ' . $user['nick']; // заголовок страницы
include_once H.'sys/inc/thead.php';
title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  
<a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     
<span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $user['id']?>"><?= $user['nick']?></a> </span>     
<span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Закладки</span> </span>       
</div>

<div class="tabs_block oh">    
<div class="tab_item left tab_active black" style="padding: 12px 9px 8px 9px">  Закладки  </div>   
<a href="/user/bookmarks/index/" class="tab_item left" style="padding: 12px 9px 8px 9px">  Метки  </a> 
<a href="/user/bookmarks/likes/" class="tab_item left">  Понравилось  </a> 
</div>
<?


$set['p_str'] = '10';
$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `bookmarks` WHERE `id_user` = '$user[id]' AND `type` = 'people' "),0);
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str']*$page-$set['p_str'];


if ($k_post == 0){
?>
<div class="wrapper link">Нет людей в закладках.</div>
<?
}
else{

?>
<div class="wrapper wbg bb0">
<?

$q = mysql_query("SELECT * FROM `bookmarks` WHERE `id_user` = '$user[id]' AND `type` = 'people' ORDER BY id DESC LIMIT $start, $set[p_str]");

while ($post = mysql_fetch_assoc($q))
{

$user_p = mysql_fetch_assoc(mysql_query("SELECT * FROM `user` WHERE `id` = $post[id_object] LIMIT 1"));

?>
<div class="list_item"> <div class="bookmark">  
<span class="iwb"> 
<a class="right" href="?type=people&del=<?= $post['id']?>"><img src="/style/i/cross_light.png" alt=""  title="Удалить закладку"/></a>
<?= group($user_p['id'])?> <a href="/user/?id=<?= $user_p['id']?>" class="mysite-link">
<b class="nick"><?= unick($user_p['id'])?></b></a> <?= medal($user_p['id'])?>      
</span>  
</div>   </div>
<?


}

?>
</div>
<?

if ($k_page>1)str('?type=people&',$k_page,$page); // Вывод страниц

?>
<div class="list_item"> <b>Выбранные метки:</b> <span class="lh_160">&nbsp;<span>Люди</span> </span> </div>
<?

}

?>
<a href="/user/bookmarks/index/" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?

}else

/***************/
/* Вывод фото  */
/***************/

if (isset($_GET['type']) && $_GET['type'] == 'photo'){

if (isset($user) && isset($_GET['del'])){
mysql_query("DELETE FROM `bookmarks` WHERE `id` = '" . intval($_GET['del']) . "' AND `id_user` = '$user[id]' AND `type` = 'foto' LIMIT 1");
$_SESSION['message'] = 'Закладка удалена.';
header("Location: ?type=photo&P=" . intval($_GET['page']) . "" . SID);
exit;
}

$set['title'] = 'Закладки : ' . $user['nick']; // заголовок страницы
include_once H.'sys/inc/thead.php';
title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  
<a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     
<span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $user['id']?>"><?= $user['nick']?></a> </span>     
<span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Закладки</span> </span>       
</div>

<div class="tabs_block oh">    
<div class="tab_item left tab_active black" style="padding: 12px 9px 8px 9px">  Закладки  </div>   
<a href="/user/bookmarks/index/" class="tab_item left" style="padding: 12px 9px 8px 9px">  Метки  </a> 
<a href="/user/bookmarks/likes/" class="tab_item left">  Понравилось  </a> 
</div>
<?


$set['p_str'] = '10';
$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `bookmarks` WHERE `id_user` = '$user[id]' AND `type` = 'foto' "),0);
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str']*$page-$set['p_str'];

if ($k_post == 0){
?>
<div class="wrapper link"> Нет фотографий в закладках. </div>
<?
}else{

?>
<div class="wrapper wbg bb0">
<?

$q = mysql_query("SELECT * FROM `bookmarks` WHERE `id_user` = '$user[id]' AND `type` = 'foto' ORDER BY id DESC LIMIT $start, $set[p_str]");



while ($post = mysql_fetch_assoc($q)){

$photo = mysql_fetch_assoc(mysql_query("SELECT * FROM `gallery_foto` WHERE `id` = '$post[id_object]' LIMIT 1"));

?>
<div class="list_item"> 
<div class="bookmark">  
<div> 
<div class="list_item bookmark_block js-file_item oh">    
<div class="left font0 relative" style="margin-right:5px;">      
<a class="tdn gview_link" href="/foto/<?= $photo['id_user']?>/<?= $photo['id_gallery']?>/<?= $photo['id']?>/">   
<div class="inl_bl relative"> <img src="/foto/pic50/<?= $photo['id']?>.p.51.50.0.<?= $photo['ras']?>" alt="" class="preview">   </div>      
</a>         
</div>  
<div class="oh">   
<a href="/foto/<?= $photo['id_user']?>/<?= $photo['id_gallery']?>/<?= $photo['id']?>/" class="arrow_link strong_link">   
<img src="/style/i/icon_img_jpg.gif" alt="" class="m p16">  <span class="m"><?= text($photo['name'])?></span></a>
<span style="color:gray;" class="m">.<?= $photo['ras']?></span>         
<span class="file_size m"> <?= size_file(filesize(H.'sys/tpic/pictures/'.$photo['id'].'.0.jpg'))?> </span>     <br> <br>
<a class="right" href="?type=photo&del=<?= $post['id']?>"><img src="/style/i/cross_light.png" alt="" title="Удалить закладку"/></a>    
<div class="clear"></div> 
</div> <div class="clear"></div>  </div>   
</div>  </div>   
</div>
<?

}
?>
</div>
<?

if ($k_page > 1)str('?type=photo&',$k_page,$page); // Вывод страниц

?>
<div class="list_item"> <b>Выбранные метки:</b> <span class="lh_160">&nbsp;<span>Фото</span> </span> </div>
<?

}


?>
<a href="/user/bookmarks/index/" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?


}else

/*******************************/
/****** ВВЫВОД БЛОГОВ ******** */
/*******************************/

if (isset($_GET['type']) && $_GET['type'] == 'blog'){

if (isset($user) && isset($_GET['del'])){
mysql_query("DELETE FROM `bookmarks` WHERE `id` = '" . intval($_GET['del']) . "' AND `id_user` = '$user[id]' AND `type` = 'notes' LIMIT 1");
$_SESSION['message'] = 'Закладка удалена.';
header("Location: ?type=blog&P=" . intval($_GET['page']) . "" . SID);
exit;
}

$set['title'] = 'Закладки : ' . $user['nick']; // заголовок страницы
include_once H.'sys/inc/thead.php';
title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  
<a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     
<span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $user['id']?>"><?= $user['nick']?></a> </span>     
<span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Закладки</span> </span>       
</div>

<div class="tabs_block oh">    
<div class="tab_item left tab_active black" style="padding: 12px 9px 8px 9px">  Закладки  </div>   
<a href="/user/bookmarks/index/" class="tab_item left" style="padding: 12px 9px 8px 9px">  Метки  </a> 
<a href="/user/bookmarks/likes/" class="tab_item left">  Понравилось  </a> 
</div>
<?


$set['p_str'] = '10';
$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `bookmarks` WHERE `id_user` = '$user[id]' AND `type` = 'notes' "),0);
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str']*$page-$set['p_str'];

if ($k_post == 0){
?>
<div class="wrapper link"> Нет блогов в закладках. </div>
<?
}else{

?>
<div class="wrapper wbg bb0">
<?

$q = mysql_query("SELECT * FROM `bookmarks` WHERE `id_user` = '$user[id]' AND `type` = 'notes' ORDER BY id DESC LIMIT $start, $set[p_str]");



while ($post = mysql_fetch_assoc($q)){

$diary = mysql_fetch_assoc(mysql_query("SELECT * FROM `notes` WHERE `id` = '$post[id_object]' LIMIT 1"));

?>
<div class="list_item"> 
<div class="bookmark">  
<span class="iwb">   
<a class="right" href="?type=blog&del=<?= $post['id']?>"><img src="/style/i/cross_light.png" alt="" title="Удалить закладку"/></a>
<span style="display:inline-block;max-width:100%;" class="m oh diary_inline">   
<a class="arrow_link strong_link" href="/user/blogs/read/?id=<?= $diary['id']?>">  
<span><?= text($diary['name'])?></span>  
</a>       
</span>   </span>  
</div>   </div>
<?

}


?>
</div>
<?

if ($k_page > 1)str('?type=blog&',$k_page,$page); // Вывод страниц

?>
<div class="list_item"> <b>Выбранные метки:</b> <span class="lh_160">&nbsp;<span>Блоги</span> </span> </div>
<?

}


?>
<a href="/user/bookmarks/index/" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?

}else

/*******************************/
/****** ВВЫВОД ФОРУМА ******** */
/*******************************/

if (isset($_GET['type']) && $_GET['type'] == 'forum'){

if (isset($user) && isset($_GET['del'])){
mysql_query("DELETE FROM `bookmarks` WHERE `id` = '" . intval($_GET['del']) . "' AND `id_user` = '$user[id]' AND `type` = 'forum' LIMIT 1");
$_SESSION['message'] = 'Закладка удалена.';
header("Location: ?type=forum&P=" . intval($_GET['page']) . "" . SID);
exit;
}

$set['title'] = 'Закладки : ' . $user['nick']; // заголовок страницы
include_once H.'sys/inc/thead.php';
title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  
<a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     
<span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $user['id']?>"><?= $user['nick']?></a> </span>     
<span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Закладки</span> </span>       
</div>

<div class="tabs_block oh">    
<div class="tab_item left tab_active black" style="padding: 12px 9px 8px 9px">  Закладки  </div>   
<a href="/user/bookmarks/index/" class="tab_item left" style="padding: 12px 9px 8px 9px">  Метки  </a> 
<a href="/user/bookmarks/likes/" class="tab_item left">  Понравилось  </a> 
</div>
<?


$set['p_str'] = '10';
$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `bookmarks` WHERE `id_user` = '$user[id]' AND `type` = 'forum' "),0);
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str']*$page-$set['p_str'];

if ($k_post == 0){
?>
<div class="wrapper link"> Нет тем форума в закладках. </div>
<?
}else{

?>
<div class="wrapper wbg bb0">
<?

$q = mysql_query("SELECT * FROM `bookmarks` WHERE `id_user` = '$user[id]' AND `type` = 'forum' ORDER BY id DESC LIMIT $start, $set[p_str]");



while ($post = mysql_fetch_assoc($q)){

$them = mysql_fetch_assoc(mysql_query("SELECT * FROM `forum_t` WHERE `id` = '$post[id_object]' LIMIT 1"));
	
// Определение подфорума
$forum = mysql_fetch_array(mysql_query("SELECT * FROM `forum_f` WHERE `id` = '$them[id_forum]' LIMIT 1"));
	
// Определение раздела
$razdel = mysql_fetch_array(mysql_query("SELECT * FROM `forum_r` WHERE `id` = '$them[id_razdel]' LIMIT 1"));
	
?>
<div class="list_item"> <div class="bookmark">  
<span class="iwb"> 
<a class="right" href="?type=forum&del=<?= $post['id']?>"><img src="/style/i/cross_light.png" alt="" title="Удалить закладку"/></a>
<img src="/style/i/Forum.gif" alt="" class="m p16">  
<a href="/forum/<?= $them['id_forum']?>/<?= $them['id_razdel']?>/"><?= text($razdel['name'])?></a>  :  
<a class="" href="/forum/<?= $them['id_forum']?>/<?= $them['id_razdel']?>/<?= $them['id']?>/"><?= text($them['name'])?></a>    
</span>  
</div>   </div>
<?

}

?>
</div>
<?

if ($k_page > 1)str('?type=forum&',$k_page,$page); // Вывод страниц

?>
<div class="list_item"> <b>Выбранные метки:</b> <span class="lh_160">&nbsp;<span>Форум</span> </span> </div>
<?

}


?>
<a href="/user/bookmarks/index/" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?

}
else{
	header("Location: /" . SID);
	exit;
}	
include_once H.'sys/inc/tfoot.php';
?>