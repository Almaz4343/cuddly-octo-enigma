<?

include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';

if(!isset($user)){
	header("Location: /" . SID);
	exit;
}

$set['title'] = 'Понравилось : Закладки : ' . $user['nick']; // заголовок страницы
include_once H.'sys/inc/thead.php';
title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  
<a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     
<span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $user['id']?>"><?= $user['nick']?></a> </span>     
<span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/bookmarks/?id=<?= $user['id']?>">Закладки</a> </span>  
<span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Понравилось</span> </span>  
</div>

<div class="tabs_block oh">    
<a href="/user/bookmarks/" class="tab_item left">  Закладки  </a>   
<a href="/user/bookmarks/index/" class="tab_item left">  Метки  </a>   
<div class="tab_item left tab_active black">  Понравилось  </div>   
</div>
<div class="wrapper wbg">
<?

/*********************/
/* ВЫВОД ВСЕГО СРАЗУ */
/*********************/
if (!isset($_GET['type'])){
?>
<div class="wrapper block">   
<span class="b grey">Все</span>   
<span class="service_links_block">|</span>   
<a href="/user/bookmarks/likes/?type=photo"> Фото   </a>  
<span class="service_links_block">|</span>     
<a href="/user/bookmarks/likes/?type=blog"> Блог   </a>      
</div>
<?

$set['p_str']  = '10';
$k_post = mysql_result(mysql_query("SELECT COUNT(id_object) FROM `bookmarks_like` WHERE `id_user` = '$user[id]'"),0);
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str']*$page-$set['p_str'];

if($k_post == 0){
?>
<div class="link"> Записи не найдены.  </div>
<?
}
else{

?>
<div class="list f-c_fll">
<?

$q = mysql_query("SELECT * FROM `bookmarks_like` WHERE `id_user` = '$user[id]' ORDER BY `time` DESC LIMIT $start,$set[p_str]");

while($post = mysql_fetch_assoc($q)){

if($post['type'] == 'blog'){
$diary = mysql_fetch_assoc(mysql_query("SELECT * FROM `notes` WHERE `id` = '$post[id_object]' LIMIT 1"));
?>
<div class="list_item"> <div class="bookmark">  
<span class="iwb">  <span style="display:inline-block;max-width:100%;" class="m oh diary_inline">   
<a class="arrow_link strong_link" href="/user/blogs/read/?id=<?= $diary['id']?>">  <span><?= text($diary['name'])?></span>  
</a>   
</span>   </span>  
</div>   </div>
<?
}elseif($post['type'] == 'photo'){
$photo = mysql_fetch_assoc(mysql_query("SELECT * FROM `gallery_foto` WHERE `id` = '$post[id_object]' LIMIT 1"));
?>
<div class="list_item"> 
<div class="bookmark">  
<div> 
<div class="list_item bookmark_block js-file_item oh">    
<div class="left font0 relative" style="margin-right:5px;">      
<a class="tdn gview_link" href="/foto/<?= $photo['id_user']?>/<?= $photo['id_gallery']?>/<?= $photo['id']?>/">   
<div class="inl_bl relative"> <img src="/foto/pic50/<?= $photo['id']?>.p.51.50.0.<?= $photo['ras']?>" alt="" class="preview">   </div>      
</a>         
</div>  
<div class="oh">   
<a href="/foto/<?= $photo['id_user']?>/<?= $photo['id_gallery']?>/<?= $photo['id']?>/" class="arrow_link strong_link">   
<img src="/style/i/icon_img_jpg.gif" alt="" class="m p16">  <span class="m"><?= text($photo['name'])?></span></a>
<span style="color:gray;" class="m">.<?= $photo['ras']?></span>         
<span class="file_size m"> <?= size_file(filesize(H.'sys/tpic/pictures/'.$photo['id'].'.0.jpg'))?> </span>     <br>     
<div class="clear"></div> 
</div> <div class="clear"></div>  </div>   
</div>  </div>   
</div>
<?
}

}

?>
</div>
<?
}

if ($k_page > 1)str("?",$k_page,$page); // Вывод страниц

}else

/**************/
/* Вывод фото */
/**************/

if (isset($_GET['type']) && $_GET['type'] == 'photo'){

?>
<div class="wrapper block">   
<a href="/user/bookmarks/likes/"> Все  </a>  
<span class="service_links_block">|</span>   
<span class="b grey"> Фото   </span> 
<span class="service_links_block">|</span>     
<a href="/user/bookmarks/likes/?type=blog"> Блог   </a>      
</div>
<?

$set['p_str']  = '10';
$k_post = mysql_result(mysql_query("SELECT COUNT(id_object) FROM `bookmarks_like` WHERE `id_user` = '$user[id]' AND `type` = 'photo'"),0);
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str']*$page-$set['p_str'];

if($k_post == 0){
?>
<div class="link"> Записи не найдены.  </div>
<?
}
else{

?>
<div class="list f-c_fll">
<?

$q = mysql_query("SELECT * FROM `bookmarks_like` WHERE `id_user` = '$user[id]' AND `type` = 'photo' ORDER BY `time` DESC LIMIT $start,$set[p_str]");

while($post = mysql_fetch_assoc($q)){

$photo = mysql_fetch_assoc(mysql_query("SELECT * FROM `gallery_foto` WHERE `id` = '$post[id_object]' LIMIT 1"));
?>
<div class="list_item"> 
<div class="bookmark">  
<div> 
<div class="list_item bookmark_block js-file_item oh">    
<div class="left font0 relative" style="margin-right:5px;">      
<a class="tdn gview_link" href="/foto/<?= $photo['id_user']?>/<?= $photo['id_gallery']?>/<?= $photo['id']?>/">   
<div class="inl_bl relative"> <img src="/foto/pic50/<?= $photo['id']?>.p.51.50.0.<?= $photo['ras']?>" alt="" class="preview">   </div>      
</a>         
</div>  
<div class="oh">   
<a href="/foto/<?= $photo['id_user']?>/<?= $photo['id_gallery']?>/<?= $photo['id']?>/" class="arrow_link strong_link">   
<img src="/style/i/icon_img_jpg.gif" alt="" class="m p16">  <span class="m"><?= text($photo['name'])?></span></a>
<span style="color:gray;" class="m">.<?= $photo['ras']?></span>         
<span class="file_size m"> <?= size_file(filesize(H.'sys/tpic/pictures/'.$photo['id'].'.0.jpg'))?> </span>     <br>     
<div class="clear"></div> 
</div> <div class="clear"></div>  </div>   
</div>  </div>   
</div>
<?

}

?>
</div>
<?
}

if ($k_page > 1)str("?type=photo&amp;",$k_page,$page); // Вывод страниц

}else

/**************/
/* Вывод блогов */
/**************/

if (isset($_GET['type']) && $_GET['type'] == 'blog'){

?>
<div class="wrapper block">   
<a href="/user/bookmarks/likes/"> Все  </a>  
<span class="service_links_block">|</span>   
<a href="/user/bookmarks/likes/?type=photo">  Фото  </a> 
<span class="service_links_block">|</span>     
<span class="b grey"> Блог   </span> 
</div>
<?

$set['p_str']  = '10';
$k_post = mysql_result(mysql_query("SELECT COUNT(id_object) FROM `bookmarks_like` WHERE `id_user` = '$user[id]' AND `type` = 'blog'"),0);
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str']*$page-$set['p_str'];

if($k_post == 0){
?>
<div class="link"> Записи не найдены.  </div>
<?
}
else{

?>
<div class="list f-c_fll">
<?

$q = mysql_query("SELECT * FROM `bookmarks_like` WHERE `id_user` = '$user[id]' AND `type` = 'blog' ORDER BY `time` DESC LIMIT $start,$set[p_str]");

while($post = mysql_fetch_assoc($q)){

$diary = mysql_fetch_assoc(mysql_query("SELECT * FROM `notes` WHERE `id` = '$post[id_object]' LIMIT 1"));
?>
<div class="list_item"> <div class="bookmark">  
<span class="iwb">  <span style="display:inline-block;max-width:100%;" class="m oh diary_inline">   
<a class="arrow_link strong_link" href="/user/blogs/read/?id=<?= $diary['id']?>">  <span><?= text($diary['name'])?></span>  
</a>   
</span>   </span>  
</div>   </div>
<?
}

?>
</div>
<?
}

if ($k_page > 1)str("?type=photo&amp;",$k_page,$page); // Вывод страниц

}







?>
</div>
<?


include_once H.'sys/inc/tfoot.php';
?>