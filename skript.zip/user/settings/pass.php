<?
include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/shif.php';
include_once H.'sys/inc/user.php';
only_reg();


if (isset($_POST['cfms'])){
 
if (isset($_POST['password']) && mysql_result(mysql_query("SELECT COUNT(*) FROM `user` WHERE `id` = $user[id] AND `pass` = '".shif($_POST['password'])."' LIMIT 1"), 0)==1)  
{  
if (isset($_POST['new_password']) && isset($_POST['repeat_new_password']))  
{  
if ($_POST['new_password']==$_POST['repeat_new_password'])  
{  
if (strlen2($_POST['new_password'])<6)$err='По соображениям безопасности новый пароль не может быть короче 6-ти символов';  
if (strlen2($_POST['new_password'])>32)$err='Длина пароля превышает 32 символа';  
}  
else $err='Новый пароль не совпадает с подтверждением.';  
}  
else $err='Введите новый пароль.';  
}  
else $err='Текущий пароль введен неверно! ';
 

 
if (!isset($err))  
{  
mysql_query("UPDATE `user` SET `pass` = '".shif($_POST['new_password'])."' WHERE `id` = '$user[id]' LIMIT 1");  
setcookie('password', cookie_encrypt($_POST['new_password'],$user['id']), time()+60*60*24*365);  
$_SESSION['message'] = 'Пароль успешно изменен';  
header("Location: /user/settings/?");  
exit;  
}
 
}


$set['title'] = ' Изменить пароль : Настройки : ' . $user['nick'];
include_once H.'sys/inc/thead.php';
title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="//c.spac.me/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $user['id']?>"><?= $user['nick']?></a> </span>    <span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/settings/">Настройки</a> </span>  <span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Изменить пароль</span> </span>       </div>
<?


err(); 


?>
<div class="list_item"> 
<form method="post" action="pass.php">  
<div> 
<label for="password"><b class="grey">Введите ваш текущий пароль:</b></label><br> 
<input name="password" size="20" maxlength="16" value="" id="password" style="width:35%;" type="password"> 
</div>  

<div class="pad_t_a"> 
<label for="new_password"><b class="grey">Введите новый пароль:</b></label><br> 
<input name="new_password" size="20" maxlength="16" value="" id="new_password" style="width:35%;" type="password"> 
</div> 

<div class="pad_t_a"> 
<label for="repeat_new_password"><b class="grey">Повторите новый пароль:</b></label><br> 
<input name="repeat_new_password" size="20" maxlength="16" value="" id="repeat_new_password" style="width:35%;" type="password"> 
</div>    

<div class="pad_t_a"> <input value="Сохранить" class="main_submit" name="cfms" type="submit"> </div> 

</form> 
</div>

<div class="list_item light_blue"> Используйте только латинские буквы и цифры.<br> Пароль должен содержать не менее 6 и не более 16 символов и состоять из латинских букв и цифр.<br> Пробелы недопустимы. </div>

<a href="/user/settings/?" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>

<?




include_once H.'sys/inc/tfoot.php';
?>