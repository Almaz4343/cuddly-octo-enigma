<?
include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';

only_reg();

$userSet = mysql_fetch_array(mysql_query("SELECT * FROM `user_set` WHERE `id_user` = '".$user['id']."' LIMIT 1"));



$set['title'] = 'Настройки приватности  : Настройки: ' . $user['nick'];
include_once H.'sys/inc/thead.php';
title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $user['id']?>"><?= $user['nick']?></a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/settings/">Настройки</a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Настройки приватности</span> </span>       </div>
<?

err();

if (isset($_GET['setting']) && $_GET['setting'] == 1)
{ 
if (isset($_POST['cfms'])){
if (isset($_POST['friends']) && ($_POST['friends']==0 || $_POST['friends']==1 || $_POST['friends']==2))
{
mysql_query("UPDATE `user_set` SET `privat_friend` = '".intval($_POST['friends'])."' WHERE `id_user` = '$user[id]'");
}
$_SESSION['message'] = 'Настройки сохранены.';
header('Location: ?');
exit;
}

?>
<div>  
<div> 
<form action="/user/settings/private.php?setting=1" method="post">  
<div>  
<div class="vlight_border_bottom stnd_padd pdb vlight_border_bottom"> 
<label class="lbl">Кто видит моих друзей:</label> 
</div> 
  
<div> 
<label for="am_na_63879239_21" class="t-block_item stnd_padd vlight_border_bottom"> 
<input name="friends" id="am_na_63879239_21" value="1" <?= ($userSet['privat_friend'] == 1 ? ' checked="checked"' : null)?> class="m" type="radio"> 
<img class="m p16" src="//c.spac.me/i/ico/ac_all_darkblue.png" alt="Все"> <span class="m">&nbsp;Все</span> 
</label> 
</div>   

<div> 
<label for="am_oo_63879239_21" class="t-block_item stnd_padd vlight_border_bottom"> 
<input name="friends" id="am_oo_63879239_21" value="0" <?= ($userSet['privat_friend'] == 0 ? ' checked="checked"' : null)?> class="m" type="radio"> 
<img class="m p16" src="//c.spac.me/i/ico/ac_user_red.png" alt="Только я"> <span class="m">&nbsp;Только я</span> 
</label> 
</div>   

<div> 
<label for="am_fo_63879239_21" class="t-block_item stnd_padd vlight_border_bottom"> 
<input name="friends" id="am_fo_63879239_21" value="2" class="m" <?= ($userSet['privat_friend'] == 2 ? ' checked="checked"' : null)?> type="radio"> 
<img class="m p16" src="//c.spac.me/i/ico/ac_friends_green.png" alt="Мои друзья"> <span class="m">&nbsp;Мои друзья</span> 
</label> 
</div>          

<!-- ПК и ТАЧИ --> 
</div>      
<div class="stnd_padd vlight_border_bottom"> 
<input name="cfms" value="Сохранить" class="main_submit" id="mainSubmitForm" type="submit">   
</div> 
</form> 
</div> 
</div>
<a href="/user/settings/private.php" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?

}

if (!isset($_GET['setting'])){
?>
<div>
<div class="stnd_padd vlight_border_bottom"> Кто видит моих друзей: 
<a href="/user/settings/private.php?setting=1" class="arrow_link">   
<?
if($userSet['privat_friend'] == 1){
?>
<img src="/style/i/status_all.png" alt="" class="m"> <span class="m">Все</span>
<?
}
elseif($userSet['privat_friend'] == 0){
?>
<img src="/style/i/status_me.png" alt="" class="m"> <span class="m">Только я</span>
<?
}   
elseif($userSet['privat_friend'] == 2){
?>
<img src="/style/i/status_friends.png" alt="" class="m"> <span class="m">Друзья</span>
<?
}
?>
</a> 
</div>
</div>
<a href="/user/settings/" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?
}
include_once H.'sys/inc/tfoot.php';
?>