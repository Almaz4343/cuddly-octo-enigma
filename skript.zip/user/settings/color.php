<?
include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';

only_reg();

$style = array(
'b26767','b28067','b29967','b2b267','99b267','80b267','67b267','67b280','67b299','67b2b2','6799b2','6780b2','6767b2','8067b2','9967b2','b267b2','b26799','b26780',
'4c4c4c','666666','7f7f7f','754444','755444','756444','757544','647544','547544','447544','447554','447564','447575','446475','445475','444475','544475','644475',
'754475','754464','754454','000000','191919','333333'
);


if (isset($_GET['cfms'])){
if(isset($_GET['set']) && $_GET['set'] < 42){

$st = intval($_GET['set']);
$user['panelka_st'] = $style[$st];
mysql_query("UPDATE `user` SET `panelka_st` = '".$user['panelka_st']."', `panelka` = '".$st."' WHERE `id` = '$user[id]' LIMIT 1");

header('Location: ?');
exit;
}
}

$set['title'] = 'Стиль панелей  : Настройки: ' . $user['nick'];
include_once H.'sys/inc/thead.php';
title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $user['id']?>"><?= $user['nick']?></a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/settings/">Настройки</a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Стиль панелей</span> </span>       </div>
<?

err();

?>
<div class="stnd_padd" style="padding-bottom:0;">Выберите цвет:</div>

<div class="stnd_padd oh light_border_bottom">

<div class="left" style="width:50%;"> 
<div style="padding-right:5px;">  
<?
for ($i = 0; $i <= 41; $i++){

?>
<div style="-webkit-border-radius: 6px; border-radius: 6px; background-color:#<?= $style[$i]?>; margin-bottom:10px;" class="oh"> 
<a href="?set=<?= $i?>&cfms" class="arrow_link" style="display:block; text-decoration:none; padding:5px;">
<div class="oh" style="height:19px; <?= ($user['panelka_st'] == $style[$i] ? 'background: url(/style/i/ok.png) center no-repeat;' : null)?>"></div>
</a> 
</div>  
<?= ($i == 20 ? '</div></div><div class="left" style="width:50%;"><div style="padding-left:5px;">' : null)?>
<?= ($i == 41 ? '</div></div>' : null)?>
<?
}

?>
</div>
<a href="/user/settings/" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?

include_once H.'sys/inc/tfoot.php';
?>