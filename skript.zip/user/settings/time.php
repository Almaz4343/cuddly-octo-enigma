<?
include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';

only_reg();


if (isset($_POST['cfms'])){
//Время вкл/выкл
if (isset($_POST['timestate']) && $_POST['timestate'] == 1){
mysql_query("UPDATE `user` SET `p_time` = '1' WHERE `id` = '$user[id]' LIMIT 1");
}
else{ 
mysql_query("UPDATE `user` SET `p_time` = '0' WHERE `id` = '$user[id]' LIMIT 1");
}
//Время
if (isset($_POST['timezone']) && (is_numeric($_POST['timezone']) && $_POST['timezone']>=-15 && $_POST['timezone']<=10))
{
$user['set_timesdvig'] = intval($_POST['timezone']);
mysql_query("UPDATE `user` SET `set_timesdvig` = '$user[set_timesdvig]' WHERE `id` = '$user[id]' LIMIT 1");
}
else $err='Ошибка! Неверный часовой пояс.';

if (!isset($err)){
$_SESSION['message'] = 'Изменения в настройках времени сохранены!';
header("Location: time.php"); 
exit;
}

}

$set['title'] = ' Время  : Настройки: ' . $user['nick'];
include_once H.'sys/inc/thead.php';
title();


?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $user['id']?>"><?= $user['nick']?></a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/settings/">Настройки</a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text"> Время</span> </span>       </div>
<?

err();


?>
<div class="stnd_padd light_border_bottom"> 
<form method="POST" action="/user/settings/time.php"> 
<div> 

<div> 
<label for="timestate">Отображать время:</label> 
<input name="timestate" id="timestate" value="1" <?=  ($user['p_time'] ? ' checked = "checked"' : null)?> type="checkbox"> 
</div> 

<div class="pad_t_a"> 
<label for="timezone">Часовой пояс:</label>
<select name="timezone" id="timezone">  
<?

for ($i=-15; $i<10; $i++){

if($i == -15){$timek = "-12:00";
}elseif($i == -14){$timek = "-11:00";
}elseif($i == -13){$timek = "-10:00";
}elseif($i == -12){$timek = "-09:00";
}elseif($i == -11){$timek = "-08:00";
}elseif($i == -10){$timek = "-07:00";
}elseif($i == -9){$timek = "-06:00";
}elseif($i == -8){$timek = "-05:00";
}elseif($i == -7){$timek = "-04:00";
}elseif($i == -6){$timek = "-03:00";
}elseif($i == -5){$timek = "-02:00";
}elseif($i == -4){$timek = "-01:00";
}elseif($i == -3){$timek = "00:00";
}elseif($i == -2){$timek = "+01:00";
}elseif($i == -1){$timek = "+02:00";
}elseif($i == 0){$timek = "+03:00   Москва";
}elseif($i == 1){$timek = "+04:00";
}elseif($i == 2){$timek = "+05:00";
}elseif($i == 3){$timek = "+06:00";
}elseif($i == 4){$timek = "+07:00";
}elseif($i == 5){$timek = "+08:00";
}elseif($i == 6){$timek = "+09:00";
}elseif($i == 7){$timek = "+10:00";
}elseif($i == 8){$timek = "+11:00";
}elseif($i == 9){$timek = "+12:00";
}
else{
$timek = date("G:i", $time+$i*60*60);
}

?>  
<option value="<?= $i?>" <?= ($user['set_timesdvig'] == $i ? " selected = 'selected'" : null)?>>  <?= $timek?>   </option> 
<?
}
?> 
</select>
</div> 

<div class="pad_t_a">  
<input value="Сохранить" class="main_submit" name="cfms" type="submit"> 
</div> 

</div> 
</form> 
</div>

<a href="/user/settings/" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?

include_once H.'sys/inc/tfoot.php';
?>