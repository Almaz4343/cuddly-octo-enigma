<?
include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';
only_reg();

if (isset($_GET['Fsize']) && $_GET['Fsize'] == '13') {
  	if (isset($user)) {
  	query("UPDATE `user` SET `user_shrift` = '0' WHERE `id` = '$user[id]' LIMIT 1");
  	$_SESSION['message'] = 'Вы успешно выбрали размер шрифта #13..';
  	header('Location: ?');
  	exit;
  	}
}if (isset($_GET['Fsize']) && $_GET['Fsize'] == '14') {
  	if (isset($user)) {
  	query("UPDATE `user` SET `user_shrift` = '1' WHERE `id` = '$user[id]' LIMIT 1");
  	$_SESSION['message'] = 'Вы успешно выбрали размер шрифта #14..';
  	header('Location: ?');
  	exit;
  	}
}if (isset($_GET['Fsize']) && $_GET['Fsize'] == '16') {
  	if (isset($user)) {
  	query("UPDATE `user` SET `user_shrift` = '2' WHERE `id` = '$user[id]' LIMIT 1");
  	$_SESSION['message'] = 'Вы успешно выбрали размер шрифта #16..';
  	header('Location: ?');
  	exit;
  	}
}if (isset($_GET['Fsize']) && $_GET['Fsize'] == '18') {
  	if (isset($user)) {
  	query("UPDATE `user` SET `user_shrift` = '3' WHERE `id` = '$user[id]' LIMIT 1");
  	$_SESSION['message'] = 'Вы успешно выбрали размер шрифта #18..';
  	header('Location: ?');
  	exit;
  	}
}if (isset($_GET['Fsize']) && $_GET['Fsize'] == '20') {
  	if (isset($user)) {
  	query("UPDATE `user` SET `user_shrift` = '4' WHERE `id` = '$user[id]' LIMIT 1");
  	$_SESSION['message'] = 'Вы успешно выбрали размер шрифта #20..';
  	header('Location: ?');
  	exit;
  	}
}if (isset($_GET['Fsize']) && $_GET['Fsize'] == '22') {
  	if (isset($user)) {
  	query("UPDATE `user` SET `user_shrift` = '5' WHERE `id` = '$user[id]' LIMIT 1");
  	$_SESSION['message'] = 'Вы успешно выбрали размер шрифта #22..';
  	header('Location: ?');
  	exit;
  	}
}if (isset($_GET['Fsize']) && $_GET['Fsize'] == '24') {
  	if (isset($user)) {
  	query("UPDATE `user` SET `user_shrift` = '6' WHERE `id` = '$user[id]' LIMIT 1");
  	$_SESSION['message'] = 'Вы успешно выбрали размер шрифта #24..';
  	header('Location: ?');
  	exit;
  	}
}

$set['title'] = 'Настройки : ' . $user['nick'];
include_once H.'sys/inc/thead.php';
title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="//c.spac.me/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $user['id']?>"><?= $user['nick']?></a> </span>     <span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Настройки</span> </span>       </div>

<div class="wrapper">
<div class="title oh black">    <span class="block-title">Основные настройки</span>     </div>
<div class="wbg grey">  <div class="list f-c_fll">

<a href="/user/settings/pass.php" class="link  darkblue  arrow    "> 
<span>          <span>  Изменить пароль </span>          </span>  
</a>

<a href="/user/settings/private.php" class="link -full  darkblue  arrow    "> 
<span>          <span>  Настройки приватности </span>          </span>  
</a>

<a href="/user/settings/mail.php" class="link  darkblue  arrow    "> 
<span>          <span>  Настройки почты </span>          </span>  
</a>


</div></div>
</div>


<div class="wrapper">
<div class="title oh black">    <span class="block-title">Настройки интерфейса</span>     </div>
<div class="wbg grey">  

<div class="list f-c_fll">

<a href="/user/settings/navi.php" class="link  darkblue  arrow    "> 
<span>          <span>  Нижняя панель </span>          </span>  
</a>

<a href="/user/settings/color.php" class="link  darkblue  arrow    "> 
<span>          <span>  Стиль панелей </span>          </span>  
</a>

<a href="/user/settings/time.php" class="link  darkblue  arrow    "> 
<span>          <span>  Время </span>          </span>  
</a>

<div class="block"> 
<div class="grey pad_b_a">Шрифт:</div>
<div> 
<span style="font-size:13px;" class="horiz_sep">         
<?=(($user['user_shrift'] == 0) ? '<span class="t b"> 13 </span>' : '<a href="?Fsize=13" class="inl-link  no_ajax"> 13 </a>')?>          
</span>
<span style="font-size:14px;" class="horiz_sep">   
<?=(($user['user_shrift'] == 1) ? '<span class="t b"> 14 </span>' : '<a href="?Fsize=14" class="inl-link  no_ajax"> 14 </a>')?> 
<!-- --><!-- --><!-- --><!-- -->
</span>
<span style="font-size:16px;" class="horiz_sep">   
<?=(($user['user_shrift'] == 2) ? '<span class="t b"> 16 </span>' : '<a href="?Fsize=16" class="inl-link  no_ajax"> 16 </a>')?> 
<!-- --><!-- --><!-- --><!-- -->
</span>
<span style="font-size:18px;" class="horiz_sep">   
<?=(($user['user_shrift'] == 3) ? '<span class="t b"> 18 </span>' : '<a href="?Fsize=18" class="inl-link  no_ajax"> 18 </a>')?> 
<!-- --><!-- --><!-- --><!-- -->
</span>
<span style="font-size:20px;" class="horiz_sep">   
<?=(($user['user_shrift'] == 4) ? '<span class="t b"> 20 </span>' : '<a href="?Fsize=20" class="inl-link  no_ajax"> 20 </a>')?> 
<!-- --><!-- --><!-- --><!-- -->
</span>
<span style="font-size:22px;" class="horiz_sep">   
<?=(($user['user_shrift'] == 5) ? '<span class="t b"> 22 </span>' : '<a href="?Fsize=22" class="inl-link  no_ajax"> 22 </a>')?> 
<!-- --><!-- --><!-- --><!-- -->
</span>
<span style="font-size:24px;" class="horiz_sep">   
<?=(($user['user_shrift'] == 6) ? '<span class="t b"> 24 </span>' : '<a href="?Fsize=24" class="inl-link  no_ajax"> 24 </a>')?> 
<!-- --><!-- --><!-- --><!-- -->
</span> 
</div> 
</div>

</div></div>
</div>

<div class="wrapper"> <div class="list f-c_fll">         
<a href="/exit.php" class="link  grey      "> 
<span><!--     --><img src="/style/i/ico/exit.png" alt="" class="m"> <!--   -->
<span class="m">Выйти со всех устройств</span>
<!--   --></span>  
</a>              
</div>    </div>

<a href="/user/?id=<?= $user['id']?>" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?







include_once H.'sys/inc/tfoot.php';
?>