<?
include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';

only_reg();

$set['title'] = 'Нижняя панель навигации  : Настройки: ' . $user['nick'];
include_once H.'sys/inc/thead.php';
title();

// Добавить
if(isset($_GET['add']))
{
$add_link  = "".intval($_GET['add'])."";
$link = mysql_fetch_array(mysql_query("SELECT * FROM `links_niz` WHERE `id` = '$add_link' LIMIT 1"));
if(mysql_result(mysql_query("SELECT COUNT(*) FROM `links_niz` WHERE `id` = '".$link['id']."' LIMIT 1"),0)!=0)
{
if(mysql_result(mysql_query("SELECT COUNT(*) FROM `links_niz_user` WHERE `id_link` = '".$link['id']."' AND `id_user` = '$user[id]' LIMIT 1"),0)==0)
{
$pos = mysql_result(mysql_query("SELECT MAX(`pos`) FROM `links_niz_user` WHERE `id_user` = '$user[id]'"), 0)+1;
mysql_query("INSERT INTO `links_niz_user` (`id_link`, `id_user`, `pos`) VALUES ('$link[id]', '$user[id]', '$pos')");
}
}
header("location: ?");
exit;
}
// Удалить
if(isset($_GET['del']))
{
$dell_link  = "".intval($_GET['del'])."";
$link1 = mysql_fetch_array(mysql_query("SELECT * FROM `links_niz_user` WHERE `id_link` = '$dell_link' AND `id_user` = '$user[id]' LIMIT 1"));
$links1 = mysql_query("SELECT * FROM `links_niz_user` WHERE `id_user` = '$user[id]' AND `pos` > '$link1[pos]' ORDER BY `pos` ASC");
while ($p = mysql_fetch_array($links1))
{
mysql_query("UPDATE `links_niz_user` SET `pos` = '".($p['pos']-1)."' WHERE `id` = '$p[id]' LIMIT 1");
}
mysql_query("DELETE FROM `links_niz_user` WHERE `id` = '$link1[id]' AND `id_user` = '$user[id]'");
header("location: ?");
exit;
}
// Выше
if (isset($_GET['up']))
{
$link=mysql_fetch_assoc(mysql_query("SELECT * FROM `links_niz_user` WHERE `id` = '".intval($_GET['up'])."' AND `id_user` = '$user[id]' LIMIT 1"));
if(mysql_result(mysql_query("SELECT COUNT(*) FROM `links_niz_user` WHERE `pos` < '$link[pos]' AND `id_user` = '$user[id]' LIMIT 1"),0)!=0)
{
mysql_query("UPDATE `links_niz_user` SET `pos` = '".($link['pos'])."' WHERE `pos` = '".($link['pos']-1)."' AND `id_user` = '$user[id]' LIMIT 1");
mysql_query("UPDATE `links_niz_user` SET `pos` = '".($link['pos']-1)."' WHERE `id` = '".intval($_GET['up'])."' AND `id_user` = '$user[id]' LIMIT 1");
$_SESSION['message'] = 'Успешно вверх!';
}
header("location: ?");
exit;
}
// Ниже
if (isset($_GET['down']))
{
$link=mysql_fetch_assoc(mysql_query("SELECT * FROM `links_niz_user` WHERE `id` = '".intval($_GET['down'])."' AND `id_user` = '$user[id]' LIMIT 1"));
if(mysql_result(mysql_query("SELECT COUNT(*) FROM `links_niz_user` WHERE `pos` > '$link[pos]' AND `id_user` = '$user[id]' LIMIT 1"),0)!=0)
{
mysql_query("UPDATE `links_niz_user` SET `pos` = '".($link['pos'])."' WHERE `pos` = '".($link['pos']+1)."' AND `id_user` = '$user[id]' LIMIT 1");
mysql_query("UPDATE `links_niz_user` SET `pos` = '".($link['pos']+1)."' WHERE `id` = '".intval($_GET['down'])."' AND `id_user` = '$user[id]' LIMIT 1");
$_SESSION['message'] = 'Успешно вниз!';
}else{
$_SESSION['message'] = '111111';
}
header("location: ?");
exit;
}


?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $user['id']?>"><?= $user['nick']?></a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/settings/">Настройки</a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Нижняя панель навигации</span> </span>       </div>
<?

err();

?>
<div class="stnd_padd vlight_border_bottom"> Здесь вы можете самостоятельно выбрать ссылки, которые отображаются на нижней панели. </div>
<div>
<?


/*
$links = mysql_query("SELECT * FROM `links_niz_user` WHERE `id_user` = '$user[id]' ORDER BY `id` ASC");
while ($post = mysql_fetch_array($links))
{
$link = mysql_fetch_array(mysql_query("SELECT * FROM `links_niz` WHERE `id` = '$post[id_link]' LIMIT 1"));


?>
<div class="stnd_padd vlight_border_bottom overfl_hid">   
<a href="?up=<?= $post['id']?>" class="left" style="margin-right:10px;">
<img src="/style/i/up.gif" alt="" class="p13">
</a> 
<a href="?down=<?= $post['id']?>" class="left" style="margin-right:10px;">
<img src="/style/i/down.gif" alt="" class="p13">
</a> 
<?
if ($link['id']==0){
?>
<a href="?add=<?= $post['id']?>" class="right"><img src="/style/i/lj.gif" alt="" class="m p16"></a>  
<div class="overfl_hid"><?= text($post['link_name'])?></div> 
<?
}else{
?>
<a href="?del=<?= $link['id']?>" class="right"><img src="/style/i/cross_r.gif" alt="" class="m p16"></a>  
<div class="overfl_hid"><?= text($link['name'])?></div> 
<?
}
?>
</div>
<?
}
*/
$links = mysql_query("SELECT * FROM `links_niz` ORDER BY `id` ASC");

while ($post = mysql_fetch_array($links))
{
if(mysql_result(mysql_query("SELECT COUNT(*) FROM `links_niz_user` WHERE `id_link` = '$post[id]' AND `id_user` = '$user[id]' ORDER BY `pos` ASC LIMIT 1"),0)==0)
{
?>
<div class="stnd_padd vlight_border_bottom overfl_hid">   
<a href="?add=<?= $post['id']?>" class="right"><img src="/style/i/lj.gif" alt="" class="m p16"></a>  
<div class="overfl_hid"><?= text($post['name'])?></div> 
</div>
<?
}else{
?>
<div class="stnd_padd vlight_border_bottom overfl_hid">   
<a href="?del=<?= $post['id']?>" class="right"><img src="/style/i/cross_r.gif" alt="" class="m p16"></a>  
<div class="overfl_hid"><?= text($post['name'])?></div> 
</div>
<?
}
}

?>
</div>
<div> 
<a href="/user/settings/color.php" class="t-block_item stnd_padd arrow_link vlight_border_bottom"> 
<i class="i red_item m" style="text-decoration:underline;">Настроить стиль панелей</i> 
</a> 
</div>
<a href="/user/settings/" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?

include_once H.'sys/inc/tfoot.php';
?>