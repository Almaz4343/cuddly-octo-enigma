<?
include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';
only_reg();

$userSet = mysql_fetch_array(mysql_query("SELECT * FROM `user_set` WHERE `id_user` = '".$user['id']."' LIMIT 1"));

if (isset($_POST['cfms'])){
 // Сообщения
if (isset($_POST['Access']) && ($_POST['Access']==0 || $_POST['Access']==1 || $_POST['Access']==2))
{
mysql_query("UPDATE `user_set` SET `privat_mail` = '".intval($_POST['Access'])."' WHERE `id_user` = '$user[id]'");
}

if (isset($_POST['Contacts_cnt']) && is_numeric($_POST['Contacts_cnt']) && $_POST['Contacts_cnt']>0 && $_POST['Contacts_cnt']<=30)
{
$user['set_p_maill'] = intval($_POST['Contacts_cnt']);
mysql_query("UPDATE `user` SET `set_p_maill` = '$user[set_p_maill]' WHERE `id` = '$user[id]' LIMIT 1");
}
else $err='Неправильное количество пунктов на страницу';


$_SESSION['message'] = 'Настройки почты успешно изменены. ';
header('Location: /konts.php');
exit;
}


$set['title'] = 'Настройки почты  : Настройки: ' . $user['nick'];
include_once H.'sys/inc/thead.php';
title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $user['id']?>"><?= $user['nick']?></a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/settings/">Настройки</a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Настройки почты</span> </span>       </div>
<?

err();

?>
<div class="wrapper">

<form action="?" method="post">
<div class="bord-botm">

<div class="block">  
<div>  
<label class="lbl">  Контактов на странице   (от 3 до 30): </label>   
<div class="input-txt_wrapper">  
<input class="input-txt" name="Contacts_cnt" value="<?= $user['set_p_maill']?>" maxlength="2" type="text">  
</div>   
</div>   </div>

<div class="block"> 
<label class="lbl">Писать в почту могут:</label>      
<label class="input-radio"> 
<input name="Access" id="Access0" value="1" <?= ($userSet['privat_mail'] == 1 ? ' checked="checked"' : null)?> type="radio">         
<img src="/style/i/mode_na.png" alt="" class="m">       <span class="m">  Все </span>           </label>   <br> 
<label class="input-radio"> 
<input name="Access" id="Access1" value="2" <?= ($userSet['privat_mail'] == 2 ? ' checked="checked"' : null)?> type="radio">         
<img src="/style/i/mode_fronl.png" alt="" class="m">      <span class="m">  Друзья </span>  </label>   <br> 
<label class="input-radio"> 
<input name="Access" id="Access2" value="0" <?= ($userSet['privat_mail'] == 0 ? ' checked="checked"' : null)?> type="radio">         
<img src="/style/i/mode_ownonl.png" alt="" class="m">       <span class="m">  Никто </span> </label>       
</div></div>
<table class="table__wrap table__links"> <tbody><tr> 
<td class="table__cell" width="50%"> <!-- --><!-- --><!-- --><!-- --><!-- -->
<button name="cfms" value="Сохранить" class="  link  blue full is_final    " id="cfms"><!--   -->
<img src="/style/i/ok_blue.png" alt="" class="m"> <!--   --><span class="m"> Сохранить</span><!-- --></button>
<!-- --><!-- --> </td> <td class="table__cell table__cell_last" width="50%">     
<a href="/konts.php" class="link          "> <span>Отменить</span>  </a>    </td> </tr> </tbody></table>
<?


?>
</form>
</div>
<?

include_once H.'sys/inc/tfoot.php';
?>