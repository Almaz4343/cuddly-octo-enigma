<?
include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';


if (isset($ank)){
	$ank['id'] = $ank['id'];
}
if (isset($_GET['id'])){
	$ank['id'] = intval($_GET['id']);
}

$ank = get_user($ank['id']);

if($user['level'] < 4){
if ($user['id'] != $ank['id']){
header("Location: /user/anketa/?id=$ank[id]");
exit;
}
}

// Если не определили юзера
if(!$ank || $ank['id'] == 0 || !isset($_GET['id'])){
$set['title'] = 'Ошибка';
include_once H.'sys/inc/thead.php';
title();
?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="//c.spac.me/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Ошибка</span> </span>       </div>
<div class="list_item">Пользователь не обнаружен</div>
<?
include_once H.'sys/inc/tfoot.php';
exit;
}


if (isset($_POST['cfms'])){

// Ориентация
if (isset($_POST['ank_orien']) && $_POST['ank_orien']==0)
{
$ank['ank_orien']=0;
mysql_query("UPDATE `user` SET `ank_orien` = '0' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['ank_orien']) && $_POST['ank_orien']==1)
{
$ank['ank_orien']=1;
mysql_query("UPDATE `user` SET `ank_orien` = '1' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['ank_orien']) && $_POST['ank_orien']==2)
{
$ank['ank_orien']=2;
mysql_query("UPDATE `user` SET `ank_orien` = '2' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['ank_orien']) && $_POST['ank_orien']==3)
{
$ank['ank_orien']=3;
mysql_query("UPDATE `user` SET `ank_orien` = '3' WHERE `id` = '$ank[id]' LIMIT 1");
}

// Цель знакомства
if (isset($_POST['ank_lov_1']) && $_POST['ank_lov_1']==1)
{
$ank['ank_lov_1']=1;
mysql_query("UPDATE `user` SET `ank_lov_1` = '1' WHERE `id` = '$ank[id]' LIMIT 1");
}
else
{
$ank['ank_lov_1']=0;
mysql_query("UPDATE `user` SET `ank_lov_1` = '0' WHERE `id` = '$ank[id]' LIMIT 1");
}
####
if (isset($_POST['ank_lov_2']) && $_POST['ank_lov_2']==1)
{
$ank['ank_lov_2']=1;
mysql_query("UPDATE `user` SET `ank_lov_2` = '1' WHERE `id` = '$ank[id]' LIMIT 1");
}
else
{
$ank['ank_lov_2']=0;
mysql_query("UPDATE `user` SET `ank_lov_2` = '0' WHERE `id` = '$ank[id]' LIMIT 1");
}
####
if (isset($_POST['ank_lov_3']) && $_POST['ank_lov_1']==1)
{
$ank['ank_lov_3']=1;
mysql_query("UPDATE `user` SET `ank_lov_3` = '1' WHERE `id` = '$ank[id]' LIMIT 1");
}
else
{
$ank['ank_lov_3']=0;
mysql_query("UPDATE `user` SET `ank_lov_3` = '0' WHERE `id` = '$ank[id]' LIMIT 1");
}
####
if (isset($_POST['ank_lov_4']) && $_POST['ank_lov_4']==1)
{
$ank['ank_lov_4']=1;
mysql_query("UPDATE `user` SET `ank_lov_4` = '1' WHERE `id` = '$ank[id]' LIMIT 1");
}
else
{
$ank['ank_lov_4']=0;
mysql_query("UPDATE `user` SET `ank_lov_4` = '0' WHERE `id` = '$ank[id]' LIMIT 1");
}
####
if (isset($_POST['ank_lov_5']) && $_POST['ank_lov_5']==1)
{
$ank['ank_lov_5']=1;
mysql_query("UPDATE `user` SET `ank_lov_5` = '1' WHERE `id` = '$ank[id]' LIMIT 1");
}
else
{
$ank['ank_lov_5']=0;
mysql_query("UPDATE `user` SET `ank_lov_5` = '0' WHERE `id` = '$ank[id]' LIMIT 1");
}
####
if (isset($_POST['ank_lov_6']) && $_POST['ank_lov_6']==1)
{
$ank['ank_lov_6']=1;
mysql_query("UPDATE `user` SET `ank_lov_6` = '1' WHERE `id` = '$ank[id]' LIMIT 1");
}
else
{
$ank['ank_lov_6']=0;
mysql_query("UPDATE `user` SET `ank_lov_6` = '0' WHERE `id` = '$ank[id]' LIMIT 1");
}
####
if (isset($_POST['ank_lov_7']) && $_POST['ank_lov_7']==1)
{
$ank['ank_lov_7']=1;
mysql_query("UPDATE `user` SET `ank_lov_7` = '1' WHERE `id` = '$ank[id]' LIMIT 1");
}
else
{
$ank['ank_lov_7']=0;
mysql_query("UPDATE `user` SET `ank_lov_7` = '0' WHERE `id` = '$ank[id]' LIMIT 1");
}
####
if (isset($_POST['ank_lov_8']) && $_POST['ank_lov_8']==1)
{
$ank['ank_lov_8']=1;
mysql_query("UPDATE `user` SET `ank_lov_8` = '1' WHERE `id` = '$ank[id]' LIMIT 1");
}
else
{
$ank['ank_lov_8']=0;
mysql_query("UPDATE `user` SET `ank_lov_8` = '0' WHERE `id` = '$ank[id]' LIMIT 1");
}

// Рост
if (isset($_POST['ank_rost']) && (intval($_POST['ank_rost']) && strlen($_POST['ank_rost'])>=1 && strlen($_POST['ank_rost'])<=4 || $_POST['ank_rost']==NULL))
{
$ank['ank_rost']=$_POST['ank_rost'];
if ($ank['ank_rost']==null)$ank['ank_rost']='null';
mysql_query("UPDATE `user` SET `ank_rost` = $ank[ank_rost] WHERE `id` = '$ank[id]' LIMIT 1");

if ($ank['ank_rost']=='null')$ank['ank_rost']=NULL;
}
else $err[]='Неверный формат роста';

//Вес
if (isset($_POST['ank_ves']) && (intval($_POST['ank_ves']) && strlen($_POST['ank_ves'])>=1 && strlen($_POST['ank_ves'])<=4 || $_POST['ank_ves']==NULL))
{
$ank['ank_ves']=$_POST['ank_ves'];
if ($ank['ank_ves']==null)$ank['ank_ves']='null';
mysql_query("UPDATE `user` SET `ank_ves` = $ank[ank_ves] WHERE `id` = '$ank[id]' LIMIT 1");

if ($ank['ank_ves']=='null')$ank['ank_ves']=NULL;
}
else $err[]='Неверный формат веса';

// Цвет глаз
if (isset($_POST['ank_cvet_glas']) && preg_match('#^([A-zА-я \-]*)$#ui', $_POST['ank_cvet_glas']))
{
$ank['ank_cvet_glas']=$_POST['ank_cvet_glas'];
mysql_query("UPDATE `user` SET `ank_cvet_glas` = '".my_esc($ank['ank_cvet_glas'])."' WHERE `id` = '$ank[id]' LIMIT 1");
}
else $err[]='Неверный формат цвет глаз';

// Волосы
if (isset($_POST['ank_volos']) && preg_match('#^([A-zА-я \-]*)$#ui', $_POST['ank_volos']))
{
$ank['ank_volos']=$_POST['ank_volos'];
mysql_query("UPDATE `user` SET `ank_volos` = '".my_esc($ank['ank_volos'])."' WHERE `id` = '$ank[id]' LIMIT 1");
}
else $err[]='Неверный формат цвет волос';

// Телосложение
if (isset($_POST['ank_telosl']) && $_POST['ank_telosl']==0)
{
$ank['ank_telosl']=0;
mysql_query("UPDATE `user` SET `ank_telosl` = '0' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['ank_telosl']) && $_POST['ank_telosl']==1)
{
$ank['ank_telosl']=1;
mysql_query("UPDATE `user` SET `ank_telosl` = '1' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['ank_telosl']) && $_POST['ank_telosl']==2)
{
$ank['ank_telosl']=2;
mysql_query("UPDATE `user` SET `ank_telosl` = '2' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['ank_telosl']) && $_POST['ank_telosl']==3)
{
$ank['ank_telosl']=3;
mysql_query("UPDATE `user` SET `ank_telosl` = '3' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['ank_telosl']) && $_POST['ank_telosl']==4)
{
$ank['ank_telosl']=4;
mysql_query("UPDATE `user` SET `ank_telosl` = '4' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['ank_telosl']) && $_POST['ank_telosl']==5)
{
$ank['ank_telosl']=5;
mysql_query("UPDATE `user` SET `ank_telosl` = '5' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['ank_telosl']) && $_POST['ank_telosl']==6)
{
$ank['ank_telosl']=6;
mysql_query("UPDATE `user` SET `ank_telosl` = '6' WHERE `id` = '$ank[id]' LIMIT 1");
}


// Характер
if (isset($_POST['ank_haracter']) && strlen2($_POST['ank_haracter'])<=512){
if (preg_match('#[^A-zА-я0-9 _\-\=\+\(\)\*\!\?\.,]#ui',$_POST['ank_haracter']))$err[]='В поле "Характер" используются запрещенные символы';
else {
$ank['ank_haracter'] = $_POST['ank_haracter'];
mysql_query("UPDATE `user` SET `ank_haracter` = '".my_esc($ank['ank_haracter'])."' WHERE `id` = '$ank[id]' LIMIT 1");
}
}
else $err[]='О характере нужно писать меньше :)';

// На теле есть
if (isset($_POST['ank_tatu']) && $_POST['ank_tatu']==1)
{
$ank['ank_tatu']=1;
mysql_query("UPDATE `user` SET `ank_tatu` = '1' WHERE `id` = '$ank[id]' LIMIT 1");
}
else
{
$ank['ank_tatu']=0;
mysql_query("UPDATE `user` SET `ank_tatu` = '0' WHERE `id` = '$ank[id]' LIMIT 1");
}
###
if (isset($_POST['ank_pirs']) && $_POST['ank_pirs']==1)
{
$ank['ank_pirs']=1;
mysql_query("UPDATE `user` SET `ank_pirs` = '1' WHERE `id` = '$ank[id]' LIMIT 1");
}
else
{
$ank['ank_pirs']=0;
mysql_query("UPDATE `user` SET `ank_pirs` = '0' WHERE `id` = '$ank[id]' LIMIT 1");
}


// О партнере
if (isset($_POST['ank_o_par']) && strlen2($_POST['ank_o_par'])<=215)
{

if (preg_match('#[^A-zА-я0-9 _\-\=\+\(\)\*\!\?\.,]#ui',$_POST['ank_o_par']))$err[]='В поле "О партнере" используются запрещенные символы';
else {
$ank['ank_o_par']=$_POST['ank_o_par'];
mysql_query("UPDATE `user` SET `ank_o_par` = '".my_esc($ank['ank_o_par'])."' WHERE `id` = '$ank[id]' LIMIT 1");
}
}
else $err[]='О партнере нужно писать меньше :)';

if (!isset($err)){
$_SESSION['message'] = 'Изменения сохранены. ';
header("Location: /user/anketa/?id=$ank[id]");
exit;
}

}

$set['title'] = "Для знакомств : Анкета : " . $ank['nick'];
include_once H.'sys/inc/thead.php';
title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="//c.spac.me/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $ank['id']?>"><?= $ank['nick']?></a> </span>    <span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/anketa/?id=<?= $ank['id']?>">Анкета</a> </span>     <span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Для знакомств</span> </span>       </div>
<?

err();


?>
<form method="post" action="/user/anketa/edit/love.php?id=<?= $ank['id']?>">
<div class="wrapper"> 

<div class="bord-botm pad_b_a">    

<div class="stnd_padd"><b>Знакомства</b></div>

<div class="stnd_padd"> 
<label><b class="grey">Ориентация:</b></label><br>      
<label class="input-radio"> <input name="ank_orien" id="ank_orien1" <?= ($ank['ank_orien']==1?' checked="checked"':null)?> value="1" type="radio"> Гетеро </label>   <br> 
<label class="input-radio"> <input name="ank_orien" id="ank_orien3" <?= ($ank['ank_orien']==3?' checked="checked"':null)?> value="3" type="radio"> <?= ($ank['pol']==1? 'Гей':'Лесби')?> </label>   <br> 
<label class="input-radio"> <input name="ank_orien" id="ank_orien2" <?= ($ank['ank_orien']==2?' checked="checked"':null)?> value="2" type="radio"> Би </label>   <br> 
<label class="input-radio"> <input name="ank_orien" id="ank_orien0" <?= ($ank['ank_orien']==0?' checked="checked"':null)?> value="0" type="radio"> Не важно </label>       
</div>

<div class="stnd_padd"> 
<label><b class="grey">Цель знакомства:</b></label><br>      
<label> <input name="ank_lov_1" id="ank_lov_1" <?= ($ank['ank_lov_1']==1?' checked="checked"':null)?> value="1" type="checkbox"> Дружба и общение</label>  <br> 
<label> <input name="ank_lov_2" id="ank_lov_2" <?= ($ank['ank_lov_2']==1?' checked="checked"':null)?> value="1" type="checkbox"> Флирт, СМС-переписка</label>  <br> 
<label> <input name="ank_lov_3" id="ank_lov_3" <?= ($ank['ank_lov_3']==1?' checked="checked"':null)?> value="1" type="checkbox"> Любовь, отношения</label>  <br> 
<label> <input name="ank_lov_4" id="ank_lov_4" <?= ($ank['ank_lov_4']==1?' checked="checked"':null)?> value="1" type="checkbox"> Брак, создание семьи</label>  <br> 
<label> <input name="ank_lov_5" id="ank_lov_5" <?= ($ank['ank_lov_5']==1?' checked="checked"':null)?> value="1" type="checkbox"> Виртуальный секс</label>  <br> 
<label> <input name="ank_lov_6" id="ank_lov_6" <?= ($ank['ank_lov_6']==1?' checked="checked"':null)?> value="1" type="checkbox"> Секс в реале</label>  <br> 
<label> <input name="ank_lov_7" id="ank_lov_7" <?= ($ank['ank_lov_7']==1?' checked="checked"':null)?> value="1" type="checkbox"> Ищу спонсора</label>  <br> 
<label> <input name="ank_lov_8" id="ank_lov_8" <?= ($ank['ank_lov_8']==1?' checked="checked"':null)?> value="1" type="checkbox"> Стану спонсором</label>    
</div>
<?

if($ank['ank_rost'] == 0){$rostik = '';}else{$rostik = ''.$ank['ank_rost'].'';}
if($ank['ank_ves'] == 0){$rostikves = '';}else{$rostikves = ''.$ank['ank_ves'].'';}

?>
<div class="stnd_padd"> 
<label><b class="grey">Рост:</b></label><br>  
<div>   <div class="input-txt_wrapper">  <input class="input-txt" name="ank_rost" value="<?= $rostik?>" type="text">  </div>   </div>   
</div>

<div class="stnd_padd"> 
<label><b class="grey">Вес:</b></label><br>  
<div>   <div class="input-txt_wrapper">  <input class="input-txt" name="ank_ves" value="<?= $rostikves?>" type="text">  </div>   </div>   
</div>

<div class="stnd_padd"> 
<label><b class="grey">Цвет глаз:</b></label><br>  
<div>   <div class="input-txt_wrapper">  
<input class="input-txt" name="ank_cvet_glas" value="<?= text($ank['ank_cvet_glas'])?>" maxlength="20" type="text">  
</div>   </div>   
</div>

<div class="stnd_padd"> 
<label><b class="grey">Цвет волос:</b></label><br>  
<div>   <div class="input-txt_wrapper">  
<input class="input-txt" name="ank_volos" value="<?= text($ank['ank_volos'])?>" maxlength="20" type="text">  
</div>   </div>   
</div>

<div class="stnd_padd"> 
<label><b class="grey">Телосложение:</b></label><br>      
<label class="input-radio"> <input name="ank_telosl" id="ank_telosl0" <?= ($ank['ank_telosl']==0?' checked="checked"':null)?> value="0" type="radio"> Не важно </label>   <br> 
<label class="input-radio"> <input name="ank_telosl" id="ank_telosl1" <?= ($ank['ank_telosl']==1?' checked="checked"':null)?> value="1" type="radio"> Обычное </label>   <br> 
<label class="input-radio"> <input name="ank_telosl" id="ank_telosl2" <?= ($ank['ank_telosl']==2?' checked="checked"':null)?> value="2" type="radio"> Худощавое </label>   <br> 
<label class="input-radio"> <input name="ank_telosl" id="ank_telosl3" <?= ($ank['ank_telosl']==3?' checked="checked"':null)?> value="3" type="radio"> Спортивное </label>   <br> 
<label class="input-radio"> <input name="ank_telosl" id="ank_telosl4" <?= ($ank['ank_telosl']==4?' checked="checked"':null)?> value="4" type="radio"> Мускулистое </label>   <br> 
<label class="input-radio"> <input name="ank_telosl" id="ank_telosl5" <?= ($ank['ank_telosl']==5?' checked="checked"':null)?> value="5" type="radio"> Плотное </label>   <br> 
<label class="input-radio"> <input name="ank_telosl" id="ank_telosl6" <?= ($ank['ank_telosl']==6?' checked="checked"':null)?> value="6" type="radio"> Полное </label>       
</div>

<div class="stnd_padd"> 
<label><b class="grey">Характер:</b></label><br>  
<div>   
<div class="input-txt_wrapper">  <input class="input-txt" name="ank_haracter" value="<?= text($ank['ank_haracter'])?>" maxlength="20" type="text">  </div>   
</div>   
</div>

<div class="stnd_padd"> 
<label><b class="grey">На теле есть:</b></label><br>      
<label> <input name="ank_pirs" id="ank_pirs" <?= ($ank['ank_pirs']==1?' checked="checked"':null)?> value="1" type="checkbox"> Пирсинг</label>  <br> 
<label> <input name="ank_tatu" id="ank_tatu" <?= ($ank['ank_tatu']==1?' checked="checked"':null)?> value="1" type="checkbox"> Татуировки</label>    
</div>

<div class="stnd_padd"> 
<label><b class="grey">О желаемом партнере:</b></label><br>  <div>   
<div class="input-txt_wrapper">  <input class="input-txt" name="ank_o_par" value="<?= text($ank['ank_o_par'])?>" maxlength="300" type="text">  </div>   
</div>   </div>

</div> 

<table class="table__wrap"> <tbody><tr> 
<td class="table__cell" width="50%"> 
<input class="link blue full is_final" name="cfms" value="Сохранить" type="submit"> 
</td> 
<td class="table__cell table__cell_last" width="50%">     
<a href="/user/anketa/?id=<?= $ank['id']?>" class="link          "> <span>Отменить</span>  </a>    
</td> 
</tr> </tbody></table>   

</div>
</form>
<?



include_once H.'sys/inc/tfoot.php';
?>