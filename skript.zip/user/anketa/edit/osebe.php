<?
include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';


if (isset($ank)){
	$ank['id'] = $ank['id'];
}
if (isset($_GET['id'])){
	$ank['id'] = intval($_GET['id']);
}

$ank = get_user($ank['id']);

if($user['level'] < 4){
if ($user['id'] != $ank['id']){
header("Location: /user/anketa/?id=$ank[id]");
exit;
}
}

// Если не определили юзера
if(!$ank || $ank['id'] == 0 || !isset($_GET['id'])){
$set['title'] = 'Ошибка';
include_once H.'sys/inc/thead.php';
title();
?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="//c.spac.me/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Ошибка</span> </span>       </div>
<div class="list_item">Пользователь не обнаружен</div>
<?
include_once H.'sys/inc/tfoot.php';
exit;
}

if (isset($_POST['cfms'])){

// О себе
if (isset($_POST['ank_o_sebe']) && strlen2($_POST['ank_o_sebe'])<=512){
if (preg_match('#[^A-zА-я0-9 _\-\=\+\(\)\*\!\?\.,]#ui',$_POST['ank_o_sebe']))$err[]='В поле "О себе" используются запрещенные символы';
else {
$ank['ank_o_sebe'] = $_POST['ank_o_sebe'];
mysql_query("UPDATE `user` SET `ank_o_sebe` = '".my_esc($ank['ank_o_sebe'])."' WHERE `id` = '$ank[id]' LIMIT 1");
}
}
else $err[]='О себе нужно писать меньше :)';

// Интересы
if (isset($_POST['ank_interes']) && strlen2($_POST['ank_interes'])<=512){
if (preg_match('#[^A-zА-я0-9 _\-\=\+\(\)\*\!\?\.,]#ui',$_POST['ank_interes']))$err[]='В поле "Интересы" используются запрещенные символы';
else {
$ank['ank_interes'] = $_POST['ank_interes'];
mysql_query("UPDATE `user` SET `ank_interes` = '".my_esc($ank['ank_interes'])."' WHERE `id` = '$ank[id]' LIMIT 1");
}
}
else $err[]='О интересах нужно писать меньше :)';

// Музыка
if (isset($_POST['ank_music']) && strlen2($_POST['ank_music'])<=512){
if (preg_match('#[^A-zА-я0-9 _\-\=\+\(\)\*\!\?\.,]#ui',$_POST['ank_music']))$err[]='В поле "Музыка" используются запрещенные символы';
else {
$ank['ank_music'] = $_POST['ank_music'];
mysql_query("UPDATE `user` SET `ank_music` = '".my_esc($ank['ank_music'])."' WHERE `id` = '$ank[id]' LIMIT 1");
}
}
else $err[]='О музыке нужно писать меньше :)';

// Фильмы
if (isset($_POST['ank_film']) && strlen2($_POST['ank_film'])<=512){
if (preg_match('#[^A-zА-я0-9 _\-\=\+\(\)\*\!\?\.,]#ui',$_POST['ank_film']))$err[]='В поле "Фильмы" используются запрещенные символы';
else {
$ank['ank_film'] = $_POST['ank_film'];
mysql_query("UPDATE `user` SET `ank_film` = '".my_esc($ank['ank_film'])."' WHERE `id` = '$ank[id]' LIMIT 1");
}
}
else $err[]='О фильмах нужно писать меньше :)';

// Сериалы
if (isset($_POST['ank_serial']) && strlen2($_POST['ank_serial'])<=512){
if (preg_match('#[^A-zА-я0-9 _\-\=\+\(\)\*\!\?\.,]#ui',$_POST['ank_serial']))$err[]='В поле "Сериалы" используются запрещенные символы';
else {
$ank['ank_serial'] = $_POST['ank_serial'];
mysql_query("UPDATE `user` SET `ank_serial` = '".my_esc($ank['ank_serial'])."' WHERE `id` = '$ank[id]' LIMIT 1");
}
}
else $err[]='О сериалах нужно писать меньше :)';

// Книги
if (isset($_POST['ank_book']) && strlen2($_POST['ank_book'])<=512){
if (preg_match('#[^A-zА-я0-9 _\-\=\+\(\)\*\!\?\.,]#ui',$_POST['ank_book']))$err[]='В поле "Книги" используются запрещенные символы';
else {
$ank['ank_book'] = $_POST['ank_book'];
mysql_query("UPDATE `user` SET `ank_book` = '".my_esc($ank['ank_book'])."' WHERE `id` = '$ank[id]' LIMIT 1");
}
}
else $err[]='О книгах нужно писать меньше :)';

// Цитаты
if (isset($_POST['ank_citat']) && strlen2($_POST['ank_citat'])<=512){
if (preg_match('#[^A-zА-я0-9 _\-\=\+\(\)\*\!\?\.,]#ui',$_POST['ank_citat']))$err[]='В поле "Цитаты" используются запрещенные символы';
else {
$ank['ank_citat'] = $_POST['ank_citat'];
mysql_query("UPDATE `user` SET `ank_citat` = '".my_esc($ank['ank_citat'])."' WHERE `id` = '$ank[id]' LIMIT 1");
}
}
else $err[]='О цитатах нужно писать меньше :)';

// Политические взгляды
if (isset($_POST['polit_vzg']) && $_POST['polit_vzg']==0)
{
$ank['polit_vzg']=0;
mysql_query("UPDATE `user` SET `polit_vzg` = '0' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['polit_vzg']) && $_POST['polit_vzg']==1)
{
$ank['polit_vzg']=1;
mysql_query("UPDATE `user` SET `polit_vzg` = '1' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['polit_vzg']) && $_POST['polit_vzg']==2)
{
$ank['polit_vzg']=2;
mysql_query("UPDATE `user` SET `polit_vzg` = '2' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['polit_vzg']) && $_POST['polit_vzg']==3)
{
$ank['polit_vzg']=3;
mysql_query("UPDATE `user` SET `polit_vzg` = '3' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['polit_vzg']) && $_POST['polit_vzg']==4)
{
$ank['polit_vzg']=4;
mysql_query("UPDATE `user` SET `polit_vzg` = '4' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['polit_vzg']) && $_POST['polit_vzg']==5)
{
$ank['polit_vzg']=5;
mysql_query("UPDATE `user` SET `polit_vzg` = '5' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['polit_vzg']) && $_POST['polit_vzg']==6)
{
$ank['polit_vzg']=6;
mysql_query("UPDATE `user` SET `polit_vzg` = '6' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['polit_vzg']) && $_POST['polit_vzg']==7)
{
$ank['polit_vzg']=7;
mysql_query("UPDATE `user` SET `polit_vzg` = '7' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['polit_vzg']) && $_POST['polit_vzg']==8)
{
$ank['polit_vzg']=8;
mysql_query("UPDATE `user` SET `polit_vzg` = '8' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['polit_vzg']) && $_POST['polit_vzg']==9)
{
$ank['polit_vzg']=9;
mysql_query("UPDATE `user` SET `polit_vzg` = '9' WHERE `id` = '$ank[id]' LIMIT 1");
}

// Мировоззрение
if (isset($_POST['ank_mirovozr']) && $_POST['ank_mirovozr']==0)
{
$ank['ank_mirovozr']=0;
mysql_query("UPDATE `user` SET `ank_mirovozr` = '0' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['ank_mirovozr']) && $_POST['ank_mirovozr']==1)
{
$ank['ank_mirovozr']=1;
mysql_query("UPDATE `user` SET `ank_mirovozr` = '1' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['ank_mirovozr']) && $_POST['ank_mirovozr']==2)
{
$ank['ank_mirovozr']=2;
mysql_query("UPDATE `user` SET `ank_mirovozr` = '2' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['ank_mirovozr']) && $_POST['ank_mirovozr']==3)
{
$ank['ank_mirovozr']=3;
mysql_query("UPDATE `user` SET `ank_mirovozr` = '3' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['ank_mirovozr']) && $_POST['ank_mirovozr']==4)
{
$ank['ank_mirovozr']=4;
mysql_query("UPDATE `user` SET `ank_mirovozr` = '4' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['ank_mirovozr']) && $_POST['ank_mirovozr']==5)
{
$ank['ank_mirovozr']=5;
mysql_query("UPDATE `user` SET `ank_mirovozr` = '5' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['ank_mirovozr']) && $_POST['ank_mirovozr']==6)
{
$ank['ank_mirovozr']=6;
mysql_query("UPDATE `user` SET `ank_mirovozr` = '6' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['ank_mirovozr']) && $_POST['ank_mirovozr']==7)
{
$ank['ank_mirovozr']=7;
mysql_query("UPDATE `user` SET `ank_mirovozr` = '7' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['ank_mirovozr']) && $_POST['ank_mirovozr']==8)
{
$ank['ank_mirovozr']=8;
mysql_query("UPDATE `user` SET `ank_mirovozr` = '8' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['ank_mirovozr']) && $_POST['ank_mirovozr']==9)
{
$ank['ank_mirovozr']=9;
mysql_query("UPDATE `user` SET `ank_mirovozr` = '9' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['ank_mirovozr']) && $_POST['ank_mirovozr']==10)
{
$ank['ank_mirovozr']=10;
mysql_query("UPDATE `user` SET `ank_mirovozr` = '10' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['ank_mirovozr']) && $_POST['ank_mirovozr']==11)
{
$ank['ank_mirovozr']=11;
mysql_query("UPDATE `user` SET `ank_mirovozr` = '11' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['ank_mirovozr']) && $_POST['ank_mirovozr']==12)
{
$ank['ank_mirovozr']=12;
mysql_query("UPDATE `user` SET `ank_mirovozr` = '12' WHERE `id` = '$ank[id]' LIMIT 1");
}

// Курение
if (isset($_POST['ank_smok']) && $_POST['ank_smok']==0)
{
$ank['ank_smok']=0;
mysql_query("UPDATE `user` SET `ank_smok` = '0' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['ank_smok']) && $_POST['ank_smok']==1)
{
$ank['ank_smok']=1;
mysql_query("UPDATE `user` SET `ank_smok` = '1' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['ank_smok']) && $_POST['ank_smok']==2)
{
$ank['ank_smok']=2;
mysql_query("UPDATE `user` SET `ank_smok` = '2' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['ank_smok']) && $_POST['ank_smok']==3)
{
$ank['ank_smok']=3;
mysql_query("UPDATE `user` SET `ank_smok` = '3' WHERE `id` = '$ank[id]' LIMIT 1");
}

// Алкоголь
if (isset($_POST['ank_alko_n']) && $_POST['ank_alko_n'] == 0){
$ank['ank_alko_n'] = 0;
mysql_query("UPDATE `user` SET `ank_alko_n` = '0' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['ank_alko_n']) && $_POST['ank_alko_n'] == 1){
$ank['ank_alko_n'] = 1;
mysql_query("UPDATE `user` SET `ank_alko_n` = '1' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['ank_alko_n']) && $_POST['ank_alko_n'] == 2){
$ank['ank_alko_n'] = 2;
mysql_query("UPDATE `user` SET `ank_alko_n` = '2' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['ank_alko_n']) && $_POST['ank_alko_n'] == 3){
$ank['ank_alko_n'] = 3;
mysql_query("UPDATE `user` SET `ank_alko_n` = '3' WHERE `id` = '$ank[id]' LIMIT 1");
}




if (!isset($err)){
$_SESSION['message'] = 'Изменения сохранены. ';
header("Location: /user/anketa/?id=$ank[id]");
exit;
}

}

$set['title'] = "О себе : Анкета : " . $ank['nick'];
include_once H.'sys/inc/thead.php';
title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="//c.spac.me/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $ank['id']?>"><?= $ank['nick']?></a> </span>    <span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/anketa/?id=<?= $ank['id']?>">Анкета</a> </span>     <span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">О себе</span> </span>       </div>
<?

err();



?>
<form method="post" action="/user/anketa/edit/osebe.php?id=<?= $ank['id']?>">  
<div class="wrapper"> 

<div class="bord-botm pad_b_a">    

<div class="stnd_padd"><b>О себе</b></div> 

<div class="stnd_padd">  <div>   
<div class="input-txt_wrapper">  
<textarea placeholder="Введите информацию о себе" class="input-txt" rows="5" cols="17" name="ank_o_sebe" maxlength="512"><?= text($ank['ank_o_sebe'])?></textarea>  
</div>   
</div>   </div> 

<div class="stnd_padd"> 
<label><b class="grey">Интересы:</b></label><br>   
<div> <div class="input-txt_wrapper"> 
<textarea class="input-txt" rows="5" cols="17" name="ank_interes"  maxlength="512"><?= text($ank['ank_interes'])?></textarea> 
</div>  </div>    
</div> 

<div class="stnd_padd"> 
<label><b class="grey">Любимая музыка:</b></label><br>  
<div>   <div class="input-txt_wrapper">  
<textarea placeholder="Введите информацию о любимой музыке" class="input-txt" rows="5" cols="17" name="ank_music" maxlength="512"><?= text($ank['ank_music'])?></textarea>  
</div>   </div>   
</div> 

<div class="stnd_padd"> 
<label><b class="grey">Любимые фильмы:</b></label><br>   
<div> <div class="input-txt_wrapper"> 
<textarea class="input-txt" maxlength="512" rows="5" cols="17" name="ank_film"><?= text($ank['ank_film'])?></textarea> 
</div>  </div>    
</div> 

<div class="stnd_padd"> 
<label><b class="grey">Любимые сериалы:</b></label><br>   
<div> <div class="input-txt_wrapper"> 
<textarea class="input-txt" maxlength="512" rows="5" cols="17" name="ank_serial"><?= text($ank['ank_interes'])?></textarea> 
</div>  </div>    
</div> 

<div class="stnd_padd"> 
<label><b class="grey">Любимые книги:</b></label><br>   
<div> <div class="input-txt_wrapper"> 
<textarea class="input-txt" maxlength="512" rows="5" cols="17" name="ank_book"><?= text($ank['ank_book'])?></textarea> 
</div>  </div>    
</div> 

<div class="stnd_padd light_border_bottom"> 
<label><b class="grey">Любимые цитаты:</b></label><br>  
<div>   <div class="input-txt_wrapper">  
<textarea placeholder="Введите информацию о любимых цитатах" class="input-txt" rows="5" cols="17" name="ank_citat" maxlength="512"><?= text($ank['ank_citat'])?></textarea>  
</div>   </div>   
</div> 

<div class="stnd_padd light_border_bottom"> 
<label><b class="grey">Политические взгляды:</b></label><br>      
<label class="input-radio"> <input name="polit_vzg" id="polit_vzg0" value="0" <?= ($ank['polit_vzg'] == 0 ? 'checked="checked"' : null)?> type="radio"> Не важно </label>   <br> 
<label class="input-radio"> <input name="polit_vzg" id="polit_vzg1" value="1" <?= ($ank['polit_vzg'] == 1 ? 'checked="checked"' : null)?> type="radio"> Индифферентные </label>   <br> 
<label class="input-radio"> <input name="polit_vzg" id="polit_vzg2" value="2" <?= ($ank['polit_vzg'] == 2 ? 'checked="checked"' : null)?> type="radio"> Коммунистические </label>   <br> 
<label class="input-radio"> <input name="polit_vzg" id="polit_vzg3" value="3" <?= ($ank['polit_vzg'] == 3 ? 'checked="checked"' : null)?> type="radio"> Социалистические </label>   <br> 
<label class="input-radio"> <input name="polit_vzg" id="polit_vzg4" value="4" <?= ($ank['polit_vzg'] == 4 ? 'checked="checked"' : null)?> type="radio"> Умеренные </label>   <br> 
<label class="input-radio"> <input name="polit_vzg" id="polit_vzg5" value="5" <?= ($ank['polit_vzg'] == 5 ? 'checked="checked"' : null)?> type="radio"> Либеральные </label>   <br> 
<label class="input-radio"> <input name="polit_vzg" id="polit_vzg6" value="6" <?= ($ank['polit_vzg'] == 6 ? 'checked="checked"' : null)?> type="radio"> Консервативные </label>   <br> 
<label class="input-radio"> <input name="polit_vzg" id="polit_vzg7" value="7" <?= ($ank['polit_vzg'] == 7 ? 'checked="checked"' : null)?> type="radio"> Монархические </label>   <br> 
<label class="input-radio"> <input name="polit_vzg" id="polit_vzg8" value="8" <?= ($ank['polit_vzg'] == 8 ? 'checked="checked"' : null)?> type="radio"> Ультраконсервативные </label>   <br> 
<label class="input-radio"> <input name="polit_vzg" id="polit_vzg9" value="9" <?= ($ank['polit_vzg'] == 9 ? 'checked="checked"' : null)?> type="radio"> Либертарианские </label>       
</div> 

<div class="stnd_padd light_border_bottom"> 
<label><b class="grey">Мировоззрение:</b></label><br>      
<label class="input-radio"> <input name="ank_mirovozr" id="ank_mirovozr0" value="0" <?= ($ank['ank_mirovozr'] == 0 ? 'checked="checked"' : null)?> type="radio"> Не важно </label>   <br> 
<label class="input-radio"> <input name="ank_mirovozr" id="ank_mirovozr1" value="1" <?= ($ank['ank_mirovozr'] == 1 ? 'checked="checked"' : null)?> type="radio"> Православие </label>   <br> 
<label class="input-radio"> <input name="ank_mirovozr" id="ank_mirovozr2" value="2" <?= ($ank['ank_mirovozr'] == 2 ? 'checked="checked"' : null)?> type="radio"> Католицизм </label>   <br> 
<label class="input-radio"> <input name="ank_mirovozr" id="ank_mirovozr3" value="3" <?= ($ank['ank_mirovozr'] == 3 ? 'checked="checked"' : null)?> type="radio"> Иудаизм </label>   <br> 
<label class="input-radio"> <input name="ank_mirovozr" id="ank_mirovozr4" value="4" <?= ($ank['ank_mirovozr'] == 4 ? 'checked="checked"' : null)?> type="radio"> Протестантизм </label>   <br> 
<label class="input-radio"> <input name="ank_mirovozr" id="ank_mirovozr5" value="5" <?= ($ank['ank_mirovozr'] == 5 ? 'checked="checked"' : null)?> type="radio"> Ислам </label>   <br> 
<label class="input-radio"> <input name="ank_mirovozr" id="ank_mirovozr6" value="6" <?= ($ank['ank_mirovozr'] == 6 ? 'checked="checked"' : null)?> type="radio"> Буддизм </label>   <br> 
<label class="input-radio"> <input name="ank_mirovozr" id="ank_mirovozr7" value="7" <?= ($ank['ank_mirovozr'] == 7 ? 'checked="checked"' : null)?> type="radio"> Конфуцианство </label>   <br> 
<label class="input-radio"> <input name="ank_mirovozr" id="ank_mirovozr8" value="8" <?= ($ank['ank_mirovozr'] == 8 ? 'checked="checked"' : null)?> type="radio"> Светский гуманизм </label>   <br> 
<label class="input-radio"> <input name="ank_mirovozr" id="ank_mirovozr9" value="9" <?= ($ank['ank_mirovozr'] == 9 ? 'checked="checked"' : null)?> type="radio"> Пастафарианство </label>   <br> 
<label class="input-radio"> <input name="ank_mirovozr" id="ank_mirovozr10" value="10" <?= ($ank['ank_mirovozr'] == 10 ? 'checked="checked"' : null)?> type="radio"> Атеизм </label>   <br> 
<label class="input-radio"> <input name="ank_mirovozr" id="ank_mirovozr12" value="12" <?= ($ank['ank_mirovozr'] == 12 ? 'checked="checked"' : null)?> type="radio"> Агностицизм </label>   <br> 
<label class="input-radio"> <input name="ank_mirovozr" id="ank_mirovozr11" value="11" <?= ($ank['ank_mirovozr'] == 11 ? 'checked="checked"' : null)?> type="radio"> Другое </label>       
</div> 

<div class="stnd_padd light_border_bottom"> 
<label><b class="grey">Отношение к курению:</b></label><br>      
<label class="input-radio"> <input name="ank_smok" id="ank_smok0" value="0" <?= ($ank['ank_smok'] == 0 ? 'checked="checked"' : null)?> type="radio"> Не важно </label>   <br> 
<label class="input-radio"> <input name="ank_smok" id="ank_smok1" value="1" <?= ($ank['ank_smok'] == 1 ? 'checked="checked"' : null)?> type="radio"> Негативное </label>   <br> 
<label class="input-radio"> <input name="ank_smok" id="ank_smok2" value="2" <?= ($ank['ank_smok'] == 2 ? 'checked="checked"' : null)?> type="radio"> Нейтральное </label>   <br> 
<label class="input-radio"> <input name="ank_smok" id="ank_smok3" value="3" <?= ($ank['ank_smok'] == 3 ? 'checked="checked"' : null)?> type="radio"> Положительное </label>       
</div> 

<div class="stnd_padd "> 
<label><b class="grey">Отношение к алкоголю:</b></label><br>      
<label class="input-radio"> <input name="ank_alko_n" id="ank_alko_n0" value="0" <?= ($ank['ank_alko_n'] == 0 ? 'checked="checked"' : null)?> type="radio"> Не важно </label>   <br> 
<label class="input-radio"> <input name="ank_alko_n" id="ank_alko_n1" value="1" <?= ($ank['ank_alko_n'] == 1 ? 'checked="checked"' : null)?> type="radio"> Негативное </label>   <br> 
<label class="input-radio"> <input name="ank_alko_n" id="ank_alko_n2" value="2" <?= ($ank['ank_alko_n'] == 2 ? 'checked="checked"' : null)?> type="radio"> Нейтральное </label>   <br> 
<label class="input-radio"> <input name="ank_alko_n" id="ank_alko_n3" value="3" <?= ($ank['ank_alko_n'] == 3 ? 'checked="checked"' : null)?> type="radio"> Положительное </label>       
</div>   
 
</div> 

<table class="table__wrap"> <tbody><tr> 
<td class="table__cell" width="50%"> 
<input class="link blue full is_final" name="cfms" value="Сохранить" type="submit"> 
</td> 
<td class="table__cell table__cell_last" width="50%">     
<a href="/user/anketa/?id=<?= $ank['id']?>" class="link          "> <span>Отменить</span>  </a>    
</td> 
</tr> </tbody></table>   

</div>  
</form>
<?

include_once H.'sys/inc/tfoot.php';
?>