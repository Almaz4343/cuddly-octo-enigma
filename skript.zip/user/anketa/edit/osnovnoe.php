<?
include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';


if (isset($ank)){
	$ank['id'] = $ank['id'];
}
if (isset($_GET['id'])){
	$ank['id'] = intval($_GET['id']);
}

$ank = get_user($ank['id']);

if($user['level'] < 4){
if ($user['id'] != $ank['id']){
header("Location: /user/anketa/?id=$ank[id]");
exit;
}
}

// Если не определили юзера
if(!$ank || $ank['id'] == 0 || !isset($_GET['id'])){
$set['title'] = 'Ошибка';
include_once H.'sys/inc/thead.php';
title();
?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="//c.spac.me/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Ошибка</span> </span>       </div>
<div class="list_item">Пользователь не обнаружен</div>
<?
include_once H.'sys/inc/tfoot.php';
exit;
}


if (isset($_POST['cfms'])){

// Имя
if (isset($_POST['ank_name']) && preg_match('#^([A-zА-я \-]*)$#ui', $_POST['ank_name']))
{
$ank['ank_name'] = $_POST['ank_name'];
mysql_query("UPDATE `user` SET `ank_name` = '".my_esc($ank['ank_name'])."' WHERE `id` = '$ank[id]' LIMIT 1");
}
else $err[]='Неверный формат имени.';

// Фамилия
if (isset($_POST['ank_family']) && preg_match('#^([A-zА-я \-]*)$#ui', $_POST['ank_family']))
{
$ank['ank_family'] = $_POST['ank_family'];
mysql_query("UPDATE `user` SET `ank_family` = '".my_esc($ank['ank_family'])."' WHERE `id` = '$ank[id]' LIMIT 1");
}
else $err[]='Неверный формат фамилии.';

// Пол
if (isset($_POST['pol']) && $_POST['pol'] == 1){
$ank['pol'] = 1;
mysql_query("UPDATE `user` SET `pol` = '1' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['pol']) && $_POST['pol'] == 0){
$ank['pol'] = 0;
mysql_query("UPDATE `user` SET `pol` = '0' WHERE `id` = '$ank[id]' LIMIT 1");
}

// Дата рождения
if (isset($_POST['ank_d_r']) && (is_numeric($_POST['ank_d_r']) && $_POST['ank_d_r']>=0 && $_POST['ank_d_r']<=31 || $_POST['ank_d_r']==NULL))
{
$ank['ank_d_r']= (int) $_POST['ank_d_r'];
if ($ank['ank_d_r']==null)$ank['ank_d_r'] = 'null';
mysql_query("UPDATE `user` SET `ank_d_r` = $ank[ank_d_r] WHERE `id` = '$ank[id]' LIMIT 1");
if ($ank['ank_d_r']=='null')$ank['ank_d_r'] = NULL;
}
else $err[]='Неверный формат дня рождения';

if (isset($_POST['ank_m_r']) && (is_numeric($_POST['ank_m_r']) && $_POST['ank_m_r']>=0 && $_POST['ank_m_r']<=13 || $_POST['ank_m_r']==NULL))
{
$ank['ank_m_r']= (int) $_POST['ank_m_r'];
if ($ank['ank_m_r']==null)$ank['ank_m_r']='null';
mysql_query("UPDATE `user` SET `ank_m_r` = $ank[ank_m_r] WHERE `id` = '$ank[id]' LIMIT 1");
if ($ank['ank_m_r']=='null')$ank['ank_m_r']=NULL;
}
else $err[]='Неверный формат месяца рождения';

if (isset($_POST['ank_g_r']) && (is_numeric($_POST['ank_g_r']) && $_POST['ank_g_r']>=0 && $_POST['ank_g_r']<=date('Y') || $_POST['ank_g_r']==NULL))
{
$ank['ank_g_r']= (int) $_POST['ank_g_r'];
if ($ank['ank_g_r']==null)$ank['ank_g_r']='null';
mysql_query("UPDATE `user` SET `ank_g_r` = $ank[ank_g_r] WHERE `id` = '$ank[id]' LIMIT 1");
if ($ank['ank_g_r']=='null')$ank['ank_g_r']=NULL;
}
else $err[]='Неверный формат года рождения';

// Сем. положение
if (isset($_POST['sem_pol']) && $_POST['sem_pol']==0)
{
$ank['sem_pol']=0;
mysql_query("UPDATE `user` SET `sem_pol` = '0' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['sem_pol']) && $_POST['sem_pol']==1)
{
$ank['sem_pol']=1;
mysql_query("UPDATE `user` SET `sem_pol` = '1' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['sem_pol']) && $_POST['sem_pol']==2)
{
$ank['sem_pol']=2;
mysql_query("UPDATE `user` SET `sem_pol` = '2' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['sem_pol']) && $_POST['sem_pol']==3)
{
$ank['sem_pol']=3;
mysql_query("UPDATE `user` SET `sem_pol` = '3' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['sem_pol']) && $_POST['sem_pol']==4)
{
$ank['sem_pol']=4;
mysql_query("UPDATE `user` SET `sem_pol` = '4' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['sem_pol']) && $_POST['sem_pol']==5)
{
$ank['sem_pol']=5;
mysql_query("UPDATE `user` SET `sem_pol` = '5' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['sem_pol']) && $_POST['sem_pol']==6)
{
$ank['sem_pol']=6;
mysql_query("UPDATE `user` SET `sem_pol` = '6' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['sem_pol']) && $_POST['sem_pol']==7)
{
$ank['sem_pol']=7;
mysql_query("UPDATE `user` SET `sem_pol` = '7' WHERE `id` = '$ank[id]' LIMIT 1");
}

// Город
if (isset($_POST['ank_city']) && preg_match('#^([A-zА-я \-]*)$#ui', $_POST['ank_city']))
{
$ank['ank_city'] = $_POST['ank_city'];
mysql_query("UPDATE `user` SET `ank_city` = '".my_esc($ank['ank_city'])."' WHERE `id` = '$ank[id]' LIMIT 1");
}
else $err[]='Неверный формат названия города';

// Чем занимаюсь
if (isset($_POST['ank_zan']) && $_POST['ank_zan']==0)
{
$ank['ank_zan']=0;
mysql_query("UPDATE `user` SET `ank_zan` = '0' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['ank_zan']) && $_POST['ank_zan']==1)
{
$ank['ank_zan']=1;
mysql_query("UPDATE `user` SET `ank_zan` = '1' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['ank_zan']) && $_POST['ank_zan']==2)
{
$ank['ank_zan']=2;
mysql_query("UPDATE `user` SET `ank_zan` = '2' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['ank_zan']) && $_POST['ank_zan']==3)
{
$ank['ank_zan']=3;
mysql_query("UPDATE `user` SET `ank_zan` = '3' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['ank_zan']) && $_POST['ank_zan']==4)
{
$ank['ank_zan']=4;
mysql_query("UPDATE `user` SET `ank_zan` = '4' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['ank_zan']) && $_POST['ank_zan']==5)
{
$ank['ank_zan']=5;
mysql_query("UPDATE `user` SET `ank_zan` = '5' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['ank_zan']) && $_POST['ank_zan']==6)
{
$ank['ank_zan']=6;
mysql_query("UPDATE `user` SET `ank_zan` = '6' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['ank_zan']) && $_POST['ank_zan']==7)
{
$ank['ank_zan']=7;
mysql_query("UPDATE `user` SET `ank_zan` = '7' WHERE `id` = '$ank[id]' LIMIT 1");
}
if (isset($_POST['ank_zan']) && $_POST['ank_zan']==8)
{
$ank['ank_zan']=8;
mysql_query("UPDATE `user` SET `ank_zan` = '8' WHERE `id` = '$ank[id]' LIMIT 1");
}

// Профессия
if (isset($_POST['ank_profes']) && strlen2($_POST['ank_profes']) <= 300)
{
if (preg_match('#[^A-zА-я0-9 _\-\=\+\(\)\*\!\?\.,]#ui',$_POST['ank_profes']))$err[]='В поле "Профессия" используются запрещенные символы';
else {
$ank['ank_profes'] = $_POST['ank_profes'];
mysql_query("UPDATE `user` SET `ank_profes` = '".my_esc($ank['ank_profes'])."' WHERE `id` = '$ank[id]' LIMIT 1");
}
}
else $err[]='О своей Профессии нужно писать меньше :)';


if (!isset($err)){
$_SESSION['message'] = 'Изменения сохранены. ';
header("Location: /user/anketa/?id=$ank[id]");
exit;
}

}

$set['title'] = "Основная информация : Анкета : " . $ank['nick'];
include_once H.'sys/inc/thead.php';
title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="//c.spac.me/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $ank['id']?>"><?= $ank['nick']?></a> </span>    <span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/anketa/?id=<?= $ank['id']?>">Анкета</a> </span>     <span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Основная информация</span> </span>       </div>
<?

err();


if ($ank['id'] == $user['id']){
$my_names = 'Введите ваше имя';
$my_surname = 'Введите вашу фамилию';
$my_real_city = 'Введите ваш родной город';
$my_live_city = 'Введите ваш город';
$my_profession = 'Введите вашу профессию';
}else{
$my_names = 'Введите имя для '. $ank['nick'];
$my_surname = 'Введите фамилию для '. $ank['nick'];
$my_real_city = 'Введите родной город для '. $ank['nick'];
$my_live_city = 'Введите город для '. $ank['nick'];
$my_profession = 'Введите профессию для '. $ank['nick'];
}

if ($ank['ank_m_r']==null){$mecyac='-';}
if ($ank['ank_m_r']==1){$mecyac='января';}
if ($ank['ank_m_r']==2){$mecyac='февраля';}
if ($ank['ank_m_r']==3){$mecyac='марта';}
if ($ank['ank_m_r']==4){$mecyac='апреля';}
if ($ank['ank_m_r']==5){$mecyac='мая';}
if ($ank['ank_m_r']==6){$mecyac='июня';}
if ($ank['ank_m_r']==7){$mecyac='июля';}
if ($ank['ank_m_r']==8){$mecyac='августа';}
if ($ank['ank_m_r']==9){$mecyac='сентября';}
if ($ank['ank_m_r']==10){$mecyac='октября';}
if ($ank['ank_m_r']==11){$mecyac='ноября';}
if ($ank['ank_m_r']==12){$mecyac='декабря';}
if ($ank['ank_d_r']==null){$mecyacdd='-';}else{$mecyacdd=''.$ank['ank_d_r'].'';}
if ($ank['ank_g_r']==null){$mecyacgg='-';}else{$mecyacgg=''.$ank['ank_g_r'].'';}
?>
<form method="post" action="/user/anketa/edit/osnovnoe.php?id=<?= $ank['id']?>">
<div class="wrapper"> 

<div class="bord-botm pad_b_a">
<div class="stnd_padd b"> Основная информация </div>
<?
if ($ank['id'] == $user['id']){
?>
<div class="stnd_padd oh"> 
<div class="left dot_pic">      
<span class="pr">   
<div class="inl_bl relative"> <?= ava40($ank['id'])?>   </div>     
</span>        
</div> 
<div class="oh"> <a href="/foto/edit_photo/?">Сменить аватар</a> </div> 
</div>
<?
}
?>

<div class="stnd_padd">  <div>  
<label class="lbl">  Имя:   </label>   
<div class="input-txt_wrapper">  
<input placeholder="<?= $my_names?>" class="input-txt" name="ank_name" value="<?= text($ank['ank_name'])?>" maxlength="50" type="text">  
</div>   
</div>   </div>

<div class="stnd_padd">  <div>  
<label class="lbl">  Фамилия:   </label>   
<div class="input-txt_wrapper">  
<input placeholder="<?= $my_surname?>" class="input-txt" name="ank_family" value="<?= text($ank['ank_family'])?>" maxlength="50" type="text">  
</div>   
</div>   </div>

<div class="stnd_padd"> 
<label class="lbl">Пол:</label>      
<label class="input-radio"> 
<input name="pol" value="0" <?= ($ank['pol']==0?' checked="checked"':null)?> type="radio">  Женский
</label>   <br> 
<label class="input-radio"> 
<input name="pol" value="1" <?= ($ank['pol']==1?' checked="checked"':null)?> type="radio">  Мужской
</label>        
</div>

<div class="stnd_padd"> 
<label class="lbl">Дата рождения:</label>  

<select name="ank_d_r" class="select">
<option value="0"<?= ($ank['ank_d_r'] == null ? " selected='selected'" : null)?>>-</option>
<option value="1"<?= ($ank['ank_d_r'] == 1 ? " selected='selected'" : null)?>>1</option>  
<option value="2"<?= ($ank['ank_d_r'] == 2 ? " selected='selected'" : null)?>>2</option>  
<option value="3"<?= ($ank['ank_d_r'] == 3 ? " selected='selected'" : null)?>>3</option>  
<option value="4"<?= ($ank['ank_d_r'] == 4 ? " selected='selected'" : null)?>>4</option>  
<option value="5"<?= ($ank['ank_d_r'] == 5 ? " selected='selected'" : null)?>>5</option>  
<option value="6"<?= ($ank['ank_d_r'] == 6 ? " selected='selected'" : null)?>>6</option>  
<option value="7"<?= ($ank['ank_d_r'] == 7 ? " selected='selected'" : null)?>>7</option>  
<option value="8"<?= ($ank['ank_d_r'] == 8 ? " selected='selected'" : null)?>>8</option>  
<option value="9"<?= ($ank['ank_d_r'] == 9 ? " selected='selected'" : null)?>>9</option>  
<option value="10"<?= ($ank['ank_d_r'] == 10 ? " selected='selected'" : null)?>>10</option>  
<option value="11"<?= ($ank['ank_d_r'] == 11 ? " selected='selected'" : null)?>>11</option>  
<option value="12"<?= ($ank['ank_d_r'] == 12 ? " selected='selected'" : null)?>>12</option>  
<option value="13"<?= ($ank['ank_d_r'] == 13 ? " selected='selected'" : null)?>>13</option>  
<option value="14"<?= ($ank['ank_d_r'] == 14 ? " selected='selected'" : null)?>>14</option>  
<option value="15"<?= ($ank['ank_d_r'] == 15 ? " selected='selected'" : null)?>>15</option>  
<option value="16"<?= ($ank['ank_d_r'] == 16 ? " selected='selected'" : null)?>>16</option>  
<option value="17"<?= ($ank['ank_d_r'] == 17 ? " selected='selected'" : null)?>>17</option>  
<option value="18"<?= ($ank['ank_d_r'] == 18 ? " selected='selected'" : null)?>>18</option>  
<option value="19"<?= ($ank['ank_d_r'] == 19 ? " selected='selected'" : null)?>>19</option>  
<option value="20"<?= ($ank['ank_d_r'] == 20 ? " selected='selected'" : null)?>>20</option>  
<option value="21"<?= ($ank['ank_d_r'] == 21 ? " selected='selected'" : null)?>>21</option>  
<option value="22"<?= ($ank['ank_d_r'] == 22 ? " selected='selected'" : null)?>>22</option>  
<option value="23"<?= ($ank['ank_d_r'] == 23 ? " selected='selected'" : null)?>>23</option>  
<option value="24"<?= ($ank['ank_d_r'] == 24 ? " selected='selected'" : null)?>>24</option>  
<option value="25"<?= ($ank['ank_d_r'] == 25 ? " selected='selected'" : null)?>>25</option>  
<option value="26"<?= ($ank['ank_d_r'] == 26 ? " selected='selected'" : null)?>>26</option>  
<option value="27"<?= ($ank['ank_d_r'] == 27 ? " selected='selected'" : null)?>>27</option>  
<option value="28"<?= ($ank['ank_d_r'] == 28 ? " selected='selected'" : null)?>>28</option>  
<option value="29"<?= ($ank['ank_d_r'] == 29 ? " selected='selected'" : null)?>>29</option>  
<option value="30"<?= ($ank['ank_d_r'] == 30 ? " selected='selected'" : null)?>>30</option>  
<option value="31"<?= ($ank['ank_d_r'] == 31 ? " selected='selected'" : null)?>>31</option>  
</select> 

<select name="ank_m_r" class="select"> 
<option value="0"<?= ($ank['ank_m_r'] == null ? " selected='selected'" : null)?>>-</option>
<option value="1"<?= ($ank['ank_m_r'] == 1 ? " selected='selected'" : null)?>>января</option>  
<option value="2"<?= ($ank['ank_m_r'] == 2 ? " selected='selected'" : null)?>>февраля</option>  
<option value="3"<?= ($ank['ank_m_r'] == 3 ? " selected='selected'" : null)?>>марта</option>  
<option value="4"<?= ($ank['ank_m_r'] == 4 ? " selected='selected'" : null)?>>апреля</option>  
<option value="5"<?= ($ank['ank_m_r'] == 5 ? " selected='selected'" : null)?>>мая</option>  
<option value="6"<?= ($ank['ank_m_r'] == 6 ? " selected='selected'" : null)?>>июня</option>  
<option value="7"<?= ($ank['ank_m_r'] == 7 ? " selected='selected'" : null)?>>июля</option>  
<option value="8"<?= ($ank['ank_m_r'] == 8 ? " selected='selected'" : null)?>>августа</option>  
<option value="9"<?= ($ank['ank_m_r'] == 9 ? " selected='selected'" : null)?>>сентября</option>  
<option value="10"<?= ($ank['ank_m_r'] == 10 ? " selected='selected'" : null)?>>октября</option>  
<option value="11"<?= ($ank['ank_m_r'] == 11 ? " selected='selected'" : null)?>>ноября</option>  
<option value="12"<?= ($ank['ank_m_r'] == 12 ? " selected='selected'" : null)?>>декабря</option>    
</select> 

<select name="ank_g_r" class="select"> 
<option value="0"<?= ($ank['ank_g_r'] == null ? " selected='selected'" : null)?>>-</option>  
<option value="2011"<?= ($ank['ank_g_r'] == 2011 ? " selected='selected'" : null)?>>2011</option>  
<option value="2010"<?= ($ank['ank_g_r'] == 2010 ? " selected='selected'" : null)?>>2010</option>  
<option value="2009"<?= ($ank['ank_g_r'] == 2009 ? " selected='selected'" : null)?>>2009</option>  
<option value="2008"<?= ($ank['ank_g_r'] == 2008 ? " selected='selected'" : null)?>>2008</option>  
<option value="2007"<?= ($ank['ank_g_r'] == 2007 ? " selected='selected'" : null)?>>2007</option>  
<option value="2006"<?= ($ank['ank_g_r'] == 2006 ? " selected='selected'" : null)?>>2006</option>  
<option value="2005"<?= ($ank['ank_g_r'] == 2005 ? " selected='selected'" : null)?>>2005</option>  
<option value="2004"<?= ($ank['ank_g_r'] == 2004 ? " selected='selected'" : null)?>>2004</option>  
<option value="2003"<?= ($ank['ank_g_r'] == 2003 ? " selected='selected'" : null)?>>2003</option>  
<option value="2002"<?= ($ank['ank_g_r'] == 2002 ? " selected='selected'" : null)?>>2002</option>  
<option value="2001"<?= ($ank['ank_g_r'] == 2001 ? " selected='selected'" : null)?>>2001</option>  
<option value="2000"<?= ($ank['ank_g_r'] == 2000 ? " selected='selected'" : null)?>>2000</option>  
<option value="1999"<?= ($ank['ank_g_r'] == 1999 ? " selected='selected'" : null)?>>1999</option>  
<option value="1998"<?= ($ank['ank_g_r'] == 1998 ? " selected='selected'" : null)?>>1998</option>  
<option value="1997"<?= ($ank['ank_g_r'] == 1997 ? " selected='selected'" : null)?>>1997</option>  
<option value="1996"<?= ($ank['ank_g_r'] == 1996 ? " selected='selected'" : null)?>>1996</option>  
<option value="1995"<?= ($ank['ank_g_r'] == 1995 ? " selected='selected'" : null)?>>1995</option>  
<option value="1994"<?= ($ank['ank_g_r'] == 1994 ? " selected='selected'" : null)?>>1994</option>  
<option value="1993"<?= ($ank['ank_g_r'] == 1993 ? " selected='selected'" : null)?>>1993</option>  
<option value="1992"<?= ($ank['ank_g_r'] == 1992 ? " selected='selected'" : null)?>>1992</option>  
<option value="1991"<?= ($ank['ank_g_r'] == 1991 ? " selected='selected'" : null)?>>1991</option>  
<option value="1990"<?= ($ank['ank_g_r'] == 1990 ? " selected='selected'" : null)?>>1990</option>  
<option value="1989"<?= ($ank['ank_g_r'] == 1989 ? " selected='selected'" : null)?>>1989</option>  
<option value="1988"<?= ($ank['ank_g_r'] == 1988 ? " selected='selected'" : null)?>>1988</option>  
<option value="1987"<?= ($ank['ank_g_r'] == 1987 ? " selected='selected'" : null)?>>1987</option>  
<option value="1986"<?= ($ank['ank_g_r'] == 1986 ? " selected='selected'" : null)?>>1986</option>  
<option value="1985"<?= ($ank['ank_g_r'] == 1985 ? " selected='selected'" : null)?>>1985</option>  
<option value="1984"<?= ($ank['ank_g_r'] == 1984 ? " selected='selected'" : null)?>>1984</option>  
<option value="1983"<?= ($ank['ank_g_r'] == 1983 ? " selected='selected'" : null)?>>1983</option>  
<option value="1982"<?= ($ank['ank_g_r'] == 1982 ? " selected='selected'" : null)?>>1982</option>  
<option value="1981"<?= ($ank['ank_g_r'] == 1981 ? " selected='selected'" : null)?>>1981</option>  
<option value="1980"<?= ($ank['ank_g_r'] == 1980 ? " selected='selected'" : null)?>>1980</option>  
<option value="1979"<?= ($ank['ank_g_r'] == 1979 ? " selected='selected'" : null)?>>1979</option>  
<option value="1978"<?= ($ank['ank_g_r'] == 1978 ? " selected='selected'" : null)?>>1978</option>  
<option value="1977"<?= ($ank['ank_g_r'] == 1977 ? " selected='selected'" : null)?>>1977</option>  
<option value="1976"<?= ($ank['ank_g_r'] == 1976 ? " selected='selected'" : null)?>>1976</option>  
<option value="1975"<?= ($ank['ank_g_r'] == 1975 ? " selected='selected'" : null)?>>1975</option>  
<option value="1974"<?= ($ank['ank_g_r'] == 1974 ? " selected='selected'" : null)?>>1974</option>  
<option value="1973"<?= ($ank['ank_g_r'] == 1973 ? " selected='selected'" : null)?>>1973</option>  
<option value="1972"<?= ($ank['ank_g_r'] == 1972 ? " selected='selected'" : null)?>>1972</option>  
<option value="1971"<?= ($ank['ank_g_r'] == 1971 ? " selected='selected'" : null)?>>1971</option>  
<option value="1970"<?= ($ank['ank_g_r'] == 1970 ? " selected='selected'" : null)?>>1970</option>  
<option value="1969"<?= ($ank['ank_g_r'] == 1969 ? " selected='selected'" : null)?>>1969</option>  
<option value="1968"<?= ($ank['ank_g_r'] == 1968 ? " selected='selected'" : null)?>>1968</option>  
<option value="1967"<?= ($ank['ank_g_r'] == 1967 ? " selected='selected'" : null)?>>1967</option>  
<option value="1966"<?= ($ank['ank_g_r'] == 1966 ? " selected='selected'" : null)?>>1966</option>  
<option value="1965"<?= ($ank['ank_g_r'] == 1965 ? " selected='selected'" : null)?>>1965</option>  
<option value="1964"<?= ($ank['ank_g_r'] == 1964 ? " selected='selected'" : null)?>>1964</option>  
<option value="1963"<?= ($ank['ank_g_r'] == 1963 ? " selected='selected'" : null)?>>1963</option>  
<option value="1962"<?= ($ank['ank_g_r'] == 1962 ? " selected='selected'" : null)?>>1962</option>  
<option value="1961"<?= ($ank['ank_g_r'] == 1961 ? " selected='selected'" : null)?>>1961</option>  
<option value="1960"<?= ($ank['ank_g_r'] == 1960 ? " selected='selected'" : null)?>>1960</option>  
<option value="1959"<?= ($ank['ank_g_r'] == 1959 ? " selected='selected'" : null)?>>1959</option>  
<option value="1958"<?= ($ank['ank_g_r'] == 1958 ? " selected='selected'" : null)?>>1958</option>  
<option value="1957"<?= ($ank['ank_g_r'] == 1957 ? " selected='selected'" : null)?>>1957</option>  
<option value="1956"<?= ($ank['ank_g_r'] == 1956 ? " selected='selected'" : null)?>>1956</option>  
<option value="1955"<?= ($ank['ank_g_r'] == 1955 ? " selected='selected'" : null)?>>1955</option>  
<option value="1954"<?= ($ank['ank_g_r'] == 1954 ? " selected='selected'" : null)?>>1954</option>  
<option value="1953"<?= ($ank['ank_g_r'] == 1953 ? " selected='selected'" : null)?>>1953</option>  
<option value="1952"<?= ($ank['ank_g_r'] == 1952 ? " selected='selected'" : null)?>>1952</option>  
<option value="1951"<?= ($ank['ank_g_r'] == 1951 ? " selected='selected'" : null)?>>1951</option>  
<option value="1950"<?= ($ank['ank_g_r'] == 1950 ? " selected='selected'" : null)?>>1950</option>  
<option value="1949"<?= ($ank['ank_g_r'] == 1949 ? " selected='selected'" : null)?>>1949</option>  
<option value="1948"<?= ($ank['ank_g_r'] == 1948 ? " selected='selected'" : null)?>>1948</option>  
<option value="1947"<?= ($ank['ank_g_r'] == 1947 ? " selected='selected'" : null)?>>1947</option>  
<option value="1946"<?= ($ank['ank_g_r'] == 1946 ? " selected='selected'" : null)?>>1946</option>  
<option value="1945"<?= ($ank['ank_g_r'] == 1945 ? " selected='selected'" : null)?>>1945</option>  
<option value="1944"<?= ($ank['ank_g_r'] == 1944 ? " selected='selected'" : null)?>>1944</option>  
<option value="1943"<?= ($ank['ank_g_r'] == 1943 ? " selected='selected'" : null)?>>1943</option>  
<option value="1942"<?= ($ank['ank_g_r'] == 1942 ? " selected='selected'" : null)?>>1942</option>  
<option value="1941"<?= ($ank['ank_g_r'] == 1941 ? " selected='selected'" : null)?>>1941</option>  
<option value="1940"<?= ($ank['ank_g_r'] == 1940 ? " selected='selected'" : null)?>>1940</option>  
<option value="1939"<?= ($ank['ank_g_r'] == 1939 ? " selected='selected'" : null)?>>1939</option>  
<option value="1938"<?= ($ank['ank_g_r'] == 1938 ? " selected='selected'" : null)?>>1938</option>  
<option value="1937"<?= ($ank['ank_g_r'] == 1937 ? " selected='selected'" : null)?>>1937</option>  
<option value="1936"<?= ($ank['ank_g_r'] == 1936 ? " selected='selected'" : null)?>>1936</option>  
<option value="1935"<?= ($ank['ank_g_r'] == 1935 ? " selected='selected'" : null)?>>1935</option>  
<option value="1934"<?= ($ank['ank_g_r'] == 1934 ? " selected='selected'" : null)?>>1934</option>  
<option value="1933"<?= ($ank['ank_g_r'] == 1933 ? " selected='selected'" : null)?>>1933</option>  
<option value="1932"<?= ($ank['ank_g_r'] == 1932 ? " selected='selected'" : null)?>>1932</option>  
<option value="1931"<?= ($ank['ank_g_r'] == 1931 ? " selected='selected'" : null)?>>1931</option>  
<option value="1930"<?= ($ank['ank_g_r'] == 1930 ? " selected='selected'" : null)?>>1930</option>   
</select>     
</div>

<div class="stnd_padd"> 
<label class="lbl">Семейное положение:</label>      
<label class="input-radio"> <input name="sem_pol" value="0" <?= ($ank['sem_pol'] == 0 ? 'checked="checked"' : null)?> type="radio"> Не важно </label>   <br> 
<label class="input-radio"> <input name="sem_pol" value="1" <?= ($ank['sem_pol'] == 1 ? 'checked="checked"' : null)?> type="radio"> <?= (($ank['pol'] == 1) ? 'Не женат ' : 'Не замужем')?> </label>   <br> 
<label class="input-radio"> <input name="sem_pol" value="2" <?= ($ank['sem_pol'] == 2 ? 'checked="checked"' : null)?> type="radio"> <?= (($ank['pol'] == 1) ? 'Женат ' : 'Замужем')?> </label>   <br> 
<label class="input-radio"> <input name="sem_pol" value="3" <?= ($ank['sem_pol'] == 3 ? 'checked="checked"' : null)?> type="radio"> <?= (($ank['pol'] == 1) ? 'Уже не женат ' : 'Уже не замужем')?> </label>   <br> 
<label class="input-radio"> <input name="sem_pol" value="4" <?= ($ank['sem_pol'] == 4 ? 'checked="checked"' : null)?> type="radio"> В активном поиске </label>   <br> 
<label class="input-radio"> <input name="sem_pol" value="5" <?= ($ank['sem_pol'] == 5 ? 'checked="checked"' : null)?> type="radio"> Влюблён<?= (($ank['pol'] == 1) ? '' : 'а')?> </label>   <br> 
<label class="input-radio"> <input name="sem_pol" value="6" <?= ($ank['sem_pol'] == 6 ? 'checked="checked"' : null)?> type="radio"> Помолвлен<?= (($ank['pol'] == 1) ? '' : 'а')?> </label>   <br> 
<label class="input-radio"> <input name="sem_pol" value="7" <?= ($ank['sem_pol'] == 7 ? 'checked="checked"' : null)?> type="radio"> Всё сложно </label>         
</div>

<div class="stnd_padd">  <div>  
<label class="lbl">  Город:   </label>   
<div class="input-txt_wrapper">  
<input placeholder="<?= $my_live_city?>" class="input-txt" name="ank_city" value="<?= text($ank['ank_city'])?>" maxlength="50" type="text">  
</div>   
</div>   </div>

<div class="stnd_padd"> 
<label class="lbl">Чем я занимаюсь:</label>      
<label class="input-radio"> <input name="ank_zan" value="0" <?= ($ank['ank_zan'] == 0 ? 'checked="checked"' : null)?> type="radio"> Не важно </label>   <br> 
<label class="input-radio"> <input name="ank_zan" value="1" <?= ($ank['ank_zan'] == 1 ? 'checked="checked"' : null)?> type="radio"> Учусь в школе  </label>   <br> 
<label class="input-radio"> <input name="ank_zan" value="2" <?= ($ank['ank_zan'] == 2 ? 'checked="checked"' : null)?> type="radio"> Учусь в колледже/лицее  </label>   <br> 
<label class="input-radio"> <input name="ank_zan" value="3" <?= ($ank['ank_zan'] == 3 ? 'checked="checked"' : null)?> type="radio"> Учусь в ВУЗе  </label>   <br> 
<label class="input-radio"> <input name="ank_zan" value="4" <?= ($ank['ank_zan'] == 4 ? 'checked="checked"' : null)?> type="radio"> Учусь в военном училище </label>   <br> 
<label class="input-radio"> <input name="ank_zan" value="5" <?= ($ank['ank_zan'] == 5 ? 'checked="checked"' : null)?> type="radio"> Служу в армии </label>   <br> 
<label class="input-radio"> <input name="ank_zan" value="6" <?= ($ank['ank_zan'] == 6 ? 'checked="checked"' : null)?> type="radio"> Работаю </label>   <br> 
<label class="input-radio"> <input name="ank_zan" value="7" <?= ($ank['ank_zan'] == 7 ? 'checked="checked"' : null)?> type="radio"> Не работаю </label>     <br>      
<label class="input-radio"> <input name="ank_zan" value="8" <?= ($ank['ank_zan'] == 8 ? 'checked="checked"' : null)?> type="radio"> Сижу на зоне </label>         
</div>

<div class="stnd_padd">  <div>  
<label class="lbl">  Профессия:   </label>   
<div class="input-txt_wrapper">  
<input placeholder="<?= $my_profession?>" class="input-txt" name="ank_profes" value="<?= text($ank['ank_profes'])?>" maxlength="40" type="text">  
</div>   
</div>   </div>

</div> 

<table class="table__wrap"> <tbody><tr> 
<td class="table__cell" width="50%"> 
<input class="link blue full is_final" name="cfms" value="Сохранить" type="submit"> 
</td> 
<td class="table__cell table__cell_last" width="50%">     
<a href="/user/anketa/?id=<?= $ank['id']?>" class="link          "> <span>Отменить</span>  </a>    
</td> 
</tr> </tbody></table>

</div> 
</form>
<?



include_once H.'sys/inc/tfoot.php';
?>