<?
include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';

if (isset($user)){
	$ank['id'] = $user['id'];
}
if (isset($_GET['id'])){
	$ank['id'] = intval($_GET['id']);
}

$ank = get_user($ank['id']);

// Если не определили юзера
if(!$ank || $ank['id'] == 0 || !isset($_GET['id'])){
$set['title'] = 'Ошибка';
include_once H.'sys/inc/thead.php';
title();
?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Ошибка</span> </span>       </div>
<div class="list_item">Пользователь не обнаружен</div>
<?
include_once H.'sys/inc/tfoot.php';
exit;
}

/* Бан пользователя */ 
if ((!isset($user) || $user['group_access'] == 0) && mysql_result(mysql_query("SELECT COUNT(*) FROM `ban` WHERE `razdel` = 'all' AND `id_user` = '$ank[id]' AND (`time` > '$time' OR `navsegda` = '1')"), 0)!=0)
{
$set['title'] = 'Анкета : ' . $ank['nick']; // заголовок страницы
include_once H.'sys/inc/thead.php';
title();

$post_ban = mysql_fetch_assoc(mysql_query("SELECT * FROM `ban` WHERE `id_user` = '$ank[id]' AND `time` > '$time'"));
?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text"><?= $ank['nick']?></span> </span>       </div>
<div class="wrapper"> 
<div class="block t_center bord-botm grey">   Этот аккаунт был заблокирован за нарушение <a href="/rules.php">условий использования сервиса</a>.   </div>  
<div class="block">   
<div> <span class="grey">Время блокировки:</span> <?= vremja($post_ban['time'])?> </div>   
</div>
</div>
<?

include_once H.'sys/inc/tfoot.php';
exit;
}

// Приватность станички
$uSet = mysql_fetch_array(mysql_query("SELECT * FROM `user_set` WHERE `id_user` = '$ank[id]'  LIMIT 1"));
$frend = mysql_result(mysql_query("SELECT COUNT(*) FROM `frends` WHERE (`user` = '$user[id]' AND `frend` = '$ank[id]') OR (`user` = '$ank[id]' AND `frend` = '$user[id]') LIMIT 1"),0);
$frend_new = mysql_result(mysql_query("SELECT COUNT(*) FROM `frends_new` WHERE (`user` = '$user[id]' AND `to` = '$ank[id]') OR (`user` = '$ank[id]' AND `to` = '$user[id]') LIMIT 1"),0);



$set['title'] = "Анкета : " . $ank['nick'];
include_once H.'sys/inc/thead.php';
title();
err();

$timediff = mysql_result(mysql_query("SELECT `time` FROM `user` WHERE `id` = '$ank[id]' LIMIT 1",$db), 0);

$oneMinute = 60; 
$oneHour = 60*60; 
$hourfield = floor(($timediff)/$oneHour); 
$minutefield = floor(($timediff-$hourfield*$oneHour)/$oneMinute); 
$secondfield = floor(($timediff-$hourfield*$oneHour-$minutefield*$oneMinute)); 

$sHoursLeft = $hourfield; 
$sHoursText = "ч,"; 
$nHoursLeftLength = strlen($sHoursLeft); 
$h_1=substr($sHoursLeft, -1, 1); 
if (substr($sHoursLeft, -2, 1) != 1 && $nHoursLeftLength > 1){
    if ($h_1 == 2 || $h_1 == 3 || $h_1 == 4) 
    { 
        $sHoursText = "ч,"; 
    }elseif ($h_1== 1){ 
        $sHoursText = "ч,"; 
    } 
} 
if ($nHoursLeftLength==1){
    if ($h_1== 2 || $h_1== 3 || $h_1== 4){ 
        $sHoursText = "ч,"; 
    }elseif ($h_1== 1){ 
        $sHoursText = "ч,"; 
    } 
} 
$sMinsLeft = $minutefield; 
$sMinsText = "мин"; 
$nMinsLeftLength = strlen($sMinsLeft); 
$m_1 = substr($sMinsLeft,-1, 1); 
if ($nMinsLeftLength>1 && substr($sMinsLeft,-2,1) != 1){ 
    if ($m_1== 2 || $m_1== 3 || $m_1== 4) 
    { 
        $sMinsText = "мин"; 
    }else if ($m_1== 1){ 
        $sMinsText = "мин"; 
    } 
} 

if ($nMinsLeftLength==1){ 
    if ($m_1== 2 || $m_1==3 || $m_1== 4) 
    { 
        $sMinsText = "мин"; 
    }elseif ($m_1== "1"){ 
        $sMinsText = "мин"; 
    } 
} 
$displaystring = $sHoursLeft . $sHoursText . $sMinsLeft . $sMinsText;

if ($timediff < 0){
	$displaystring='Это уже не юзер';
}
$rTime = time()-600;

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $ank['id']?>"><?= $ank['nick']?></a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Анкета</span> </span>       </div>
<?

?>
<div>   
     
<div>   
<div class="stnd_padd oh light_border_bottom "> 
 
<div class="left dot_pic">      
<?
if (isset($user) && $ank['id'] == $user['id']){
?>
<a href="/foto/edit_photo/?" title="Изменить аватар">
<div class="inl_bl relative"> <?= ava80($ank['id'])?>   </div>      
</a>
<?
}
else{
?>
<div class="inl_bl relative"> <?= ava80($ank['id'])?>   </div> 
<?
}



?> 
</div> 

<div class="left"> 

<span class="m"> <?= group($ank['id'])?> 
<a href="/user/?id=<?= $ank['id']?>" class="mysite-link"><b class="nick"><?= $ank['nick']?></b></a>  
</span>    
<?
if($ank['rating'] > 0){
?>
<div class="inl_bl m">  <span class="bordered grey"> <?= $ank['rating']?> </span>  </div>      
<?
}
if ((user_access('user_ban_set') || user_access('user_ban_set_h') || user_access('user_ban_unset')) && $ank['id'] != $user['id']){
?>
<a href="/adm_panel/ban.php?id=<?= $ank['id']?>"><font color="red">[Бан]</font></a>
<?
}
?>
<div> 
<?
if ($ank['ank_name'] != NULL OR $ank['ank_family'] != NULL){
?>
<div class="grey break-word">
<?
if ($ank['ank_name'] != NULL){
?>
<?= text($ank['ank_name'])?> 
<?
}
if ($ank['ank_family'] != NULL){
?>
<?= text($ank['ank_family'])?> 
<?
}
?>
</div>  
<?
}
// Склон текста & Tw1nGo
$my_age_day = array('год', 'года', 'лет');
$ank['ank_age'] = date("Y") - $ank['ank_g_r'];
?>
<div class="grey">
<?
if ($ank['ank_d_r'] != NULL && $ank['ank_m_r'] != NULL && $ank['ank_g_r'] != NULL){
?>
<?= des2num($ank['ank_age'], $my_age_day)?>
<?
if ($ank['ank_city'] != NULL){
?>, <?
}
}
if ($ank['ank_city'] != NULL){
?>
<span class="arrow_link"><?= text($ank['ank_city'])?></span>
<?
}
?>
</div>    
<?
if($ank['date_last'] < $rTime){
?>
<div class="oh"> <div class="left">     
<span class="bordered grey">           <span class=" grey">  <?= vremja($ank['date_last'])?> </span>         </span>     
</div> </div>
<?
}else{
if ($user['id'] != $ank['id']){
?>
<div class="oh"> <div class="left"> <span class="bordered green"> <span class=" green">  В сети </span> </span> </div> </div>
<?
}
}
?> 
</div> 
</div>   </div>   </div> </div> 

<div class="tabs_block oh">    
<a href="/user/?id=<?= $ank['id']?>" class="tab_item left" style="padding: 12px 9px 8px 9px"> Профиль  </a>   
<div class="tab_item left tab_active black" style="padding: 12px 9px 8px 9px">  Анкета  </div> 
<a href="/user/activity/?id=<?= $ank['id']?>" class="tab_item left" style="padding: 12px 9px 8px 9px">  Активность  </a>
</div>

<div class="wrapper"> 
<div class="block col_blocks"> 
<div><span class="grey">Регистрация:</span> <?= vremja($ank['date_reg'])?></div>  
<?
if ($ank['group_access'] > 1){
?>
<div class="pad_t_a"><span class="grey">Должность:</span> <?= text($ank['group_name'])?> Xmyx.Ru </div> 
<?
}
?>
<div class="pad_t_a"><span class="grey">Последний визит:</span> <?= vremja($ank['date_last'])?></div>
<div class="pad_t_a"><span class="grey">Время онлайн:</span> <?= $displaystring?> </div> 
</div>   
</div>


<div class="wrapper"> 
<div class="title oh black text_left relative"> Основное 
<?
if (isset($user) && $user['id'] == $ank['id'] || $user['level'] > $ank['level']){
?>
<a class="arrow_link right full_link" href="edit/osnovnoe.php?id=<?= $ank['id']?>"> <img src="/style/i/edit_info.png" alt="" class="p16"> </a>
<?
}
?> 
</div>

<div class="block">
<?
if (isset($user) && $user['id'] == $ank['id']){

if ($ank['ank_name']!=NULL){$ank_nam='16';}else{$ank_nam='0';}
if ($ank['ank_family']!=NULL){$ank_fam='16';}else{$ank_fam='0';}
if ($ank['ank_city']!=NULL){$ank_sitykj='16';}else{$ank_sitykj='0';}
if ($ank['ank_d_r']!=NULL && $ank['ank_m_r']!=NULL && $ank['ank_g_r']!=NULL){$ank_drozhd='14';}else{$ank_drozhd='0';}
if ($ank['ank_d_r']!=NULL && $ank['ank_m_r']!=NULL){$ank_drozhd='14';}else{$ank_drozhd='0';}
if ($ank['sem_pol']!=0){$ank_sempol='13';}else{$ank_sempol='0';}
if ($ank['ank_profes']!=NULL){$ank_profes='13';}else{$ank_profes='0';}
if ($ank['ank_zan']!=0){$ank_zany='12';}else{$ank_zany='0';}
$osnovnoe = $ank_nam + $ank_fam + $ank_drozhd + $ank_sitykj + $ank_sempol + $ank_profes + $ank_zany;

if ($osnovnoe < 100){
?>
<div> 
<table width="100%"> <tbody><tr> 
<td class="td_progress"> <div class="progress-item"> 
<div class="progress-item__runner progress-item__runner_light" style="width: <?= $osnovnoe?>%"></div> 
</div> 
</td> 
<td class="td_progress_num"> <div class="progress-item__num"><?= $osnovnoe?>%</div> </td> 
</tr> </tbody></table> 
</div>
<?
}
}
if ($ank['ank_name'] != NULL){
?>
<div class="pad_t_a"> <span class="grey">Имя:</span> <?= text($ank['ank_name'])?> </div>
<?
}
if ($ank['ank_family'] != NULL){
?>
<div class="pad_t_a"> <span class="grey">Фамилия:</span> <?= text($ank['ank_family'])?> </div>
<?
}

?>
<div class="pad_t_a"> <span class="grey">Пол:</span> <?= ($ank['pol'] == 1 ? 'Мужской' : 'Женский')?> </div>
<?

if ($ank['ank_d_r'] != 0 && $ank['ank_m_r'] != 0 && $ank['ank_g_r'] != 0){

if ($ank['ank_m_r']==1)$ank['mes']='Января';elseif ($ank['ank_m_r']==2)$ank['mes']='Февраля';elseif ($ank['ank_m_r']==3)$ank['mes']='Марта';
elseif ($ank['ank_m_r']==4)$ank['mes']='Апреля';elseif ($ank['ank_m_r']==5)$ank['mes']='Мая';elseif ($ank['ank_m_r']==6)$ank['mes']='Июня';
elseif ($ank['ank_m_r']==7)$ank['mes']='Июля';elseif ($ank['ank_m_r']==8)$ank['mes']='Августа';elseif ($ank['ank_m_r']==9)$ank['mes']='Сентября';
elseif ($ank['ank_m_r']==10)$ank['mes']='Октября';elseif ($ank['ank_m_r']==11)$ank['mes']='Ноября';else $ank['mes']='Декабря';
?>
<div class="pad_t_a"> <span class="grey">Дата рождения:</span> <?= $ank['ank_d_r']?> <?=$ank['mes']?> <?=$ank['ank_g_r']?> </div> 
<?
}
elseif($ank['ank_d_r'] != 0 && $ank['ank_m_r'] != 0)
{
if ($ank['ank_m_r']==1)$ank['mes']='Января';elseif ($ank['ank_m_r']==2)$ank['mes']='Февраля';elseif ($ank['ank_m_r']==3)$ank['mes']='Марта';
elseif ($ank['ank_m_r']==4)$ank['mes']='Апреля';elseif ($ank['ank_m_r']==5)$ank['mes']='Мая';elseif ($ank['ank_m_r']==6)$ank['mes']='Июня';
elseif ($ank['ank_m_r']==7)$ank['mes']='Июля';elseif ($ank['ank_m_r']==8)$ank['mes']='Августа';elseif ($ank['ank_m_r']==9)$ank['mes']='Сентября';
elseif ($ank['ank_m_r']==10)$ank['mes']='Октября';elseif ($ank['ank_m_r']==11)$ank['mes']='Ноября';else $ank['mes']='Декабря';
?>
<div class="pad_t_a"> <span class="grey">Дата рождения:</span> <?= $ank['ank_d_r']?> <?=$ank['mes']?> </div>
<?
}
if ($ank['sem_pol'] != 0){
if ($ank['sem_pol'] == 1){
$SP_user = ''.(($ank['pol'] == 1) ? 'Не женат ' : 'Не замужем').'';
}elseif ($ank['sem_pol'] == 2){
$SP_user = ''.(($ank['pol'] == 1) ? 'Женат ' : 'Замужем').'';
}elseif ($ank['sem_pol'] == 3){
$SP_user = ''.(($ank['pol'] == 1) ? 'Уже не женат ' : 'Уже не замужем').'';
}elseif ($ank['sem_pol'] == 4){
$SP_user = 'В активном поиске ';
}elseif ($ank['sem_pol'] == 5){
$SP_user = 'Влюблён'.(($ank['pol'] == 1) ? '' : 'а').'';
}elseif ($ank['sem_pol'] == 6){
$SP_user = 'Помолвлен'.(($ank['pol'] == 1) ? '' : 'а').'';
}elseif ($ank['sem_pol'] == 7){
$SP_user = 'Всё сложно ';
}
?>
<div class="pad_t_a"> <span class="grey">Семейное положение:</span> <?= $SP_user?> </div>
<?
}
if($ank['ank_city'] != NULL){
?>
<div class="pad_t_a"> <span class="grey">Город:</span> <?= text($ank['ank_city'])?> </div>
<?
}
if ($ank['ank_zan'] == 1){
$ank_zan = 'Учусь в школе ';
}elseif ($ank['ank_zan'] == 2){
$ank_zan = 'Учусь в колледже/лицее ';
}elseif ($ank['ank_zan'] == 3){
$ank_zan = 'Учусь в ВУЗе';
}elseif ($ank['ank_zan'] == 4){
$ank_zan = 'Учусь в военном училище';
}elseif ($ank['ank_zan'] == 5){
$ank_zan = 'Служу в армии ';
}elseif ($ank['ank_zan'] == 6){
$ank_zan = 'Работаю ';
}elseif ($ank['ank_zan'] == 7){
$ank_zan = 'Не работаю  ';
}elseif ($ank['ank_zan'] == 8){
$ank_zan = 'Сижу на зоне  ';
}
if ($ank['ank_zan'] != 0){
?> 
<div class="pad_t_a"> <span class="grey">Чем занимаюсь:</span> <?= $ank_zan?> </div>
<?
}
if($ank['ank_profes'] != NULL){
?>
<div class="pad_t_a"> <span class="grey">Профессия:</span> <?= text($ank['ank_profes'])?> </div>
<?
}
?>
</div>
</div>
<?



if (isset($user) && $user['id'] == $ank['id']){
if ($ank['ank_o_sebe'] == NULL && $ank['ank_interes'] == NULL && $ank['ank_music'] == NULL && $ank['ank_film'] == NULL && $ank['ank_serial'] == NULL && $ank['ank_book'] == NULL && 
$ank['ank_citat'] == NULL && $ank['polit_vzg'] == 0 && $ank['ank_mirovozr'] == 0 && $ank['ank_smok'] == 0 && $ank['ank_alko_n'] == 0){
?>
<div class="wrapper word_break"> 
<div class="title oh black text_left relative"> О себе 
<a class="arrow_link right full_link" href="edit/osebe.php?id=<?= $ank['id']?>"> <img src="/style/i/edit_info.png" alt="" class="p16"> </a> 
</div> 
<div class="block oh word_break">  Расскажите о себе, это поможет вам найти друзей по интересам и взглядам.  </div> 
</div>   
<?
}
}

if ($ank['ank_o_sebe'] != NULL OR $ank['ank_interes'] != NULL OR $ank['ank_music'] != NULL OR $ank['ank_film'] != NULL OR $ank['ank_serial'] != NULL OR $ank['ank_book'] != NULL OR 
$ank['ank_citat'] != NULL OR $ank['polit_vzg'] != 0 OR $ank['ank_mirovozr'] != 0 OR $ank['ank_smok'] != 0 OR $ank['ank_alko_n'] != 0){
?>
<div class="wrapper word_break">
<div class="title oh black text_left relative"> О себе 
<?
if (isset($user) && $user['id'] == $ank['id'] || $user['level'] > $ank['level']){
?>
<a class="arrow_link right full_link" href="edit/osebe.php?id=<?= $ank['id']?>"> <img src="/style/i/edit_info.png" alt="" class="p16"> </a>
<?
}
?> 
</div>
<div class="block">
<?

if (isset($user) && $user['id'] == $ank['id']){

if ($ank['ank_o_sebe'] != NULL){$ank_osebee='10';}else{$ank_osebee='0';}
if ($ank['ank_interes'] != NULL){$aank_interes='9';}else{$aank_interes='0';}
if ($ank['ank_music'] != NULL){$aank_music='9';}else{$aank_music='0';}
if ($ank['ank_film'] != NULL){$aank_film='9';}else{$aank_film='0';}
if ($ank['ank_serial'] != NULL){$aank_serial='9';}else{$aank_serial='0';}
if ($ank['ank_book'] != NULL){$aank_book='9';}else{$aank_book='0';}
if ($ank['ank_citat'] != NULL){$aank_citat='9';}else{$aank_citat='0';}
if ($ank['polit_vzg'] !=0 ){$apolit_vzg='9';}else{$apolit_vzg='0';}
if ($ank['ank_mirovozr'] !=0 ){$aank_mirovozr='9';}else{$aank_mirovozr='0';}
if ($ank['ank_smok'] !=0 ){$aank_smok='9';}else{$aank_smok='0';}
if ($ank['ank_alko_n'] !=0 ){$aank_alko='9';}else{$aank_alko='0';}




$osebe = $ank_osebee + $aank_interes + $aank_music + $aank_serial + $aank_book + $aank_film + $aank_citat + $apolit_vzg + $aank_mirovozr + $aank_smok + $aank_alko;

if ($osebe < 100){
?>
<div> 
<table width="100%"> <tbody><tr> 
<td class="td_progress"> <div class="progress-item"> 
<div class="progress-item__runner progress-item__runner_light" style="width: <?= $osebe?>%"></div> 
</div> 
</td> 
<td class="td_progress_num"> <div class="progress-item__num"><?= $osebe?>%</div> </td> 
</tr> </tbody></table> 
</div>
<?
}
}

?>

<?

if($ank['ank_music'] != NULL){
?>
<div class="pad_t_a"> <span class="grey">Любимая музыка:</span> <?= text($ank['ank_music'])?> </div>
<?
}
if($ank['ank_film'] != NULL){
?>
<div class="pad_t_a"> <span class="grey">Любимые фильмы:</span> <?= text($ank['ank_film'])?> </div>
<?
}
if($ank['ank_serial'] != NULL){
?>
<div class="pad_t_a"> <span class="grey">Любимые сериалы:</span> <?= text($ank['ank_serial'])?> </div>
<?
}
if($ank['ank_book'] != NULL){
?>
<div class="pad_t_a"> <span class="grey">Любимые книги:</span> <?= text($ank['ank_book'])?> </div>
<?
}
if($ank['ank_o_sebe'] != NULL){
?>
<div class="pad_t_a"> <span class="grey">О себе:</span> <?= text($ank['ank_o_sebe'])?> </div>
<?
}
if($ank['ank_interes'] != NULL){
?>
<div class="pad_t_a"> <span class="grey">Интересы:</span> <?= text($ank['ank_interes'])?> </div>
<?
}
if($ank['ank_citat'] != NULL){
?>
<div class="pad_t_a"> <span class="grey">Любимые цитаты:</span> <?= text($ank['ank_citat'])?> </div>
<?
}
if($ank['polit_vzg'] != 0 OR $ank['ank_mirovozr'] != 0 OR $ank['ank_smok'] != 0 OR $ank['ank_alko_n'] != 0){
?>
<div class="b pad_t_a"> Взгляды </div>
<?
}
if ($ank['polit_vzg'] == 1){
$polit_vzgl = 'Индифферентные  ';
}elseif ($ank['polit_vzg'] == 2){
$polit_vzgl = 'Коммунистические ';
}elseif ($ank['polit_vzg'] == 3){
$polit_vzgl = 'Социалистические';
}elseif ($ank['polit_vzg'] == 4){
$polit_vzgl = 'Умеренные';
}elseif ($ank['polit_vzg'] == 5){
$polit_vzgl = 'Либеральные ';
}elseif ($ank['polit_vzg'] == 6){
$polit_vzgl = 'Консервативные ';
}elseif ($ank['polit_vzg'] == 7){
$polit_vzgl = 'Монархические  ';
}elseif ($ank['polit_vzg'] == 8){
$polit_vzgl = 'Ультраконсервативные  ';
}elseif ($ank['polit_vzg'] == 9){
$polit_vzgl = 'Либертарианские  ';
}
 
if ($ank['polit_vzg'] != 0){
?>
<div class="pad_t_a"> <span class="grey">Полит. взгляды:</span> <?= $polit_vzgl?> </div>
<?
}

if ($ank['ank_mirovozr'] == 1){
$ank_mirov = 'Православие  ';
}elseif ($ank['ank_mirovozr'] == 2){
$ank_mirov = 'Католицизм';
}elseif ($ank['ank_mirovozr'] == 3){
$ank_mirov = 'Иудаизм';
}elseif ($ank['ank_mirovozr'] == 4){
$ank_mirov = 'Протестантизм';
}elseif ($ank['ank_mirovozr'] == 5){
$ank_mirov = 'Ислам ';
}elseif ($ank['ank_mirovozr'] == 6){
$ank_mirov = 'Буддизм ';
}elseif ($ank['ank_mirovozr'] == 7){
$ank_mirov = 'Конфуцианство  ';
}elseif ($ank['ank_mirovozr'] == 8){
$ank_mirov = 'Светский гуманизм  ';
}elseif ($ank['ank_mirovozr'] == 9){
$ank_mirov = 'Пастафарианство  ';
}elseif ($ank['ank_mirovozr'] == 10){
$ank_mirov = 'Атеизм ';
}elseif ($ank['ank_mirovozr'] == 12){
$ank_mirov = 'Агностицизм ';
}elseif ($ank['ank_mirovozr'] == 11){
$ank_mirov = 'Другое  ';
}

if ($ank['ank_mirovozr'] != 0){
?>
<div class="pad_t_a"> <span class="grey">Мировоззрение:</span> <?= $ank_mirov?> </div>
<?
}

if ($ank['ank_smok'] == 1){
$ank_smoks = 'Негативное ';
}elseif ($ank['ank_smok'] == 2){
$ank_smoks = 'Нейтральное';
}elseif ($ank['ank_smok'] == 3){
$ank_smoks = 'Положительное';
}
 

if ($ank['ank_smok'] != 0){
?>
<div class="pad_t_a"> <span class="grey">Отношение к курению:</span> <?= $ank_smoks?> </div>
<?
}

if ($ank['ank_alko_n'] == 1){
$ank_revo = 'Негативное ';
}elseif ($ank['ank_alko_n'] == 2){
$ank_revo = 'Нейтральное';
}elseif ($ank['ank_alko_n'] == 3){
$ank_revo = 'Положительное';
}

if ($ank['ank_alko_n'] != 0){
?>
<div class="pad_t_a"> <span class="grey">Отношение к алкоголю:</span> <?= $ank_revo?> </div>
<?
}


?>
</div>
</div>
<?
}


/*
if ($ank['ank_o_sebe'] != NULL && $ank['ank_interes'] != NULL && $ank['ank_music'] != NULL && $ank['ank_film'] != NULL && $ank['ank_serial'] != NULL && $ank['ank_book'] != NULL && 
$ank['ank_citat'] != NULL && $ank['polit_vzg'] != 0 && $ank['ank_mirovozr'] != 0 && $ank['ank_smok'] != 0 && $ank['ank_alko_n'] != 0){
*/
if (isset($user) && $user['id'] == $ank['id']){
if ($ank['ank_orien'] == 0 && $ank['ank_rost'] == NULL && $ank['ank_ves'] == NULL && $ank['ank_cvet_glas'] == NULL && 
$ank['ank_lov_1'] == 0 && $ank['ank_lov_2'] == 0 && $ank['ank_lov_3'] == 0 && $ank['ank_lov_4'] == 0 && 
$ank['ank_lov_5'] == 0 && $ank['ank_lov_6'] == 0 && $ank['ank_lov_7'] == 0 && $ank['ank_lov_8'] == 0 && 
$ank['ank_volos'] == NULL && $ank['ank_telosl'] == 0 && $ank['ank_haracter'] == NULL && $ank['ank_pirs'] == 0 && 
$ank['ank_tatu'] == 0 && $ank['ank_o_par'] == null){
?>
<div class="wrapper word_break" style="margin-bottom: -1px;"> 
<div class="title oh black text_left relative"> Для знакомств 
<a class="arrow_link right full_link" href="edit/love.php?id=<?= $ank['id']?>"> <img src="/style/i/edit_info.png" alt="" class="p16"> </a> 
</div>  
<div class="block">Заполните информацию о себе и найдите свою половинку!</div>  
</div>
<?
}
}

if ($ank['ank_orien'] != 0 OR $ank['ank_rost'] != 0 OR $ank['ank_ves'] != 0 OR $ank['ank_cvet_glas'] != NULL OR 
$ank['ank_lov_1'] != 0 OR $ank['ank_lov_2'] != 0 OR $ank['ank_lov_3'] != 0 OR $ank['ank_lov_4'] != 0 OR 
$ank['ank_lov_5'] != 0 OR $ank['ank_lov_6'] != 0 OR $ank['ank_lov_7'] != 0 OR $ank['ank_lov_8'] != 0 OR 
$ank['ank_volos'] != NULL OR $ank['ank_telosl'] != 0 OR $ank['ank_haracter'] != NULL OR $ank['ank_pirs'] != 0 OR 
$ank['ank_tatu'] != 0 OR $ank['ank_o_par'] != null){

?>
<div class="wrapper word_break">
<div class="title oh black text_left relative"> Для знакомств 
<?
if (isset($user) && $user['id'] == $ank['id'] || $user['level'] > $ank['level']){
?>
<a class="arrow_link right full_link" href="edit/love.php?id=<?= $ank['id']?>"> <img src="/style/i/edit_info.png" alt="" class="p16"> </a>
<?
}
?> 
</div>
<?

if (isset($user) && $user['id'] == $ank['id']){

if($ank['ank_lov_1'] != 0 OR $ank['ank_lov_2'] != 0 OR $ank['ank_lov_3'] != 0 OR $ank['ank_lov_4'] != 0 OR 
$ank['ank_lov_5'] != 0 OR $ank['ank_lov_6'] != 0 OR $ank['ank_lov_7'] != 0 OR $ank['ank_lov_8'] != 0){
$celb = '11';
}else{
$celb = '0';
}
if ($ank['ank_orien'] != 0){$ank_orie = '9';}else{$ank_orie = '0';}
if ($ank['ank_o_par'] != null){$ank_paraas = '11';}else{$ank_paraas = '0';}
if ($ank['ank_rost'] != 0){$ank_prost = '9';}else{$ank_prost = '0';}
if ($ank['ank_ves'] != 0){$ank_pves = '11';}else{$ank_pves = '0';}
if ($ank['ank_cvet_glas'] != NULL){$acvet_glas='9';}else{$acvet_glas='0';}
if ($ank['ank_volos'] != NULL){$aank_volos='11';}else{$aank_volos='0';}
if ($ank['ank_haracter'] != NULL){$aank_haracters='9';}else{$aank_haracters='0';}
if ($ank['ank_telosl'] != 0){$aank_telosls = '11';}else{$aank_telosls = '0';}
if($ank['ank_pirs'] != 0 OR $ank['ank_tatu'] != 0){$atatuazh = '9';}else{$atatuazh = '0';}


$love_is = $celb + $ank_orie + $ank_paraas + $ank_prost + $ank_pves + $acvet_glas + $aank_volos + $aank_haracters + $aank_telosls + $atatuazh;

if ($love_is < 100){
?>
<div class="block bord-botm">
<div> 
<table width="100%"> <tbody><tr> 
<td class="td_progress"> <div class="progress-item"> 
<div class="progress-item__runner progress-item__runner_light" style="width: <?= $love_is?>%"></div> 
</div> 
</td> 
<td class="td_progress_num"> <div class="progress-item__num"><?= $love_is?>%</div> </td> 
</tr> </tbody></table> 
</div>
</div>
<?
}
}

if (isset($_GET['plus_dating']))
{
mysql_query("UPDATE `user` SET `ank_dating` = '1' WHERE `id` = '".$ank['id']."' LIMIT 1");
$_SESSION['message'] = 'Анкета добавлена в знакомства. ';
header("Location: ?id=".$ank['id']."");
exit;
}

if (isset($_GET['minus_dating']))
{
mysql_query("UPDATE `user` SET `ank_dating` = '0' WHERE `id` = '".$ank['id']."' LIMIT 1");
$_SESSION['message'] = 'Анкета удалена из знакомств. ';
header("Location: ?id=".$ank['id']."");
exit;
}

?>
<div class="block bord-botm"> <span class="grey m"> Анкета в знакомствах: </span> 
<?
if (isset($user) && $user['id'] == $ank['id'] || $user['level'] > $ank['level']){
if($ank['ank_dating'] == 0){
?>   
<a href="?id=<?= $ank['id']?>&plus_dating" title="Добавить анкету в знакомства"><span class="black m">Нет</span>  </a>
<?
}else{
?>
<a href="?id=<?= $ank['id']?>&minus_dating" title="Убрать анкету из знакомств"><span class="green m">Да</span> </a>
<?
}
}else{
if($ank['ank_dating'] == 0){
?>   
<span class="black m">Нет</span>  
<?
}else{
?>
<span class="green m">Да</span> 
<?
}
}
?>  
</div>
<?


?>
<div class="block">
<?


if ($ank['ank_orien'] == 1){
$aank_orien = 'Гетеро ';
}elseif ($ank['ank_orien'] == 2){
$aank_orien = 'Би ';
}elseif ($ank['ank_orien'] == 3){
$aank_orien = ''.($ank['pol']==1? 'Гей':'Лесби').'';
}

if($ank['ank_orien'] != 0){
?>
<div class="pad_t_a"> <span class="grey">Ориентация:</span> <?= $aank_orien?> </div>
<?
}



if($ank['ank_lov_1'] != 0 OR $ank['ank_lov_2'] != 0 OR $ank['ank_lov_3'] != 0 OR $ank['ank_lov_4'] != 0 OR 
$ank['ank_lov_5'] != 0 OR $ank['ank_lov_6'] != 0 OR $ank['ank_lov_7'] != 0 OR $ank['ank_lov_8'] != 0){
?>
<div class="pad_t_a"> <span class="grey">Цель знакомства:</span> 
<?
if ($ank['ank_lov_1'] == 1)echo 'Дружба и общение; ';
if ($ank['ank_lov_2'] == 1)echo 'Флирт, СМС-переписка; ';
if ($ank['ank_lov_3'] == 1)echo 'Любовь, отношения; ';
if ($ank['ank_lov_4'] == 1)echo 'Брак, создание семьи; ';
if ($ank['ank_lov_5'] == 1)echo 'Виртуальный секс; ';
if ($ank['ank_lov_6'] == 1)echo 'Секс в реале; ';
if ($ank['ank_lov_7'] == 1)echo 'Ищу спонсора; ';
if ($ank['ank_lov_8'] == 1)echo 'Стану спонсором; ';
?>
</div>
<?
}

if($ank['ank_o_par'] != null){
?>
<div class="pad_t_a"> <span class="grey">О желаемом партнёре:</span> <?= text($ank['ank_o_par'])?> </div>
<?
}
if($ank['ank_rost'] != 0){
?>
<div class="pad_t_a"> <span class="grey">Рост:</span> <?= text($ank['ank_rost'])?> </div>
<?
}
if($ank['ank_ves'] != 0){
?>
<div class="pad_t_a"> <span class="grey">Вес:</span> <?= text($ank['ank_ves'])?> </div>
<?
}
if($ank['ank_cvet_glas'] != null){
?>
<div class="pad_t_a"> <span class="grey">Цвет глаз:</span> <?= text($ank['ank_cvet_glas'])?> </div>
<?
}
if($ank['ank_volos'] != null){
?>
<div class="pad_t_a"> <span class="grey">Цвет волос:</span> <?= text($ank['ank_volos'])?> </div>
<?
}


if ($ank['ank_telosl'] == 1){
$atel = 'Обычное ';
}elseif ($ank['ank_telosl'] == 2){
$atel = 'Худощавое';
}elseif ($ank['ank_telosl'] == 3){
$atel = 'Спортивное';
}elseif ($ank['ank_telosl'] == 4){
$atel = 'Мускулистое';
}elseif ($ank['ank_telosl'] == 5){
$atel = 'Плотное';
}elseif ($ank['ank_telosl'] == 6){
$atel = 'Полное';
}

if($ank['ank_haracter'] != null){
?>
<div class="pad_t_a"> <span class="grey">Характер:</span> <?= text($ank['ank_haracter'])?> </div>
<?
}

if($ank['ank_telosl']!=0){
?>
<div class="pad_t_a"> <span class="grey">Телосложение:</span> <?= $atel?> </div>
<?
}

if ($ank['ank_pirs'] == 1 OR $ank['ank_tatu'] == 1){
?>
<div class="pad_t_a"> <span class="grey">На теле есть:</span> 
<?
if ($ank['ank_pirs'] == 1)echo 'Пирсинг; ';
if ($ank['ank_tatu'] == 1)echo 'Татуировки; ';
?>
</div>
<?
}

?>
</div>
</div>
<?
}

if($ank['id'] != $user['id']){
?>
<div class="wrapper wbg">   
<table class="table__wrap"> <tbody><tr>  
<td class="table__cell" width="33%">     
<a href="/mail.php?id=<?= $ank['id']?>" class="link         "> 
<span>        <img src="/style/i/mail_grey.png" alt="" class="m">      <span class="m">  Написать </span>          </span>  
</a>     
</td> 
<?
if(isset($user)){
?>  
<td class="table__cell" width="33%">    
<?
if ($frend_new == 0 && $frend==0){
?> 
<a href="/user/frends/create.php?add=<?= $ank['id']?>" class="link blue">          
<img src="/style/i/befriends.png" alt="" class="m">      <span class="m">  Дружить </span>          
<!-- --><!-- --><!-- --></a><!-- -->
<?
}elseif ($frend_new == 1){
?>  
<a href="/user/frends/create.php?otm=<?= $ank['id']?>" class="link blue">          
<img src="/style/i/befriends_inprocess.png" alt="" class="m">      <span class="m">  Запрошено </span>          
<!-- --><!-- --><!-- --></a><!-- -->
<?
}elseif ($frend == 2){
?> 
<a href="/user/frends/create.php?del=<?= $ank['id']?>" data-action="friends_delete" class="link green">          
<img src="/style/i/befriends_on.png" alt="" class="m">      <span class="m">  Дружите </span>          
<!-- --><!-- --><!-- --></a><!-- -->
<?
}
?>
</td>  
<?
}
?>    
<td class="table__cell table__cell_last" width="33%">     
<div class="js-subscr_link">     
<a href="/user/gifts/?id=<?= $ank['id']?>" class="link        js-action_link "> 
<span>        <img src="/style/i/ico/gifts.png" alt="" class="m">      <span class="m">  Подарок </span>          </span>  
</a>    
</div>  
</td>  
</tr> </tbody></table>    
</div>
<?
}


?>
<a href="/user/?id=<?= $ank['id']?>" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?

include_once H.'sys/inc/tfoot.php';
?>