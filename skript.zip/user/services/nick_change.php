<?

include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';


$set['title'] = 'Изменение ника : Доп. услуги : ' . $user['nick'];
include_once H.'sys/inc/thead.php';
title();

if (!isset($user)){
	$_SESSION['err'] = 'Пользоваться Доп. услугами, могут только пользователи.';
	header("location: /aut.php");
	exit;
}

if (isset($_POST['nick']) && $_POST['nick'] != NULL && $user['money'] > 100)
{
	if (mysql_result(mysql_query("SELECT COUNT(*) FROM `user` WHERE `nick` = '".my_esc($_POST['nick'])."'"),0) == 0)
	{
		$nick = my_esc($_POST['nick']);
		
		if(!preg_match("#^([A-z0-9\-\_\ ])+$#ui", $_POST['nick']))$err[] = 'В нике присутствуют запрещенные символы!';

		if (strlen2($nick) < 5)$err[] = 'Вы ввели короткий ник.';
		if (strlen2($nick) > 16)$err[] = 'Вы ввели длинный ник.';
	}
	else 
	$err[] = 'Ник <b>'.htmlspecialchars($_POST['nick']).'</b> уже занят.';

	if (!isset($err))
	{
		mysql_query("UPDATE `user` SET `money` = '".($user['money']-100)."', `nick` = '".$nick."' WHERE `id` = '".$user['id']."' LIMIT 1");
		$_SESSION['message'] = "Ваш Ник успешно изменен.";
		header("location: ?");
		exit;
	}
}

// Меняем только размер букв
if (isset($_POST['nick_edit']) && $_POST['nick_edit'] != NULL && $user['nick_edit'] == 0)
{
	$nick = my_esc($_POST['nick_edit']);
	$us_nick = mb_strtolower($user['nick'], 'UTF-8'); 
	$form_nick = mb_strtolower($nick, 'UTF-8');
 
	if ($us_nick != $form_nick)$err[] = 'Здесь можно поменять только размер букв. При этом их последовательность должна оставаться прежней.';
	
	if (!isset($err))
	{
		mysql_query("UPDATE `user` SET `nick` = '".$nick."', `nick_edit` = '1' WHERE `id` = '".$user['id']."' LIMIT 1");
		$_SESSION['message'] = 'Вы успешно изменили размеры букв в нике.';
		header("location: ?");
		exit;
	}
}

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $user['id']?>"><?= $user['nick']?></a> </span>   <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/services/">Доп. услуги</a> </span>  <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Изменение ника</span> </span>       </div>
<?

err();

$cases = array('монета', 'монеты', 'монет');

?>
<div class="list_item gradient_block1"> Изменение ника стоит <span style="color:green"><b>100</b></span> монет.
<br> У вас на счету:  <span style="color:red"><?= des2num($user['money'], $cases)?></span>  
<div class="overfl_hid"> <a href="#" class="right">Пополнить счет</a> </div> 
</div>
<?

if($user['money'] < 100){
?>
<div class="list_item" style="background:#eaeef4;"> У вас не хватает монет для изменения ника. </div>
<?
}else{
?>
<div class="stnd_padd" style="padding-bottom:1px;"> Введите новый ник: </div>
<div class="list_item gradient_block1"> 
<form method="post" action="nick_change.php"> 
<input name="nick" value="" maxlength="16" type="text">  
<input value="Изменить" class="main_submit" type="submit"><br>   
</form> 
</div>
<?
}
if ($user['nick_edit'] == 0)
{
?>
<div class="stnd_padd" style="padding-bottom:1px;"> У вас есть возможность один раз бесплатно поменять размеры букв в нике. Для того, чтобы это сделать, введите ваш ник в новом формате: </div>
<div class="list_item gradient_block1"> 
<form method="post" action="nick_change.php"> 
<input name="nick_edit" value="<?= $user['nick']?>" maxlength="16" type="text">  
<input value="Изменить" class="main_submit" type="submit"><br>   
</form> 
</div>
<?
}
?>
<a href="/user/services/" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?


include_once H.'sys/inc/tfoot.php';

?>