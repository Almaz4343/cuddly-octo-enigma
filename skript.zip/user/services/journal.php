<?

include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';


$set['title'] = 'Журнал операций : Доп. услуги : ' . $user['nick'];
include_once H.'sys/inc/thead.php';
title();

if (!isset($user)){
	$_SESSION['err'] = 'Пользоваться Доп. услугами, могут только пользователи.';
	header("location: /aut.php");
	exit;
}


?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $user['id']?>"><?= $user['nick']?></a> </span>   <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/services/">Доп. услуги</a> </span>  <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Журнал операций</span> </span>       </div>
<?

err();

$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `money` WHERE `id_user` = '".$user['id']."'"),0);

if($k_post == 0){
$dop_div = '';
}else{
$dop_div = ' style="border-bottom:0;"';
}
?>
<div class="wrapper"<?= $dop_div?>> 
<div class="block bord-botm"> 
<div class="header b mt_0"> Журнал операций </div> 
<div class="grey"> Здесь отображаются все операции с вашим счётом: пополнение, подключение услуг, отправка подарков и прочее. </div> 
</div>
<div class="list f-c_fll">
<?

$set['p_str'] = '15';
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str']*$page-$set['p_str'];

if ($k_post == 0){
?>
<div class="col_blocks block grey"> Список операций пуст.  </div>
<?
}
else{

$q = mysql_query("SELECT * FROM `money` WHERE `id_user` = '$user[id]' ORDER BY id DESC LIMIT $start, $set[p_str]");


while($money = mysql_fetch_array($q)){

$cases = array('монета', 'монеты', 'монет');

?>
<div class="block  bord-botm grey"> 
<span class="comment_date lgrey"><?= vremja($money['time'])?></span> 
<?
if($money['minus_plus'] == 0){
?>
<span class="red">-<?= des2num($money['money'], $cases)?></span>
<?
}else{
?>
<span class="green">+<?= des2num($money['money'], $cases)?></span>
<?
}
?> 
<br><?= text($money['msg'])?> 
</div>
<?
}
}

?>
</div>
</div>
<?

if ($k_page > 1)str('?',$k_page,$page); // Вывод страниц

?>
<a href="/user/services/" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?


include_once H.'sys/inc/tfoot.php';

?>