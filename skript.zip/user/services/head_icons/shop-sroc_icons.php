<?
/**
 * Autor : Tw1nGo :)
**/

$set['title'] = 'Иконки : Доп. услуги : ' . $user['nick'];

include_once H.'sys/inc/thead.php';
only_reg();
title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $user['id']?>"><?= $user['nick']?></a> </span>   <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/services/">Доп. услуги</a> </span>  <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Иконки</span> </span>       </div>
<?

err();


// ## Сроки выбора для иконки
$d7 =    5; // 7 дней
$d30 =  12; // 1 месяц
$d180 = 60; // 6 месяцев
$d365 = 99; // 1 год
$d0 =  199; // навсегда


// ## Определяем ID иконки :)
$IDIcon = intval($_GET['head']);
// ## Если выбрали ID которого нет! ТО нах на главную :)
if($IDIcon < 1 or $IDIcon > 127)  header('Location: /?'.SID);

$MYicon = mysql_fetch_assoc(mysql_query("SELECT * FROM `spaces_icons` WHERE `id_user` = '".$user['id']."' AND `id_icon` = '".$IDIcon."' LIMIT 1"));
if($MYicon){
$_SESSION['message']='У Вас уже куплена эта иконка';
header('Location: /user/services/head_icons/?loc=3'.SID);
exit;
}


if(isset($_POST['time']) and (isset($_GET['get']))) {

if($_POST['time'] == '7') 
{
if($user['money'] >= $d7) 
{
$d7_time = $time+604800;
mysql_query("DELETE FROM `spaces_icons` WHERE `id_user` = '".$user['id']."'");
mysql_query("UPDATE `user` SET `money` = '".($user['money']-$d7)."' WHERE `id` = '$user[id]' LIMIT 1");
mysql_query("UPDATE `user` SET `ico_onn` = '1' WHERE `id` = '$user[id]' LIMIT 1");
mysql_query("INSERT INTO `spaces_icons` (`id_user`, `id_icon`, `time`) values('$user[id]', '$IDIcon', '$d7_time')");

// Отправляем в журнал операций
$msg_journal = "подключение иконки пользователя ";
mysql_query("INSERT INTO `money` (`id_user`, `money`, `minus_plus`, `msg`, `time`) values('$user[id]', '$d7', '0', '$msg_journal', '$time')");


header('Location: /user/services/head_icons/?loc=3'.SID);
$_SESSION['message']='Иконка успешно приобретена!';

}
else
{
echo '<div class="err"> Недостаточно средств!</div>';
}
}

if($_POST['time'] == '30') 
{
if($user['money'] >= $d30) 
{
$d30_time = $time+2592000;
mysql_query("DELETE FROM `spaces_icons` WHERE `id_user` = '".$user['id']."'");
mysql_query("UPDATE `user` SET `money` = '".($user['money']-$d30)."' WHERE `id` = '$user[id]' LIMIT 1");
mysql_query("UPDATE `user` SET `ico_onn` = '1' WHERE `id` = '$user[id]' LIMIT 1");
mysql_query("INSERT INTO `spaces_icons` (`id_user`, `id_icon`, `time`) VALUES ('".$user['id']."', '".$IDIcon."', '".$d30_time."')"); 
// Отправляем в журнал операций
$msg_journal = "подключение иконки пользователя ";
mysql_query("INSERT INTO `money` (`id_user`, `money`, `minus_plus`, `msg`, `time`) values('$user[id]', '$d30', '0', '$msg_journal', '$time')");


header('Location: /user/services/head_icons/?loc=3'.SID);
$_SESSION['message']='Иконка успешно приобретена!';

}
else
{
echo '<div class="err"> Недостаточно средств!</div>';
}
}

if($_POST['time'] == '180') 
{
if($user['money'] >= $d180) 
{
$d180_time = $time+15552000;
mysql_query("DELETE FROM `spaces_icons` WHERE `id_user` = '".$user['id']."'");
mysql_query("UPDATE `user` SET `money` = '".($user['money']-$d180)."' WHERE `id` = '$user[id]' LIMIT 1");
mysql_query("UPDATE `user` SET `ico_onn` = '1' WHERE `id` = '$user[id]' LIMIT 1");
mysql_query("INSERT INTO `spaces_icons` (`id_user`, `id_icon`, `time`) VALUES ('".$user['id']."', '".$IDIcon."', '".$d180_time."')"); 
// Отправляем в журнал операций
$msg_journal = "подключение иконки пользователя ";
mysql_query("INSERT INTO `money` (`id_user`, `money`, `minus_plus`, `msg`, `time`) values('$user[id]', '$d180', '0', '$msg_journal', '$time')");


header('Location: /user/services/head_icons/?loc=3'.SID);
$_SESSION['message']='Иконка успешно приобретена!';

}
else
{
echo '<div class="err"> Недостаточно средств!</div>';
}
}

if($_POST['time'] == '365') 
{
if($user['money'] >= $d365) 
{
$d365_time = $time+31536000;
mysql_query("DELETE FROM `spaces_icons` WHERE `id_user` = '".$user['id']."'");
mysql_query("UPDATE `user` SET `money` = '".($user['money']-$d365)."' WHERE `id` = '$user[id]' LIMIT 1");
mysql_query("UPDATE `user` SET `ico_onn` = '1' WHERE `id` = '$user[id]' LIMIT 1");
mysql_query("INSERT INTO `spaces_icons` (`id_user`, `id_icon`, `time`) VALUES ('".$user['id']."', '".$IDIcon."', '".$d365_time."')"); 
// Отправляем в журнал операций
$msg_journal = "подключение иконки пользователя ";
mysql_query("INSERT INTO `money` (`id_user`, `money`, `minus_plus`, `msg`, `time`) values('$user[id]', '$d365', '0', '$msg_journal', '$time')");


header('Location: /user/services/head_icons/?loc=3'.SID);
$_SESSION['message']='Иконка успешно приобретена!';

}
else
{
echo '<div class="err"> Недостаточно средств!</div>';
}
}

if($_POST['time'] == '0') 
{
if($user['money'] >= $d0) 
{
$d0_time = $time+9999999999;
mysql_query("DELETE FROM `spaces_icons` WHERE `id_user` = '".$user['id']."'");
mysql_query("UPDATE `user` SET `money` = '".($user['money']-$d0)."' WHERE `id` = '$user[id]' LIMIT 1");
mysql_query("UPDATE `user` SET `ico_onn` = '1' WHERE `id` = '$user[id]' LIMIT 1");
mysql_query("INSERT INTO `spaces_icons` (`id_user`, `id_icon`, `time`) VALUES ('".$user['id']."', '".$IDIcon."', '".$d0_time."')"); 
// Отправляем в журнал операций
$msg_journal = "подключение иконки пользователя ";
mysql_query("INSERT INTO `money` (`id_user`, `money`, `minus_plus`, `msg`, `time`) values('$user[id]', '$d0', '0', '$msg_journal', '$time')");


header('Location: /user/services/head_icons/?loc=3'.SID);
$_SESSION['message']='Иконка успешно приобретена!';

}
else
{
echo '<div class="err"> Недостаточно средств!</div>';
}
}

}

?>
<div class="tabs_block oh"> 
<span class="tab_active tab_item left black"><b>Магазин</b></span>  
<a href="/user/services/head_icons/?loc=3" class="left tab_item" style="padding-bottom:8px">Мои иконки</a>  
</div>
<div class="tabs_line"></div>

<div class="list_item p14"> 
<b class="grey m">Выбрали:</b> <img src="/user/services/head_icons/head/color/<?= $IDIcon?>.png" alt="" class="m"> 
</div>

<form action="/user/services/head_icons/?loc=2&get=ok&head=<?= $IDIcon?>" method="post"> 
<div class="list_item"> 
<b class="grey">Стоимость использования:</b><br>  
<div class="small_padd pl0 pr0"> 
<input name="time" value="7" id="time_7" checked="checked" type="radio"> 
<label for="time_7"> 7 дней - <span><?= $d7?> монет</span> </label> 
</div>  
<div class="small_padd pl0 pr0"> 
<input name="time" value="30" id="time_30" type="radio"> 
<label for="time_30"> 1 месяц - <span><?= $d30?> монет</span> </label> 
</div>  
<div class="small_padd pl0 pr0"> 
<input name="time" value="180" id="time_180" type="radio"> 
<label for="time_180"> 6 месяцев - <span><?= $d180?> монет</span> </label> 
</div>  
<div class="small_padd pl0 pr0"> 
<input name="time" value="365" id="time_365" type="radio"> 
<label for="time_365"> 1 год - <span><?= $d365?> монет</span> </label> 
</div>  
<div class="small_padd pl0 pr0"> 
<input name="time" value="0" id="time_0" type="radio"> 
<label for="time_0"> навсегда - <span><?= $d0?> монет</span> </label> 
</div>    
</div> 
<div class="list_item"> 
<input value="Купить" id="mainSearch" class="main_submit" type="submit"> 
</div> 
</form>

<a href="/user/services/head_icons/" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>







