<?

/**
* Autor : Tw1nGo
**/

$set['title'] = 'Иконки : Доп. услуги : ' . $user['nick'];

include_once H.'sys/inc/thead.php';
title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $user['id']?>"><?= $user['nick']?></a> </span>   <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/services/">Доп. услуги</a> </span>  <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Иконки</span> </span>       </div>
<?

err();

?>
<div class="tabs_block oh"> 
<span class="tab_active tab_item left black"><b>Магазин</b></span>  
<a href="?loc=3" class="left tab_item" style="padding-bottom:8px">Мои иконки</a>  
</div>

<div class="tabs_line"></div>

<div class="list_item">   <div class="oh">  
<?
$x = 0;
while ($x++ < 127){
$icon = mysql_fetch_assoc(mysql_query("SELECT * FROM `spaces_icons` WHERE `id_user` = '".$user['id']."' AND `id_icon` = '$x'  LIMIT 1"));
?>
<a href="?head=<?= $x?>&amp;loc=2" class="adv_user_link wa mt_m p14 font0">
<?
if($icon['time'] > $time){
?>
<i class="i bought_head"></i>
<?
}
?>
<img src="head/color/<?= $x?>.png" alt="">
</a>
<?
}
?>
</div></div>


<a href="/user/services/" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?

?>