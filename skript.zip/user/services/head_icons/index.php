<?
/**
 * & CMS Name :: DCMS-Social
 * & Author   :: Igor Slepko
 * & Contacts :: http://gix.su/user/Tw1nGo
 */
include_once '../../../sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';

$act = isset($_GET['loc']) ? my_esc($_GET['loc']) : null;

switch ($act) {

default:
include_once H.'user/services/head_icons/shop_icons.php';
break;

case '1':
include_once H.'user/services/head_icons/shop_icons.php';
break;

case '2':
include_once H.'user/services/head_icons/shop-sroc_icons.php';
break;

case '3':
include_once H.'user/services/head_icons/my_icons.php';
break;

}

include_once H.'sys/inc/tfoot.php';
?>