<?

/**
 * Autor : Tw1nGo
**/

$set['title'] = 'Иконки : Доп. услуги : ' . $user['nick'];

include_once H.'sys/inc/thead.php';
only_reg();
title();



if (isset($_GET['setIcon'])) {


$id = mysql_fetch_assoc(mysql_query("SELECT * FROM `spaces_icons` WHERE `id_user` = '".$user['id']."'  LIMIT 1"));
mysql_query("UPDATE `spaces_icons` SET `id_icon` = '".$id['id_icon']."' WHERE `id_user` = '$user[id]' LIMIT 1");
mysql_query("UPDATE `user` SET `ico_onn` = '1' WHERE `id` = '$user[id]' LIMIT 1");	
$_SESSION['message'] = 'Установлена новая иконка пользователя ';
header('Location: ?loc=3');
exit;

}
if (isset($_GET['setDefault']) && $_GET['setDefault'] == '1') {

  	mysql_query("UPDATE `user` SET `ico_onn` = '0' WHERE `id` = '$user[id]' LIMIT 1");	
  	$_SESSION['message'] = 'Иконка пользователя изменена на стандартную ';
  	header('Location: ?loc=3');
  	exit;

}

err();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $user['id']?>"><?= $user['nick']?></a> </span>   <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/services/">Доп. услуги</a> </span>  <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Иконки</span> </span>       </div>
<?

$icon = mysql_fetch_assoc(mysql_query("SELECT * FROM `spaces_icons` WHERE `id_user` = '".$user['id']."'  LIMIT 1"));
$MYicon = mysql_fetch_assoc(mysql_query("SELECT * FROM `spaces_icons` WHERE `id_user` = '".$user['id']."' AND `vid` = '1' LIMIT 1"));
$NOicon = mysql_fetch_assoc(mysql_query("SELECT * FROM `spaces_icons` WHERE `id_user` = '".$user['id']."' AND `vid` = '0' LIMIT 1"));

?>
<div class="tabs_block oh"> 
<a href="?loc=1" class="tab_item left" style="padding-bottom:8px">Магазин</a> 
<span class="left tab_item tab_active black" style="padding-bottom:8px"><b>Мои иконки</b></span> 
</div>
<div class="tabs_line"></div>
<div class="list_item"> 
<div class="bottom_pad"> <b class="grey">Доступно:</b> </div>  
<div class="oh">  
<?


if($user['ico_onn'] == 1) {
?>
<a href="?loc=3&amp;setDefault=1" class="adv_user_link wa mt_m p14"><?= group_ico($user['id'])?></a> 
<? 
}else{
?>
<span style="background:#e4e1e1;" class="adv_user_link wa mt_m p14"><?= group_ico($user['id'])?></span>
<?
}






$q = mysql_query("SELECT * FROM `spaces_icons` WHERE `id_user` = '".$user['id']."'ORDER BY time DESC");
while ($post = mysql_fetch_assoc($q))
{
if($user['ico_onn'] == 0){

?> 
<a href="?loc=3&amp;setIcon=<?= $icon['id_icon']?>" class="adv_user_link wa mt_m p14">
<img src="/user/services/head_icons/head/color/<?= $post['id_icon']?>.png" alt="">
</a>  


<?
}else{
?>
<span style="background:#e4e1e1;" class="adv_user_link wa mt_m p14">
<img src="/user/services/head_icons/head/color/<?=$post['id_icon']?>.png" alt="">
</span>
<?
}
}
?>
</div>
<?

if($user['ico_onn'] != 0){
?>
<div class="pad_t_a grey"> Данная иконка куплена до <?= vremja($icon['time'])?>. </div>
<?
}
?>


</div>

<a href="/user/services/head_icons/" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?

?>