<?

include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';


$set['title'] = 'Доп. услуги : ' . $user['nick'];
include_once H.'sys/inc/thead.php';
title();

if (!isset($user)){
	$_SESSION['err'] = 'Пользоваться Доп. услугами, могут только пользователи.';
	header("location: /aut.php");
	exit;
}


?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $user['id']?>"><?= $user['nick']?></a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Доп. услуги</span> </span>       </div>
<?

err();

$cases = array('монета', 'монеты', 'монет');

?>
<div class="block-wrapper t_center grey mb0"> Заранее благодарим вас за использование доп. услуг. Этим вы помогаете развитию сайта. </div>

<div class="wrapper"> 
<div class="block bord-botm"> 
<div class="header b mt_0 upcs"> Состояние счёта </div> 
<div class="grey"> У вас на счету: <span class="red"><?= des2num($user['money'], $cases)?></span>    <br>
<br> Монеты это внутренняя валюта сайта. С помощью монет вы можете оплатить различные дополнительные услуги.<br>    
</div> 
</div>     
<a href="#" class="link  blue   is_final   "> 
<span>
<!--     -->
<img src="/style/i/ico/add_blue.png" alt="" class="m"> <!--   --><span class="m">Пополнить (скоро)</span> 
<!--   -->
</span>  
</a>    
</div>

<div class="wrapper">
<div class="title oh black">    <span class="block-title">Доступные услуги</span>     </div>
<div class="wbg grey">  <div class="list f-c_fll">


<a href="nick_change.php" class="link    darkblue  arrow    "> <span>        
<table class="table__wrap table_no_borders"> <tbody><tr> 
<td class="table__cell text_left" width="42px"> <img src="/style/i/nick_b.png" alt="" width="32px" height="32px"> </td> 
<td class="table__cell text_left">      
<span class="m">  <div class="b pad_b_a"> Изменение ника </div>   </span>   
<div class="grey m lbl_sub_text"> Возможность изменить свой ник на новый, при этом все ваши записи, друзья и файлы останутся. </div>     
</td> 
</tr> </tbody></table>      
</span>  </a>


<a href="/user/services/head_icons/?" class="link    darkblue  arrow    "> <span>        
<table class="table__wrap table_no_borders"> <tbody><tr> 
<td class="table__cell text_left" width="42px"> <img src="//c.spac.me/i/head_icons_b.png" alt="" width="32px" height="32px"> </td> 
<td class="table__cell text_left">      
<span class="m">  <div class="b pad_b_a"> Изменить иконку пользователя </div>   </span>   
<div class="grey m lbl_sub_text"> Иконка возле ника пользователя отображается на сайте. Иконки можно дарить своим друзьям. </div>     
</td> </tr> </tbody></table>      
</span>  
</a>

</div></div>
</div>

<div class="wrapper">     
<a href="journal.php" class="link    darkblue  arrow    "> 
<span>        <img src="/style/i/ed_middle.png" alt="" class="m">      <span class="m">  Журнал операций </span>          </span>  
</a>     
</div>

<a href="/user/?id=<?= $user['id']?>" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?


include_once H.'sys/inc/tfoot.php';

?>