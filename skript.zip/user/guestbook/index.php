<?
/**
 * & Author   :: Igor Slepko
 * & Contacts :: http://gix.su/user/Tw1nGo
**/
include_once '../../sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';


$act = isset($_GET['S']) ? my_esc($_GET['S']) : null;

switch ($act) {

default:
include_once H.'user/guestbook/guest_index.php';
break;

case 'set':
include_once H.'user/guestbook/guest_settings.php';
break;

}

include_once H.'sys/inc/tfoot.php';
?>