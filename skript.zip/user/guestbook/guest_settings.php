<?

// Определяем uID юзера
if (isset($user))$ank['id'] = $user['id'];
if (isset($_GET['uid']))$ank['id'] = intval($_GET['uid']);

$ank = get_user($ank['id']);

if (!isset($_GET['uid']) || !$ank || $ank['id'] == 0){
$_SESSION['err'] = 'Ошибка. Гостевая юзера не найдена. ';
header("Location: /user/guestbook/?uid=$user[id]".SID);exit;
}

if (isset($user) && $user['id'] != $ank['id']) {
$_SESSION['err'] = 'Ошибка! Попытайтесь еще раз.';
header('Location: /user/guestbook/?uid='.$user['id'].'');
exit;	
}

$set['title'] = "Настройки  : Гостевая : " . text($user['nick']);
include_once H.'sys/inc/thead.php';
title();


?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $ank['id']?>" class=""><?= $ank['nick']?></a> </span>  <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/guestbook/?uid=<?= $ank['id']?>" class="">Гостевая</a> </span>   <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Гостевая</span> </span>       </div>
<?


$userSet = mysql_fetch_array(mysql_query("SELECT * FROM `user_set` WHERE `id_user` = '".$user['id']."' LIMIT 1"));

if (isset($_POST['cfms'])) {

 // Просмотр гостевой
if (isset($_POST['guestbook_access']) && ($_POST['guestbook_access']==0 || $_POST['guestbook_access']==1 || $_POST['guestbook_access']==2))
{
mysql_query("UPDATE `user_set` SET `guestbook_access` = '".intval($_POST['guestbook_access'])."' WHERE `id_user` = '$user[id]'");
}

 // Писать могут
if (isset($_POST['guestbook_komm']) && ($_POST['guestbook_komm']==0 || $_POST['guestbook_komm']==1 || $_POST['guestbook_komm']==2))
{
mysql_query("UPDATE `user_set` SET `guestbook_komm` = '".intval($_POST['guestbook_komm'])."' WHERE `id_user` = '$user[id]'");
}

	$_SESSION['message'] = 'Настройки Гостевой успешно изменены.';
	header('Location: /user/guestbook/?uid='.$user['id'].'');
}

err();


?>
<form action="" method="post">  
<div>  

<div class="list_item light_border_bottom">
<b>Читатели:</b>
<br>
<input name="guestbook_access" value="0" <?= ($userSet['guestbook_access'] == 0 ? " checked='checked'":null)?> type="radio"> 
<img class="p13" src="/style/i/status_all.png" alt="Все"> Все  
<br>
<input name="guestbook_access" value="1" <?= ($userSet['guestbook_access'] == 1 ? " checked='checked'":null)?> type="radio"> 
<img class="p13" src="/style/i/status_friends.png" alt="Друзья"> Друзья
<br> 
<input name="guestbook_access" value="2" <?= ($userSet['guestbook_access'] == 2 ? " checked='checked'":null)?> type="radio"> 
<img class="p13" src="/style/i/status_me.png" alt="Никто"> Никто
</div>   

<div class="list_item light_border_bottom">
<b>Писатели:</b>
<br>
<input name="guestbook_komm" value="0" <?= ($userSet['guestbook_komm'] == 0 ? " checked='checked'":null)?> type="radio"> 
<img class="p13" src="/style/i/status_all.png" alt="Все"> Все<br>  
  
<input name="guestbook_komm" value="1" <?= ($userSet['guestbook_komm'] == 1 ? " checked='checked'":null)?> type="radio"> 
<img class="p13" src="/style/i/status_friends.png" alt="Друзья"> Друзья<br>  


<input name="guestbook_komm" value="2" <?= ($userSet['guestbook_komm'] == 2 ? " checked='checked'":null)?> type="radio"> 
<img class="p13" src="/style/i/status_me.png" alt="Никто"> Никто<br>  
</div> 

<div class="stnd_padd vlight_border_bottom"> 
<input name="cfms" value="Изменить" class="main_submit" type="submit">   
</div> 
</div> 
</form>

<a href="/user/guestbook/?uid=<?= $ank['id']?>" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Гостевая/<?= $ank['nick']?>  </a>
<?

?>