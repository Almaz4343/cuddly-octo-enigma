<?

/**
 * & Nick     :: Tw1nGo
 * & Author   :: Igor Slepko
 * & Contacts :: http://gix.su/user/Tw1nGo
**/


// Определяем uID юзера
if (isset($user))$ank['id'] = $user['id'];
if (isset($_GET['uid']))$ank['id'] = intval($_GET['uid']);

$ank = get_user($ank['id']);
$anka = get_user($ank['id']);
if (!isset($_GET['uid']) || !$ank || $ank['id'] == 0){
$_SESSION['err'] = 'Ошибка. Гостевая юзера не найдена. ';
header("Location: /user/guestbook/?uid=$user[id]".SID);exit;
}

	
$uSet = mysql_fetch_array(mysql_query("SELECT * FROM `user_set` WHERE `id_user` = '$ank[id]'  LIMIT 1"));
$frend = mysql_result(mysql_query("SELECT COUNT(*) FROM `frends` WHERE (`user` = '$user[id]' AND `frend` = '$ank[id]') OR (`user` = '$ank[id]' AND `frend` = '$user[id]') LIMIT 1"),0);
	
if ($ank['id'] != $user['id'] && $user['group_access'] == 0){	

if($uSet['guestbook_access'] > 0){
$set['title'] = 'Ошибка'; // заголовок страницы
include_once H.'sys/inc/thead.php';
title();


?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Ошибка</span> </span>       </div>
<?
	
if ($uSet['guestbook_access'] == 1 && $frend != 2) // Если только для друзей
{
?>
<div class="list_item light_border_bottom error_block">  Внимание!  <br> Гостевая книга открыта только для друзей. </div>
<?	
}
	
if ($uSet['guestbook_access'] == 2) // Если закрыта гостевая полностью
{
?>
<div class="list_item light_border_bottom error_block">  Внимание!  <br> Гостевая книга закрыта для всех. </div>
<?	
}
?>
<a href="/user/?id=<?= $ank['id']?>" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?
	include_once H.'sys/inc/tfoot.php';
	exit;
}	
}

if (isset($_POST['smiles'])){
header("Location: /plugins/smiles/".SID);
exit;
}
if (isset($_POST['bb_teg'])){
header("Location: /plugins/rules/bb-code.php".SID);
exit;
}

if (isset($user) && isset($_GET['otvet'])){
$guest_otvet = mysql_fetch_assoc(mysql_query("SELECT * FROM `user_guest` WHERE `uid` = '".intval($_GET['otvet'])."' LIMIT 1"));
$guest_user = mysql_fetch_assoc(mysql_query("SELECT * FROM `user` WHERE `id` = '".$guest_otvet['id_user']."' LIMIT 1"));


if (!$guest_otvet || $guest_otvet['uid'] == 0 || !$guest_user || $guest_user['id'] == 0 || $user['id'] == $guest_user['id']){
$otv_post = 0;
}else{
$otv_post = 1;
}
}else{
$otv_post = 0;
}



if (isset($_GET['like'])){
$guest_like = mysql_fetch_assoc(mysql_query("SELECT * FROM `user_guest` WHERE `uid` = '" . intval($_GET['like']) . "' LIMIT 1"));
$anks = get_user($guest_like['id_user']);
if (isset($user)){
if ($user['id'] != $anks['id']){
if (isset($_GET['like']) && mysql_result(mysql_query("SELECT COUNT(*) FROM `user_guest_like` WHERE
 `id_post` = '$guest_like[uid]' AND `id_user` = '$user[id]' LIMIT 1"),0) == 0){
mysql_query("INSERT INTO `user_guest_like` (`id_user`, `id_post`, `like`, `dlike`) VALUES ('$user[id]', '$guest_like[uid]', '1', '0')");
mysql_query("UPDATE `user` SET `balls` = '".($ank['balls']+3)."' ,`rating` = '".($ank['rating']+1)."' WHERE `id` = '$ank[id]' LIMIT 1");
}else{
$_SESSION['err'] = 'Вы уже голосовали.';
}
}else{
$_SESSION['err'] = 'Вы не можете голосовать за свои записи.';
}
}else{
$_SESSION['err'] = 'Вы не можете голосовать, вы не авторизованы.';
}
header('Location: /user/guestbook/?uid='.$ank['id'].'');
exit;	
}

if (isset($_GET['dlike'])){
$guest_like = mysql_fetch_assoc(mysql_query("SELECT * FROM `user_guest` WHERE `uid` = '" . intval($_GET['dlike']) . "' LIMIT 1"));
$anks = get_user($guest_like['id_user']);
if (isset($user)){
if ($user['id'] != $anks['id']){
if (isset($_GET['dlike']) && mysql_result(mysql_query("SELECT COUNT(*) FROM `user_guest_like` WHERE
 `id_post` = '$guest_like[uid]' AND `id_user` = '$user[id]' LIMIT 1"),0) == 0){
mysql_query("INSERT INTO `user_guest_like` (`id_user`, `id_post`, `like`, `dlike`) VALUES ('$user[id]', '$guest_like[uid]', '0', '1')");
mysql_query("UPDATE `user` SET `balls` = '".($ank['balls']+3)."' WHERE `id` = '$ank[id]' LIMIT 1");
}else{
$_SESSION['err'] = 'Вы уже голосовали.';
}
}else{
$_SESSION['err'] = 'Вы не можете голосовать за свои записи.';
}
}else{
$_SESSION['err'] = 'Вы не можете голосовать, вы не авторизованы.';
}
header('Location: /user/guestbook/?uid='.$ank['id'].'');
exit;	
}




// Удаление комма 
if (isset($_GET['dell']))
{
	$guest_dell = mysql_fetch_assoc(mysql_query("SELECT * FROM `user_guest` WHERE `uid` = '" . intval($_GET['dell']) . "' LIMIT 1"));
	
	if ($guest_dell['id_user'] == $user['id'] || $user['level'] >= 4)
	{
		mysql_query("DELETE FROM `user_guest` WHERE `uid` = '$guest_dell[uid]' LIMIT 1");
		$_SESSION['message'] = 'Запись успешно удалена';
		header('Location: /user/guestbook/?uid='.$ank['id'].'');
		exit;		
	}
}

if (isset($_POST['msg']) && isset($user)) {
$msg = $_POST['msg'];
if ($mat)$err[] = 'В тексте сообщения обнаружен мат: '.$mat;
elseif (strlen2($msg) > 2000)$err[] = 'Комментарий не должен быть более чем 2000 символов.';
elseif (strlen2($msg) == 0)$err[] = 'Комментарий не должен быть пустым.';
elseif (strlen2($msg) == 1)$err[] = 'Комментарий слишком короткий.';
elseif (mysql_result(mysql_query("SELECT COUNT(*) FROM `user_guest` WHERE `id_user` = '$user[id]' AND  `id_guest` = '$ank[id]' AND `msg` = '".my_esc($msg)."' LIMIT 1"),0)!=0)$err='Ваше сообщение повторяет предыдущее..';
elseif (!isset($err)){

// Если ответ
if ($otv_post == 0){
mysql_query("INSERT INTO `user_guest` (`id_user`, `time`, `msg`, `id_guest`) values('$user[id]', '$time', '".my_esc($msg)."', '$ank[id]')");
if (isset($user) && $user['id'] != $ank['id']){
$otvet_msg = "Пользователь ".$user['nick']." написал у Вас в гостевой.  [url=/user/guestbook/?uid=".$user['id']."]Подробнее...[/url]";
mysql_query("INSERT INTO `mail` (`id_user`, `id_kont`, `time`, `msg`, `read`) VALUES ('0', '".$ank['id']."', '".$time."', '".my_esc($otvet_msg)."', '0')");

}
}
// Если нет ответа
else{
mysql_query("INSERT INTO `user_guest` (`id_user`, `time`, `msg`, `reply_id_user`, `id_guest`) values('$user[id]', '$time', '".my_esc($msg)."', '$guest_user[id]', '$ank[id]')");

if (isset($user) && $user['id'] != $guest_user['id']){
$otvet_msg = "Пользователь ".$user['nick']." ответил Вам на сообщение в гостевой.  [url=/user/guestbook/?uid=".$ank['id']."]Подробнее...[/url]";
}
mysql_query("INSERT INTO `mail` (`id_user`, `id_kont`, `time`, `msg`, `read`) VALUES ('0', '".$guest_user['id']."', '".$time."', '".my_esc($otvet_msg)."', '0')");
}

header("Location: /user/guestbook/?uid=$ank[id]".SID);exit;
}
}

$set['title']= 'Гостевая : ' . text($ank['nick']);
include_once H.'sys/inc/thead.php';
title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $ank['id']?>" class=""><?= $ank['nick']?></a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Гостевая</span> </span>       </div>
<?


err();



$set['p_str'] = '15';
$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `user_guest` WHERE `id_guest` = '$ank[id]'"),0);
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str']*$page-$set['p_str'];

?>
<a name="page-up"></a>
<link rel="stylesheet" type="text/css" href="http://spac.me/css/custom/CommentWidget/CommentsWap.css?r=1447p" data-tmp_css="1" />
<div class="header oh text_left"> <b class="upcs m">Комментарии (<?= $k_post?>)</b>   </div>
<?

$q = mysql_query("SELECT * FROM `user_guest` WHERE `id_guest` = '$ank[id]' ORDER BY `uid` DESC LIMIT $start, $set[p_str]");

while ($post = mysql_fetch_assoc($q)) {
$ank = mysql_fetch_assoc(mysql_query("SELECT * FROM `user` WHERE `id` = $post[id_user] LIMIT 1"));
$ank_guest = get_user($post['id_user']);
$user_guest = get_user($post['id_guest']);
$reply_guest = get_user($post['reply_id_user']);

$postBan = mysql_result(mysql_query("SELECT COUNT(*) FROM `ban` WHERE `post` = '0' AND `id_user` = '$ank[id]' AND (`time` > '$time' OR `navsegda` = '1')"), 0);
if ($postBan == 0){
$dop_divka = '';
}else{
$dop_divka = ' comm_hidden';
}

?>
<div id="<?= $ank_guest['id']?>"> 
<div class="comm oh<?= $dop_divka?>">
<div class="p40 left t-padd_right"> 
<div class="inl_bl relative">
<a href="/user/?id=<?= $ank_guest['id']?>" class="tdn"> <?= ava40($ank_guest['id'])?> </a> 
</div>  
</div> 
<div class="oh">  
<div>  
<span> 
<?= group($ank_guest['id'])?> <a href="/user/?id=<?= $ank_guest['id']?>" class="mysite-link"><b class="nick black"><?= unick($ank_guest['id'])?></b></a>    
</span> 
<div class="right">  
<a class="grey js-link_copy"> <span class="m"> <?= vremja($post['time'])?> </span> </a>  
</div> 
</div>   
<?
if ($postBan == 0){	
if ($post['reply_id_user'] != 0){
?>
<div class="grey">ответил<?= ($reply_guest['pol'] == 1 ? '' : 'а')?>  <b><?= $reply_guest['nick']?></b>  </div>   
<?
}
}
?>
</div>
<div class="cl">      <div class="nl"> 
<?
if ($postBan == 0){	  
?>
<?= output_text($post['msg'])?>
<?
}else{  
?>
<?= output_text($banMess)?>
<?
} 
?>  
</div>         </div>
   
<div class="oh pad_t_a">  
<?
if ($postBan == 0){	
if (isset($user) && $user['id'] != $ank_guest['id']){
?>
<a href="?uid=<?= $user_guest['id']?>&amp;otvet=<?= $post['uid']?>" class="link-grey js-comm_reply">Ответить</a>
<?
}
}
if (isset($user) && $user['id'] == $user_guest['id'] || $user['level'] >= 4){
?>   
<span class="slb">         
<?
if ($postBan == 0){	
if (isset($user) && $user['id'] != $ank_guest['id']){
?>
|  
<?
}
}
?>
<a href="?uid=<?= $user_guest['id']?>&dell=<?= $post['uid']?>">Удалить</a>  </span>       
<?
}

$like = mysql_result(mysql_query("SELECT COUNT(*) FROM `user_guest_like` WHERE `id_post` = '$post[uid]' AND `like` = '1'"),0);
$likee = mysql_result(mysql_query("SELECT COUNT(*) FROM `user_guest_like` WHERE `id_post` = '$post[uid]' AND `like` = '1' AND `id_user` = '$user[id]'"),0);
$dlike = mysql_result(mysql_query("SELECT COUNT(*) FROM `user_guest_like` WHERE `id_post` = '$post[uid]' AND `dlike` = '1'"),0);
$dlikee = mysql_result(mysql_query("SELECT COUNT(*) FROM `user_guest_like` WHERE `id_post` = '$post[uid]' AND `dlike` = '1' AND `id_user` = '$user[id]'"),0);
$like_golos = mysql_result(mysql_query("SELECT COUNT(*) FROM `user_guest_like` WHERE `id_post` = '$post[uid]' AND `id_user` = '$user[id]'"),0);

if ($like == 0 && $dlike == 0)
{
$wote = '0';
}
else
{
if ($like == $dlike)
{
$wote = '0';
}
else if ($like > $dlike)
{
$woter = $like - $dlike;
$wote = $woter;
}
else if ($dlike > $like)
{
$woter = $dlike - $like;
$wote = $woter;
}
}

if($likee){
$cvet_like = ' style="color:#108210"';
}else{
$cvet_like = '';
}


if ($postBan == 0){	
if($like_golos == 0){
?>   
<div class="grey right">     
<a href="?uid=<?= $user_guest['id']?>&amp;like=<?= $post['uid']?>" class="js-vote_btn" title="За "> 
<img src="/style/i/vote/up_disabled.png" alt="" class="m p16"> </a> 
<span class="m" id="like_cnt" style="margin: 0 4px 0 3px"> <?= $wote?> </span>  
<a href="?uid=<?= $user_guest['id']?>&amp;dlike=<?= $post['uid']?>" class="js-vote_btn" title="Против "> 
<img src="/style/i/vote/down_disabled.png" alt="" class="m p16"> </a>
</div>
<?
}else{
?>   
<div class="comm_vote right">     
<a href="?uid=<?= $user_guest['id']?>&amp;like=<?= $post['uid']?>" class="js-vote_btn" title="За ">
<? 
if($likee){
?>
<img src="/style/i/vote/up_on.png" alt="" class="m p16">
<?
}else{
?>
<img src="/style/i/vote/up_disabled.png" alt="" class="m p16">
<?
}
?>
</a> 
<span class="comm_vote_cnt text-block12"<?= $cvet_like?>><?= $wote?></span>
<a href="?uid=<?= $user_guest['id']?>&amp;dlike=<?= $post['uid']?>" class="js-vote_btn" title="Против ">
<? 
if($dlikee){
?>
<img src="/style/i/vote/down_on.png" alt="" class="m p16">
<?
}else{
?>
<img src="/style/i/vote/down_disabled.png" alt="" class="m p16">
<?
}
?>
</a> 
</div>
<?
}
}


?>
<div class="cl"></div> </div>   
</div> </div>
<?

}


if ($k_page > 1){

	str('?uid='.$ank['id'].'&',$k_page,$page); // Вывод страниц

}


// Для Юзеров
if (isset($user)){


// Начало ||  Приватность гостевой
if ($ank['id'] != $user['id'] && $user['group_access'] == 0){	

if ($uSet['guestbook_komm'] == 1 && $frend != 2) // Если только для друзей
{
?>
<div class="list_item light_border_bottom error_block">  Пользователь открыл доступ только для друзей.  </div>
<?	
include_once H.'sys/inc/tfoot.php';
exit;
}
	
if ($uSet['guestbook_komm'] == 2) // Если закрыта гостевая полностью
{
?>
<div class="list_item light_border_bottom error_block">  Пользователь запретил комментировать всем.  </div>
<?	
include_once H.'sys/inc/tfoot.php';
exit;
}
}
// Конец приватности



if ($otv_post == 0){
?>
<form method="post" action="?uid=<?= $ank['id']?>&amp;<?= $passgen?>">
<div class="wrapper block pd0">  

<div class="block  js-toolbar_wrap">  
<div class="text-input__wrap"> <div class="cl" style="margin-bottom: 5px;"> <div class="relative">  
<div class="input-txt_wrapper"> 
<textarea class="input-txt" tabindex="1" name="msg" rows="4" id="textarea" data-maxlength="2000" data-toolbar="{hide:true,disable:{}}" cols="17" placeholder="Напишите комментарий"></textarea> 
</div> 
</div> </div>    </div> 
</div>

<div class="block wide pdt">   <div class="cf pad_t_a"> 
<span class="form-tools__left left">  
<!-- --><!-- --><!-- --><!-- --><!-- -->
<button name="smiles" value="" class="  url-btn     " id="smiles_btn"><!--   -->
<img src="/style/i/ico/smile.png" alt="" class="m"> <!--   --><span class="m"> </span><!-- -->
</button>
<!-- --><!-- -->  
</span>   
<span class="form-tools__left left"><span class="js-bb_toggle"> 
<!-- --><!-- --><!-- --><!-- --><!-- -->
<button name="bb_teg" value="" class="  url-btn     " id="response_btn"><!--   -->
<img src="/style/i/a.png" alt="" class="m"> <!--   --><span class="m"> </span><!-- -->
</button>
<!-- --><!-- --> 
</span> 
</span>   
<input value="Отправить" class="main_submit right" type="submit">  
</div> </div>

</div>
</form>
<?
}
else{
?>
<div id="comments_form">
<form method="post" action="?uid=<?= $ank['id']?>&amp;otvet=<?= $guest_otvet['uid']?>&amp;<?= $passgen?>">
<div class="wrapper block pd0"> 
<div id="comments_form_reply" class="stnd_padd pdb"> 
<span class="grey">Ответить на комментарий</span> 
<span id="comments_form_user"><?= group($guest_user['id'])?>  
<a href="/user/?id=<?= $guest_user['id']?>" class="mysite-link"><b class="nick black"><?= $guest_user['nick']?></b></a>  </span>: 
</div> 

<div class="block  js-toolbar_wrap">  
<div class="text-input__wrap"> <div class="cl" style="margin-bottom: 5px;"> <div class="relative">  
<div class="input-txt_wrapper"> 
<textarea class="input-txt" tabindex="1" name="msg" rows="4" id="textarea" data-maxlength="2000" data-toolbar="{hide:true,disable:{}}" cols="17" placeholder="Напишите комментарий"></textarea> 
</div> 
</div> </div>    </div> 
</div>

<div class="block wide pdt">   <div class="cf pad_t_a"> 
<span class="form-tools__left left">  
<!-- --><!-- --><!-- --><!-- --><!-- -->
<button name="smiles" value="" class="  url-btn     " id="smiles_btn"><!--   -->
<img src="/style/i/ico/smile.png" alt="" class="m"> <!--   --><span class="m"> </span><!-- -->
</button>
<!-- --><!-- -->  
</span>   
<span class="form-tools__left left"><span class="js-bb_toggle"> 
<!-- --><!-- --><!-- --><!-- --><!-- -->
<button name="bb_teg" value="" class="  url-btn     " id="response_btn"><!--   -->
<img src="/style/i/a.png" alt="" class="m"> <!--   --><span class="m"> </span><!-- -->
</button>
<!-- --><!-- --> 
</span> 
</span>   
<input value="Отправить" class="main_submit right" type="submit">  
</div> </div>

</div>
</form>
</div>
<?

}
}
// Для гостей
else{
?>
<div class="comm_form">  <div class="oh t_center busi">Для добавления комментариев необходимо    <a href="/aut.php" class="inl-link ">  авторизоваться<!-- --><!-- --><!-- --></a><!-- --></div>   </div>
<a href="/user/?id=<?= $ank['id']?>" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?
}



if (isset($user) && $anka['id'] == $user['id']){
?>
<div class="wrapper">     
<a href="/user/guestbook/settings/?uid=<?= $user['id']?>" class="link  darkblue  arrow    "> 
<span>        <img src="/style/i/mail/cog_blue.png" alt="" class="m">      <span class="m">  Настройки гостевой </span>          </span>  
</a>    
</div>
<?
}


?>