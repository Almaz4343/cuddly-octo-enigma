<?
include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';

if (isset($user)){
	$ank['id'] = $user['id'];
}
if (isset($_GET['id'])){
	$ank['id'] = intval($_GET['id']);
}

$ank = get_user($ank['id']);

// Если не определили юзера
if(!$ank || $ank['id'] == 0 || !isset($_GET['id'])){
$set['title'] = 'Ошибка';
include_once H.'sys/inc/thead.php';
title();
?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Ошибка</span> </span>       </div>
<div class="list_item">Пользователь не обнаружен</div>
<?
include_once H.'sys/inc/tfoot.php';
exit;
}



/* Бан пользователя */ 
if ((!isset($user) || $user['group_access'] == 0) && mysql_result(mysql_query("SELECT COUNT(*) FROM `ban` WHERE `razdel` = 'all' AND `id_user` = '$ank[id]' AND (`time` > '$time' OR `navsegda` = '1')"), 0)!=0)
{
$set['title'] = $ank['nick']; // заголовок страницы
include_once H.'sys/inc/thead.php';
title();
$post_ban = mysql_fetch_assoc(mysql_query("SELECT * FROM `ban` WHERE `id_user` = '$ank[id]' AND `time` > '$time'"));
?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text"><?= $ank['nick']?></span> </span>       </div>
<div class="wrapper"> 
<div class="block t_center bord-botm grey">   Этот аккаунт был заблокирован за нарушение <a href="/rules.php">условий использования сервиса</a>.   </div>  
<div class="block">   
<div> <span class="grey">Время блокировки:</span> <?= vremja($post_ban['time'])?> </div>   
</div>
</div>
<?

include_once H.'sys/inc/tfoot.php';
exit;
}	


/*-------------------------гости----------------------*/
if (isset($user) && $user['id'] != $ank['id'] && !isset($_SESSION['guest_' . $ank['id']]))
{
	if(mysql_result(mysql_query("SELECT COUNT(*) FROM `my_guests` WHERE `id_ank` = '$ank[id]' AND `id_user` = '$user[id]' LIMIT 1"),0) == 0)
	{
		mysql_query("INSERT INTO `my_guests` (`id_ank`, `id_user`, `time`) VALUES ('$ank[id]', '$user[id]', '$time')");
		mysql_query("UPDATE `user` SET `balls` = '".($ank['balls']+1)."' ,`rating_tmp` = '".($ank['rating_tmp']+1)."' WHERE `id` = '$ank[id]' LIMIT 1");
		$_SESSION['guest_' . $ank['id']] = 1;
	}
	elseif (!isset($_SESSION['guest_' . $ank['id']]))
	{
		$guest = mysql_fetch_array(mysql_query("SELECT * FROM `my_guests` WHERE `id_ank` = '$ank[id]' AND `id_user` = '$user[id]' LIMIT 1"));
		mysql_query("UPDATE `my_guests` SET  `time` = '$time', `read` = '1' WHERE `id` = '$guest[id]' LIMIT 1");
		mysql_query("UPDATE `user` SET `rating_tmp` = '".($ank['rating_tmp']+1)."' WHERE `id` = '$ank[id]' LIMIT 1");
		$_SESSION['guest_' . $ank['id']] = 1;
	}
}
/*----------------------------------------------------*/




if ((!isset($_SESSION['refer']) || $_SESSION['refer']==NULL)
&& isset($_SERVER['HTTP_REFERER']) && $_SERVER['HTTP_REFERER']!=NULL &&
!preg_match('#info\.php#',$_SERVER['HTTP_REFERER']))
$_SESSION['refer']=str_replace('&','&amp;',preg_replace('#^http://[^/]*/#','/', $_SERVER['HTTP_REFERER']));



// Приветствие
if (isset($_POST['welcome_msg']) && isset($user) && $user['id'] == $ank['id'])
{
$msg = $_POST['welcome_msg'];
$mat = antimat($msg);
if ($mat)$err[] = 'В тексте приветствия обнаружен мат: '.$mat;

if (strlen2($msg) > 500){
$err = 'Приветствие не должно быть больше 500 символов.';
}elseif (strlen2($msg) == 0){
$err = 'Вы не ввели приветствие.';
}elseif (strlen2($msg) == 1){
$err = 'Слишком короткое приветствие.';
}elseif (mysql_result(mysql_query("SELECT COUNT(*) FROM `wellcome` WHERE `id_user` = '$user[id]' AND `text` = '".my_esc($msg)."' LIMIT 1"),0) != 0){
$err = 'У вас есть такое приветствие.';
}
elseif(!isset($err)){
mysql_query("UPDATE `wellcome` SET `on_off` = '0' WHERE `id_user` = '$user[id]'");
mysql_query("INSERT INTO `wellcome` (`id_user`, `time`, `text`, `on_off`) values('$user[id]', '$time', '".my_esc($msg)."', '1')");
header("Location: /user/?id=$ank[id]");
exit;
} 
}





// Добавляем в закладки
if (isset($_GET['fav']) && isset($user) && $ank['id'] != $user['id']){	
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `bookmarks` WHERE `id_user` = '".$user['id']."' AND `id_object` = '".$ank['id']."' AND `type` = 'people' LIMIT 1"),0) == 0 && $_GET['fav'] == 1){
	mysql_query("INSERT INTO `bookmarks` (`id_object`, `id_user`, `time`,`type`) VALUES ('$ank[id]', '$user[id]', '$time', 'people')");
	$_SESSION['message'] = $ank['nick'] . ' добавлен в закладки';
}	
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `bookmarks` WHERE `id_user` = '".$user['id']."' AND `id_object` = '".$ank['id']."' AND `type` = 'people' LIMIT 1"),0) == 1 && $_GET['fav'] == 0){
	mysql_query("DELETE FROM `bookmarks` WHERE `id_user` = '$user[id]' AND  `id_object` = '$ank[id]' AND `type` = 'people'");
	$_SESSION['message'] = $ank['nick'] . ' удален из закладок';
}
header("Location: /user/?id=$ank[id]");
exit;
}
// Конец


/****ДРУЗЬЯ****/

// Добавляем в друзья
if (isset($_GET['remove_add'])){

$ank['id'] = intval($_GET['remove_add']);

if (mysql_result(mysql_query("SELECT COUNT(*) FROM `user` WHERE `id` = '$ank[id]' LIMIT 1"),0)==0){
	header("Location: /".SID);exit;
}if (mysql_result(mysql_query("SELECT COUNT(*) FROM `frends` WHERE (`user` = '$user[id]' AND `frend` = '$ank[id]') OR (`user` = '$ank[id]' AND `frend` = '$user[id]') LIMIT 1"),0)==1){
	header("Location: /".SID);exit;
}if (mysql_result(mysql_query("SELECT COUNT(*) FROM `frends_new` WHERE (`user` = '$user[id]' AND `to` = '$ank[id]') OR (`user` = '$ank[id]' AND `to` = '$user[id]') LIMIT 1"),0)==1){
	header("Location: /".SID);exit;
}if ($ank['id'] == $user['id']){
	header("Location: /".SID);exit;
}

mysql_query("INSERT INTO `frends_new` (`user`, `to`, `time`) values('$user[id]', '$ank[id]', '$time')");
mysql_query("OPTIMIZE TABLE `frends_new`");
mysql_query("INSERT INTO `mail` (`id_user`, `id_kont`, `msg`, `time`) values('0', '$ank[id]', 'Пользователь [b]$user[nick][/b] предлагает Вам дружбу. [b][url=/user/friends/pendings/]Подробней[/url][/b].', '$time')"); 

$_SESSION['message'] = "Ваше предложение дружбы отправлено пользователю ".$ank['nick'].".";
header("Location: /user/?id=$ank[id]");
exit;

}

//  Удаляем из друзей
if (isset($_GET['friend_remov_del'])){

$no = intval($_GET['friend_remov_del']);
$abD = get_user($no);
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `user` WHERE `id` = '$no' LIMIT 1"),0)==0){
	header("Location: /");exit;
}

if (mysql_result(mysql_query("SELECT COUNT(*) FROM `frends` WHERE (`user` = '$user[id]' AND `frend` = '$no') OR (`user` = '$no' AND `frend` = '$user[id]') LIMIT 1"),0)>0)
{
mysql_query("DELETE FROM `frends` WHERE `user` = '$user[id]' AND `frend` = '$no' LIMIT 1");
mysql_query("DELETE FROM `frends` WHERE `user` = '$no' AND `frend` = '$user[id]' LIMIT 1");
mysql_query("DELETE FROM `frends_new` WHERE `user` = '$no' AND `to` = '$user[id]' LIMIT 1");
mysql_query("DELETE FROM `frends_new` WHERE `user` = '$user[id]' AND `to` = '$no' LIMIT 1");
mysql_query("OPTIMIZE TABLE `frends`");
mysql_query("OPTIMIZE TABLE `frends_new`");
mysql_query("INSERT INTO `mail` (`id_user`, `id_kont`, `msg`, `time`) values('0', '$no', 'Пользователь  [b]$user[nick][/b] больше не является вашим другом.', '$time')"); 

$_SESSION['message'] = "Пользователь ".$abD['nick']." больше не является вашим другом.";
header("Location: /user/?id=$ank[id]");

}
exit;
}

// Отклоняем заявку в друзья которую отправили
if (isset($_GET['remove_del']))
{
$no = intval($_GET['remove_del']);

if (mysql_result(mysql_query("SELECT COUNT(*) FROM `user` WHERE `id` = '$no' LIMIT 1"),0)==0){
	header("Location: /?");exit;
}

if (mysql_result(mysql_query("SELECT COUNT(*) FROM `frends_new` WHERE (`user` = '$user[id]' AND `to` = '$no') OR (`user` = '$no' AND `to` = '$user[id]') LIMIT 1"),0)>0)
{

mysql_query("DELETE FROM `frends` WHERE `user` = '$user[id]' AND `frend` = '$no' LIMIT 1");
mysql_query("DELETE FROM `frends` WHERE `user` = '$no' AND `frend` = '$user[id]' LIMIT 1");
mysql_query("DELETE FROM `frends_new` WHERE `user` = '$no' AND `to` = '$user[id]' LIMIT 1");
mysql_query("DELETE FROM `frends_new` WHERE `user` = '$user[id]' AND `to` = '$no' LIMIT 1");
mysql_query("OPTIMIZE TABLE `frends`");
mysql_query("OPTIMIZE TABLE `frends_new`");

$_SESSION['message'] = "Предложение дружбы удалено.";
header("Location: /user/?id=$ank[id]");
}

exit;
}

/****КОНЕЦ****/

// Начало личной страници
$set['title'] = $ank['nick'];
include_once H.'sys/inc/thead.php';
title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  
<a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     
<span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text"><?= $ank['nick']?></span> </span>     
</div>
<?

if ((user_access('user_ban_set') || user_access('user_ban_set_h') || user_access('user_ban_unset')) && $ank['id'] != $user['id']){
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `ban` WHERE `razdel` = 'all' AND `id_user` = '$ank[id]' AND (`time` > '$time' OR `navsegda` = '1')"), 0)!=0)
{
$post_ban = mysql_fetch_assoc(mysql_query("SELECT * FROM `ban` WHERE `id_user` = '$ank[id]' AND `time` > '$time'"));
?>
<div class="wrapper"> 
<div class="block t_center bord-botm grey">   Этот аккаунт был заблокирован за нарушение <a href="/rules.php">условий использования сервиса</a>.   </div>  
<div class="block">   
<div> 
<a class="right" href="/adm_panel/ban.php?id=<?= $ank['id']?>"> <font color="red">Снять Бан</font></a>  
<span class="grey">Время блокировки:</span> <?= vremja($post_ban['time'])?>
</div></div> 
</div>
<?
}
}

// Приватность станички
$uSet = mysql_fetch_array(mysql_query("SELECT * FROM `user_set` WHERE `id_user` = '$ank[id]'  LIMIT 1"));
$frend = mysql_result(mysql_query("SELECT COUNT(*) FROM `frends` WHERE (`user` = '$user[id]' AND `frend` = '$ank[id]') OR (`user` = '$ank[id]' AND `frend` = '$user[id]') LIMIT 1"),0);
$frend_new = mysql_result(mysql_query("SELECT COUNT(*) FROM `frends_new` WHERE (`user` = '$user[id]' AND `to` = '$ank[id]') OR (`user` = '$ank[id]' AND `to` = '$user[id]') LIMIT 1"),0);
	
if ($ank['id'] != $user['id'] && $user['group_access'] == 0){	

// Начинаем вывод если стр имеет приват настройки
if (($uSet['privat_str'] == 2 && $frend != 2) || $uSet['privat_str'] == 0){
$rTime = time()-600;
?>  
<div class="stnd_padd oh pdb"> 
 
<div class="left dot_pic">      
<span class="tdn">   <div class="inl_bl relative"> <?= ava80($ank['id'])?>   </div>      </span> 
</div> 

<div class="left"> 

<span class="m"> <?= group($ank['id'])?> 
<a href="/user/?id=<?= $ank['id']?>" class="mysite-link"><b class="nick"><?= $ank['nick']?></b></a>  
</span>    
<?
if($ank['rating'] > 0){
?>
<div class="inl_bl m">  <span class="bordered grey"> <?= $ank['rating']?> </span>  </div>      
<?
}
?>
<div> 
<?
if ($ank['ank_name'] != NULL OR $ank['ank_family'] != NULL){
?>
<div class="grey break-word">
<?
if ($ank['ank_name'] != NULL){
?>
<?= text($ank['ank_name'])?> 
<?
}
if ($ank['ank_family'] != NULL){
?>
<?= text($ank['ank_family'])?> 
<?
}
?>
</div>  
<?
}
// Склон текста & Tw1nGo
$my_age_day = array('год', 'года', 'лет');
$ank['ank_age'] = date("Y") - $ank['ank_g_r'];
?>
<div class="grey">
<?
if ($ank['ank_d_r'] != NULL && $ank['ank_m_r'] != NULL && $ank['ank_g_r'] != NULL){
?>
<?= des2num($ank['ank_age'], $my_age_day)?>
<?
if ($ank['ank_city'] != NULL){
?>, <?
}
}
if ($ank['ank_city'] != NULL){
?>
<span class="arrow_link"><?= text($ank['ank_city'])?></span>
<?
}
?>
</div>    
<?
if($ank['date_last'] < $rTime){
?>
<div class="oh"> <div class="left">     
<span class="bordered grey">           <span class=" grey">  <?= vremja($ank['date_last'])?> </span>         </span>     
</div> </div>
<?
}else{
?>
<div class="oh"> <div class="left"> <span class="bordered green"> <span class=" green">  В сети </span> </span> </div> </div>
<?
}
?> 
</div> 
</div>   </div>   
<?
}
	
// Если только для друзей
if ($uSet['privat_str'] == 2 && $frend != 2){

?>
<div class="wrapper"> 
<span class="list_item light_border_bottom error_block m">Пользователь <b class="nick"><?= $ank['nick']?></b> открыл страницу только для друзей. </span>
</div>
<?
		
// В друзья
if (isset($user) && $ank['id'] != $user['id']){
?>
<div class="wrapper wbg">   
<table class="table__wrap"> <tbody><tr>  
<td class="table__cell" width="33%">     
<a href="/mail.php?id=<?= $ank['id']?>" class="link         "> 
<span>        <img src="/style/i/mail_grey.png" alt="" class="m">      <span class="m">  Написать </span>          </span>  
</a>     
</td>  
<td class="table__cell" width="33%">    
<?
if ($frend_new == 0 && $frend==0){
?> 
<a href="/user/frends/create.php?add=<?= $ank['id']?>" class="link blue">          
<img src="/style/i/befriends.png" alt="" class="m">      <span class="m">  Дружить </span>          
<!-- --><!-- --><!-- --></a><!-- -->
<?
}elseif ($frend_new == 1){
?>  
<a href="/user/frends/create.php?otm=<?= $ank['id']?>" class="link blue">          
<img src="/style/i/befriends_inprocess.png" alt="" class="m">      <span class="m">  Запрошено </span>          
<!-- --><!-- --><!-- --></a><!-- -->
<?
}elseif ($frend == 2){
?> 
<a href="/user/frends/create.php?del=<?= $ank['id']?>" data-action="friends_delete" class="link green">          
<img src="/style/i/befriends_on.png" alt="" class="m">      <span class="m">  Дружите </span>          
<!-- --><!-- --><!-- --></a><!-- -->
<?
}
?>
</td>       
<td class="table__cell table__cell_last" width="33%">  
<?
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `mark_people` WHERE `id_user` = '" . $user['id'] . "' AND `id_people` = '" . $ank['id'] . "' LIMIT 1"),0) == 0){
?>   
<div class="js-subscr_link">     
<a href="/user/?id=<?= $ank['id']?>&fav=1" class="link        js-action_link "> 
<span>        <img src="/style/i/fav_grey.png" alt="" class="m">      <span class="m">  В закладки </span>          </span>  
</a>    
</div>  
<?
}else{
?>
<div class="js-subscr_link">     
<a href="/user/?id=<?= $ank['id']?>&fav=0" class="link  green js-action_link "> 
<span>        <img src="/style/i/fav_on.png" alt="" class="m">      <span class="m">  В закладках </span>          </span>  
</a>    
</div>
<?
}
?>
</td>  
</tr> </tbody></table>    
</div>
<?
}
include_once H.'sys/inc/tfoot.php';
exit;
}
	
// Если закрыта страница полностью
if ($uSet['privat_str'] == 0) {
?>
<div class="wrapper"> 
<span class="list_item light_border_bottom error_block m">Пользователь <b class="nick"><?= $ank['nick']?></b> запретил просматривать его страничку. </span>
</div>
<?
include_once H.'sys/inc/tfoot.php';
exit;
}

}


if ($set['web'] == true)
include_once H."user/info/web.php";
else
include_once H."user/info/wap.php";


include_once H.'sys/inc/tfoot.php';
?>