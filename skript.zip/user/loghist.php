<?
include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';
only_reg();

$set['title'] = 'История входов : ' . $user['nick'];

include_once H.'sys/inc/thead.php';
title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  
<a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     
<span class="lc_brw"> 
<img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $user['id']?>"><?= $user['nick']?></a> 
</span>     
<span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">История входов</span> </span>       
</div>
<div class="start_page_padd light_blue light_border_bottom grey"> Здесь вы сможете проверить, не заходил ли кто-то чужой под вашим ником!<br>  Показаны последние 7 входов за последние время.  </div>
<?

$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `user_log` WHERE `id_user` = '$user[id]'"),0);

if (empty($k_post))
{
?>
<div class="start_page_padd light_blue light_border_bottom grey">Нет записаных авторизаций.</div>
<?
}	 

$q = mysql_query("SELECT * FROM `user_log` WHERE `id_user` = '".$user['id']."' ORDER BY `id` DESC  LIMIT 7");

while ($post = mysql_fetch_assoc($q))
{
?>
<div class="list_item light_border_bottom"> 
<span class="light_item">Дата:</span> <?= vremja($post['time'])?> <br>  
<span class="light_item">IP-адрес:</span> <?= long2ip($post['ip'])?>  <br>   
<span class="light_item">Браузер:</span> <?= output_text($post['ua'])?><br>  
</div>
<?
}

?>
<div class="start_page_padd light_blue light_border_bottom"><b>Самый первый вход</b></div>
<?

$k_post2 = mysql_result(mysql_query("SELECT COUNT(*) FROM `user_log` WHERE `id_user` = '$user[id]' ORDER BY `id` "),0);

if (empty($k_post2))
{
?>
<div class="start_page_padd light_blue light_border_bottom grey">Входа еще не было!.</div>
<?
}	

$q2 = mysql_query("SELECT * FROM `user_log` WHERE `id_user` = '".$user['id']."' ORDER BY `id` ASC LIMIT 1");

while ($post2 = mysql_fetch_assoc($q2))
{
?>
<div class="list_item light_border_bottom"> 
<span class="light_item">Дата:</span> <?= vremja($post2['time'])?> <br>  
<span class="light_item">IP-адрес:</span> <?= long2ip($post2['ip'])?>  <br>   
<span class="light_item">Браузер:</span> <?= output_text($post2['ua'])?><br>  
</div>
<?
}

?>
<a href="/user/startpage.php" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?

include_once H.'sys/inc/tfoot.php';
?>