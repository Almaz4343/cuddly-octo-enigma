<?PHP
include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';

// Определяем uID юзера
if (isset($user))$ank['id'] = $user['id'];
if (isset($_GET['uid']))$ank['id'] = intval($_GET['uid']);
	
	
$ank = get_user($ank['id']);

if (!isset($_GET['uid']) || !$ank || $ank['id'] == 0){
$_SESSION['err'] = 'Данной анкеты не существует. ';
header("Location: /user/?id=$user[id]".SID);exit;
}

$set['title'] = 'Друзья : ' . $ank['nick'];
include_once H.'sys/inc/thead.php';
title();

$uSet = mysql_fetch_array(mysql_query("SELECT * FROM `user_set` WHERE `id_user` = '$ank[id]'  LIMIT 1"));
$frend = mysql_result(mysql_query("SELECT COUNT(*) FROM `frends` WHERE (`user` = '$user[id]' AND `frend` = '$ank[id]') OR (`user` = '$ank[id]' AND `frend` = '$user[id]') LIMIT 1"),0);
$frend_new = mysql_result(mysql_query("SELECT COUNT(*) FROM `frends_new` WHERE (`user` = '$user[id]' AND `to` = '$ank[id]') OR (`user` = '$ank[id]' AND `to` = '$user[id]') LIMIT 1"),0);

$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `frends` WHERE `user` = '$ank[id]' AND `i` = '1'"), 0);
$onl_fr = mysql_result(mysql_query("SELECT COUNT(*) FROM `frends` INNER JOIN `user` ON `frends`.`frend`=`user`.`id` WHERE `frends`.`user` = '$ank[id]' AND `frends`.`i` = '1' AND `user`.`date_last`>'".(time()-600)."'"), 0);
$zayava = mysql_result(mysql_query("SELECT COUNT(id) FROM `frends_new` WHERE `to` = '$ank[id]' LIMIT 1"), 0);


?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $ank['id']?>"><?= $ank['nick']?></a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/friends/?uid=<?= $ank['id']?>">Друзья</a> </span>       </div>
<?

if ($ank['id'] != $user['id'] && ($user['group_access'] == 0 || $user['group_access'] <= $ank['group_access'])){

// Если только для друзей
if ($uSet['privat_friend']  ==  2 && $frend != 2)  {

?>
<div class="wrapper"> 
<div class="block">Доступ к списку друзей пользователя <b><?= $ank['nick']?></b> открыт только для друзей. </div>
</div>
<?
		
include_once H.'sys/inc/tfoot.php';
exit;
}

// Если закрыта
if ($uSet['privat_friend']  ==  0) {

?>
<div class="wrapper"> 
<div class="block">Доступ к списку друзей пользователя <b><?= $ank['nick']?></b> закрыт.</div>
</div>
<?
		
include_once H.'sys/inc/tfoot.php';
exit;
}

}
if (isset($user) && $ank['id'] == $user['id']){
if($zayava > 0){
?>
<div class="wrapper">     
<a href="/user/friends/pendings/" class="link -full    blue  arrow    "> 
<span>        
<img src="/style/i/ico/add_user.png" alt="" class="m">      <span class="m">  <?= $zayava?> человек хочет дружить с вами </span>          
</span>  
</a>    
</div>
<?
}
}



?>
<div class="wrapper-nobg"> 
<form action="/user/friends/?uid=<?= $ank['id']?>" method="post">       
<table class="table__wrap search-wrap input-txt_grid"> <tbody><tr> 
<td class="input-txt_grid_input"> 
<div class="input-txt_wrapper_search relative"> 
<input class="input-txt" name="q" value="" maxlength="64" type="text"> </div> 
</td> 
<td class="input-txt_grid_sep"></td> 
<td class="input-txt_grid_btn"> <input class="search__btn" value="Найти" type="submit"> </td> 
</tr> </tbody></table>     
</form> 
</div>
<?

?>
<div class="tabs_block oh"> 
<div class="left">  
<a href="/user/friends/?uid=<?= $ank['id']?>" class="left tab_item tab_active black"> Все (<?= $k_post?>) </a>  
<a href="/user/friends/online/?uid=<?= $ank['id']?>" class="left tab_item "> Онлайн 
<?
if($onl_fr != 0){?>(<?= $onl_fr?>)<?}
?>
</a>  
</div> </div>
<div class="oh" style="margin-top: -1px; border-top:1px solid #cccaca;"> 
<?

$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str'] * $page - $set['p_str'];

$q = mysql_query("SELECT * FROM `frends` WHERE `user` = '$ank[id]' AND `i` = '1'ORDER BY time DESC LIMIT $start, $set[p_str]");

if (isset($user) && $ank['id'] == $user['id']){
$_kto = '<b>Вас</b>';
}else{
$_kto = 'пользователя <b>'.$ank['nick'].'</b>';
}

if ($k_post == 0){
?>
<div class="js-row block bord-botm oh grey relative">У <?= $_kto?> нет друзей. </div>
<?
}
else{

while ($frend = mysql_fetch_assoc($q))
{
$frend = get_user($frend['frend']);


if ($ank['id'] == $user['id']){
?>
<div class="js-row block bord-botm oh grey relative">       
<table class="table__wrap table_no_borders table__wrap-fixed"> <tbody><tr> 
<td class="table__cell text_left word_break">   
<div class="left font0">   
<a href="/user/?id=<?= $frend['id']?>" class="tdn">       
<span class="pr">   <div class="inl_bl relative"> <?= ava40($frend['id'])?> </div>     </span>        
</a>  
</div>   
<div class="pre_content_wrap break-word">  
<?= group($frend['id'])?> 
<a href="/user/?id=<?= $frend['id']?>" class="black full_link">   <b><?= $frend['nick']?></b>  </a>   <?= medal($frend['id'])?>
<?
if($frend['ank_name'] != null || $frend['ank_family'] != null){
?>
<div class="grey">  
<div class="break-word"> 
<?
if($frend['ank_name'] != null){
?>
<?= text($frend['ank_name'])?> 
<?
}
if($frend['ank_family'] != null){
?>
<?= text($frend['ank_family'])?>
<?
}
?>
</div>      
</div>
<?
}
?>             
</div>  
</td> 
<td class="table__cell grey_bg" width="1px"> </td> 
<td class="table__cell m" width="30%"> 
<?
$r_timeS = time() - 600;
if($frend['date_last'] < $r_timeS){
?>
<div class="t-padd_left t_center word_break relative">  <?= vremja($frend['date_last'])?> </div> 
<?
}else{
?>
<div class="t-padd_left t_center word_break relative green">  В сети </div> 
<?
}
?>
</td> 
</tr> </tbody></table>     
</div>
<?
}else{

?>
<div class="js-row block bord-botm oh grey relative">        
<div class="left font0">   
<a href="/user/?id=<?= $frend['id']?>" class="tdn">       
<span class="pr">   <div class="inl_bl relative"> <?= ava40($frend['id'])?>  </div>     </span>        
</a>  
</div>   
<div class="pre_content_wrap break-word"> 
<?= group($frend['id'])?> 
<a href="/user/?id=<?= $frend['id']?>" class="black full_link">   <b><?= $frend['nick']?></b>  </a>   <?= medal($frend['id'])?>                
<?
if($frend['ank_name'] != null || $frend['ank_family'] != null){
?>
<div class="grey">  
<div class="break-word"> 
<?
if($frend['ank_name'] != null){
?>
<?= text($frend['ank_name'])?> 
<?
}
if($frend['ank_family'] != null){
?>
<?= text($frend['ank_family'])?>
<?
}
?>
</div>      
</div>
<?
}
?>
</div>     </div>
<?
}

}

}
?>
</div>
<?


if ($k_page > 1) { 
    str('?uid=' . $ank['id'] . '&amp;', $k_page, $page);
}

?>
<a href="/user/?id=<?= $ank['id']?>" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?

include_once H.'sys/inc/tfoot.php';


?>