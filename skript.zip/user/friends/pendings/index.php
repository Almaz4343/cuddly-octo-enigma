<?PHP
include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';

$sid = $user['id'];
$ank = get_user($sid);

if (!isset($user)){
	header("Location: /?".SID);exit;
}

$set['title'] = 'Предложения : Заявки : ' . $ank['nick'];
include_once H.'sys/inc/thead.php';
title();

$k_post = mysql_result(mysql_query("SELECT COUNT(id) FROM `frends_new` WHERE `to` = '$ank[id]' LIMIT 1"), 0);

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $ank['id']?>"><?= $ank['nick']?></a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/friends/?uid=<?= $ank['id']?>">Друзья</a> </span>  <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Предложения</span> </span>     </div>

<div class="header"> <b>Заявки в друзья</b> 
<?
if($k_post > 0){
?>
<span class="cnt"><?= $k_post?></span> 
<?
}
?>
</div>
<?



$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str']*$page-$set['p_str'];

$q = mysql_query("SELECT * FROM `frends_new` WHERE `to` = '$user[id]' ORDER BY time DESC");

if ($k_post == 0){
?>
<div class="wrapper"><div class="col_blocks block">  Предложения не найдены.  </div></div>
<?
}
else{

while ($frend = mysql_fetch_assoc($q))
{
$frend = get_user($frend['user']);

// Определяем сколько лет	
$frend['ank_age'] = null;
if ($frend['ank_d_r'] != NULL && $frend['ank_m_r'] != NULL && $frend['ank_g_r'] != NULL){
	$frend['ank_age'] = date("Y")-$frend['ank_g_r'];
	if (date("n") < $frend['ank_m_r'])
	$frend['ank_age'] = $frend['ank_age'] - 1;
	elseif (date("n") == $frend['ank_m_r']&& date("j") < $frend['ank_d_r'])
	$frend['ank_age'] = $frend['ank_age'] - 1;
}

$rTime = time() - 600;

?>
<div class="wrapper">  
<div class="js-row block bord-botm oh grey relative">  
      
<div class="left font0">   
<a href="/user/?id=<?= $frend['id']?>" class="tdn">       
<span class="pr">   <div class="inl_bl relative"> <?= ava40($frend['id'])?>   </div>     </span>        
</a>  
</div> 
  
<div class="pre_content_wrap break-word"> 
<?= group($frend['id'])?>    <a href="/user/?id=<?= $frend['id']?>" class="black full_link">   <b><?= $frend['nick']?></b>  </a>   <?= medal($frend['id'])?>          
<?
if($frend['date_last'] < $rTime){
?>
<span class="grey">(<?= vremja($frend['date_last'])?>)</span>       
<?
}
?>
<div class="grey">  
<?
if($frend['ank_name'] != null OR $frend['ank_family'] != null){
?>
<div class="break-word">
<?
}

if($frend['ank_name'] != null){
?>  
<?= text($frend['ank_name'])?>
<?
}
if($frend['ank_family'] != null){
?>  
<?= text($frend['ank_family'])?>
<?
}
if($frend['ank_name'] != null OR $frend['ank_family'] != null){
?>
</div>
<?
}
// Вывод возвраста
if ($frend['ank_d_r'] != NULL && $frend['ank_m_r'] != NULL && $frend['ank_g_r'] != NULL){
$my_age_day = array('год', 'года', 'лет');
?>    
<?= des2num($frend['ank_age'], $my_age_day)?>
<? 
if ($frend['ank_city'] != NULL){
?>, <?
} 
}
if ($frend['ank_city'] != NULL){
?>
<?= text($frend['ank_city'])?>
<?
} 
?>
</div>             </div>       
</div>     
<table class="table__wrap"> <tbody><tr>  
<td class="table__cell" width="50%">    
<div class="js-subscr_link" data-sub="friend" data-type="add" data-user="<?= $frend['nick']?>" data-mode="2">     
<a href="/user/frends/create.php?ok=<?= $frend['id']?>" class="link -full    blue      "> 
<span><!--     --><img src="/style/i/befriends_blue.png" alt="" class="m"> <!--   --><span class="m">Дружить</span><!--    --></span>  
</a>    
</div> 
<td class="table__cell table__cell_last" width="50%">     
<a href="/user/frends/create.php?no=<?= $frend['id']?>" class="link -full          "> 
<span><!--      --><span>Отклонить</span><!--    --></span>  
</a>    
</td>  
</tr> </tbody></table>      
</div>
<?
}

}
if ($k_page > 1) { 
    str('?', $k_page, $page);
}

?>
<a href="/user/friends/?uid=<?= $ank['id']?>" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад </a>
<?


include_once H.'sys/inc/tfoot.php';

?>