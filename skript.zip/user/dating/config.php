<?

if (isset($_POST['cfms']))
{
if (isset($_POST['gender']) && is_numeric($_POST['gender']) && $_POST['gender']>=0 && $_POST['gender']<=2)
{
$_SESSION['gender']=intval($_POST['gender']);
}
else{
$_SESSION['gender']=2;
}

if (isset($_POST['on_off']) && is_numeric($_POST['on_off']) && ($_POST['on_off']==0 || $_POST['on_off']==1))
{
$_SESSION['on_off']=intval($_POST['on_off']);
}
else{
$_SESSION['on_off']=0;
}

if (isset($_POST['age_from']) && is_numeric($_POST['age_from']) && ($_POST['age_from']==0 || ($_POST['age_from']>=11 && $_POST['age_from']<=80)))
{
$_SESSION['age_from']=intval($_POST['age_from']);
}else{
$_SESSION['age_from']=0;
}
if (isset($_POST['age_to']) && is_numeric($_POST['age_to']) && ($_POST['age_to']==0 || ($_POST['age_to']>=11 && $_POST['age_to']<=80)))
{
if (isset($_POST['age_from']) && is_numeric($_POST['age_from']) && ($_POST['age_from']==0 || ($_POST['age_from']>=11 && $_POST['age_from']<=80)) && $_POST['age_from']<=$_POST['age_to'])
{
$_SESSION['age_to']=intval($_POST['age_to']);
}else{
$_SESSION['age_to']=0;
}
}else{
$_SESSION['age_to']=0;
}




header("Location: ?");
exit;
}
?>