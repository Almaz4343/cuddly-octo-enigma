<?
include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';

$set['title'] = 'Знакомства'; // заголовок страницы

$sort_sp = "WHERE `ank_dating` = '1'";
$age_from = 0;
$age_to = 0;
$gender = 2;
$on_off = 0;


// Возраст от
if (isset($_SESSION['age_from']) && is_numeric($_SESSION['age_from']) && ($_SESSION['age_from']==0 || ($_SESSION['age_from']>=11 && $_SESSION['age_from']<=80))){
	$age_from=intval($_SESSION['age_from']);
}
// Возвраст до
if (isset($_SESSION['age_to']) && is_numeric($_SESSION['age_to']) && ($_SESSION['age_to']==0 || ($_SESSION['age_to']>=11 && $_SESSION['age_to']<=80))){
	$age_to=intval($_SESSION['age_to']);
}
// Поиск по полу
if (isset($_SESSION['gender']) && is_numeric($_SESSION['gender']) && $_SESSION['gender']>=0 && $_SESSION['gender']<=2){
	$gender=intval($_SESSION['gender']);
}
// Онлайн или нет
if (isset($_SESSION['on_off']) && is_numeric($_SESSION['on_off']) && ($_SESSION['on_off']==0 || $_SESSION['on_off']==1)){
	$on_off = intval($_SESSION['on_off']);
}



// Файл конфигурации
if (isset($_GET['search'])){
	include_once H.'user/dating/config.php';
}


if ($age_from > 0 || $age_to > 0 || $gender < 2 || $on_off > 0)
{
$sort_sp = "WHERE `ank_dating` = '1' AND ";
if ($age_from > 0)
{
	$age_from2 = date('Y')-$age_from;
	$sort_sp = "".$sort_sp." `ank_g_r` != '' AND `ank_g_r` <= '".$age_from2."'";
}

if ($age_to > 0){

$age_to2 = date('Y') - $age_to;

if ($age_from > 0)
{
	$sort_sp = "".$sort_sp." AND `ank_g_r` != '' AND `ank_g_r` >= '".$age_to2."'";
}else{
	$sort_sp = "".$sort_sp." `ank_g_r` != '' AND `ank_g_r` >= '".$age_to2."'";
}

}

if ($gender < 2){
if ($age_from > 0 || $age_to > 0)
{
	$sort_sp = "".$sort_sp." AND `pol` = '".$gender."'";
}else{
	$sort_sp = "".$sort_sp." `pol` = '".$gender."'";
}
}

if ($on_off > 0){
if ($age_from > 0 || $age_to > 0 || $gender < 2)
{
	$sort_sp = "".$sort_sp." AND `date_last` > '".($time-600)."'";
}else{
	$sort_sp = "".$sort_sp." `date_last` > '".($time-600)."'";
}
}

}

if (isset($_GET['sort']) && ($_GET['sort'] == 'popular' || $_GET['sort'] == 'new'))
{
if ($_GET['sort'] == 'new')
{
$_SESSION['d_sort'] = 1;
}
else if ($_GET['sort'] == 'popular')
{
$_SESSION['d_sort'] = 2;
}
header("Location: ?");
exit;
}


if (isset($_GET['i_dating']))
{
mysql_query("UPDATE `user` SET `ank_dating` = '1' WHERE `id` = '".$user['id']."' LIMIT 1");
$_SESSION['message'] = 'Анкета добавлена в знакомства. ';
header("Location: ?");
exit;
}




include_once H.'sys/inc/thead.php';

title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="//c.spac.me/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/dating/">Знакомства</a> </span>       </div>
<?

err();


if(isset($user) && $user['ank_dating'] == 0){
?>
<div class="oh t_center busi">   
<a href="?i_dating" class="inl-link ">  Добавить анкету в знакомства.
<!-- --><!-- --><!-- -->
</a>
<!-- -->
</div>
<?
}

?>
<form action="/user/dating/?search" method="post">
<div class="list_item"> 

<div> 
<label for="gender">Пол:</label> 
<label class="edit_checbox"><input name="gender" value="2" <?= ($gender==2?" checked='checked'":null)?> type="radio"> Любой</label> 
<label class="edit_checbox"><input name="gender" value="1" <?= ($gender==1?" checked='checked'":null)?> type="radio"> Муж.</label> 
<label><input name="gender" value="0" <?= ($gender==0?" checked='checked'":null)?> type="radio"> Жен.</label> 
</div>

<div class="pad_t_a"> 
<label for="age_from">Возраст: от</label> 
<select name="age_from">
<?
if ($age_from==0)
{
echo "<option value='0' selected='selected'>-</option>";
}else{
echo "<option value='0'>".$voz_ot."</option>";
}
foreach (array('11','12','13','14','15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31', '32', '33', '34', '35', '36', '37', '38', '39', '40', '41', '42', '43', '44', '45', '46', '47', '48', '49', '50', '51', '52', '53', '54', '55', '56', '57', '58', '59', '60', '61', '62', '63', '64', '65', '66', '67', '68', '69', '70', '71', '72', '73', '74', '75', '76', '77', '78', '79', '80') as $voz_ot)
{
if ($age_from==$voz_ot)
{
echo "<option value='".$voz_ot."' selected='selected'>".$voz_ot."</option>";
}else{
echo "<option value='".$voz_ot."'>".$voz_ot."</option>";
}
}
?>
</select> до <select name="age_to">
<?

if ($age_to==0)
{
echo "<option value='0' selected='selected'>-</option>";
}else{
echo "<option value='0'>".$voz_do."</option>";
}
foreach (array('11','12','13','14','15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31', '32', '33', '34', '35', '36', '37', '38', '39', '40', '41', '42', '43', '44', '45', '46', '47', '48', '49', '50', '51', '52', '53', '54', '55', '56', '57', '58', '59', '60', '61', '62', '63', '64', '65', '66', '67', '68', '69', '70', '71', '72', '73', '74', '75', '76', '77', '78', '79', '80') as $voz_do)
{
if ($age_to==$voz_do)
{
echo "<option value='".$voz_do."' selected='selected'>".$voz_do."</option>";
}else{
echo "<option value='".$voz_do."'>".$voz_do."</option>";
}
}
?>
</select>
</div>

<div class="pad_t_a"> 
<label for="on_off">Сейчас на сайте: </label> 
<label class="edit_checbox">
<input type="checkbox" name="on_off" <?= ($on_off==1?" checked='checked'":null)?> value="1" /> 
</label>
</div>
<div class="oh pad_t_a"> 
<input name="cfms" value="Искать" id="mainSearch" class="main_submit" type="submit"> 
</div> </div>
</form>
<?



if (!isset($_SESSION['d_sort']) || $_SESSION['d_sort']==NULL || $_SESSION['d_sort']==0 || !is_numeric($_SESSION['d_sort']) || !isset($user))
{
$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `user` ".$sort_sp.""), 0);
$k_page=k_page($k_post,$set['p_str']);
$page=page($k_page);
$start=$set['p_str']*$page-$set['p_str'];


$q=mysql_query("SELECT * FROM `user` ".$sort_sp." ORDER BY `id` DESC LIMIT $start, $set[p_str]");
?>
<div class="busi_switcher main_switcher wbg"> 
<table width="100%"><tbody><tr>   
<td width="50%">   
<a href="?sort=popular">  Популярные  </a>   
</td>    
<td width="50%">   <span class="active_item">  Новые  </span>   </td>        
</tr></tbody></table>  
</div>
<?
}else{
if ($_SESSION['d_sort']==1)
{
$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `user` ".$sort_sp.""), 0);
$k_page=k_page($k_post,$set['p_str']);
$page=page($k_page);
$start=$set['p_str']*$page-$set['p_str'];


$q=mysql_query("SELECT * FROM `user` ".$sort_sp." ORDER BY `id` DESC LIMIT $start, $set[p_str]");
?>
<div class="busi_switcher main_switcher wbg"> 
<table width="100%"><tbody><tr>   
<td width="50%">   
<a href="?sort=popular">  Популярные  </a>   
</td>    
<td width="50%">   <span class="active_item">  Новые  </span>   </td>        
</tr></tbody></table>  
</div>
<?
}else if ($_SESSION['d_sort']==2)
{
$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `user` ".$sort_sp.""), 0);
$k_page=k_page($k_post,$set['p_str']);
$page=page($k_page);
$start=$set['p_str']*$page-$set['p_str'];


$q=mysql_query("SELECT * FROM `user` ".$sort_sp." ORDER BY `rating` DESC LIMIT $start, $set[p_str]");
?>
<div class="busi_switcher main_switcher wbg"> 
<table width="100%"><tbody><tr>   
<td width="50%">   <span class="active_item">  Популярные </span> 
</td>    
<td width="50%">  <a href="?sort=new">   Новые   </a>     </td>        
</tr></tbody></table>  
</div>
<?
}
}

if ($k_post==0)
{
?>
<div class="list_item gradient_block1"> <b>Никого не найдено!</b> </div>
<?
}







while ($post=mysql_fetch_assoc($q))
{

$ank = get_user($post['id']);

// Определяем сколько лет	
$ank['ank_age'] = null;
if ($ank['ank_d_r'] != NULL && $ank['ank_m_r'] != NULL && $ank['ank_g_r'] != NULL){
	$ank['ank_age'] = date("Y")-$ank['ank_g_r'];
	if (date("n") < $ank['ank_m_r'])
	$ank['ank_age'] = $ank['ank_age'] - 1;
	elseif (date("n") == $ank['ank_m_r']&& date("j") < $ank['ank_d_r'])
	$ank['ank_age'] = $ank['ank_age'] - 1;
}

?>
<div class="light_border_bottom t-bg3 oh"> 
<a href="/user/?id=<?= $post['id']?>" class="t-block_item t-padd_right t-link_no_underline_block oh"> 
<div class="t-block_item stnd_padd t-bg_arrow_next oh"> 
<div class="left dot_pic"> <div class="left font0">      
<span class="pr">   
<div class="inl_bl relative">  <?= ava80($post['id'])?>    </div>     
</span>        
</div> </div> 
<div class="oh" style=""> <?= group($post['id'])?> <b class="t-strong_item t-link_item_hover">
<?
// Вывод возвраста
if ($ank['ank_d_r'] != NULL && $ank['ank_m_r'] != NULL && $ank['ank_g_r'] != NULL){
$my_age_day = array('год', 'года', 'лет');
?>
<?= unick($post['id'])?></b>,  <span><?= des2num($ank['ank_age'], $my_age_day)?></span>  
<? 
}else{
?>
<?= unick($post['id'])?></b>
<?
}

if($post['ank_city'] != null){
?>
<br><span class="grey"> <?= text($post['ank_city'])?> </span>
<?
}
if($ank['ank_lov_1'] != 0 OR $ank['ank_lov_2'] != 0 OR $ank['ank_lov_3'] != 0 OR $ank['ank_lov_4'] != 0 OR 
$ank['ank_lov_5'] != 0 OR $ank['ank_lov_6'] != 0 OR $ank['ank_lov_7'] != 0 OR $ank['ank_lov_8'] != 0){
?>
<br>
<?
if ($ank['ank_lov_1'] == 1)echo 'Дружба и общение; ';
if ($ank['ank_lov_2'] == 1)echo 'Флирт, СМС-переписка; ';
if ($ank['ank_lov_3'] == 1)echo 'Любовь, отношения; ';
if ($ank['ank_lov_4'] == 1)echo 'Брак, создание семьи; ';
if ($ank['ank_lov_5'] == 1)echo 'Виртуальный секс; ';
if ($ank['ank_lov_6'] == 1)echo 'Секс в реале; ';
if ($ank['ank_lov_7'] == 1)echo 'Ищу спонсора; ';
if ($ank['ank_lov_8'] == 1)echo 'Стану спонсором; ';
?>
<?
}else{
if($ank['ank_o_sebe'] != null){
?>
<br> <?= text($ank['ank_o_sebe'])?>
<?
}
}
?>
  </div> </div> </a> </div>
<?



}






include_once H.'sys/inc/tfoot.php';

?>