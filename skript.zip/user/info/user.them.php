<?php
include_once '../../sys/inc/start.php';
include_once '../../sys/inc/compress.php';
include_once '../../sys/inc/sess.php';
include_once '../../sys/inc/home.php';
include_once '../../sys/inc/settings.php';
include_once '../../sys/inc/db_connect.php';
include_once '../../sys/inc/ipua.php';
include_once '../../sys/inc/fnc.php';
include_once '../../sys/inc/user.php';

/* Бан юзера */
if(mysql_result(mysql_query("SELECT COUNT(`id`)FROM `user` WHERE `id`='".intval($_GET['id'])."' LIMIT 1"),0)==0){
header('Location: /');
exit;
}

if(isset($_GET['id']))
$ank = get_user(intval($_GET['id']));
else 
$ank = get_user($user['id']);


$set['title']='Поиск тем и комментариев автора : Форум';
include_once '../../sys/inc/thead.php';
title();


?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="//c.spac.me/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/forum/">Форум</a> </span>     <span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Поиск тем и комментариев автора</span> </span>       </div>

<div class="stnd_padd light_border_bottom"> 
Автор:  <?= group($ank['id'])?>
<a href="/user/?id=<?= $ank['id']?>" class="mysite-link"><b class="nick"><?= $ank['nick']?></b></a>     
</div>
<?

if(!isset($_GET['filter'])){
?>
<div class="bottom_link_block">  
<b>Темы</b>  <span class="service_links_block">|</span>  
<a href="?id=<?= $ank['id']?>&filter" class="arrow_link"><span>Комментарии</span></a>  
</div>
<?
}else{
?>
<div class="bottom_link_block">  
<a href="?id=<?= $ank['id']?>" class="arrow_link"><span>Темы</span></a>  <span class="service_links_block">|</span>  <b>Комментарии</b>  
</div>
<?
}



if(isset($_GET['filter'])){
$set['p_str'] = '20';
$k_post = mysql_result(mysql_query("SELECT COUNT(`id`) FROM `forum_p` WHERE `id_user`='".$ank['id']."'"), 0);
$k_page = k_page($k_post, $set['p_str']);
$page = page($k_page);
$start = $set['p_str'] * $page - $set['p_str'];


$q=mysql_query("SELECT id_them, msg,id, id_razdel, time, id_forum,id_them FROM `forum_p` WHERE `id_user`='".$ank['id']."' ORDER BY `time` DESC LIMIT $start,$set[p_str]");

while($post = mysql_fetch_assoc($q)){

$comm = mysql_result(mysql_query("SELECT COUNT(*)FROM `forum_p` WHERE `id_them`='".$post['id']."'"),0);

?>
<div class="stnd_padd light_border_bottom oh"> 
<span class="comment_date right_fix"><?= vremja($post['time'])?></span>   
<a href="/forum/<?= $post['id_forum']?>/<?= $post['id_razdel']?>/<?= $post['id_them']?>/" class="m">  <?= rez_text($post['msg'],80)?>  </a> 
<img class="m p16" src="/style/i/comm_num.gif" alt=""> 
<span class="m">(<?= $comm?>)</span>  
</div>
<?

}

if ($k_page > 1)str('user.them.php?id='.$ank['id'].'&komm&amp;', $k_page, $page); // Вывод страниц

}
else
{

$set['p_str'] = '20';
$k_post = mysql_result(mysql_query("SELECT COUNT(`id`) FROM `forum_t` WHERE `id_user`='".$ank['id']."'"), 0);
$k_page = k_page($k_post, $set['p_str']);
$page = page($k_page);
$start = $set['p_str'] * $page - $set['p_str'];


$q=mysql_query("SELECT id, name, id_forum, time, id_razdel FROM `forum_t` WHERE `id_user`='".$ank['id']."' ORDER BY `time` DESC LIMIT $start,$set[p_str]");

while($them = mysql_fetch_assoc($q)){
$comm_them = mysql_result(mysql_query("SELECT COUNT(*)FROM `forum_p` WHERE `id_them`='".$them['id']."'"),0);

?>
<div class="stnd_padd light_border_bottom oh"> 
<span class="comment_date right_fix"><?= vremja($them['time'])?></span>   
<a href="/forum/<?= $them['id_forum']?>/<?= $them['id_razdel']?>/<?= $them['id']?>/" class="m">  <?= text($them['name'])?>  </a> <img class="m p16" src="/style/i/comm_num.gif" alt=""> 
<span class="m">(<?= $comm_them?>)</span>  
</div>
<?
}

if ($k_page > 1)str('user.them.php?id='.$ank['id'].'&', $k_page, $page); // Вывод страниц

}


?>
<a href="/user/?id=<?= $ank['id']?>" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?

include_once '../../sys/inc/tfoot.php';
?>






?>