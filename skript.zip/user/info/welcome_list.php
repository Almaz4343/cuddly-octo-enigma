<?
include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';


if (isset($user)){
	$ank['id'] = $user['id'];
}
if (isset($_GET['id'])){
	$ank['id'] = intval($_GET['id']);
}

$ank = get_user($ank['id']);

// Если не определили юзера
if(!$ank || $ank['id'] == 0 || !isset($_GET['id'])){
$set['title'] = 'Ошибка';
include_once H.'sys/inc/thead.php';
title();
?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Ошибка</span> </span>       </div>
<div class="list_item">Пользователь не обнаружен</div>
<?
include_once H.'sys/inc/tfoot.php';
exit;
}

if (isset($_POST['welcome_msg']) && isset($user) && $user['id'] == $ank['id'])
{
$msg = $_POST['welcome_msg'];
$mat = antimat($msg);
if ($mat)$err[] = 'В тексте приветствия обнаружен мат: '.$mat;

if (strlen2($msg) > 500){$err='Приветствие не должно быть больше 500 символов.';}
elseif (strlen2($msg) == 0){$err='Вы не ввели приветствие.';}
elseif (strlen2($msg) == 1){$err='Слишком короткое приветствие.';}
elseif (mysql_result(mysql_query("SELECT COUNT(*) FROM `wellcome` WHERE `id_user` = '$user[id]' AND `text` = '".my_esc($msg)."' LIMIT 1"),0)!=0){$err='Ваше сообщение повторяет предыдущее';}
elseif(!isset($err)){
//mysql_query("UPDATE `wellcome` SET `on_off` = '0' WHERE `id_user` = '$user[id]'");
mysql_query("INSERT INTO `wellcome` (`id_user`, `time`, `text`, `on_off`) values('$user[id]', '$time', '".my_esc($msg)."', '0')");
header("Location: ?id=$ank[id]");
exit;
} 
}

if (isset($_GET['dell']))  {
	if (isset($user)){
    	$id = intval($_GET['dell']);
    	if (mysql_result(mysql_query("SELECT COUNT(*) FROM `wellcome` WHERE `id` = '".$id."'"),0) == 1) {
	$posti = mysql_fetch_assoc(mysql_query("SELECT * FROM `wellcome` WHERE `id` = '".$id."' LIMIT 1"));
	$anki = mysql_fetch_assoc(mysql_query("SELECT * FROM `user` WHERE `id` = $posti[id_user] LIMIT 1"));    
  	if (isset($user) && ($user['level'] > $anki['level']) || $posti['id_user'] == $user['id']){
    	mysql_query("DELETE FROM `wellcome` WHERE `id` = '$posti[id]'");
    	$_SESSION['message'] = 'Приветствие удалено.';
    	header("Location: ?id=".$ank['id']."");
    	exit;
    	}
  	}
  }
}

// Устанавлюем на стр
if (isset($_GET['wellcome_on'])){ 
if (isset($user) && $user['id'] == $ank['id']){
$uida = intval($_GET['wellcome_on']);
$ank_welcq = mysql_fetch_assoc(mysql_query("SELECT * FROM `wellcome` WHERE `id_user` = '$ank[id]' AND `id` = '$uida' LIMIT 1"));
mysql_query("UPDATE `wellcome` SET `on_off` = '0' WHERE `id_user` = '$user[id]'");
mysql_query("UPDATE `wellcome` SET `on_off` = '1' WHERE `id` = '$ank_welcq[id]'");
$_SESSION['message'] = 'Приветствие установлено на странице.';
header("Location: ?id=$ank[id]");
exit;
}
}



// Рассказать друзьям || Tw1nGo || 18.01.2017
if (isset($_GET['ask'])){ 
if (isset($user) && $user['id'] != $ank['id']){
$uid = intval($_GET['ask']);
$ank_welc = mysql_fetch_assoc(mysql_query("SELECT * FROM `wellcome` WHERE `id_user` = '$ank[id]' AND `id` = '$uid' LIMIT 1"));

if (mysql_result(mysql_query("SELECT COUNT(*) FROM `wellcome` WHERE `id_user` = '$user[id]' AND `text` = '$ank_welc[text]' LIMIT 1"),0) == 0)
{
if(mysql_result(mysql_query("SELECT COUNT(*) FROM `wellcome_share` WHERE `id_wellcome` = '$ank_welc[id]' AND `id_user` = '$user[id]' LIMIT 1"),0) == 0)
{
mysql_query("INSERT INTO `wellcome_share` (`id_user`, `time`, `id_wellcome`) values('$user[id]', '$time', '$ank_welc[id]')");
mysql_query("INSERT INTO `wellcome` (`id_user`, `time`, `text`, `on_off`) values('$user[id]', '$time', '$ank_welc[text]', '0')");
mysql_query("INSERT INTO `mail` (`id_user`, `id_kont`, `msg`, `time`) values('0', '$ank[id]', 'Пользователь $user[nick] поделился вашим приветствием! [url=/user/info/welcome_list.php?id=$user[id]]Подробней[/url]', '$time')");
$_SESSION['message'] = 'Успешно поделились приветствием.';
header("Location: ?id=$ank[id]");
exit;
}else{
$_SESSION['err'] = 'Вы уже делились этим приветствием!';
header("Location: ?id=$ank[id]");
exit;
}
}else{
$_SESSION['err'] = 'У Вас уже есть такое приветствие!';
header("Location: ?id=$ank[id]");
exit;
}

}
}

// КТО ПОДЕЛИЛСЯ
if (isset($_GET['share_list'])){
$uids = intval($_GET['share_list']);
$share_who = mysql_fetch_array(mysql_query("SELECT * FROM `wellcome` WHERE `id_user` = '$ank[id]' AND `id` = '$uids' LIMIT 1"));
$autor = mysql_fetch_assoc(mysql_query("SELECT * FROM `user` WHERE `id` = $share_who[id_user] LIMIT 1")); 
$set['title'] = 'Поделились : История приветствий : ' . $ank['nick'];
include_once H.'sys/inc/thead.php';
title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  
<a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     
<span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> 
<a href="/user/?id=<?= $ank['id']?>"><?= $ank['nick']?></a> </span>     
<span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> 
<a href="?id=<?= $ank['id']?>">Приветствия</a> </span> 
<span class="lc_brw"> 
<img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Поделились приветствием</span> 
</span>       
</div>

<div class="stnd_padd" style="padding-bottom:0;"> <div class="friends_access_list attach_block mt_0 grey">  
<a href="/user/?id=<?=  $autor['id']?>"> <?=  $autor['nick']?> </a>:  
<span style="display:inline-block;max-width:100%;" class="m oh diary_inline">   
<span class="arrow_link strong_link blue">  <span><?= output_text($share_who['text'])?></span>  </span>   
</span>   
</div> </div>



<?
 
$k_post12 = mysql_result(mysql_query("SELECT COUNT(*) FROM `wellcome_share` WHERE `id_wellcome` = '$share_who[id]'"),0);
$k_page12 = k_page($k_post12,$set['p_str']);
$page12 = page($k_page12);
$start12 = $set['p_str']*$page12-$set['p_str'];

if($k_post12 == 0){
?>
<div class="wrapper link" style="margin: 10px;"> Еще не делились.</div>
<?
}

$q12 = mysql_query("SELECT * FROM `wellcome_share` WHERE `id_wellcome` = '$share_who[id]' ORDER BY `id` DESC LIMIT $start12, $set[p_str]");  


while ($post1 = mysql_fetch_array($q12)){
$us = mysql_fetch_assoc(mysql_query("SELECT * FROM `user` WHERE `id` = $post1[id_user] LIMIT 1"));

?>
<div class="list_item"> 
<?= group($us['id'])?> 
<a href="/user/?id=<?= $us['id']?>" class="mysite-link"><b class="nick"><?= unick($us['id'])?> </b></a>  
</div>
<?
}


?>
<a href="?id=<?= $ank['id']?>" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?


include_once H.'sys/inc/tfoot.php';
exit;
}
// КОНЕЦ
else{
$set['title'] = 'История приветствий : ' . $ank['nick'];
include_once H.'sys/inc/thead.php';
title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> 
<a href="/user/?id=<?= $ank['id']?>"><?= $ank['nick']?></a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Журнал приветствий</span> </span>       </div>
<?
err();

if (isset($user) && $user['id'] == $ank['id']){
?>
<div class="wrapper bb0" style="margin-bottom: 0;">  
<div class="bord-botm">     
<a href="?id=<?= $ank['id']?>&welcome=new" class="link  blue"> <span> <img src="/style/i/edit_info.png" alt="" class="m p14"> <span class="m">  Написать приветствие </span>          </span>  </a>     
</div></div>
<?
if (isset($user) && isset($_GET['welcome']) && $_GET['welcome'] == 'new'){
?>
<div class="wrapper" style="margin: 0 5px; border-top: 0;"> 
<form action="?id=<?= $ank['id']?>&welcome=new" method="post"> 
<div class="block bord-botm">  
<div>   <div class="input-txt_wrapper">  <textarea class="input-txt" rows="5" cols="17" name="welcome_msg" maxlength="500"></textarea>  </div>   </div>  
</div>  
<table class="table__wrap"> <tbody><tr> 
<td class="table__cell" width="50%"> 
<!-- --><!-- --><!-- --><!-- --><!-- -->
<button type="submit" value="Сохранить" class="  link  blue full is_final    " id="cfms">
<!--   -->
<img src="/style/i/ok_blue.png" alt="" class="m"> 
<!--   -->
<span class="m"> Сохранить</span>
<!-- -->
</button>
<!-- --><!-- --> 
</td> 
<td class="table__cell table__cell_last" width="50%">     
<a href="?id=<?= $ank['id']?>" class="link         "> <span>Отменить</span>  </a>    
</td> 
</tr> </tbody></table> 
</form> 
</div>
<?
}
} 


$set['p_str'] = '10';
$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `wellcome` WHERE `id_user` = '".$ank['id']."'"),0);
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str'] * $page-$set['p_str'];
$q = mysql_query("SELECT * FROM `wellcome` WHERE `id_user` = '".$ank['id']."' ORDER BY `id` DESC LIMIT $start, $set[p_str]");


if ($k_post == 0){
?>
<div class="bubble" style="margin: 15px 5px;"> Приветствий пока нет.</div>
<?
}
else{

?>
<div class="wrapper bb0"> 
<?

while ($post = mysql_fetch_assoc($q))
{

$anks = mysql_fetch_assoc(mysql_query("SELECT * FROM `user` WHERE `id` = $post[id_user] LIMIT 1"));
$whom_ask = mysql_result(mysql_query("SELECT COUNT(*) FROM `wellcome_share` WHERE `id_wellcome` = '$post[id]'"),0);;

?>   
<div class="widgets-group widgets-group_top-mrg"> 
<div class="list_item"> 
<div class="oh">  
<span class="right">  <span class="grey"><?= vremja($post['time'])?>  </span></span>
<?= group($anks['id'])?>   <a href="/user/?id=<?= $anks['id']?>" class="normal-stnd tdn color-black-light"><b><?= unick($anks['id'])?></b></a> <?= medal($anks['id'])?>
<div class="bubble">   
<?
if (isset($user) && ($user['level'] > $anks['level'] || $user['level'] >=3 || $user['id'] == $anks['id'])){
?> 
<a class="right" href="?id=<?= $anks['id']?>&dell=<?=  $post['id']?>"><img class="m p16" src="/style/i/cross_light.png" alt=""></a>  
<?
}
?>
<div class="oh"><?= output_text($post['text'])?></div></div>
<div class="oh cl grey "> 
<?
if (isset($user) && $user['id'] != $ank['id']){
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `wellcome_share` WHERE `id_wellcome` = '$post[id]' AND `id_user` = '$user[id]' LIMIT 1"),0) == 0){
?>
<div class="left">  
<a href="?id=<?= $anks['id']?>&ask=<?=  $post['id']?>" title="Добавить себе">
<img alt="" class="m p14" src="/style/i/plus.png"> <span class="m blue">Добавить к себе</span> </a>    
</div> 
<?
}else{
?>
<div class="left"> 
<img src="/style/i/ok_grey.png" alt="" class="m p14"> <span class="m grey">Добавлено</span>  
</div> 
<?
}
}

if ($user['id'] == $ank['id']){
$style = '';
}else{
$style = ' style="margin-left:10px;"';
}



if (isset($user) && ($user['level'] >=3 || $user['id'] == $ank['id'])){
if ($post['on_off'] == 0){
?>
<div class="left"<?= $style?>>  
<a href="?id=<?= $anks['id']?>&wellcome_on=<?=  $post['id']?>" title="На страницу">
<img alt="" class="m p14" src="/style/i/plus.png"> <span class="m blue"> На страницу </span> </a>    
</div> 
<?
}else{
?>
<div class="left"<?= $style?>>   
<img src="/style/i/ok_grey.png" alt="" class="m p14"> <span class="m grey">На странице</span> 
</div> 
<?
}
}
?>
<a class="right" href="?id=<?= $anks['id']?>&share_list=<?=  $post['id']?>" title="Поделилось: <?= $post['ask']?> человек"> 
<img alt="" class="m p14" src="/style/i/action_share_color.gif"> <span class="m"><?= $whom_ask?></span> 
</a>
</div>
</div>
</div></div>
<?


}
?>
</div>
<?
}

if ($k_page>1)str("?id=".$ank['id'].'&amp;',$k_page,$page); // Вывод страниц


?>
<a href="/user/?id=<?= $ank['id']?>" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?

include_once H.'sys/inc/tfoot.php';
}

?>