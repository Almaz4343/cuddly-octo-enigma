<?

// Определяем приветствие пользователя
$wellcome = mysql_fetch_assoc(mysql_query("SELECT * FROM `wellcome` WHERE `id_user` = '$ank[id]' AND `on_off` = '1' LIMIT 1"));




if(isset($_GET['from']) && $_GET['from'] == 'online'){
?>
<a href="/online.php" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?
}
if(isset($_GET['from']) && $_GET['from'] == 'users'){
?>
<a href="/user/users.php" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?
}
?>
<div>   
     
<div>   
<div class="stnd_padd oh pdb"> 
 
<div class="left dot_pic">      
<?
if (isset($user) && $ank['id'] == $user['id']){
?>
<a href="/foto/edit_photo/?" title="Изменить аватар">
<div class="inl_bl relative"> <?= ava80($ank['id'])?>   </div>      
</a>
<?
}
else{
?>
<div class="inl_bl relative"> <?= ava80($ank['id'])?>   </div> 
<?
}

$rTime = time()-600;
if (isset($user) && $ank['id'] == $user['id']){
if($ank['date_last'] > $rTime){
?>         
<div> <span class="bordered  on  signature">  В сети  </span>   </div> 
<?
}
}
?> 
</div> 

<div class="left"> 

<span class="m"> <?= group($ank['id'])?> 
<a href="/user/?id=<?= $ank['id']?>" class="mysite-link"><b class="nick"><?= $ank['nick']?></b></a>  
</span>    
<?
if($ank['rating'] > 0){
?>
<div class="inl_bl m">  <span class="bordered grey"> <?= $ank['rating']?> </span>  </div>      
<?
}
if ((user_access('user_ban_set') || user_access('user_ban_set_h') || user_access('user_ban_unset')) && $ank['id'] != $user['id']){
?>
<a href="/adm_panel/ban.php?id=<?= $ank['id']?>"><font color="red">[Бан]</font></a>
<?
}
?>
<div> 
<?
if ($ank['ank_name'] != NULL OR $ank['ank_family'] != NULL){
?>
<div class="grey break-word">
<?
if ($ank['ank_name'] != NULL){
?>
<?= text($ank['ank_name'])?> 
<?
}
if ($ank['ank_family'] != NULL){
?>
<?= text($ank['ank_family'])?> 
<?
}
?>
</div>  
<?
}
// Склон текста & Tw1nGo
$my_age_day = array('год', 'года', 'лет');
$ank['ank_age'] = date("Y") - $ank['ank_g_r'];
?>
<div class="grey">
<?
if ($ank['ank_d_r'] != NULL && $ank['ank_m_r'] != NULL && $ank['ank_g_r'] != NULL){
?>
<?= des2num($ank['ank_age'], $my_age_day)?>
<?
if ($ank['ank_city'] != NULL){
?>, <?
}
}
if ($ank['ank_city'] != NULL){
?>
<span class="arrow_link"><?= text($ank['ank_city'])?></span>
<?
}
?>
</div>    
<?
if (isset($user) && $user['id'] == $ank['id']){
if ($ank['ank_name'] == NULL && $ank['ank_family'] == NULL){
?>
<div>    
<a href="/user/anketa/edit/osnovnoe.php?id=<?= $user['id']?>" class="inl-link  link-blue">  <span>  Расскажите о себе </span>          
<!-- --><!-- --><!-- --></a><!-- --> 
</div>
<?
}
}
if($ank['date_last'] < $rTime){
?>
<div class="oh"> <div class="left">     
<span class="bordered grey">           <span class=" grey">  <?= vremja($ank['date_last'])?> </span>         </span>     
</div> </div>
<?
}else{
if ($user['id'] != $ank['id']){
?>
<div class="oh"> <div class="left"> <span class="bordered green"> <span class=" green">  В сети </span> </span> </div> </div>
<?
}
}
?> 
</div> 
</div>   </div>   
<?

if ($wellcome['id'] || $ank['id'] == $user['id']){
if ($wellcome['id']){
// если стоит уже какой-то
if (isset($user) && $user['id'] == $ank['id']){
?>
<div class="stnd_padd light_border_bottom"> 
<div class="relative">    
<div id="original_status"> <div class="oh att_it mt_0"> 
<table class="table__wrap table__wrap-fixed table_no_borders show_icons"> <tbody><tr> 
<td class="table__cell m text_left"> <span class="service_item"><?= output_text($wellcome['text'])?></span> </td> 
<td class="table__cell m" width="16px"> 
<a href="?id=<?= $ank['id']?>&welcome=edit"> 
<img src="/style/i/edit_info.png" alt="" class="m p16 fl_n"> 
</a> 
</td> 
</tr> </tbody></table> 
</div> </div>  
<?
if (isset($user) && isset($_GET['welcome']) && $_GET['welcome'] == 'new' || isset($_GET['welcome']) && $_GET['welcome'] == 'edit'){
if ($user['id'] == $ank['id']){
if($_GET['welcome'] == 'new'){
$msg_welc = '';
}
if($_GET['welcome'] == 'edit'){
$msg_welc = text($wellcome['text']);
}
?>
<div class=" pad_t_a">  
<div class="wrapper margin0"> 
<form action="?id=<?= $ank['id']?>" method="post"> 
<div class="block bord-botm">  
<div>   <div class="input-txt_wrapper">  <textarea class="input-txt" rows="5" cols="17" name="welcome_msg" maxlength="500"><?= $msg_welc?></textarea>  </div>   </div>  
</div>  
<table class="table__wrap"> <tbody><tr> 
<td class="table__cell" width="50%"> 
<!-- --><!-- --><!-- --><!-- --><!-- -->
<button type="submit" value="Сохранить" class="  link  blue full is_final    " id="cfms">
<!--   -->
<img src="/style/i/ok_blue.png" alt="" class="m"> 
<!--   -->
<span class="m"> Сохранить</span>
<!-- -->
</button>
<!-- --><!-- --> 
</td> 
<td class="table__cell table__cell_last" width="50%">     
<a href="?id=<?= $ank['id']?>" class="link         "> <span>Отменить</span>  </a>    
</td> 
</tr> </tbody></table> 
</form> 
</div>   </div>
<?
}
}
?>        
</div> </div>          
<?
// Чужой
}else{
?>
<div class="stnd_padd light_border_bottom"> <div class="relative">   
<div id="original_status"> <div class="att_it mt_0">
<span class="service_item"><?= output_text($wellcome['text'])?></span>
</div> </div>    
</div> </div>       
<?
}
//Это наш.. не заполнен когда
}else{
?>
<div class="stnd_padd light_border_bottom"> <div class="relative">    
<div id="original_status"> <div class="oh att_it mt_0"> 
<table class="table__wrap table__wrap-fixed table_no_borders show_icons"> <tbody><tr> 
<td class="table__cell m text_left"> <span class="grey">Напишите приветствие</span> </td> 
<td class="table__cell m" width="16px"> 
<a href="?id=<?= $ank['id']?>&welcome=new"> <img src="/style/i/edit_info.png" alt="" class="m p16 fl_n"> </a> 
</td> 
</tr> </tbody></table> 
</div> </div> 
<?
if (isset($user) && isset($_GET['welcome']) && $_GET['welcome'] == 'new'){
if ($user['id'] == $ank['id'])
{
?>
<div class=" pad_t_a">  
<div class="wrapper margin0"> 
<form action="?id=<?= $ank['id']?>" method="post"> 
<div class="block bord-botm">  
<div>   <div class="input-txt_wrapper">  <textarea class="input-txt" rows="5" cols="17" name="welcome_msg" maxlength="512"></textarea>  </div>   </div>  
</div>  
<table class="table__wrap"> <tbody><tr> 
<td class="table__cell" width="50%"> 
<!-- --><!-- --><!-- --><!-- --><!-- -->
<button type="submit" value="Сохранить" class="  link  blue full is_final    " id="cfms">
<!--   -->
<img src="/style/i/ok_blue.png" alt="" class="m"> 
<!--   -->
<span class="m"> Сохранить</span>
<!-- -->
</button>
<!-- --><!-- --> 
</td> 
<td class="table__cell table__cell_last" width="50%">     
<a href="?id=<?= $ank['id']?>" class="link         "> <span>Отменить</span>  </a>    
</td> 
</tr> </tbody></table> 
</form> 
</div>   </div>
<?
}
}
?>        
</div> </div>
<?
}
}
?>
</div>
<div class="tabs_block oh">    
<div class="tab_item left tab_active black" style="padding: 12px 9px 8px 9px">  Профиль  </div>   
<a href="/user/anketa/?id=<?= $ank['id']?>" class="tab_item left" style="padding: 12px 9px 8px 9px">  Анкета  </a>  
<a href="/user/activity/?id=<?= $ank['id']?>" class="tab_item left" style="padding: 12px 9px 8px 9px">  Активность  </a>   
</div>
<div class="wrapper wbg">
<?
$k_p = mysql_result(mysql_query("SELECT COUNT(id) FROM `gifts_user` WHERE `id_user` = '$ank[id]' AND `status` = '1'"),0);
if ($k_p > 0){	
?>
<div class="start_page_padd" style="padding-top: 5px;"> 
<?
$q = mysql_query("SELECT id,id_gift,status FROM `gifts_user` WHERE `id_user` = '$ank[id]' AND `status` = '1' ORDER BY `id` DESC LIMIT 4");

while ($post = mysql_fetch_assoc($q)){
$gift = mysql_fetch_assoc(mysql_query("SELECT id FROM `gift_list` WHERE `id` = '$post[id_gift]' LIMIT 1"));
?>
<span style="margin-right:4px;" class="tdn"> 
<a href="/user/gifts/user_list/?details=<?= $post['id']?>&id=<?= $ank['id']?>" class="arrow_link"> 
<img src="/sys/gift/<?= $gift['id']?>.png" alt="" class="m p25"> </a> 
</span>  
<?
}
if ($k_p > 4){	
?>  
<a href="/user/gifts/user_list/?id=<?= $ank['id']?>" class="arrow_link"><span style="font-size:large;vertical-align:bottom;text-decoration:none;">»</span></a> 
<?
}
?>
</div>
<?
}
?>
<div class="widgets-group links-group bb0">  
<?

$koll_guestbook = mysql_result(mysql_query("SELECT COUNT(*) FROM `user_guest` WHERE `id_guest` = '$ank[id]'"),0);
?>
<a href="/user/guestbook/?uid=<?= $ank['id']?>" class="link  darkblue arrow    "> 
<span>        
<img src="/style/i/ico/gb.png" alt="" class="m p16">  <span class="m">  Гостевая </span>  <span class="m">(<?= $koll_guestbook?>)</span>        
</span>  
</a>
<?

$dnevnik = mysql_result(mysql_query("SELECT COUNT(*) FROM `notes` WHERE `id_user` = '".$ank['id']."'"),0);
if (isset($user) && $user['id'] == $ank['id']){
?>
<table class="table_no_borders sublink table__wrap-fixed bord-botm" style="border-spacing:0" width="100%"> <tbody><tr> 
<td class="table__cell_block text_left">   
<a href="/user/blogs/view/?id=<?= $ank['id']?>" class="link  darkblue     "> 
<span>  <img src="/style/i/blog.png" alt="" class="m p16"> <span class="m">  Личный блог </span>   <span class="m">(<?= $dnevnik?>)</span>       </span>  
</a>   
</td> 
<td class="table__cell table__cell_block m" width="100px"> 
<div class="sub_link nowrap oh">     
<a href="/user/blogs/new/?" class="link       "> <span>   <span class="bordered blue"> <span class=" blue">  Написать </span> </span>   </span>  </a>    
</div> 
</td> 
</tr> </tbody></table>
<?
}else{
?>
<a href="/user/blogs/view/?id=<?= $ank['id']?>" class="link  darkblue arrow    "> 
<span>        
<img src="/style/i/blog.png" alt="" class="m p16">      <span class="m">  Личный блог </span>   <span class="m">(<?= $dnevnik?>)</span>       
</span>  
</a>
<?
}

$koll_wellcom = mysql_result(mysql_query("SELECT COUNT(*) FROM `wellcome` WHERE `id_user` = '$ank[id]'"),0);
?>
<a href="/user/info/welcome_list.php?id=<?= $ank['id']?>" class="link  darkblue arrow    "> 
<span>        
<img src="/style/i/ed_middle.png" alt="" class="m p16">  <span class="m">  Журнал приветствий </span>  <span class="m">(<?= $koll_wellcom?>)</span>        
</span>  
</a>

<a href="/user/info/user.them.php?id=<?= $ank['id']?>" class="link  darkblue  arrow    "> 
<span> <img src="/style/i/forum.png" alt="" class="m">      <span class="m">  Темы и комментарии </span>  </span>  
</a>
<?

if (isset($user) && $user['id'] == $ank['id']){
$zakladki =mysql_result(mysql_query("SELECT COUNT(`id`)FROM `bookmarks` WHERE `id_user`='".$ank['id']."'"),0);
?>
<a href="/user/bookmarks/?id=<?= $ank['id']?>" class="link  darkblue arrow    "> 
<span>        
<img src="/style/i/ico/fav.png" alt="" class="m">      <span class="m">  Закладки </span>   
<?
if($zakladki > 0){
?>
<span class="m">(<?= $zakladki?>)</span> 
<?
}
?>      
</span>  
</a>
<?
}

?>
<div class="bord-botm"></div>
<?

$fotografii = mysql_result(mysql_query("SELECT COUNT(*) FROM `gallery_foto` WHERE `id_user` = '$ank[id]'"),0);
?>
<a href="/foto/<?= $ank['id']?>/" class="link  darkblue arrow    "> 
<span>        
<img src="/style/i/photo.png" alt="" class="m p16">      <span class="m">  Фотографии </span>   <span class="m">(<?= $fotografii?>)</span>       
</span>  
</a>
<a href="#" class="link  darkblue arrow    "> 
<span>        
<img src="/style/i/ico/music.png" alt="" class="m p16">      <span class="m">  Музыка </span>   <span class="m">(0)</span>       
</span>  
</a>
<a href="#" class="link  darkblue arrow    "> 
<span>        
<img src="/style/i/file.png" alt="" class="m p16">      <span class="m">  Файлы </span>   <span class="m">(0)</span>       
</span>  
</a>
<div class="bord-botm"></div>
<?
$friends = mysql_result(mysql_query("SELECT COUNT(*) FROM `frends` WHERE `user` = '$ank[id]' AND `i` = '1'"), 0);
$k_fr = mysql_result(mysql_query("SELECT COUNT(*) FROM `frends` WHERE `user` = '$ank[id]' AND `i` = '1'"), 0);
$res = mysql_query("select `frend` from `frends` WHERE `user` = '$ank[id]' AND `i` = '1'");
$i = 0;
while ($k_fr = mysql_fetch_array($res)){
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `user` WHERE `id` = '$k_fr[frend]' && `date_last` > '".(time()-600)."'"),0) != 0)$i++;
}

if ($ank['id'] != $user['id'])
{
if (($uSet['privat_friend'] == 2 && $frend == 2) || $uSet['privat_friend'] == 1 || $user['group_access'] > $ank['group_access']) 
{
?>
<a href="/user/friends/?uid=<?= $ank['id']?>" class="link  darkblue arrow    "> 
<span>        
<img src="/style/i/friends.png" alt="" class="m p16">      <span class="m">  Друзья </span>   
<span class="m">(<?= $friends?>
<?
if($i > 0)echo '/<span class="green">'.$i.'</span>';
?>
)</span>       
</span>  
</a>
<?
}
}
else{
?>
<a href="/user/friends/?uid=<?= $ank['id']?>" class="link  darkblue arrow    "> 
<span>        
<img src="/style/i/friends.png" alt="" class="m p16">      <span class="m">  Друзья </span>   
<span class="m">(<?= $friends?>
<?
if($i > 0)echo '/<span class="green">'.$i.'</span>';
?>
)</span>       
</span>  
</a>
<?
}
if (isset($user) && $user['id'] == $ank['id']){
$my_gosti = mysql_result(mysql_query("SELECT COUNT(*) FROM `my_guests` WHERE `id_ank` = '$user[id]'"),0);
$new_gosti = mysql_result(mysql_query("SELECT COUNT(*) FROM `my_guests` WHERE `id_ank` = '$user[id]' AND `read` = '1'"),0);
	

?>
<a href="/user/guest/" class="link  darkblue arrow    "> 
<span> <img src="/style/i/ico/readers.png" alt="" class="m"> <span class="m">  Гости </span> <span class="m">(<?=  $my_gosti?>) 
<?
if($new_gosti > 0){
?>
<font color="red">+<?=  $new_gosti?></font>
<?
}
?>
</span> </span>  
</a>
<?
}
?>
<a href="/user/gifts/user_list/?id=<?= $ank['id']?>" class="link  darkblue arrow    "> 
<span>        
<img src="/style/i/gift.png" alt="" class="m">      <span class="m">  Подарки </span>   <span class="m">(<?=  $k_p?>)</span>       
</span>  
</a>
<?
if (isset($user) && $user['id'] == $ank['id']){
?>
<a href="/user/settings/" class="link  darkblue arrow    "> 
<span>        <img src="/style/i/settings.png" alt="" class="m">      <span class="m">  Настройки </span>          </span>  
</a>
<a href="/user/services/" class="link  darkblue arrow    "> 
<span>        <img src="/style/i/ico/add.png" alt="" class="m">      <span class="m">  Дополнительные услуги </span>          </span>  
</a>
<?
}
if (isset($user) && $ank['id'] == $user['id']){
?>
<div class="bord-botm"></div>

<a href="/user/loghist.php" class="link  darkblue arrow    "> 
<span>        <img src="/style/i/history.png" alt="" class="m">      <span class="m">  История входов </span>          </span>  
</a>

<a href="/exit.php" class="link  darkblue arrow    "> 
<span>        <img src="/style/i/exit.png" alt="" class="m">      <span class="m">  Выход </span>          </span>  
</a>
<?
}
?>
</div>
</div>
<?

if (isset($user) && $ank['id'] != $user['id']){
?>
<div class="wrapper wbg">   
<table class="table__wrap"> <tbody><tr>  
<td class="table__cell" width="33%">     
<a href="/mail.php?id=<?= $ank['id']?>" class="link         "> 
<span>        <img src="/style/i/mail_grey.png" alt="" class="m">      <span class="m">  Написать </span>          </span>  
</a>     
</td>  
<td class="table__cell" width="33%">    
<?
if ($frend_new == 0 && $frend==0){
?> 
<a href="?id=<?= $ank['id']?>&remove_add=<?= $ank['id']?>" class="link blue">          
<img src="/style/i/befriends.png" alt="" class="m">      <span class="m">  Дружить </span>          
<!-- --><!-- --><!-- --></a><!-- -->
<?
}elseif ($frend_new == 1){
?>  
<a href="?id=<?= $ank['id']?>&friend_remov=1" class="link blue">          
<img src="/style/i/befriends_inprocess.png" alt="" class="m">      <span class="m">  Запрошено </span>          
<!-- --><!-- --><!-- --></a><!-- -->
<?
}elseif ($frend == 2){
?> 
<a href="?id=<?= $ank['id']?>&friend_del=1" data-action="friends_delete" class="link green">          
<img src="/style/i/befriends_on.png" alt="" class="m">      <span class="m">  Дружите </span>          
<!-- --><!-- --><!-- --></a><!-- -->
<?
}
?>
</td>       
<td class="table__cell table__cell_last" width="33%">  
<?
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `bookmarks` WHERE `id_user` = '".$user['id']."' AND `id_object` = '".$ank['id']."' AND `type`='people' LIMIT 1"),0) == 0)
{
?>   
<div class="js-subscr_link">     
<a href="?id=<?= $ank['id']?>&fav=1" class="link        js-action_link "> 
<span>        <img src="/style/i/fav_grey.png" alt="" class="m">      <span class="m">  В закладки </span>          </span>  
</a>    
</div>  
<?
}else{
?>
<div class="js-subscr_link">     
<a href="?id=<?= $ank['id']?>&fav=0" class="link  green js-action_link "> 
<span>        <img src="/style/i/fav_on.png" alt="" class="m">      <span class="m">  В закладках </span>          </span>  
</a>    
</div>
<?
}
?>
</td>  
</tr> </tbody></table>    
</div>
<?
if($frend == 2){
if (isset($_GET['friend_del']) && $_GET['friend_del'] == 1)
{
?>
<div class="wrapper" id="friend_confirm_delete_<?= $ank['id']?>"> 
<div class="block bord-botm"> Вы действительно хотите удалить <b><?= $ank['nick']?></b> из друзей? </div>  
<table class="table__wrap"> <tbody><tr> 
<td class="table__cell" width="50%"> 
<a href="?id=<?= $ank['id']?>&friend_remov_del=<?= $ank['id']?>" class="link is_final js-subscr_ok"> <span class="ico ico_ok_blue"></span> Да </a> 
</td> 
<td class="table__cell table__cell_last" width="50%"> 
<a href="?id=<?= $ank['id']?>" class="link is_final js-subscr_cancel"> <span class="ico ico_remove"></span> Отменить </a> </td> 
</tr> </tbody></table>  
</div>
<?
}
}elseif ($frend_new == 1){
if (isset($_GET['friend_remov']) && $_GET['friend_remov'] == 1)
{
?>
<div class="wrapper" id="friend_confirm_remov_<?= $ank['id']?>"> 
<div class="block bord-botm"> Вы действительно хотите отменить предложение дружбы для <b><?= $ank['nick']?></b>? </div>  
<table class="table__wrap"> <tbody><tr> 
<td class="table__cell" width="50%"> 
<a href="?id=<?= $ank['id']?>&remove_del=<?= $ank['id']?>" class="link is_final js-subscr_ok"> <span class="ico ico_ok_blue"></span> Да </a> 
</td> 
<td class="table__cell table__cell_last" width="50%"> 
<a href="?id=<?= $ank['id']?>" class="link is_final js-subscr_cancel"> <span class="ico ico_remove"></span> Отменить </a> </td> 
</tr> </tbody></table>  
</div>
<?
}
}

}

?>
<div class="wrapper">     
<a href="/user/gifts/?id=<?= $ank['id']?>" class="link  blue     "> 
<span>        <img src="/style/i/gifts_blue.png" alt="" class="m">      <span class="m">  Сделать подарок <?= $ank['nick']?> </span> 
</span>  
</a>    
</div>

</div>
<?

if(isset($_GET['from']) && $_GET['from'] == 'on'){
?>
<a href="/online.php" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?
}
if(isset($_GET['from']) && $_GET['from'] == 'us'){
?>
<a href="/user/users.php" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?
}

?>