<?
include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';
only_reg();

// Очистка гостей
if (isset($_GET['truncate']))
{
	mysql_query("DELETE FROM `my_guests` WHERE `id_ank` = '$user[id]'");
	$_SESSION['message'] = 'Список гостей очищен';
	header('Location: ?');
}

if (isset($_GET['truncate_id']))  {
  if (isset($user)) {
    $id = (int) $_GET['truncate_id'];
  	if (mysql_result(query("SELECT COUNT(*) FROM `my_guests`  WHERE `id_ank` = '$user[id]' AND `id` = '$id'"),0) == 1) {
    	query("DELETE FROM `my_guests` WHERE `id_ank` = '$user[id]' AND `id` = '$id' LIMIT 1");
    	header('Location: ?');
    	exit;
  	}
  }
}

// заголовок страницы
$set['title'] = 'Гости';

include_once H.'sys/inc/thead.php';

title();


?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> 
<a href="/user/?id=<?= $user['id']?>"><?= $user['nick']?></a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Мои гости</span> </span>       </div>
<?


$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `my_guests` WHERE `id_ank` = '$user[id]'"),0);
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str'] * $page - $set['p_str'];

if ($k_post == 0)
{	
?>
<div class="wrapper">  <div class="col_blocks block"> 	Вашу страничку еще не посещали </div> </div>
<?
}

$q = mysql_query("SELECT * FROM `my_guests` WHERE `id_ank` = '$user[id]' ORDER BY `time` DESC  LIMIT $start, $set[p_str]");



while ($post = mysql_fetch_array($q))
{
$ank = get_user($post['id_user']);
	
?>
<div class="wrapper wbg">  
<div class="js-row block oh grey relative">        
<div class="left font0"> 

<div class="btn-tools_centered btn-tools_centered-indent">     
<a href="?truncate_id=<?= $post['id']?>" class="link      icon-link     "> 
<span>     <div class="no-text">   <img src="/style/i/remove.png" alt="" class="m">   </div>     </span>  
</a>    
</div>
  
<a href="/user/?id=<?= $ank['id']?>" class="tdn">       
<span class="pr">   <div class="inl_bl relative"> <?= ava40($ank['id'])?>   </div>     </span>        
</a>  
</div>  
<div class="pre_content_wrap break-word"> 
<?= group($ank['id'])?>   
<a href="/user/?id=<?= $ank['id']?>" class="black full_link">   <b><?= unick($ank['id'])?></b>  </a>  <?= medal($ank['id'])?>             
<?
$rTime = time()-600;
if($ank['date_last'] < $rTime){
?>
<span class="grey">(<?= vremja($ank['date_last'])?>)</span>
<?
}
?>       
<div class="grey"> 
<?
if ($ank['ank_name'] != NULL OR $ank['ank_family'] != NULL){
?>
<div class="grey break-word">
<?
if ($ank['ank_name'] != NULL){
?>
<?= text($ank['ank_name'])?> 
<?
}
if ($ank['ank_family'] != NULL){
?>
<?= text($ank['ank_family'])?> 
<?
}
?>
</div>  
<?
}
// Склон текста & Tw1nGo
$my_age_day = array('год', 'года', 'лет');
$ank['ank_age'] = date("Y") - $ank['ank_g_r'];
if ($ank['ank_d_r'] != NULL && $ank['ank_m_r'] != NULL && $ank['ank_g_r'] != NULL){
?>
<?= des2num($ank['ank_age'], $my_age_day)?>
<?
if ($ank['ank_city'] != NULL){
?>, <?
}
}
if ($ank['ank_city'] != NULL){
?>
<span class="arrow_link"><?= text($ank['ank_city'])?></span>
<?
}
?>
</div> 
<?
if ($post['read'] == 1){
?>       
<div class="grey"> Посещение: <span style="color:red;"><?= vremja($post['time'])?></span> </div> 
<?
}else{
?>       
<div class="grey"> Посещение: <?= vremja($post['time'])?> </div> 
<?
}
?>            
</div>     
</div>       </div>
<?
// Помечаем пост прочитанным
mysql_query("UPDATE `my_guests` SET `read` = '0' WHERE `id` = '$post[id]' LIMIT 1");
}



if ($k_page>1)str("?",$k_page,$page);

if($k_post > 0){
?>
<div class="wrapper bb0">  
<div class="bord-botm">     
<a href="?truncate" class="link "> <span>        <img src="/style/i/delete.png" alt="" class="m">      <span class="m">  Очистить список </span>          </span>  </a>     </div>    </div>
<?
}


include_once H.'sys/inc/tfoot.php';
?>