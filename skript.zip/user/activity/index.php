<?
include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';

if (isset($user)){
	$ank['id'] = $user['id'];
}
if (isset($_GET['id'])){
	$ank['id'] = intval($_GET['id']);
}

$ank = get_user($ank['id']);

// Если не определили юзера
if(!$ank || $ank['id'] == 0 || !isset($_GET['id'])){
$set['title'] = 'Ошибка';
include_once H.'sys/inc/thead.php';
title();
?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Ошибка</span> </span>       </div>
<div class="list_item">Пользователь не обнаружен</div>
<?
include_once H.'sys/inc/tfoot.php';
exit;
}

/* Бан пользователя */ 
if ((!isset($user) || $user['group_access'] == 0) && mysql_result(mysql_query("SELECT COUNT(*) FROM `ban` WHERE `razdel` = 'all' AND `id_user` = '$ank[id]' AND (`time` > '$time' OR `navsegda` = '1')"), 0)!=0)
{
$set['title'] = 'Активность : ' . $ank['nick']; // заголовок страницы
include_once H.'sys/inc/thead.php';
title();

$post_ban = mysql_fetch_assoc(mysql_query("SELECT * FROM `ban` WHERE `id_user` = '$ank[id]' AND `time` > '$time'"));
?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text"><?= $ank['nick']?></span> </span>       </div>
<div class="wrapper"> 
<div class="block t_center bord-botm grey">   Этот аккаунт был заблокирован за нарушение <a href="/rules.php">условий использования сервиса</a>.   </div>  

</div>
<?

include_once H.'sys/inc/tfoot.php';
exit;
}


$set['title'] = "Активность : " . $ank['nick'];

include_once H.'sys/inc/thead.php';

title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $ank['id']?>"><?= $ank['nick']?></a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Активность</span> </span>       </div>

<link rel="stylesheet" type="text/css" href="http://spac.me/css/custom/Common/SubTabsWap.css?r=1451p" main_css="1"/>
<?

err();

$rTime = time()-600;

$_SESSION['user_sort'] = null;
$pagesis = null;
if (isset($_GET['List']) && ($_GET['List'] == '0' || $_GET['List'] == '1' || $_GET['List'] == '2'))
{
if ($_GET['List'] == '0'){
	$_SESSION['user_sort'] = 0;
	$pagesis = '&List=0';
}
else if ($_GET['List'] == '1'){
	$_SESSION['user_sort'] = 1;
	$pagesis = '&List=1';
}
else if ($_GET['List'] == '2'){
	$_SESSION['user_sort'] = 2;
	$pagesis = '&List=2';
}
}

?>
<div>   
     
<div>   
<div class="stnd_padd oh light_border_bottom "> 
 
<div class="left dot_pic">      
<?
if (isset($user) && $ank['id'] == $user['id']){
?>
<a href="/foto/edit_photo/?" title="Изменить аватар">
<div class="inl_bl relative"> <?= ava80($ank['id'])?>   </div>      
</a>
<?
}
else{
?>
<div class="inl_bl relative"> <?= ava80($ank['id'])?>   </div> 
<?
}



?> 
</div> 

<div class="left"> 

<span class="m"> <?= group($ank['id'])?> 
<a href="/user/?id=<?= $ank['id']?>" class="mysite-link"><b class="nick"><?= $ank['nick']?></b></a>  
</span>    
<?
if($ank['rating'] > 0){
?>
<div class="inl_bl m">  <span class="bordered grey"> <?= $ank['rating']?> </span>  </div>      
<?
}
if ((user_access('user_ban_set') || user_access('user_ban_set_h') || user_access('user_ban_unset')) && $ank['id'] != $user['id']){
?>
<a href="/adm_panel/ban.php?id=<?= $ank['id']?>"><font color="red">[Бан]</font></a>
<?
}
?>
<div> 
<?
if ($ank['ank_name'] != NULL OR $ank['ank_family'] != NULL){
?>
<div class="grey break-word">
<?
if ($ank['ank_name'] != NULL){
?>
<?= text($ank['ank_name'])?> 
<?
}
if ($ank['ank_family'] != NULL){
?>
<?= text($ank['ank_family'])?> 
<?
}
?>
</div>  
<?
}
// Склон текста & Tw1nGo
$my_age_day = array('год', 'года', 'лет');
$ank['ank_age'] = date("Y") - $ank['ank_g_r'];
?>
<div class="grey">
<?
if ($ank['ank_d_r'] != NULL && $ank['ank_m_r'] != NULL && $ank['ank_g_r'] != NULL){
?>
<?= des2num($ank['ank_age'], $my_age_day)?>
<?
if ($ank['ank_city'] != NULL){
?>, <?
}
}
if ($ank['ank_city'] != NULL){
?>
<span class="arrow_link"><?= text($ank['ank_city'])?></span>
<?
}
?>
</div>    
<?
if($ank['date_last'] < $rTime){
?>
<div class="oh"> <div class="left">     
<span class="bordered grey">           <span class=" grey">  <?= vremja($ank['date_last'])?> </span>         </span>     
</div> </div>
<?
}else{
if ($user['id'] != $ank['id']){
?>
<div class="oh"> <div class="left"> <span class="bordered green"> <span class=" green">  В сети </span> </span> </div> </div>
<?
}
}
?> 
</div> 
</div>   </div>   </div> </div> 

<div class="tabs_block oh">    
<a href="/user/?id=<?= $ank['id']?>" class="tab_item left">  Профиль  </a>   
<a href="/user/anketa/?id=<?= $ank['id']?>" class="tab_item left">  Анкета  </a>   
<div class="tab_item left tab_active black">  Активность  </div>   
</div>
<?

?>
<div class="wrapper"> 
<table class="table__wrap table_no_borders nowrap"> <tbody><tr>  
<?
if($_SESSION['user_sort'] == 0){

$set['p_str'] = '5';
$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `user_activity`  WHERE `id_user` = '$ank[id]' "),0);
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str'] * $page-$set['p_str'];

$q = mysql_query("SELECT * FROM `user_activity` WHERE `id_user` = '$ank[id]' ORDER BY `time` DESC LIMIT $start, $set[p_str]");


?>
<td class="table__cell" width="33%">  
<div class="link sub_selected b"> Все   </div>  
</td>  

<td class="table__cell" width="33%">  
<a href="/user/activity/?id=<?= $ank['id']?>&amp;List=1" class="link b"> Записи   </a>  
</td>  

<td class="table__cell" width="33%">  
<a href="/user/activity/?id=<?= $ank['id']?>&amp;List=2" class="link b"> Файлы   </a>  
</td>  
<?
}
elseif($_SESSION['user_sort'] == 1){

$set['p_str'] = '5';
$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `user_activity`  WHERE `id_user` = '$ank[id]' AND `type` != 'album'"),0);
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str'] * $page-$set['p_str'];

$q = mysql_query("SELECT * FROM `user_activity` WHERE `id_user` = '$ank[id]' AND `type` != 'album' ORDER BY `time` DESC LIMIT $start, $set[p_str]");


?>
<td class="table__cell" width="33%">  
<a href="/user/activity/?id=<?= $ank['id']?>&amp;List=0" class="link b"> Все     </a>  
</td>  

<td class="table__cell" width="33%"> 
<div class="link sub_selected b">  Записи  </div> 
</td>  

<td class="table__cell" width="33%">  
<a href="/user/activity/?id=<?= $ank['id']?>&amp;List=2" class="link b"> Файлы   </a>  
</td>  
<?
}elseif($_SESSION['user_sort'] == 2){

$set['p_str'] = '5';
$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `user_activity`  WHERE `id_user` = '$ank[id]' AND `type` = 'album'"),0);
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str'] * $page-$set['p_str'];

$q = mysql_query("SELECT * FROM `user_activity` WHERE `id_user` = '$ank[id]' AND `type` = 'album' ORDER BY `time` DESC LIMIT $start, $set[p_str]");


?>
<td class="table__cell" width="33%">  
<a href="/user/activity/?id=<?= $ank['id']?>&amp;List=0" class="link b"> Все     </a>  
</td>  

<td class="table__cell" width="33%">  
<a href="/user/activity/?id=<?= $ank['id']?>&amp;List=1" class="link b">  Записи  </a>  
</td>  

<td class="table__cell" width="33%"> 
<div class="link sub_selected b">  Файлы  </div> 
</td>  
<?
}
?>
</tr> </tbody></table> 
</div>
<?


if($ank['id'] == $user['id']){
$kto_vi = 'Ваш список активности пуст.';
}
else{
$kto_vi = 'Список активности '.$ank['nick'].' пуст.';
}

if ($k_post == 0)
{
?>
<div class="wrapper block"> <?= $kto_vi?> </div>
<?
}


while ($post = mysql_fetch_assoc($q))
{
$type = $post['type'];
$avtor = get_user($post['avtor']);
$name = null;

$d = opendir('inc/');

while($dname = readdir($d)){
	if ($dname != '.' && $dname != '..'){
		include 'inc/' . $dname;
	}
}

}


if ($k_page > 1)str('?id='.$ank['id'].''.$pagesis.'&',$k_page,$page); 

?>
<a href="/user/?id=<?= $ank['id']?>" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?

include_once H.'sys/inc/tfoot.php';
?>