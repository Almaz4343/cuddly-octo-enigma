<?


/*
* Вывод блока с содержимым 
*/
if ($type  ==  'album')
{
$gallery = mysql_fetch_assoc(mysql_query("SELECT * FROM `gallery` WHERE `id` = '".$post['id_file']."' LIMIT 1"));
$PhoTo = mysql_fetch_assoc(mysql_query("SELECT * FROM `gallery_foto` WHERE `id_gallery` = '".$post['id_file']."' AND `id` = '".$post['id_photo']."' LIMIT 1"));


if ($post['count'] > 4){
	$kol = '4';
	$kol2 = $post['count'] - 4;
	$dop_div = ' bord-botm';
}
else
{
	$kol = $post['count'];
	$kol2 = null;
	$dop_div = '';
}
	
if ($PhoTo['id'])
{
$as = mysql_query("SELECT * FROM `gallery_foto` WHERE `id_gallery` = '".$post['id_file']."' AND `id` = '".$post['id_photo']."' ORDER BY `time` DESC LIMIT 1");

?>
<div class="wrapper"> 
<div class="block oh">  
<div class="oh grey no-borders"> 
<div> 
<div class="grey small right"><?= vremja($post['time'])?></div>  
<span class="grey"> Добавил<?= ($avtor['pol'] == 1 ? '' : 'а')?> 1  фото в папку  </span> 
<a href="/foto/<?= $avtor['id']?>/<?= $gallery['id']?>/" class="arrow_link break-word">  «<span><?= text($gallery['name'])?></span>»</a>   
</div>  
<?

while ($xx = mysql_fetch_assoc($as))
{
?> 
<div class="font0">  
<div class=" tiled_item tiled_item-200"> 
<div class="tiled_inner t_center relative">   
<span class="relative" style="display: inline-block;max-width: 100%; width: 100%; padding:5px;">   
<span class="inl_bl">        
<a class="tdn gview_link" href="/foto/<?= $gallery['id_user']?>/<?= $gallery['id']?>/<?= $xx['id']?>/">   
<div class="inl_bl relative"> 
<img src="/foto/pic200/<?= $xx['id']?>..p.201.200.0.jpg" alt="" class="preview s201_200">
<?
if($xx['metka'] != 0){
?>
<img class="p16 f_18p" src="/style/i/adult_ico.png" alt="">  
<?
}
?>   
</div>      
</a>             
</span>    
</span>            
</div> </div>   
<?
}

?>
</div>   </div>   </div> </div>
<?
/*
if (isset($kol2)){
?>
<a href="/foto/<?= $avtor['id']?>/<?= $gallery['id']?>/" class="link    is_final   " style="border-top: 1px solid #c5d3e1;"> 
<span>        
<img src="/style/i/down.png" alt="" class="m">      <span class="m">  Посмотреть ещё <?= $kol2?> фото </span>          
</span>  
</a>
<?
}
*/


}
else
{
?>
<div class="wrapper"> <div class="block oh">  <b class="grey">Объект удалён</b>  </div>  </div>
<?
query("DELETE FROM `user_activity` WHERE `id_user` = '$user[id]' AND `id` = '$post[id]' LIMIT 1");
}
}
?>