<?
/*
* $name описание действий объекта 
*/
if ($type == 'them' && $post['avtor'] != $user['id'])
{
	$name = 'создал' . ($avtor['pol'] == 1 ? null : "а") . ' в форуме тему ';
}

/*
* Вывод блока с содержимым 
*/
if ($type == 'them')
{
$them = mysql_fetch_assoc(mysql_query("SELECT * FROM `forum_t` WHERE `id` = '" . $post['id_file'] . "' LIMIT 1"));
$razdel = mysql_fetch_assoc(mysql_query("SELECT * FROM `forum_r` WHERE `id` = '$them[id_razdel]' LIMIT 1"));
$forum = mysql_fetch_assoc(mysql_query("SELECT * FROM `forum_f` WHERE `id` = '$razdel[id_forum]' LIMIT 1"));
	
if ($them['id'])
{
$_msg = text($them['text']);

if (iconv_strlen($_msg, 'UTF-8') > 500) {
        $_msg= iconv_substr($_msg, 0, 497, 'UTF-8');
        $_msg = $_msg.'...';
}


?>
<div class="wrapper"> 
<div class="block oh">  
<div class="oh grey no-borders"> 
<div> 
<div class="grey small right"><?= vremja($post['time'])?></div>  
<span class="grey"> Добавил<?= ($avtor['pol'] == 1 ? null : "а")?>  тему  </span>   
</div>   
<div class="action-item-wrap">    
<div class="block bord-botm relative attaches_limiter"> 
<div class="oh">      <div class="oh"> 
<a class="arrow_link full_link" href="/forum/<?= $forum['id']?>/<?= $razdel['id']?>/<?= $them['id']?>/"> <b><?= text($them['name'])?></b> </a>  
<div> <?= $_msg?> </div>  
</div>  </div> <div>  
<div class="oh">   <div class="cl"></div> </div>    
</div> 
<div class="cl"></div> 
</div>     </div>  </div>   </div> </div>
<?
}
else
{
?>
<div class="wrapper"> <div class="block oh">  <b class="grey">Тема форума удалена.</b>  </div>  </div>
<?
query("DELETE FROM `user_activity` WHERE `id_user` = '$user[id]' AND `id` = '$post[id]' LIMIT 1");
}

}
?>