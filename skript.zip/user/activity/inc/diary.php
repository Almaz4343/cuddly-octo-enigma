<?
/*
* $name описание действий объекта 
*/
if ($type == 'notes' && $post['avtor'] != $user['id']) // дневники
{
	$name = 'добавил' . ($avtor['pol'] == 1 ? null : "а") . ' запись';
}

/*
* Вывод блока с содержимым 
*/
if ($type  ==  'notes')
{
$notes = mysql_fetch_assoc(mysql_query("SELECT * FROM `notes` WHERE `id` = '" . $post['id_file'] . "' LIMIT 1"));
$comm = mysql_result(mysql_query("SELECT COUNT(*) FROM `notes_komm` WHERE `id_notes` = '$notes[id]'"),0);

$_msg = text($notes['msg']);

if (iconv_strlen($_msg, 'UTF-8') > 200) {
        $_msg= iconv_substr($_msg, 0, 198, 'UTF-8');
        $_msg = $_msg.'..';
}

if ($notes['id'])
{
?>
<div class="wrapper"> 
<div class="block oh">  
<div class="oh grey no-borders"> 
<div> 
<div class="grey small right"><?= vremja($post['time'])?></div>  
<span class="grey"> Добавил<?= ($avtor['pol'] == 1 ? null : "а")?>  запись  </span>   
</div>   
<div class="action-item-wrap">    
<div class="block bord-botm relative attaches_limiter"> 
<div class="oh">      
<?
if ($notes['file_ves'] != 0 && $notes['file_raz'] != NULL && is_file(H."user/blogs/files/".$notes['id'].".dat"))
{
if ($notes['file_raz'] == 'png' || $notes['file_raz'] == 'gif' || $notes['file_raz'] == 'jpg' || $notes['file_raz'] == 'jpeg')
{
?>
<div class="left t-padd_right">     
<div>  
<span class="short_attach">   
<div class="inl_bl">        
<span class="pr">   
<div class="inl_bl relative"> 
<img src="/user/blogs/file/<?= $notes['id']?>.<?= $notes['file_raz']?>" alt="" class="preview s81_80" style="width:80px;">   
</div>     
</span>             
</div>     
</span>  
</div>    
</div>
<?
}
}
?>
<div class="oh"> 
<a class="arrow_link full_link" href="/user/blogs/read/?id=<?= $notes['id']?>"> <b><?= text($notes['name'])?></b> </a>  
<div> <?= $_msg?> </div>  
</div>  </div> <div>  
<div class="oh">   <div class="cl"></div> </div>    
</div> 
<div class="cl"></div> 
</div>     </div>  </div>   </div> </div>
<?


/*
<div>   
<a href="/user/lenta/subscr/?uid=<?=  $avtor['id']?>" class="mysite-link"><b class="nick"><?= $avtor['nick']?></b></a>
<?= medal($avtor['id'])?>      
<span class="grey">  <?= $name?>  </span>   
</div> 
<div class="grey small cl"> <?= vremja($post['time'])?> </div>     
<div class="action-item-wrap">     
<div class="block bord-botm relative"> 
<div class="oh">   
<div class="cl"></div>   
<div class="oh arrow_link"> 
<a class="arrow_link full_link" href="/user/blogs/read/?id=<?= $notes['id']?>"> <b>  <?= text($notes['name'])?>  </b> </a>  
<div> <?= $_msg?>  </div>  
</div>   
</div> <div>  
<div class="oh">   <div class="cl"></div> </div>    
</div> <div class="cl"></div> </div>     
</div>  </div>  </div>  
<?
*/
}
else
{
?>
<div class="wrapper"> <div class="block oh">  <b class="grey">Блог удалён</b>  </div>  </div>  
<?
query("DELETE FROM `user_activity` WHERE `id_user` = '$user[id]' AND `id` = '$post[id]' LIMIT 1");
}
}
?>