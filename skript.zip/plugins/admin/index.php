<?




include_once '../../sys/inc/start.php';




include_once '../../sys/inc/compress.php';




include_once '../../sys/inc/sess.php';




include_once '../../sys/inc/home.php';




include_once '../../sys/inc/settings.php';




include_once '../../sys/inc/db_connect.php';




include_once '../../sys/inc/ipua.php';




include_once '../../sys/inc/fnc.php';




include_once '../../sys/inc/user.php';

user_access('adm_panel_show',null,'/'.SID);









$set['title']='Раздел администрации'; // заголовок страницы









include_once '../../sys/inc/thead.php';




title();



?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Раздел для администрации</span> </span>       </div>

<?




if (user_access('adm_panel_show')){
?>
<div class="wrapper"> 
<a href="spam" class="link darkblue"> <img src="//c.spac.me/i/complaint.png" alt="" class="m"> Жалобы
<?
include_once "spam/count.php";
?>
</a>
<a href="chat" class="link darkblue"> <img src="//c.spac.me/i/chats.png" alt="" class="m p16"> Чат
<?
include_once "chat/count.php";
?>
</a>
<a href="/adm_panel/" class="link darkblue"> <img src="//c.spac.me/i/ico/settings.png" alt="" class="m"> Админка</a>
</div>
<?


























}




include_once '../../sys/inc/tfoot.php';




?>




