<?
$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_t` WHERE 
	`name` like '%" . $search_text . "%' OR
	`text` like '%" . $search_text . "%'
	"), 0);
	
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str']*$page-$set['p_str'];


$q = mysql_query("SELECT * FROM `forum_t` WHERE 
	`name` like '%" . $search_text . "%' OR
	`text` like '%" . $search_text . "%'
	 LIMIT $start, $set[p_str]");


?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/plugins/search/?search">Поиск</a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Обсуждения</span> </span>           </div>
<div class="wrapper block"> 
<div>  <div> <b>«<span class="service_item"><?= $search_text?></span>»</b> </div>
<div class="search-form">
  
<div class="wrapper-nobg"> 
<form action="?search&search=forum" method="post">  
<table class="table__wrap search-wrap input-txt_grid"> <tbody><tr> 
<td class="input-txt_grid_input"> 
<div class="input-txt_wrapper_search relative"> <input class="input-txt" name="search" value="<?= $search_text?>" maxlength="64" type="text">   </div> 
</td> 
<td class="input-txt_grid_sep"></td> 
<td class="input-txt_grid_btn"> <input class="search__btn" value="Найти" type="submit">   </td> 
</tr> </tbody></table>     
</form> 
</div>

</div> </div> </div>
<?


if ($k_post == 0)
{	
?>
<div class="wrapper block">Нет результатов</div>
<?
}


while ($them = mysql_fetch_assoc($q))
{
// Определение подфорума
$forum = mysql_fetch_array(mysql_query("SELECT * FROM `forum_f` WHERE `id` = '$them[id_forum]' LIMIT 1"));
	
// Определение раздела
$razdel = mysql_fetch_array(mysql_query("SELECT * FROM `forum_r` WHERE `id` = '$them[id_razdel]' LIMIT 1"));
	
	
$count = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_p` WHERE `id_forum` = '$forum[id]' AND `id_razdel` = '$razdel[id]' AND `id_them` = '$them[id]'"),0);

?>
<div class="stnd_padd light_border_bottom overfl_hid">  
<a href="/forum/<?= $forum['id']?>/<?= $razdel['id']?>/<?= $them['id']?>/"> <?= text($them['name'])?></a> 
<span class="grey">(<?= $count?>)</span>  
</div>
<?
	
}

echo '</table>';

// Вывод страниц
if ($k_page > 1)str("?search=forum&amp;",$k_page,$page); 
?>