<?
$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `notes` WHERE 
	`name` like '%" . $search_text . "%' OR
	`name` like '%" . translit($search_text) . "%' OR
	`name` like '%" . retranslit($search_text) . "%' OR
	`msg` like '%" . $search_text . "%' OR
	`msg` like '%" . translit($search_text) . "%' OR
	`msg` like '%" . retranslit($search_text) . "%'
	"), 0);
	
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str']*$page-$set['p_str'];


$q = mysql_query("SELECT * FROM `notes` WHERE 
	`name` like '%" . $search_text . "%' OR
	`name` like '%" . translit($search_text) . "%' OR
	`name` like '%" . retranslit($search_text) . "%' OR
	`msg` like '%" . $search_text . "%' OR
	`msg` like '%" . translit($search_text) . "%' OR
	`msg` like '%" . retranslit($search_text) . "%'
	 LIMIT $start, $set[p_str]");



?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/plugins/search/?search">Поиск</a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Записи</span> </span>           </div>
<div class="wrapper block"> 
<div>  <div> <b>«<span class="service_item"><?= $search_text?></span>»</b> </div>
<div class="search-form">
  
<div class="wrapper-nobg"> 
<form action="?search&search=diary" method="post">  
<table class="table__wrap search-wrap input-txt_grid"> <tbody><tr> 
<td class="input-txt_grid_input"> 
<div class="input-txt_wrapper_search relative"> <input class="input-txt" name="search" value="<?= $search_text?>" maxlength="64" type="text">   </div> 
</td> 
<td class="input-txt_grid_sep"></td> 
<td class="input-txt_grid_btn"> <input class="search__btn" value="Найти" type="submit">   </td> 
</tr> </tbody></table>     
</form> 
</div>

</div> </div> </div>
<?


if ($k_post == 0)
{	
?>
<div class="wrapper block">Нет результатов</div>
<?
}
else{

?>
<div class="wrapper bb0">
<?

while ($post = mysql_fetch_assoc($q))
{
$us_ank = get_user($post['id_user']);
$koment = mysql_result(mysql_query("SELECT COUNT(*) FROM `notes_komm` WHERE `id_notes` = '".$post['id']."'"), 0);
$kan_post = mysql_fetch_assoc(mysql_query("SELECT * FROM `notes_dir` WHERE `id` = '".$post['id_dir']."' LIMIT 1"));
$_msg = text($post['msg']);
if (iconv_strlen($_msg, 'UTF-8') > 50) {
        $_msg= iconv_substr($_msg, 0, 200, 'UTF-8');
        $_msg = $_msg.'...';
}
?>
<div class="block bord-botm relative attaches_limiter"> 
<div class="oh">
<div class="grey"> <?= group($us_ank['id'])?> <?= unick($us_ank['id'])?> </div>     
<div class="cl pad_t_a"></div>   
<div class="oh"> 
<a class="arrow_link full_link" href="/user/blogs/read/?id=<?= $post['id']?>"> 
<b>  <?= text($post['name'])?>  </b> 
</a>  
<div> <?= output_text($_msg)?> </div>  
</div>   </div> 
<?
if($koment > 0 OR $kan_post['name'] != null){
?>
<div>  
<div class="oh">   
<div class="oh cl grey pad_t_a">  
<?
if($koment > 0){
?> 
<span class="left"> 
<img src="//c.spac.me/i/comm_ico.png" class="m p16" alt=""> 
<span class="m"><?= $koment?></span> 
</span>  
<?
}
if($kan_post['name'] != null){
?> 
<span class="m right"> <?= text($kan_post['name'])?> </span>  
<?
}
?> 
</div>  <div class="cl"></div> </div> </div>    
<?
}
?>
<div class="cl"></div> 
</div>
<?
}
?>
</div>
<?
}



// Вывод страниц
if ($k_page > 1)str("?search=people&amp;",$k_page,$page); 

?>
<a href="?search" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Поиск  </a>
<?

?>