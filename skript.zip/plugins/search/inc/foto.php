<?
$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `gallery_foto` WHERE 
	`name` like '%" . $search_text . "%' OR
	`name` like '%" . translit($search_text) . "%' OR
	`name` like '%" . retranslit($search_text) . "%' OR
	`opis` like '%" . $search_text . "%' OR
	`opis` like '%" . translit($search_text) . "%' OR
	`opis` like '%" . retranslit($search_text) . "%'
	"), 0);
	
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str']*$page-$set['p_str'];


$q = mysql_query("SELECT * FROM `gallery_foto` WHERE 
	`name` like '%" . $search_text . "%' OR
	`name` like '%" . translit($search_text) . "%' OR
	`name` like '%" . retranslit($search_text) . "%' OR
	`opis` like '%" . $search_text . "%' OR
	`opis` like '%" . translit($search_text) . "%' OR
	`opis` like '%" . retranslit($search_text) . "%'
	 LIMIT $start, $set[p_str]");

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/plugins/search/?search">Поиск</a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Фото и картинки</span> </span>           </div>
<div class="wrapper block"> 
<div>  <div> <b>«<span class="service_item"><?= $search_text?></span>»</b> </div>
<div class="search-form">
  
<div class="wrapper-nobg"> 
<form action="?search&search=photo" method="post">  
<table class="table__wrap search-wrap input-txt_grid"> <tbody><tr> 
<td class="input-txt_grid_input"> 
<div class="input-txt_wrapper_search relative"> <input class="input-txt" name="search" value="<?= $search_text?>" maxlength="64" type="text">   </div> 
</td> 
<td class="input-txt_grid_sep"></td> 
<td class="input-txt_grid_btn"> <input class="search__btn" value="Найти" type="submit">   </td> 
</tr> </tbody></table>     
</form> 
</div>

</div> </div> </div>
<?

if ($k_post == 0)
{	
?>
<div class="wrapper block">Нет результатов</div>
<?
}else{

while ($foto = mysql_fetch_assoc($q))
{
$gallery = mysql_fetch_assoc(mysql_query("SELECT * FROM `gallery` WHERE `id` = '$foto[id_gallery]' LIMIT 1"));
$ank = get_user($foto['id_user']);
?>
<div class="list_item bookmark_block"> 
<div class="list_item bookmark_block js-file_item oh">    
<div class="left font0 relative" style="margin-right:5px;">      
<a class="tdn gview_link" href="/foto/<?= $ank['id']?>/<?= $gallery['id']?>/<?= $foto['id']?>/">   
<div class="inl_bl relative"> 
<img src="/foto/pic50/<?= $foto['id']?>.jpg" alt="" class="preview">   
</div>      
</a>         
</div>  
<div class="oh">   <span class="file_size right">      </span>   
<a href="/foto/<?= $ank['id']?>/<?= $gallery['id']?>/<?= $foto['id']?>/" class="arrow_link strong_link">   
<img src="/style/i/icon_img_jpg.gif" alt="" class="m p16">  <span class="m"><?= text($foto['name'])?></span>
</a>
<span style="color:gray;" class="m">.jpg</span> 
<?
if($foto['metka'] != 0){
?>
<img src="/style/i/adult_ico.png" alt="" class="m p16">
<?
}
?>       
<span class="file_size m"> <?= size_file(filesize(H.'sys/tpic/pictures/'.$foto['id'].'.0.jpg'))?> </span>    
<?
if($foto['opis'] != NULL){
?>
<br> <?= text($foto['opis'])?>
<?
}
?>  
<div class="clear"></div> </div> 
<div class="clear"></div>  </div>   
</div>
<?
}
// Вывод страниц
if ($k_page > 1)str("?search=photo&amp;",$k_page,$page);

?>
<a href="?search" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Поиск  </a>
<?

}