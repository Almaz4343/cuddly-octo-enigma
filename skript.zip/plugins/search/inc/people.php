<?
$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `user` WHERE 
	`id` <=> '" . $search_text . "' OR  
	`nick` like '%" . $search_text . "%' OR
	(`ank_icq` <=> '" . $search_text . "' AND `ank_icq` != '0') OR 
	(`ank_city` = '" . $search_text . "') OR 
	(`ank_family` = '" . $search_text . "') OR 
	(`ip` <=> '" . ip2long($search_text) . "' AND `ip` != NULL) OR 
	`ank_mail` <=> '" . $search_text . "'
	"), 0);
	
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str']*$page-$set['p_str'];


$q = mysql_query("SELECT * FROM `user` WHERE 
	`id` <=> '" . $search_text . "' OR  
	`nick` like '%" . $search_text . "%' OR
	(`ank_icq` <=> '" . $search_text . "' AND `ank_icq` != '0') OR 
	(`ank_city` = '" . $search_text . "') OR 
	(`ank_family` = '" . $search_text . "') OR 
	(`ip` <=> '" . ip2long($search_text) . "' AND `ip` != NULL) OR 
	`ank_mail` <=> '" . $search_text . "'
	 ORDER BY `date_last` DESC LIMIT $start, $set[p_str]");

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="//c.spac.me/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/plugins/search/?search">Поиск</a> </span>     <span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Люди</span> </span>       </div>

<div class="wrapper block"> 
<div>  
<div> <b>«<span class="service_item"><?= $search_text?></span>»</b> </div>

<div class="wrapper-nobg"> 
<form action="?search&search=users" method="post">  
<table class="table__wrap search-wrap input-txt_grid"> <tbody><tr> 
<td class="input-txt_grid_input"> 
<div class="input-txt_wrapper_search relative"> <input class="input-txt" name="search" value="<?= $search_text?>" maxlength="64" type="text">   </div> 
</td> 
<td class="input-txt_grid_sep"></td> 
<td class="input-txt_grid_btn"> <input class="search__btn" value="Найти" type="submit">   </td> 
</tr> </tbody></table>     
</form> 
</div>
  

</div> </div> 
<?

if ($k_post == 0)
{	
?>
<div class="wrapper block">Нет результатов</div>
<?
}else{

?>
<div class="start_page_padd light_blue_bg blue_border_bottom oh"> <b class="grey">Подходящие люди</b> (<?= $k_post?>) </div>
<div> <div class="list f-c_fll">
<?

while ($ank = mysql_fetch_assoc($q))
{

	$uSet = mysql_fetch_array(mysql_query("SELECT * FROM `user_set` WHERE `id_user` = '$ank[id]'  LIMIT 1"));
	$frend=mysql_result(mysql_query("SELECT COUNT(*) FROM `frends` WHERE (`user` = '$user[id]' AND `frend` = '$ank[id]') OR (`user` = '$ank[id]' AND `frend` = '$user[id]') LIMIT 1"),0);
	$frend_new=mysql_result(mysql_query("SELECT COUNT(*) FROM `frends_new` WHERE (`user` = '$user[id]' AND `to` = '$ank[id]') OR (`user` = '$ank[id]' AND `to` = '$user[id]') LIMIT 1"),0);

?>
<div class="js-row block bord-botm oh grey relative">        <div class="left font0">   
<a href="/user/?id=<?= $ank['id']?>" class="tdn">       
<span class="pr">   <div class="inl_bl relative"> <?= ava80($ank['id'])?>   </div>     </span>        
</a>  
</div>  
<div class="pre_content_wrap break-word"> 
<?= group($ank['id'])?>  <a href="/user/?id=<?= $ank['id']?>" class="black full_link">   <b><?= unick($ank['id'])?></b>  </a>             
<span class="grey">(<?= vremja($ank['date_last'])?>)</span> <div class="grey">
<?
if($ank['ank_name'] != null OR $ank['ank_family'] != null){
?>
<div class="break-word">
<?
}
if($ank['ank_name'] != null){
?>  
<?= text($ank['ank_name'])?>
<?
}
if($ank['ank_family'] != null){
?>  
<?= text($ank['ank_family'])?>
<?
}
if($ank['ank_name'] != null OR $ank['ank_family'] != null){
?>
</div>
<?
}
	if (long2ip($ank['ip']) == $search_text)
	echo 'Найден по IP: <font style="color: ' . $color . ';">' . long2ip($ank['ip']) . '</font><br />';
	
	if ($ank['id'] == $search_text)
	echo 'ID: <font style="color: ' . $color . ';">' . intval($ank['id']) . '</font><br />';
	
	if ($ank['ank_city'] == $search_text)
	echo 'Город: <font style="color: ' . $color . ';">' . text($ank['ank_city']) . '</font><br />';
	
	if ($ank['ank_mail'] == $search_text)
	echo 'E-Mail: <font style="color: ' . $color . ';">' . text($ank['ank_mail']) . '</font><br />';

?>
</div>   
<?  
if(isset($user) && $user['id'] != $ank['id']){
?>    
<div class="relative"> 
<?
if ($frend_new == 0 && $frend==0){
?>
<div class="js-subscr_link">    
<a href="/user/frends/create.php?add=<?= $ank['id']?>" class="inl-link  link-blue">          
<img src="//c.spac.me/i/befriends.png" alt="" class="m">      <span class="m">  Дружить </span>          
<!-- --><!-- --><!-- --></a><!-- --> </div> 
<?
}elseif ($frend_new == 1){
?>
<div class="js-subscr_link">    
<a href="/user/frends/create.php?otm=<?= $ank['id']?>" class="inl-link js-action_link  link-blue">          
<img src="//c.spac.me/i/befriends_inprocess.png" alt="" class="m">      <span class="m">  Запрошено </span>          
<!-- --><!-- --><!-- --></a><!-- --> </div> 
<?
}elseif ($frend == 2){
?>
<div class="js-subscr_link">    
<span data-action="friends_delete" class="inl-link js-action_link  link-green">          
<img src="//c.spac.me/i/befriends_on.png" alt="" class="m">      <span class="m">  Дружите </span>          
<!-- --><!-- --><!-- --></span><!-- --> </div> 
<?
}
?>   
</div>      
<?
}
?>
</div>     </div>
<?

}

?>
</div></div>
<?

// Вывод страниц
if ($k_page > 1)str("?search=users&amp;",$k_page,$page);

}

 
?>