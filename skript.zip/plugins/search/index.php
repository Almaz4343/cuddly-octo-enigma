<?
define('H', $_SERVER['DOCUMENT_ROOT'] . '/');
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';

if (isset($_POST['search']))
{
	$_SESSION['search_'] = $_POST['search'];
}

// Если ничего не искали
if (!isset($_SESSION['search_']))
$_SESSION['search_'] = NULL;
else
{
	$search_text = text($_SESSION['search_']);
}

// Конфигурационный файл
include 'inc/config.php';

// Заголовок
$set['title'] = $search_name;

include_once H.'sys/inc/thead.php';
title();
err();




if (isset($_GET['search']) && isset($search_text))
{
	$count['people'] = mysql_result(mysql_query("SELECT COUNT(*) FROM `user` WHERE 
	`id` <=> '" . $search_text . "' OR `nick` like '%" . $search_text . "%' OR
	`ank_city` = '" . $search_text . "' OR `ank_name` = '" . $search_text . "' OR `ank_family` = '" . $search_text . "'
	"), 0);
	
	$count['obmen'] = mysql_result(mysql_query("SELECT COUNT(*) FROM `obmennik_files` WHERE 
	`name` like '%" . $search_text . "%' OR
	`name` like '%" . translit($search_text) . "%' OR
	`name` like '%" . retranslit($search_text) . "%' OR
	`opis` like '%" . $search_text . "%' OR
	`opis` like '%" . translit($search_text) . "%' OR
	`opis` like '%" . retranslit($search_text) . "%'"), 0);
	
	$count['notes'] = mysql_result(mysql_query("SELECT COUNT(*) FROM `notes` WHERE 
	`name` like '%" . $search_text . "%' OR
	`name` like '%" . translit($search_text) . "%' OR
	`name` like '%" . retranslit($search_text) . "%' OR
	`msg` like '%" . $search_text . "%' OR
	`msg` like '%" . translit($search_text) . "%' OR
	`msg` like '%" . retranslit($search_text) . "%'
	"), 0);
	
	$count['forum'] = mysql_result(mysql_query("SELECT COUNT(*) FROM `forum_t` WHERE 
	`name` like '%" . $search_text . "%' OR
	`text` like '%" . $search_text . "%'
	"), 0);
	
	$count['photo'] = mysql_result(mysql_query("SELECT COUNT(*) FROM `gallery_foto` WHERE 
	`name` like '%" . $search_text . "%' OR
	`name` like '%" . translit($search_text) . "%' OR
	`name` like '%" . retranslit($search_text) . "%' OR
	`opis` like '%" . $search_text . "%' OR
	`opis` like '%" . translit($search_text) . "%' OR
	`opis` like '%" . retranslit($search_text) . "%'
	"), 0);
  
  $num = 0;
	
	if ($_GET['search'] == 'users')
	include 'inc/people.php';
	
	elseif ($_GET['search'] == 'files')
	include 'inc/obmen.php';
	
	elseif ($_GET['search'] == 'diary')
	include 'inc/notes.php';
	
	elseif ($_GET['search'] == 'forum')
	include 'inc/forum.php';

	elseif ($_GET['search'] == 'photo')
	include 'inc/foto.php';
	
	else
	{
		
if(!$_SESSION['search_'] == null){
if ($count['people'] != 0 OR $count['obmen'] != 0 OR $count['notes'] != 0 OR $count['forum'] != 0 OR $count['photo'] != 0){
?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Поиск</span> </span>       </div>

<div class="wrapper block"> 
<div>  <div> <b>«<span class="service_item"><?= text($_SESSION['search_'])?></span>»</b> </div>
<div class="search-form">  <div class="wrapper none_border search-form"> 


<div class="wrapper-nobg"> 
<form action="?search" method="post">  
<table class="table__wrap search-wrap input-txt_grid"> <tbody><tr> 
<td class="input-txt_grid_input"> 
<div class="input-txt_wrapper_search relative"> <input class="input-txt" name="search" value="<?= text($_SESSION['search_'])?>" maxlength="64" type="text">   </div> 
</td> 
<td class="input-txt_grid_sep"></td> 
<td class="input-txt_grid_btn"> <input class="search__btn" value="Найти" type="submit">   </td> 
</tr> </tbody></table>     
</form> 
</div>

 
</div>   </div> </div> </div>
<div class="wrapper">
<div class="block"> <b>Найдено:</b> </div>
<div class="text">  
<?
}
$i = 0;
if ($count['people'] != 0)
{
?>
<a href="?search=users" class="link darkblue"> 
<img src="/style/i/People.gif" alt="" class="m p16"> <span class="m">Люди</span> <span class="grey m">(<?= $count['people']?>)</span> 
</a>
<?
++$i;			
}
if ($count['notes'] != 0)
{
?>
<a href="?search=diary" class="link darkblue"> 
<img src="/style/i/label.png" alt="" class="m p16"> <span class="m">Записи</span> <span class="grey m">(<?= $count['notes']?>)</span> 
</a>
<?
++$i;		
}
		
if ($count['forum'] != 0)
{
?>
<a href="?search=forum" class="link darkblue"> 
<img src="/style/i/Forum.gif" alt="" class="m p16"> <span class="m">Обсуждения</span> <span class="grey m">(<?= $count['forum']?>)</span> 
</a>
<?
++$i;			
}	
if ($count['photo'] != 0)
{
?>
<a href="?search=photo" class="link darkblue"> 
<img src="/style/i/PhotoIcon.gif" alt="" class="m p16"> <span class="m">Фото и картинки</span> <span class="grey m">(<?= $count['photo']?>)</span> 
</a>
<?
++$i;			
}	
if ($count['obmen'] != 0)
{
?>
<a href="?search=files" class="link darkblue"> 
<img src="/style/i/SharedZone.gif" alt="" class="m p16"> <span class="m">Файлы</span> <span class="grey m">(<?= $count['obmen']?>)</span> 
</a>
<?
++$i;			
}
		

if ($count['people'] != 0 OR $count['obmen'] != 0 OR $count['notes'] != 0 OR $count['forum'] != 0 OR $count['photo'] != 0){
?>
</div></div>
<a href="/plugins/search/" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?
}	
		if ($i == 0)
		{

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Поиск</span> </span>       </div>

<div class="wrapper block"> 
<div>  <div> <b>«<span class="service_item"><?= text($_SESSION['search_'])?></span>»</b> </div>
<div class="search-form">  <div class="wrapper none_border search-form"> 
<div class="wrapper-nobg"> 
<form action="?search" method="post">  
<table class="table__wrap search-wrap input-txt_grid"> <tbody><tr> 
<td class="input-txt_grid_input"> 
<div class="input-txt_wrapper_search relative"> <input class="input-txt" name="search" value="<?= text($_SESSION['search_'])?>" maxlength="64" type="text">   </div> 
</td> 
<td class="input-txt_grid_sep"></td> 
<td class="input-txt_grid_btn"> <input class="search__btn" value="Найти" type="submit">   </td> 
</tr> </tbody></table>     
</form> 
</div> 
</div>   </div> </div> </div>
<div class="wrapper block"> По вашему запросу ничего не найдено. </div>

<a href="?" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?

		}
	
}else{
?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Поиск</span> </span>       </div>

<div class="wrapper block"> 
<div>  <div class="search-form">  <div class="wrapper none_border search-form"> 
<div class="wrapper-nobg"> 
<form action="?search" method="post">  
<table class="table__wrap search-wrap input-txt_grid"> <tbody><tr> 
<td class="input-txt_grid_input"> 
<div class="input-txt_wrapper_search relative"> <input class="input-txt" name="search" value="<?= text($_SESSION['search_'])?>" maxlength="64" type="text">   </div> 
</td> 
<td class="input-txt_grid_sep"></td> 
<td class="input-txt_grid_btn"> <input class="search__btn" value="Найти" type="submit">   </td> 
</tr> </tbody></table>     
</form> 
</div> 
</div>   </div> </div> </div>
<a href="/" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?
}

}
}
else
{
?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Поиск</span> </span>       </div>

<div class="wrapper block"> 
<div>  <div class="search-form">  <div class="wrapper none_border search-form"> 
<div class="wrapper-nobg"> 
<form action="?search" method="post">  
<table class="table__wrap search-wrap input-txt_grid"> <tbody><tr> 
<td class="input-txt_grid_input"> 
<div class="input-txt_wrapper_search relative"> <input class="input-txt" name="search" value="" maxlength="64" type="text">   </div> 
</td> 
<td class="input-txt_grid_sep"></td> 
<td class="input-txt_grid_btn"> <input class="search__btn" value="Найти" type="submit">   </td> 
</tr> </tbody></table>     
</form> 
</div> 
</div>   </div> </div> </div>
<a href="/" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?
} 

include_once H.'sys/inc/tfoot.php';
?>