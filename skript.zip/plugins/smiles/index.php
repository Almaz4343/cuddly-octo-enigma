<?

include_once '../../sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';

$set['title'] = 'Категории';
include_once H.'sys/inc/thead.php';

title();

if (isset($user)){
?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $user['id']?>"><?= $user['nick']?></a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/plugins/smiles/">Смайлы</a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Категории</span> </span>       </div>
<?
}
err();


$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `smile_dir`"),0);
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str'] * $page - $set['p_str'];



if ($k_post == 0) 
{
?>
<div class="mess">Нет категорий</div>
<?
}
else{

$q = mysql_query("SELECT * FROM `smile_dir` ORDER BY id ASC");

?>
<div class="list_item"> 
<table>  <tbody>
<?

while ($dir = mysql_fetch_assoc($q))
{
?>
<tr>
<td style="width:5%;"><img src="//c.spac.me/i/01_Smile1.gif" alt=""></td>
<td style="vertical-align:middle;"> 
<a href="/plugins/smiles/dir.php?id=<?=$dir['id']?>"><span class="t"><?=text($dir['name'])?></span></a>
</td>
</tr>
<?
}

?>
</tbody></table> 
</div>
<?
}
if (isset($user) && $user['level'] > 4)
{
?>
<div class="bottom_link_block lh_160">    
<a class="arrow_link" href="/adm_panel/smiles.php"> 
<img src="/style/i/edit.gif" alt="" class="icon p16"> <span>Админка</span> 
</a>  <br>        
</div>
<?
}



include_once H.'sys/inc/tfoot.php';
?>