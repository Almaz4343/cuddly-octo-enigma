<?php

include_once '../../sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';

if(isset($_GET['id'])){
	$id = intval($_GET['id']);
}
else{
	header("Location: /");
}

$dir = mysql_fetch_array(mysql_query("SELECT * FROM `smile_dir` WHERE `id` = '" . $id . "'"));

if (!$dir['id'])header("Location: /");

$set['title'] = text($dir['name']) . ' : Смайлы : ' . $user['nick'];
include_once H.'sys/inc/thead.php';

title();

if (isset($user)){
?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $user['id']?>"><?= $user['nick']?></a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/plugins/smiles/">Смайлы</a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text"><?= text($dir['name'])?></span> </span>       </div>
<?
}

err();


$set['p_str'] = '10';		
$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `smile` WHERE `dir` = '$id'"),0);
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str']*$page-$set['p_str'];


if ($k_post == 0) 
{
?>
<div class="mess">Список смайлов пуст</div>
<?
}
else{

?>
<div class="list_item gradient_block1"> 
<table>  <tbody>
<?

$q = mysql_query("SELECT * FROM `smile` WHERE `dir` = '$id' ORDER BY `id` DESC LIMIT $start, $set[p_str]");

while($post = mysql_fetch_array($q))
{

?>
<tr class="light_border_bottom"> 
<td style="width:1%; padding:5px 0;"> <img src="/style/smiles/<?=$post['id']?>.gif" alt=""> </td> 
<td style="vertical-align:middle"> <?=text($post['smile'])?> </td> 
</tr>
<?
}

?>
</tbody></table> 
</div>
<?

}
if($k_page>1)str('dir.php?id='.$id.'&amp;',$k_page,$page);


if (isset($user) && $user['level'] > 4)
{
?>
<div class="bottom_link_block lh_160">    
<a class="arrow_link" href="/adm_panel/smiles.php?id=<?= $dir['id']?>"> 
<img src="/style/i/edit.gif" alt="" class="icon p16"> <span> Редактировать категорию</span> 
</a>  <br>        
</div>
<?
}

?>
<a href="/plugins/smiles/?" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Категории  </a>
<?

include_once H.'sys/inc/tfoot.php';
?>