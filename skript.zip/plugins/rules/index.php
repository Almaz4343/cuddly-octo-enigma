<?

/**
 * & Author   :: Igor Slepko
 * & Nick     :: Tw1nGo
 * & Contacts :: http://gix.su/user/Tw1nGo
 */

include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';

$set['title'] = 'Информация';

include_once H.'sys/inc/thead.php';
title();





if (isset($user) && $user['level'] > 2){
	if (isset($_GET['del']) && is_numeric($_GET['del']) && mysql_result(mysql_query("SELECT COUNT(*) FROM `rules` WHERE `id` = '".intval($_GET['del'])."' LIMIT 1",$db), 0)==1)
	{
		mysql_query("DELETE FROM `rules` WHERE `id` = '".intval($_GET['del'])."' LIMIT 1");
		mysql_query("OPTIMIZE TABLE `rules`");

		$_SESSION['message'] = 'Пункт успешно удален';
		header("Location: ?");
		exit;
	}
}





if (isset($_GET['id']) && isset($_GET['act']) && mysql_result(mysql_query("SELECT COUNT(*) FROM `rules` WHERE `id` = '".intval($_GET['id'])."'"),0))

{
	$menu = mysql_fetch_assoc(mysql_query("SELECT * FROM `rules` WHERE `id` = '".intval($_GET['id'])."' LIMIT 1"));

	if ($_GET['act']=='up' && $user['level'] > 2)
	{
		mysql_query("UPDATE `rules` SET `pos` = '".($menu['pos'])."' WHERE `pos` = '".($menu['pos']-1)."' LIMIT 1");
		mysql_query("UPDATE `rules` SET `pos` = '".($menu['pos']-1)."' WHERE `id` = '".intval($_GET['id'])."' LIMIT 1");

		$_SESSION['message'] = 'Пункт меню сдвинут на позицию вверх';
		header("Location: ?");
		exit;
	}

	

	

	if ($_GET['act']=='down' && $user['level'] > 2)
	{
		mysql_query("UPDATE `rules` SET `pos` = '".($menu['pos'])."' WHERE `pos` = '".($menu['pos']+1)."' LIMIT 1");
		mysql_query("UPDATE `rules` SET `pos` = '".($menu['pos']+1)."' WHERE `id` = '".intval($_GET['id'])."' LIMIT 1");

		$_SESSION['message'] = 'Пункт меню сдвинут на позицию вниз';
		header("Location: ?");
		exit;
	}
}



?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <span id="transmark" style="display: none; width: 0px; height: 0px;"></span><img src="//c.spac.me/i/lb/home.png" alt=""> </a>          <span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Информация</span> </span>       </div>
 <?



$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `rules`"),0);
$q = mysql_query("SELECT * FROM `rules` ORDER BY `pos` ASC");


if ($k_post == 0){
?>
<div class="wrapper">  
<div class="col_blocks block">  Раздел информации не заполнен.  </div>
</div>
<?
}else{

?>
<div class="list_item lh_160">
<?


while ($post = mysql_fetch_assoc($q))
{

if ($post['title']){
?>
<div class="link        ">
<a href="answer/?id=<?= $post['id']?>"> 
<span><?= $post['pos']?>. <?= output_text($post['title'])?></span>  
</a> 
<?
}


if ($post['url'])echo (($user['level'] > 2) ? $post['pos'] . ") " : "") . ' <a href="' . htmlspecialchars($post['url']) . '">' . output_text($post['name_url']) . '</a> ';



if ($post['msg'])echo (($user['level'] > 2)? $post['pos'] . ") " : "") . output_text($post['msg']) . ' ';





	if ($user['level'] > 2){

	

		echo '<a href="?id=' . $post['id'] . '&amp;act=up&amp;' . $passgen . '"><img src="/style/icons/up.gif" alt="*" /></a> | ';

		echo '<a href="?id=' . $post['id'] . '&amp;act=down&amp;' . $passgen . '"><img src="/style/icons/down.gif" alt="*" /></a> | ';

		echo '<a href="edit.php?id=' . $post['id'] . '&amp;act=edits&amp;' . $passgen . '"><img src="/style/icons/edit.gif" alt="*" /></a> | ';

		echo '<a href="index.php?del=' . $post['id'] . '"><img src="/style/icons/delete.gif" alt="*" /></a>';

	}

?>
</div>
<?
}
?>
</div>
<?
}




if ($user['level'] > 4){
?>
<div class="bottom_link_block lh_160">
<a class="arrow_link" href="new.php?msg"> <img src="/style/i/edit.gif" alt="" class="icon p16"> <span style="margin-left:4px;">Добавить текст</span> </a>  <br>
<a class="arrow_link" href="new.php?url"> <img src="/style/i/move.png" alt="" class="icon p16"> <span style="margin-left:4px;">Добавить ссылку</span></a>  <br>
<a class="arrow_link" href="new.php?post"> <img src="/style/i/lj.gif" alt="" class="icon p16"> <span style="margin-left:4px;">Добавить пункт</span></a>
</div>
<?
}

?>
<a href="/" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?



include_once '../../sys/inc/tfoot.php';

?>

