<?

include_once '../../sys/inc/start.php';
include_once '../../sys/inc/compress.php';
include_once '../../sys/inc/sess.php';
include_once '../../sys/inc/home.php';
include_once '../../sys/inc/settings.php';
include_once '../../sys/inc/db_connect.php';
include_once '../../sys/inc/ipua.php';
include_once '../../sys/inc/fnc.php';
include_once '../../sys/inc/user.php';

$set['title'] = 'Теги : Информация ';

include_once '../../sys/inc/thead.php';

title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="//c.spac.me/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/plugins/rules/">Информация</a> </span>     <span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Теги</span> </span>       </div>
<?

err();


?>
<div class="list_item"> 
<div class="pad_t_a"> Теги позволяют задавать cтили отображения текста и ссылок.<br> Теги допустимы в блогах и форуме. </div> 
<br> 
<div class="pad_t_a"> <span style="color:darkred"> <b>Текстовые теги:</b> </span> </div> 

<div class="pad_t_a"> 
[b]Жирн<span id="transmark" style="display: none; width: 0px; height: 0px;"></span>ый текст[/b] - <b>Жирный текст</b> 
</div> 
<div class="pad_t_a"> [i]Наклонный текст[/i] - <i>Наклонный текст</i> </div> 
<div class="pad_t_a"> [u]Подчёркнутый текст[/u] - <u>Подчёркнутый текст</u> </div> 
<div class="pad_t_a"> [s]Перечёркнутый текст[/s] - <s>Перечёркнутый текст</s> </div> 
<div class="pad_t_a"> [color=green]Цветной текст[/color] - <span style="color:green">Цветной текст</span> </div> 
<div class="pad_t_a"> [color=#FF6600]Цветной текст[/color] - <span style="color:#ff6600">Цветной текст</span> </div> 
<div class="pad_t_a"> [fon=green]Текст с фоном[/fon] - <span style="background:green">Текст с фоном</span> </div> 
<div class="pad_t_a"> [fon=#FF6600]Текст с фоном[/fon] - <span style="background:#FF6600">Текст с фоном</span> </div> 
<div class="pad_t_a"> [quote]Цитата[/quote] - Цитирование текста </div> 
<br> 
<div class="pad_t_a"> <span style="color:darkred"> <b>Теги ссылок:</b> </span> </div> 
<div class="pad_t_a"> http://xmyx.ru - <a href="http://xmyx.ru">xmyx.ru</a> </div>  
<div class="pad_t_a"> [url=http://xmyx.ru/plugins/online_help.php]Администрация[/url] - <a href="http://xmyx.ru/plugins/online_help.php">Администрация</a> </div>     
<div class="pad_t_a"> [u=id пользователя]ник пользователя[/u] - <a href='/info.php?id=1'>Пользователь</a></div> 
</div>
<?

include_once '../../sys/inc/tfoot.php';

?>



