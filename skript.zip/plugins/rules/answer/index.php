<?

/**
 * & Author   :: Igor Slepko
 * & Nick     :: Tw1nGo
 * & Contacts :: http://gix.su/user/Tw1nGo
 */

include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';

$set['title'] = 'Ответ : Информация';

include_once H.'sys/inc/thead.php';
title();


?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="//c.spac.me/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/plugins/rules/">Информация</a> </span>          <span class="lc_brw"> <img src="//c.spac.me/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Ответ</span> </span>       </div>
<?





$post = mysql_fetch_assoc(mysql_query("SELECT * FROM `rules` WHERE `id` = '".intval($_GET['id'])."' LIMIT 1"));
$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `rules`"),0);


?>
<div class="stnd_padd t_center pdb"> 
<b>     <div class="header upcs">       <b class="m"><?= text($post['title'])?></b> </div>       </b> 
</div>
<?


if (!isset($_GET['id']) && !is_numeric($_GET['id']));


if ($user['level'] > 2){


	


	if (isset($_POST['msg']) && isset($user))


	{


		$msg=$_POST['msg'];








		if (strlen2($msg)>99999){$err='Сообщение слишком длинное';}


		elseif (strlen2($msg)<2){$err='Короткое сообщение';}


		elseif (mysql_result(mysql_query("SELECT COUNT(*) FROM `rules_p` WHERE `id_news` = '".intval($_GET['id'])."' AND `id_user` = '$user[id]' AND `msg` = '".my_esc($msg)."' LIMIT 1"),0)!=0){$err='Ваше сообщение повторяет предыдущее';}


		elseif(!isset($err)){


			$pos=mysql_result(mysql_query("SELECT MAX(`pos`) FROM `rules_p` WHERE `id_news` = '".intval($_GET['id'])."'"), 0)+1;


			mysql_query("INSERT INTO `rules_p` (`pos`, `id_user`, `time`, `msg`, `id_news`) values('$pos', '$user[id]', '$time', '".my_esc($msg)."', '".intval($_GET['id'])."')");


			$_SESSION['message'] = 'Ваш пост успешно принят';


			header("Location: ?id=$post[id]");


			exit;


		}


	}





	if (isset($_GET['ids']))$menu=mysql_fetch_assoc(mysql_query("SELECT * FROM `rules_p` WHERE `id` = '".intval($_GET['ids'])."' LIMIT 1"));


	


	if (isset($_GET['ids']) && isset($_GET['act']) && $_GET['act']=='up')


	{


		mysql_query("UPDATE `rules_p` SET `pos` = '".($menu['pos'])."' WHERE `pos` = '".($menu['pos']-1)."' LIMIT 1");


		mysql_query("UPDATE `rules_p` SET `pos` = '".($menu['pos']-1)."' WHERE `id` = '".intval($_GET['ids'])."' LIMIT 1");





		$_SESSION['message'] = 'Пункт меню сдвинут на позицию вверх';


		header("Location: ?id=$post[id]");


		exit;





	}


	if (isset($_GET['ids']) && isset($_GET['act']) && $_GET['act']=='down')


	{


		mysql_query("UPDATE `rules_p` SET `pos` = '".($menu['pos'])."' WHERE `pos` = '".($menu['pos']+1)."' LIMIT 1");


		mysql_query("UPDATE `rules_p` SET `pos` = '".($menu['pos']+1)."' WHERE `id` = '".intval($_GET['ids'])."' LIMIT 1");





		$_SESSION['message'] = 'Пункт меню сдвинут на позицию вниз';


		header("Location: ?id=$post[id]");


		exit;


	}





}








$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `rules_p` WHERE `id_news` = '".intval($_GET['id'])."'"),0);





$q = mysql_query("SELECT * FROM `rules_p` WHERE `id_news` = '".intval($_GET['id'])."' ORDER BY `pos` ASC");

?>
<div class="list_item">
<?


while ($post2 = mysql_fetch_assoc($q))


{


	$ank = get_user($post2['id_user']);


?>
<b><?= $post2['pos']?></b>. <?= output_text($post2['msg'])?> </br>
<?

if ($user['level'] > 3){
echo '<a href="?ids=' . $post2['id'] . '&amp;id=' . $post['id'] . '&amp;act=up&amp;' . $passgen . '"><img src="/style/icons/up.gif" alt="*" /></a> | ';
echo '<a href="?ids=' . $post2['id'] . '&amp;id=' . $post['id'] . '&amp;act=down&amp;' . $passgen . '"><img src="/style/icons/down.gif" alt="*" /></a> | ';
echo '<a href="edit.php?id=' . $post2['id'] . '&amp;act=edit&amp;' . $passgen . '"><img src="/style/icons/edit.gif" alt="*" /></a> | ';
echo '<a href="delete.php?del=' . $post2['id'] . '"><img src="/style/icons/delete.gif" alt="*" /></a>';
echo '</br>';
}

?>
</br>
<?
}

?>
</div>
<?








if ($user['level'] > 3){

	if(isset($_GET['new']))
	{

		echo '<form method="post" name="message" action="?id='.intval($_GET['id']) . '">';

		if ($set['web'] && is_file(H.'style/themes/'.$set['set_them'].'/altername_post_form.php'))
		include_once H.'style/themes/'.$set['set_them'].'/altername_post_form.php';
		else
		echo '<textarea name="msg"></textarea><br />';

		echo '<input value="Добавить" type="submit" />';
		echo '</form>';

	}


?>
<div class="bottom_link_block lh_160">
<a class="arrow_link" href="?id=<?= $post['id']?>&new"> <img src="/style/i/lj.gif" alt="" class="icon p16"> <span style="margin-left:4px;">Добавить пункт</span></a>
</div>
<?
}

?>
<a href="/plugins/rules/" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?

include_once H.'sys/inc/tfoot.php';

?>