<?
include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';

$set['title'] = 'Онлайн-помощь';

include_once H.'sys/inc/thead.php';
title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  
<a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>         
<span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Онлайн-помощь</span> </span>       
</div>
<div class="grey t_center" style="margin: 10px 5px;"> Можете задать свой вопрос онлайн-помощникам: </div>
<?

$k_post = mysql_result(mysql_query("SELECT COUNT(`user`.`id`) FROM `user` LEFT JOIN `user_group` ON `user`.`group_access` = `user_group`.`id` WHERE `user_group`.`level` != 0 AND `user_group`.`level` IS NOT NULL"),0);
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str'] * $page-$set['p_str'];


if ($k_post == 0){
?>
<div class="start_page_padd light_blue light_border_bottom grey">Странно, но Администрации на сайте нет.</div>
<?
}

$q = mysql_query("SELECT `user`.`id` FROM `user` LEFT JOIN `user_group` ON `user`.`group_access` = `user_group`.`id` WHERE `user_group`.`level` != 0 AND `user_group`.`level` IS NOT NULL ORDER BY `user_group`.`level` DESC LIMIT $start, $set[p_str]");
while ($ank = mysql_fetch_assoc($q))
{
$ank = get_user($ank['id']);

?>
<div class="wrapper">  
<div class="js-row block bord-botm oh grey relative">        
<div class="left font0">   
<a href="/user/?id=<?= $ank['id']?>" class="tdn"> 
<span class="pr">   <div class="inl_bl relative"> <?= ava40($ank['id'])?>  </div>     </span>        
</a>  
</div>  
<div class="pre_content_wrap break-word"> 
<?= group($ank['id'])?>   
<a href="/user/?id=<?= $ank['id']?>" class="black full_link">   <b><?= $ank['nick']?></b>  </a>   <?= medal($ank['id'])?>                 
<div class="grey">  
<div class="break-word"> Посл. посещение: <?= vremja($ank['date_last'])?> </div>
<?= text($ank['group_name'])?></div>             
</div>     
</div>  
<?
if(isset($user) && $user['id'] != $ank['id']){
?>   
<table class="table__wrap"> <tbody><tr>  
<td class="table__cell table__cell_last" width="100%">     
<a href="/mail.php" class="link"> <span>  <img src="/style/i/mail_grey.png" alt="" class="m"> <span class="m">  Написать </span>          </span>  </a>     
</td>  
</tr> </tbody></table>      
<?
}elseif(isset($user) && $user['id'] == $ank['id']){
?>   
<table class="table__wrap"> <tbody><tr>  
<td class="table__cell table__cell_last" width="100%">     
<span class="link"> <span class="m green">  Это Вы </span>  </span>     
</td>  
</tr> </tbody></table>      
<?
}
?>
</div>
<?
}

if ($k_page > 1)str("?",$k_page,$page); // Вывод страниц






include_once H.'sys/inc/tfoot.php';
?>