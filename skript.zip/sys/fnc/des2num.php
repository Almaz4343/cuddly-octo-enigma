<?php 

function des2num($int, $array) {
  $cases = array (2, 0, 1, 1, 1, 2);
  return $int . ' ' . $array[ ($int % 100 > 4 && $int % 100 < 20) ? 2 : $cases[min($int % 10, 5)] ];
}