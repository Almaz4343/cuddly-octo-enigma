<?
if (!function_exists('copyright')) 
{
	function copyright($fiera)
	{
		return preg_replace("#</div>(\n|\r)*</body>#i", "<div style='font-size: xx-small;text-align:center;'>&copy; <a style='font-size:xx-small;' title='Модификация движка Dcms' href='http://dcms-social.ru'>DCMS-Social</a> </div>\n</div>\n</body>", $fiera);
	}
	ob_start ("copyright");
}
?>