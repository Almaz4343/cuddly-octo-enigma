<?

// Аватар 50x50
function avatar($ID){

// Определяем аватар
$avatar = mysql_fetch_array(mysql_query("SELECT id,id_gallery,ras FROM `gallery_foto` WHERE `id_user` = '$ID' AND `avatar` = '1' LIMIT 1"));
// Определяем пол юзера
$us = mysql_fetch_assoc(mysql_query("SELECT * FROM `user` WHERE `id` = '$ID' LIMIT 1"));

if (is_file(H.'sys/tpic/pic50/'.$avatar['id'].'.p.51.50.0.jpg')){
return '<img class="" src="/foto/pic50/'.$avatar['id'].'.p.51.50.0.jpg" alt="">';
}else{
return '<img class="" src="/sys/tpic/pic50/' . ($us["pol"] == 1 ? 'man' : 'woman') . '.p.51.50.0.jpg" alt="">';
}

}
// Аватар 40x40
function ava40($ID){

// Определяем аватар
$avatar = mysql_fetch_array(mysql_query("SELECT id,id_gallery,ras FROM `gallery_foto` WHERE `id_user` = '$ID' AND `avatar` = '1' LIMIT 1"));
// Определяем пол юзера
$us = mysql_fetch_assoc(mysql_query("SELECT * FROM `user` WHERE `id` = '$ID' LIMIT 1"));

if($us['id'] != 0){
if (is_file(H.'sys/tpic/pic40/'.$avatar['id'].'.p.41.40.0.jpg')){
return '<img class="" src="/foto/pic40/'.$avatar['id'].'.p.41.40.0.jpg" alt="">';
}else{
return '<img class="" src="/sys/tpic/pic40/' . ($us['pol'] == 1 ? 'man' : 'woman') . '.p.41.40.0.jpg" alt="">';
}
}else{
return '<img class="" src="/sys/tpic/pic40/000.p.41.40.0.jpg" alt="">';
}
}

// Аватар 80x80
function ava80($ID){

// Определяем аватар
$avatar = mysql_fetch_array(mysql_query("SELECT id,id_gallery,ras FROM `gallery_foto` WHERE `id_user` = '$ID' AND `avatar` = '1' LIMIT 1"));
// Определяем пол юзера
$us = mysql_fetch_assoc(mysql_query("SELECT * FROM `user` WHERE `id` = '$ID' LIMIT 1"));

if (is_file(H.'sys/tpic/pic80/'.$avatar['id'].'.p.81.80.0.jpg')){
return '<img class="" src="/foto/pic80/'.$avatar['id'].'.p.81.80.0.jpg" alt="">';
}else{
return '<img class="" src="/sys/tpic/pic80/' . ($us['pol'] == 1 ? 'man' : 'woman') . '.p.81.80.0.jpg" alt="">';
}

}

// Аватар 100x100
function ava100($ID){

// Определяем аватар
$avatar = mysql_fetch_array(mysql_query("SELECT id,id_gallery,ras FROM `gallery_foto` WHERE `id_user` = '$ID' AND `avatar` = '1' LIMIT 1"));
// Определяем пол юзера
$us = mysql_fetch_assoc(mysql_query("SELECT * FROM `user` WHERE `id` = '$ID' LIMIT 1"));

if (is_file(H.'sys/tpic/pic100/'.$avatar['id'].'.p.101.100.0.jpg')){
return '<img class="" src="/foto/pic100/'.$avatar['id'].'.p.101.100.0.jpg" alt="">';
}else{
return '<img class="" src="/sys/tpic/pic100/' . ($us['pol'] == 1 ? 'man' : 'woman') . '.p.101.100.0.jpg" alt="">';
}

}

?>