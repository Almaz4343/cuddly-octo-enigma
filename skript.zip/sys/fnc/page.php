<?
// Выдает текущую страницу
function page($k_page=1)
{ 
	$page = 1;

	if (isset($_GET['P']))
	{
		if ($_GET['P'] == 'end')
			$page = intval($k_page);
			
		elseif(is_numeric($_GET['P'])) 
		$page = intval($_GET['P']);
	}

	if ($page < 1)$page = 1;

	if ($page > $k_page)
		$page = $k_page;
		
	return $page;
}

// Высчитывает количество страниц
function k_page($k_post = 0, $k_p_str = 10)
{ 
	if ($k_post != 0) 
	{
		$v_pages = ceil($k_post / $k_p_str);
		return $v_pages;
	}

	else return 1;
}

// Вывод номеров страниц 
function str($link = '?', $k_page = 1, $page = 1)
{


if ($page < 1){
$page = 1;
}

?>
<div class="pag wbg">
<div class="pgar oh font0">
<table class="table__wrap"> <tbody><tr>
<td class="table__cell" width="35%">
<?
if ($page > 1)
{
?>
<div class="pagw">   <a href="<?= $link?>P=<?= ($page - 1)?>"> ← Назад </a>   </div>
<?
}else{
?>
<div class="pagw">   <span class="dis"> ← Назад </span>   </div>
<?
}
?>
</td>
<td class="table__cell"> 
<div class="pagw pagwb">   <span class="blk"> <?= $page?> из <?= $k_page?> </span>   </div> 
</td>
<td class="table__cell" width="35%">
<?
if ($page < $k_page)
{
?>
<div class="pagw">   <a href="<?= $link?>P=<?= ($page + 1)?>"> Вперёд → </a>   </div> 
<?
}else{
?>
<div class="pagw">   <span class="dis"> Вперёд → </span>   </div>
<?
}
?>
</td>
</tr> </tbody></table>
</div>
<?

?>
<div class="pgl">  
<table class="table__wrap"> <tbody><tr>
<?


if($k_page > 1){
// № 1
if ($page != 1){
?>
<td class="table__cell"> <div class="pagw pagwr">    <a href="<?= $link?>P=1" class="mr">1</a>    </div> </td>
<?
}else{
?>
<td class="table__cell"> <div class="pagw pagwr">    <span class="cur mr">1</span>    </div> </td>
<?
}




if($k_page < 9){
for ($ot= - 6; $ot <= 6; $ot++)
{
if ($page + $ot > 1 && $page + $ot < $k_page){


if($page > 8){
if ($ot == -2 && $page + $ot > 2)
{
?>
<td class="table__cell m">  <i class="dot">...</i>  </td>
<?
}
}
// 3,4,5,6,7
if ($ot != 0){
?>
<td class="table__cell"> 
<div class="pagw pagwr">    <a href="<?= $link?>P=<?= ($page+$ot)?>" class="mr"><?= ($page+$ot)?></a>    </div> 
</td>
<?
}else{
?>
<td class="table__cell"> <div class="pagw">    <span class="cur"><?= ($page+$ot)?></span>    </div> </td>
<?
}
// Троеточье ... после 7-ки
if ($ot == 6 && $page + $ot < $k_page - 1)
{
?>
<td class="table__cell m">  <i class="dot">...</i>  </td>
<?
}
}
}
}


if($k_page >= 9){
for ($ot= - 2; $ot <= 2; $ot++)
{
if ($page + $ot > 1 && $page + $ot < $k_page){



if ($ot == -2 && $page + $ot > 2)
{
?>
<td class="table__cell m" style="border-left: 1px solid #cdd4e1;">  <i class="dot">...</i>  </td>
<?
}

// 3,4,5,6,7
if ($ot != 0){
?>
<td class="table__cell"> 
<div class="pagw pagwr">    <a href="<?= $link?>P=<?= ($page+$ot)?>" class="mr"><?= ($page+$ot)?></a>    </div> 
</td>
<?
}else{
?>
<td class="table__cell"> <div class="pagw">    <span class="cur"><?= ($page+$ot)?></span>    </div> </td>
<?
}



// Троеточье ... после 7-ки
if ($ot == 2 && $page + $ot < $k_page - 1)
{
?>
<td class="table__cell m" style="border-left: 1px solid #cdd4e1;">  <i class="dot">...</i>  </td>
<?
}
}
}


}




// Последняя страничка перед поиском (Не выбрана)
if ($page != $k_page)
{
?>
<td class="table__cell"> <div class="pagw">    <a href="<?= $link?>P=<?= $k_page?>"><?= $k_page?></a>    </div> </td>
<?
}else{
// Последняя страничка перед поиском (Выбрана)
?>
<td class="table__cell"> <div class="pagw">    <span class="cur"><?= $k_page?></span>    </div> </td>
<?
}


if($k_page > 6){
if(isset($_POST['go_number']))
{
if(isset($_POST['page_ssilka']) && $_POST['page_ssilka'] != NULL){
if(isset($_POST['page_number']) && $_POST['page_number'] != NULL && is_numeric($_POST['page_number']) && $_POST['page_number'] > 0){
$link_go = "".$_POST['page_ssilka']."P=".$_POST['page_number']."";
}
else{
$link_go = "".$_POST['page_ssilka']."";
}
}
else{
$link_go = "/index.php";
}
header("Location: ".$link_go."");
exit;
}

?>
<td class="table__cell table__cell_spb text_right">  
<span class="spb"> 
<form method="post" name="pages" action="<?= $link?>P=<?= $page?>"> 
<span class="wpni"> 
<input name="page_number" size="3" style="-wap-input-format:'5N'" maxlength="5" value="" class="pni text_left"> 
</span>  
<input name="page_ssilka" value="<?= $link?>" type="hidden">    
<input value="GO" class="pgfs" name="go_number" type="submit">  
</form> 
</span>  
</td>
<?
}
?>
</tr> </tbody></table></div>
</div>
<?

}
}
?>