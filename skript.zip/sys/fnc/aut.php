<?
function title(){

	global $user;	
	
if (isset($user)){

	global $set, $time;		
		
	
$k_new = mysql_result(mysql_query("SELECT COUNT(`mail`.`id`) FROM `mail`
	LEFT JOIN `users_konts` ON `mail`.`id_user` = `users_konts`.`id_kont` AND `users_konts`.`id_user` = '$user[id]'
	WHERE `mail`.`id_kont` = '$user[id]' AND (`users_konts`.`type` IS NULL OR `users_konts`.`type` = 'common' 
	OR `users_konts`.`type` = 'favorite') AND `mail`.`read` = '0'"),0);
			 
$k_new_fav = mysql_result(mysql_query("SELECT COUNT(`mail`.`id`) FROM `mail`
	LEFT JOIN `users_konts` ON `mail`.`id_user` = `users_konts`.`id_kont` AND `users_konts`.`id_user` = '$user[id]'
	WHERE `mail`.`id_kont` = '$user[id]' AND (`users_konts`.`type` = 'favorite') AND `mail`.`read` = '0'"),0);		
			 
$lenta = mysql_result(mysql_query("SELECT COUNT(`read`) FROM `tape` WHERE `id_user` = '$user[id]' AND `read` = '0' "),0);				 
$journal = mysql_result(mysql_query("SELECT COUNT(`read`) FROM `journal` WHERE `ank` = '$user[id]' AND `read` = '0'"), 0);	 
$avatar = mysql_fetch_array(mysql_query("SELECT id,id_gallery,ras FROM `gallery_foto` WHERE `id_user` = '$user[id]' AND `avatar` = '1' LIMIT 1"));





// #677fb2; - это стандарт
$style_panel = ' style="background: #'.$user['panelka_st'].';"';

?>
<div id="navi" class="light_header horiz-menu_advanced"<?= $style_panel?>>    
<div class="menu_wrap"<?= $style_panel?>>  
<table class="table__wrap table_no_borders" cellspacing="0" cellpadding="0"><tbody><tr>  
<td class="table__cell" width="19%">  
<a class="top_menu_link user_color_link" href="/user/startpage.php" title="Старт"> 
<img class="m p25" src="/style/i/menu/menu_b.png" alt="Старт"> 
</a>  
</td>   
<td class="table__cell" width="21%">  
<?
if ($k_new != 0 && $k_new_fav == 0){
?>
<a class="top_menu_link user_color_link" href="/new_mess.php" title="Почта"> 
<div class="inl_bl relative"> <img class="m p25" src="/style/i/menu/mail_b.png" alt="Почта">  </div> 
<span class="newevent"><?= $k_new?></span>
<?
}
else
{
?>
<a class="top_menu_link user_color_link" href="/konts.php" title="Контакты"> 
<div class="inl_bl relative"> <img class="m p25" src="/style/i/menu/mail_b.png" alt="Почта">  </div> 
<?
}
?>
</a> 
</td>   
<td class="table__cell" width="20%">  
<a class="top_menu_link user_color_link" href="/user/journal/" title="Журнал"> 
<div class="inl_bl relative"> <img class="m p25" src="/style/i/menu/journal_b.png" alt="Жур">  
<?
if($journal > 0){
?> 
<span class="newevent"><?= $journal?></span>  
<?
}
?>
</div> 
</a>  
</td>   
<td class="table__cell" width="20%">  
<a class="top_menu_link user_color_link" href="/user/lenta/" title="Лента"> 
<div class="inl_bl relative"> 
<img class="m p25" src="/style/i/menu/lenta_b.png" alt="Лента">  
<?
if($lenta > 0){
?> 
<span class="newevent"><?= $lenta?></span>  
<?
}
?>
</div> 
</a>  
</td>   

<td class="table__cell" width="20%">  
<a class="top_menu_link user_color_link" href="/user/?id=<?= $user['id']?>" title="Я">       
<span class="pr">   
<div class="inl_bl relative"> 
<?
if($avatar != 0){ 
?>
<img src="/foto/pic40/<?= $avatar['id']?>.p.41.40.0.<?= $avatar['ras']?>" alt="" class="preview s41_40" style="border-radius:50%;">
<?
}else{
?>
<img src="/style/i/menu/<?= ($user['pol']== 1 ? 'no_ava_man' : 'no_ava_girl')?>.png" alt="" class="preview s41_40" style="border-radius:50%;">
<?
}
?>
</div>     
</span>         
</a>  
</td>   
</tr></tbody></table>   
</div>  </div>
<?

if($user['p_time'] == 1){
?>
<div class="moders_header_block oh">   
<a href="/user/settings/time.php"><span class="right"><?= date("G:i", $time + $user['set_timesdvig']*60*60)?></span></a>           
</div>
<?
}

}

?>
<div class="main">
<?

}
?>