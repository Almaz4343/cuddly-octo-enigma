<?
function unick($user = NULL)
{

global $set, $time;

$nick = null;

$ank = mysql_fetch_assoc(mysql_query("SELECT * FROM `user` WHERE `id` = '$user' LIMIT 1"));

// Если в бане
if (mysql_result(mysql_query("SELECT COUNT(*) FROM `ban` WHERE `id_user` = '$user' AND (`time` > '$time' OR `navsegda` = '1')"), 0) != 0)
{
$nick = '<strike> <b>'.$ank['nick'].'</b> </strike>';
}
else 
{
// Если не в бане, то выводим
if ($user == 0){ 
$ank = array('id' => '0', 'nick' => 'Cистема',  'ank_name' => 'Система',  'ank_family' => 'оповещений', 'pol' => '1', 'rating' => '0', 'browser' => 'wap', 'date_last' => time());
}
elseif(!$ank){ 
$ank = array('id' => '0', 'nick' => '[Удален]', 'ank_name' => 'Удаленный',  'ank_family' => 'пользователь', 'pol' => '1', 'rating' => '0', 'browser' => 'wap', 'date_last' => time());
}
        
$nick = text($ank['nick']);
}

return $nick;

}
?>