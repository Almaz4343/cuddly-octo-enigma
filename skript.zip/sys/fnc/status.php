<?
function status($ID)
{

// Определяем аватар
$avatar = mysql_fetch_array(mysql_query("SELECT id,id_gallery,ras FROM `gallery_foto` WHERE `id_user` = '$ID' AND `avatar` = '1' LIMIT 1"));
// Определяем пол юзера
$us = mysql_fetch_assoc(mysql_query("SELECT * FROM `user` WHERE `id` = '$ID' LIMIT 1"));

if (is_file(H.'sys/tpic/pic50/'.$avatar['id'].'.p.51.50.0.jpg')){
return '<img class="" src="/foto/pic50/'.$avatar['id'].'.p.51.50.0.jpg" alt="">';
}else{
return '<img class="" src="/sys/tpic/pic50/' . ($us["pol"] == 1 ? 'man' : 'woman') . '.p.51.50.0.jpg" alt="">';
}

}
?>