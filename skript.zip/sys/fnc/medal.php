<?
function medal($user = 0)
{
global $set,$time;

# Определяем рейтинг юзера через ID
$ank = mysql_fetch_assoc(mysql_query("SELECT * FROM `user` WHERE `id` = '$user' LIMIT 1"));

/*
=======
Автор: 	Tw1nGo
Мод: 	Рейтинг расписан как на Spaces.RU
=======
Рейтинг 20.00 - бронзовая медаль
Рейтинг 40.00 - серебряная медаль
Рейтинг 60.00 - золотая медаль
Рейтинг 80.00 - платиновая медаль
=======
*/

if ($ank['rating'] >= 0 && $ank['rating'] <= 19)
	$medal_spaces = null;
elseif ($ank['rating'] >= 20 && $ank['rating'] <= 39)
	$medal_spaces = ' <img src="/style/i/medal/medal_bronze.gif" alt="(B)" width="8px" height="15px"> ';
elseif ($ank['rating'] >= 40 && $ank['rating'] <= 59)
	$medal_spaces = ' <img src="/style/i/medal/medal_silver.gif" alt="(S)" width="8px" height="15px"> ';
elseif ($ank['rating'] >= 60 && $ank['rating'] <= 79)
	$medal_spaces = ' <img src="/style/i/medal/medal_gold.gif" alt="(G)" width="8px" height="15px"> ';
elseif ($ank['rating'] >= 80)
	$medal_spaces = ' <img src="/style/i/medal/medal_platina.gif" alt="(P)" width="8px" height="15px"> ';
	


if ($ank['ank_d_r'] . $ank['ank_m_r'] == date("jn")){
return $medal_spaces . ' <img src="//c.spac.me/i//tortik.gif" alt="" class="p16"> ';
}else{
return $medal_spaces;
}

}
?>
