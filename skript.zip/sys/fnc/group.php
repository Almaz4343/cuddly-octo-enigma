<?
function group($user = NULL)
{
	global $set, $time;


$ank = mysql_fetch_array(mysql_query("SELECT * FROM `user` WHERE `id` = $user LIMIT 1"));
$icoNZ = mysql_fetch_array(mysql_query("SELECT * FROM `spaces_icons` WHERE `id_user` = $user AND `vid` = '0' LIMIT 1"));



        if (mysql_result(mysql_query("SELECT COUNT(*) FROM `user` WHERE `id` = '$user' AND `date_last` > '".(time()-600)."' LIMIT 1"),0)==1)
	{
		
        	if ($ank['group_access'] > 7 && ($ank['group_access'] < 10 || $ank['group_access'] > 14)) {
                    if ($ank['pol'] == 1) {
                        $Tw1nGo_ic = 'admin_man_on';
                    } else {
                        $Tw1nGo_ic = 'admin_woman_on';
                    }
                } elseif (($ank['group_access'] > 1 && $ank['group_access'] <= 7) || ($ank['group_access'] > 10 && $ank['group_access'] <= 14)) {
                    if ($ank['pol'] == 1) {
                        $Tw1nGo_ic = 'mod_man_on';
                    } else {
                        $Tw1nGo_ic = 'mod_woman_on';
                    }
                } else {
                    if ($ank['pol'] == 1) {
                        $Tw1nGo_ic = 'man_on';
                    } else {
                        $Tw1nGo_ic = 'woman_on';
                    }    
                }
                $on_off = '(ON)';
                $color = 'color';
        }else{
                if ($ank['group_access'] > 7 && ($ank['group_access'] < 10 || $ank['group_access'] > 14)) {
                    if ($ank['pol'] == 1) {
                        $Tw1nGo_ic = 'admin_man_off';
                    } else {
                        $Tw1nGo_ic = 'admin_woman_off';
                    }
                } elseif (($ank['group_access'] > 1 && $ank['group_access'] <= 7) || ($ank['group_access'] > 10 && $ank['group_access'] <= 14)) {
                    if ($ank['pol'] == 1) {
                        $Tw1nGo_ic = 'mod_man_off';
                    } else {
                        $Tw1nGo_ic = 'mod_woman_off';
                    }
                } else {
                    if ($ank['pol'] == 1) {
                        $Tw1nGo_ic = 'man_off';
                    } else {
                        $Tw1nGo_ic = 'woman_off';
                    }    
                }
                $on_off = '(OFF)';
                $color = 'gray';
         }


if($ank['id'] != 0){
if($ank['ico_onn'] != 0){
$Icon_user = ' <img class="p14" src="/user/services/head_icons/head/'.$color.'/' . $icoNZ['id_icon'] . '.png" alt="'.$on_off.'"> ';
}else{         
$Icon_user = ' <img class="p14" src="/style/i/group/' . $Tw1nGo_ic . '.gif" alt="'.$on_off.'"> ';
}
}else{
$Icon_user = ' <img class="p14" src="/style/i/group/man_off.gif" alt="'.$on_off.'"> ';
}
return $Icon_user;
}

function group_ico($user = NULL)
{
	global $set, $time;


$ank = mysql_fetch_array(mysql_query("SELECT * FROM `user` WHERE `id` = $user LIMIT 1"));


        if (mysql_result(mysql_query("SELECT COUNT(*) FROM `user` WHERE `id` = '$user' AND `date_last` > '".(time()-600)."' LIMIT 1"),0)==1)
	{
		
        	if ($ank['group_access'] > 7 && ($ank['group_access'] < 10 || $ank['group_access'] > 14)) {
                    if ($ank['pol'] == 1) {
                        $Tw1nGo_ic = 'admin_man_on';
                    } else {
                        $Tw1nGo_ic = 'admin_woman_on';
                    }
                } elseif (($ank['group_access'] > 1 && $ank['group_access'] <= 7) || ($ank['group_access'] > 10 && $ank['group_access'] <= 14)) {
                    if ($ank['pol'] == 1) {
                        $Tw1nGo_ic = 'mod_man_on';
                    } else {
                        $Tw1nGo_ic = 'mod_woman_on';
                    }
                } else {
                    if ($ank['pol'] == 1) {
                        $Tw1nGo_ic = 'man_on';
                    } else {
                        $Tw1nGo_ic = 'woman_on';
                    }    
                }
                $on_off = '(ON)';
                $color = 'color';
        }else{
                if ($ank['group_access'] > 7 && ($ank['group_access'] < 10 || $ank['group_access'] > 14)) {
                    if ($ank['pol'] == 1) {
                        $Tw1nGo_ic = 'admin_man_off';
                    } else {
                        $Tw1nGo_ic = 'admin_woman_off';
                    }
                } elseif (($ank['group_access'] > 1 && $ank['group_access'] <= 7) || ($ank['group_access'] > 10 && $ank['group_access'] <= 14)) {
                    if ($ank['pol'] == 1) {
                        $Tw1nGo_ic = 'mod_man_off';
                    } else {
                        $Tw1nGo_ic = 'mod_woman_off';
                    }
                } else {
                    if ($ank['pol'] == 1) {
                        $Tw1nGo_ic = 'man_off';
                    } else {
                        $Tw1nGo_ic = 'woman_off';
                    }    
                }
                $on_off = '(OFF)';
                $color = 'gray';
         }
        
$Icon_user = ' <img class="p14" src="/style/i/group/' . $Tw1nGo_ic . '.gif" alt="'.$on_off.'"> ';

return $Icon_user;
}
?>