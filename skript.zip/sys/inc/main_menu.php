<?


?>

<div class="wrapper">

<a href="/user/users.php" class="link darkblue"> 
<img src="/style/i/ico/people.png" alt="" class="m p16"> <span class="m">Люди</span> 
</a>

<a href="/user/dating/" class="link darkblue"> 
<img src="/style/i/ico/dating.png" alt="" class="m p16"> <span class="m">Знакомства</span> 
</a>

<a href="/forum/" class="link darkblue"> 
<img src="/style/i/ico/forum.png" alt="" class="m p16"> <span class="m">Форум</span> 
</a>

<a href="/user/blogs/?List=0" class="link darkblue"> 
<img src="/style/i/ico/blog.png" alt="" class="m p16"> <span class="m">Блоги</span> 
</a>

<a href="/plugins/rules/" class="link  darkblue      "> 
<span><!--     --><img src="/style/i/ico/info.png" alt="" class="m"> <!--   --><span class="m">Информация</span><!--   --></span>  
</a>

</div>
<?

if (user_access('adm_panel_show'))
{
?>
<div class="wrapper">
<a href="/plugins/admin/"  class="link darkblue"> <span class="ico ico_user_online"></span> Админ кабинет 
<?
include_once H.'plugins/admin/count.php';
?>
</a>
</div>
<?
}
?>