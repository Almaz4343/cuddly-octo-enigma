<?
$q = mysql_query("SELECT * FROM `news` WHERE `main_time` > '".time()."' ORDER BY `id` DESC LIMIT 1");

if (mysql_num_rows($q) == 1 && !$set['web'] && $user['news_read'] == 0)
{
	$news = mysql_fetch_assoc($q);
	echo '<div class="mess">';
	echo '<img src="/style/icons/new.gif" alt="*" /> <a href="/news/news.php?id=' . $news['id'] . '">' . text($news['title']) . '</a> ';
	echo '(' . vremja($news['time']) . ')<br />';
	echo output_text($news['msg']) . '<br />';
	
	if ($news['link']!=NULL)
	echo '<a href="' .htmlentities($news['link'], ENT_QUOTES, 'UTF-8').'">Подробности</a><br />';
	
	echo '<img src="/style/icons/komm.png" alt="*" /> (' . mysql_result(mysql_query("SELECT COUNT(*) FROM `news_komm` WHERE `id_news` = '$news[id]'"),0) . ')<br />';
	
	if (isset($user))
	echo '<div style="text-align:right;"><a href="?news_read"><img src="/style/icons/delete.gif" alt="*"></a></div>';
	echo '</div>';
}
?>