<?php 

/**
* Free Lite AntiSpam
* (c) alex-borisi
*/

if (isset($user) && isset($_POST['msg']) && $_SERVER['PHP_SELF'] == '/mail.php')
{
    if (mysql_result(mysql_query("SELECT COUNT(*) FROM `mail` WHERE `id_user` = '$user[id]' AND `msg` like '%" . my_esc('http://') . "%' AND `time` > '" . ($time - 300) . "'"),0) >= 2)
    {
        $err[] = 'Вы заподозрены в рассылке спама, и поэтому не можете писать новые сообщения в течении 5-и минут';
    }
}