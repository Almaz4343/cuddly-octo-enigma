<?
include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';

include_once H.'comm/config.php';

if(!isset($user)){
$_SESSION['err'] = 'Ошибка! Проверте введенный адрес .';
header("Location: /comm/?");
exit;
}

if(mysql_result(mysql_query("SELECT COUNT(*) FROM `comm_cat` WHERE `id` = '".intval($_GET['id'])."'"),0)!=0)
{
$cat = mysql_fetch_assoc(mysql_query("SELECT * FROM `comm_cat` WHERE `id` = '".intval($_GET['id'])."' LIMIT 1"));

$set['title'] = 'Создание : Сообщества';
include_once H.'sys/inc/thead.php';
title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/comm/">Сообщества</a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Создание</span> </span>       </div>
<?

err();


if ($mcomms <= $max_self_comms)
{
if(isset($_POST['cfms']) && isset($_POST['comm_name']))
{
$name = $_POST['comm_name'];
$desc = null;
$deviz = null;
$rules = null;
$interests = null;
if(mysql_result(mysql_query("SELECT COUNT(*) FROM `comm` WHERE `name` = '$name'"),0)!=0)$err[]="Сообщество с таким названием уже есть";
elseif(strlen2($name)>50 || strlen2($name)<3)$err[]="Название должно быть не меньше 3-х и не больше 50-ти символов";

if (!isset($err))
{
mysql_query("INSERT INTO `comm` (`name`, `desc`, `deviz`, `rules`, `interests`, `id_cat`, `id_user`, `time`) VALUES ('$name', '$desc', '$deviz', '$rules', '$interests', '$cat[id]', '$user[id]', '".time()."')");
$comm_id = mysql_insert_id();
mysql_query("INSERT INTO `comm_users` (`id_comm`, `id_user`, `time`, `activate`, `access`) VALUES ('$comm_id', '$user[id]', '".time()."', '1', 'creator')");
mysql_query("INSERT INTO `comm_journal` SET `id_comm` = '$comm_id', `id_user` = '$user[id]', `type` = 'in_comm', `time` = '$time'");
mysql_query("INSERT INTO `comm_journal` SET `id_comm` = '$comm_id', `id_user` = '$user[id]', `id_ank` = '0', `type` = 'access', `time` = '".($time + 1)."', `access` = 'creator'");
header("Location: /comm/show/?id=$comm_id");
$_SESSION['message'] = 'Сообщество успешно создано.';
exit;
}
}
err();



if($user['id'] == 1){
?>
<form action="/comm/create/?id=<?= $cat['id']?>" method="post">
<div class="wrapper"> 
<div class="block bord-botm"> 
<b class="grey">Название сообщества:</b>  
<div>   <div class="input-txt_wrapper">  
<input placeholder="Введите название сообщества" class="input-txt" name="comm_name" value="" maxlength="50" type="text">  
</div>   </div>           
</div> 
<table class="table__wrap"> <tbody><tr> 
<td class="table__cell" width="50%"> 
<!-- --><!-- --><!-- --><!-- --><!-- -->
<button name="cfms" value="Создать" class="  link  blue full is_final    " id="cfms">
<!--   --><img src="//c.spac.me/i/ok_blue.png" alt="" class="m"> <!--   --><span class="m"> Создать</span><!-- -->
</button><!-- --><!-- --> 
</td> 
<td class="table__cell table__cell_last" width="50%">     <a href="/comm/" class="link          "> <span>Отменить</span>  </a>    </td> 
</tr> </tbody></table> 
</div>
</form>
<?
}else{
?>
<div class="wrapper"> <div class="block"> 
<b class="grey">Пока не доступно, достуно только Хозяину сайта!</b>
</div></div>
<?
}


}
else
{
echo "<div class='mess'>Вы уже создали максимальное количество сообществ!</div>";
}
}
else
{
header("Location:/comm/");
exit;
}





include_once H.'sys/inc/tfoot.php';
?>