<?
include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';

if(!isset($user)){
$_SESSION['err'] = 'Ошибка! Проверте введенный адрес.';
header("Location: /comm/?");
exit;
}

// Проверяем категорию
if($user['level'] >= 3 && mysql_result(mysql_query("SELECT COUNT(*) FROM `comm_cat` WHERE `id` = '".intval($_GET['id'])."'"),0) != 0)
{

$cat = mysql_fetch_assoc(mysql_query("SELECT * FROM `comm_cat` WHERE `id` = '".intval($_GET['id'])."' LIMIT 1"));


if(isset($_POST['cfms']) && isset($_POST['comm_cat_name']))
{
$name = $_POST['comm_cat_name'];

if(mysql_result(mysql_query("SELECT COUNT(*) FROM `comm_cat` WHERE `name` = '$name' AND `id` != '$cat[id]'"),0)!=0)$err[]="Такая категория уже есть";
elseif(strlen2($name)>50 || strlen2($name)<3)$err[]="Название должно быть не меньше 3-х и не больше 50-ти символов.";
$name = my_esc($name);

if (!isset($_POST['icon']) || $_POST['icon'] == null)
$FIcon = 'default';
else
$FIcon = preg_replace('#[^a-z0-9 _\-\.]#i', null, $_POST['icon']);

if (!isset($err)){
	mysql_query("UPDATE `comm_cat` SET `name` = '$name', `icon`='$FIcon' WHERE `id` = '$cat[id]' LIMIT 1");
	$_SESSION['message'] = 'Категория успешно изменена.';
	header("Location:/comm/cat/");
	exit;
}

}




$set['title'] = 'Редактор : Категории : Сообщества';
include_once H.'sys/inc/thead.php';
title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  
<a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     
<span class="lc_brw"> 
<img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/comm/">Сообщества</a> </span>     
<span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> 
<a href="/comm/cat/">Категории</a> </span>   
<span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> 
<a href="/comm/view_cat/?id=<?= $cat['id']?>"><?= text($cat['name'])?></a> </span>   
<span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Редактор</span> </span>       
</div>
<?


err();

?>
<form action="/comm/edit_cat/?id=<?= $cat['id']?>" method="post">
<div class="wrapper"> 
<div class="block"> 
<label class="lbl">Название категории:</label>
<div>   <div class="input-txt_wrapper">  
<input placeholder="Введите название категории" class="input-txt" name="comm_cat_name" value="<?=  text($cat['name'])?>" maxlength="50" type="text">  
</div>   </div>           
</div> 
<?
$icon=array();
$opendiricon=opendir(H.'style/i/cats');
while ($icons=readdir($opendiricon))
{
	if (preg_match('#^\.|default.png#',$icons))continue;
	$icon[]=$icons;
}
closedir($opendiricon);

?>
<div class="block bord-botm"> 
<label class="lbl">Иконка:</label>
<div>   <div class="input-txt_wrapper"> 
<select name="icon"> <option value="default.png"> По умолчанию </option>
<?    
for ($i = 0; $i < sizeof($icon); $i++)
{
	echo "<option value='$icon[$i]'>$icon[$i]</option>\n";
}
?>
</select>
</div>   </div>           
</div>
<table class="table__wrap"> <tbody><tr> 
<td class="table__cell" width="50%"> 
<!-- --><!-- --><!-- --><!-- --><!-- -->
<button name="cfms" value="Сохранить" class="  link  blue full is_final    " id="cfms">
<!--   --><img src="/style/i/ok_blue.png" alt="" class="m"> <!--   --><span class="m"> Сохранить</span><!-- -->
</button><!-- --><!-- --> 
</td> 
<td class="table__cell table__cell_last" width="50%">     <a href="/comm/view_cat/?id=<?= $cat['id']?>" class="link          "> <span>Отменить</span>  </a>    </td> 
</tr> </tbody></table> 
</div>
</form>
<?

include_once H.'sys/inc/tfoot.php';

}
else{

$_SESSION['err'] = 'Ошибка! Проверте введенный адрес.';
header("Location: /comm/?");
exit;

}
?>