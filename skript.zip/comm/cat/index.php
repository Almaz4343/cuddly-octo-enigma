<?
include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';

$set['title'] = 'Сообщества по интересам';
include_once H.'sys/inc/thead.php';
title();


?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/comm/">Сообщества</a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Категории</span> </span>       </div>
<?

err();


?>
<div class="wrapper-nobg"> 
<form action="/comm/cat/" method="get">  
<table class="table__wrap search-wrap input-txt_grid"> <tbody><tr> 
<td class="input-txt_grid_input"> 
<div class="input-txt_wrapper_search relative"> <input class="input-txt" name="q" value="" maxlength="64" type="text"> </div> 
</td> 
<td class="input-txt_grid_sep"></td> 
<td class="input-txt_grid_btn"> <input class="search__btn" value="Найти" name="cfms" type="submit"> </td> 
</tr> </tbody></table>     
</form> 
</div>

<div class="tabs_block oh">    
<a href="/comm/" class="tab_item left">  Популярные  </a>   
<div class="tab_item left tab_active black">  Категории  </div>   
<a href="#" class="tab_item left">  Мои  </a>   </div>

<?


$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `comm_cat`"),0);

if($k_post == 0){
?>
<div class="wrapper"><div class="link">Категорий пока нет.</div></div>
<?
}
else{

$q = mysql_query("SELECT * FROM `comm_cat` ORDER BY `id` DESC");

?>
<div class="wrapper">
<?

while($post=mysql_fetch_array($q))
{
$count = mysql_result(mysql_query("SELECT COUNT(*) FROM `comm` WHERE `id_cat` = '$post[id]'"),0);

?>
<div class="link    arrow    ">
<a href="/comm/view_cat/?id=<?= $post['id']?>" class="green"> 
<span>        
<img src="/style/i/cats/<?= $post['icon']?>" alt="" class="m">      
<span class="m"> <?= text($post['name'])?> </span>   <span class="m">(<?= $count?>)</span>       
</span>  
</a>
</div>
<?
}

?>
</div>
<?
}


if(isset($user) && $user['level'] >= 3){
?>
<div class="wrapper"> 
<a href="/comm/create_cat/" class="link  blue      "> 
<span>
<!--     --><img src="/style/i/plus.png" alt="" class="m"> <!--   --><span class="m">Добавить категорию</span><!--   -->
</span>  
</a> 
</div> 
<?
}

include_once H.'sys/inc/tfoot.php';
?>