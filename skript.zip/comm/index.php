<?
include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';

include_once H.'comm/config.php';

$set['title'] = 'Популярные сообщества';
include_once H.'sys/inc/thead.php';
title();


?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/comm/">Сообщества</a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Популярные</span> </span>       </div>
<?

err();


?>
<div class="wrapper-nobg"> 
<form action="/comm/" method="get">  
<table class="table__wrap search-wrap input-txt_grid"> <tbody><tr> 
<td class="input-txt_grid_input"> 
<div class="input-txt_wrapper_search relative"> <input class="input-txt" name="q" value="" maxlength="64" type="text"> </div> 
</td> 
<td class="input-txt_grid_sep"></td> 
<td class="input-txt_grid_btn"> <input class="search__btn" value="Найти" name="cfms" type="submit"> </td> 
</tr> </tbody></table>     
</form> 
</div>


<div class="tabs_block oh">    
<div class="tab_item left tab_active black">  Популярные  </div>   
<a href="/comm/cat/" class="tab_item left">  Категории  </a>   
<a href="#" class="tab_item left">  Мои  </a>   
</div>
<?

$set['p_str'] = '10';
$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `comm`"),0);
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str']*$page - $set['p_str'];

if ($k_post == 0){
?>
<div class="wrapper"><div class="link">Сообществ пока нет.</div></div>
<?
}
else{

?>
<div class="wrapper bb0">
<?

$q = mysql_query("SELECT * FROM `comm` ORDER BY `visits` DESC LIMIT $start, $set[p_str]");

while($post = mysql_fetch_array($q))
{
$count = mysql_result(mysql_query("SELECT COUNT(*) FROM `comm_users` WHERE `id_comm` = '$post[id]' AND `invite` = '0' AND `activate` = '1'"),0);
$cases = array('учасник', 'учасника', 'учасник');

// sys/comm/logos
?>
<div class="block oh relative bord-botm">  
<div class="left p40">      
<span class="pr">   
<div class="inl_bl relative"> 
<?
if (is_file($logos_upload_dir . $post['id'].'_'.$post['mdi'].'.png')){
?>
<img src="<?= $logos_show_dir . $post['id']?>_<?= $post['mdi']?>.png" alt="" class="preview s81_80">   
<?
}else{
?>
<img src="<?= $screens_show_dir?>comm.f.81.80.0.jpg" alt="" class="preview s81_80">   
<?
}
?>
</div>     
</span>        
</div>  
<div class="oh pre_content_wrap"> 
<a href="/comm/show/?id=<?= $post['id']?>" class="full_link"><b class="word_break"><?= text($post['name'])?></b></a>  <br>
<?
if($post['deviz'] != null){
?>
<?= text($post['deviz'])?>   <br>
<?
}
?>
<span class="grey">
<!--     --><img src="/style/i/ico/user.png" alt="" class="m"> <!--   --><span class="m"><?= des2num($count, $cases)?></span><!--   -->
</span>   
</div>  
</div>
<?

}
?>
</div>
<?
}

if ($k_page > 1)str("?", $k_page, $page); // Вывод страниц

include_once H.'sys/inc/tfoot.php';
?>