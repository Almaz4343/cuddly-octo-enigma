<?

$screens_upload_dir = H."sys/comm/screen/";
$screens_show_dir = "/sys/comm/screen/";
$files_upload_dir = H."/sys/comm/files/";
$logos_upload_dir = H."/sys/comm/logo/";
$logos_show_dir = "/sys/comm/logo/";
$max_self_comms = 3; // максимальное к-тво собственных сообществ

mysql_query("DELETE FROM `comm_users` WHERE `time` < '".($time-(3600*3))."' AND `invite` = '1'");
mysql_query("DELETE FROM `comm_users_ban` WHERE `time_ban` < '$time'");
mysql_query("DELETE FROM `comm_visits` WHERE `time` < '".mktime(0,0,0)."'");
mysql_query("DELETE FROM `chat_comm_who` WHERE `time` < '".($time-120)."'");

$rk = ' | ';

$mcomms = mysql_result(mysql_query("SELECT COUNT(*) FROM `comm` WHERE `id_user` = '$user[id]'"), 0);
if (isset($_GET['id']) && mysql_result(mysql_query("SELECT COUNT(*) FROM `comm` WHERE `id` = '".intval($_GET['id'])."'"), 0)) {
	
if (!mysql_result(mysql_query("SELECT COUNT(*) FROM `comm_visits` WHERE `id_comm` = '".intval($_GET['id'])."' AND `id_user` = '$user[id]'"), 0)) {
mysql_query("INSERT INTO `comm_visits` SET `id_comm` = '".intval($_GET['id'])."', `id_user` = '$user[id]', `time` = '$time'");
}

$count_visits = mysql_result(mysql_query("SELECT COUNT(*) FROM `comm_visits` WHERE `id_comm` = '".intval($_GET['id'])."'"), 0);
mysql_query("UPDATE `comm` SET `visits` = '$count_visits' WHERE `id` = '".intval($_GET['id'])."'");
@$uinc = mysql_fetch_array(mysql_query("SELECT * FROM `comm_users` WHERE `id_user` = '$user[id]' AND `id_comm` = '".intval($_GET['id'])."'"));
@mysql_query("UPDATE `comm_users` SET `last_time` = '$time' WHERE `id` = '$uinc[id]'");
}


?>