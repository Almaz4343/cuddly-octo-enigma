<?
include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';

$comm = mysql_fetch_assoc(mysql_query("SELECT * FROM `comm` WHERE `id` = '".intval($_GET['id'])."' LIMIT 1"));
$cat = mysql_fetch_assoc(mysql_query("SELECT * FROM `comm_cat` WHERE `id` = '".$comm['id_cat']."' LIMIT 1"));

if(!$comm){
	$_SESSION['err'] = 'Ошибка! Такого сообщества нет.';
	header("Location: /comm/cat/?");
	exit;
}

if (mysql_result(mysql_query("SELECT COUNT(*) FROM `comm_users` WHERE `id_comm` = '$comm[id]' AND `activate` = '1' AND `invite` = '0'"),0)==0){
	$comm['id_user'] = 0;
}
// Создатель
$ank_sozd = get_user($comm['id_user']);

$count = mysql_result(mysql_query("SELECT COUNT(*) FROM `comm_users` WHERE `id_comm` = '$comm[id]' AND `activate` = '1' AND `invite` = '0'"),0);
$count_admin = mysql_result(mysql_query("SELECT COUNT(*) FROM `comm_users` WHERE `id_comm` = '$comm[id]' AND `activate` = '1' AND `invite` = '0' AND `access` != 'user'"),0);
$cases = array('человек', 'человека', 'человек');


$set['title'] = 'О сообществе : ' . text($comm['name']) . ' : Сообщества';
include_once H.'sys/inc/thead.php';
title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/comm/">Сообщества</a> </span>  <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/comm/show/?id=<?= $comm['id']?>"><?= text($comm['name'])?></a> </span>   <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">О сообществе</span> </span>       </div>
<?

err();

?>
<div class="wrapper block">  
<div class="t_center"><b><?= text($comm['name'])?></b></div>  
<div class="pad_t_a"> <span class="light_item">Создано:</span> <?= vremja($comm['time'])?> </div>
<div class="pad_t_a"> 
<span class="light_item">Категория:</span>    
<a href="/comm/view_cat/?id=<?= $cat['id']?>" class="inl-link ">  <!--      --><span><?= text($cat['name'])?></span><!--   --><!-- --><!-- --><!-- -->
</a><!-- --> 
</div>
<?
if($comm['rules'] != null){
?>
<div class="word_break pad_t_a"> <span class="light_item">Правила:</span> <?= output_text($comm['rules'])?> </div>
<?
}
if($comm['deviz'] != null){
?>
<div class="word_break pad_t_a"> <span class="light_item">Девиз:</span> <?= output_text($comm['deviz'])?> </div>
<?
}
if($comm['interests'] != null){
?>
<div class="word_break pad_t_a"> <span class="light_item">Интересы:</span> <?= output_text($comm['interests'])?> </div>
<?
}
?>
<div class="pad_t_a"> <span class="grey">Создатель:</span>    
<a href="/user/?id=<?= $ank_sozd['id']?>" class="inl-link ">  <?= $ank_sozd['nick']?><!-- --><!-- --><!-- --></a><!-- --> 
</div>
<div class="pad_t_a"> <span class="grey">Руководство:</span>    
<a href="#" class="inl-link ">  <?= des2num($count_admin, $cases)?><!-- --><!-- --><!-- --></a><!-- --> 
</div>
<div class="pad_t_a"> <span class="grey">Участие:</span> <?= ($comm['read_rule'] == 1 ? "Свободное" : "Закрытое")?> </div>
</div>
<?


if(isset($user) && $ank_sozd['id'] == $user['id'] || $user['level'] >= 3){
?>
<div class="wrapper">     
<a href="/comm/edit/?id=<?= $comm['id']?>" class="link        "> <span><!--     --><img src="/style/i/soo/profile.png" alt="" class="m"> <!--   --><span class="m">Редактировать</span><!--   --></span>  </a>    
</div>
<?
}


include_once H.'sys/inc/tfoot.php';

?>