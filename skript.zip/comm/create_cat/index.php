<?
include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';

if(!isset($user)){
$_SESSION['err'] = 'Ошибка! Проверте введенный адрес.';
header("Location: /comm/?");
exit;
}

if($user['level'] < 3){
$_SESSION['err'] = 'Ошибка! Проверте введенный адрес.';
header("Location: /comm/?");
exit;
}

if(isset($_POST['cfms']) && isset($_POST['comm_cat_name']))
{
$name = $_POST['comm_cat_name'];

if(mysql_result(mysql_query("SELECT COUNT(*) FROM `comm_cat` WHERE `name` = '$name'"),0)!=0)$err[]="Такая категория уже есть!";
elseif(strlen2($name)>50 || strlen2($name)<3)$err[]="Название должно быть не меньше 3-х и не больше 50-ти символов.";
$name = my_esc($name);

if (!isset($_POST['icon']) || $_POST['icon'] == null)
$FIcon = 'default';
else
$FIcon = preg_replace('#[^a-z0-9 _\-\.]#i', null, $_POST['icon']);

if (!isset($err))
{
$pos = mysql_result(mysql_query("SELECT MAX(`pos`) FROM `comm_cat`"),0)+1;
mysql_query("INSERT INTO `comm_cat` (`name`, `pos`, `icon`) VALUES ('$name', '$pos', '$FIcon')");
$_SESSION['message'] = 'Категория успешно создана.';
header("Location:/comm/cat/");
exit;
}
}

$set['title'] = 'Создание категории : Сообщества';
include_once H.'sys/inc/thead.php';
title();


?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/comm/">Сообщества</a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Создание категории</span> </span>       </div>
<?

err();

?>
<form action="/comm/create_cat/?" method="post">
<div class="wrapper"> 
<div class="block"> 
<label class="lbl">Название категории:</label>
<div>   <div class="input-txt_wrapper">  
<input placeholder="Введите название категории" class="input-txt" name="comm_cat_name" value="" maxlength="50" type="text">  
</div>   </div>           
</div> 
<?
$icon=array();
$opendiricon=opendir(H.'style/i/cats');
while ($icons=readdir($opendiricon))
{
	if (preg_match('#^\.|default.png#',$icons))continue;
	$icon[]=$icons;
}
closedir($opendiricon);

?>
<div class="block bord-botm"> 
<label class="lbl">Иконка:</label>
<div>   <div class="input-txt_wrapper"> 
<select name="icon"> <option value="default.png"> По умолчанию </option>
<?    
for ($i = 0; $i < sizeof($icon); $i++)
{
	echo "<option value='$icon[$i]'>$icon[$i]</option>\n";
}
?>
</select>
</div>   </div>           
</div>
<table class="table__wrap"> <tbody><tr> 
<td class="table__cell" width="50%"> 
<!-- --><!-- --><!-- --><!-- --><!-- -->
<button name="cfms" value="Создать" class="  link  blue full is_final    " id="cfms">
<!--   --><img src="/style/i/ok_blue.png" alt="" class="m"> <!--   --><span class="m"> Создать</span><!-- -->
</button><!-- --><!-- --> 
</td> 
<td class="table__cell table__cell_last" width="50%">     <a href="/comm/cat/" class="link          "> <span>Отменить</span>  </a>    </td> 
</tr> </tbody></table> 
</div>
</form>
<?

include_once H.'sys/inc/tfoot.php';
?>