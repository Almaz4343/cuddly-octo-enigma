<?
include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';

include_once H.'comm/config.php';

$comm = mysql_fetch_assoc(mysql_query("SELECT * FROM `comm` WHERE `id` = '".intval($_GET['id'])."' LIMIT 1"));
$cat = mysql_fetch_assoc(mysql_query("SELECT * FROM `comm_cat` WHERE `id` = '".$comm['id_cat']."' LIMIT 1"));

if(!$comm){
	$_SESSION['err'] = 'Ошибка! Такого сообщества нет.';
	header("Location: /comm/cat/?");
	exit;
}

if (mysql_result(mysql_query("SELECT COUNT(*) FROM `comm_users` WHERE `id_comm` = '$comm[id]' AND `activate` = '1' AND `invite` = '0'"),0)==0){
	$comm['id_user'] = 0;
}

// Создатель
$ank_sozd = get_user($comm['id_user']);

if(isset($user) && $ank_sozd['id'] == $user['id'] || $user['level'] >= 3){


if(isset($_POST['cfms']))
{
$name = $_POST['comm_name'];
$deviz = $_POST['deviz'];
$interests = $_POST['interests'];
$rules = $_POST['rules'];

if(mysql_result(mysql_query("SELECT COUNT(*) FROM `comm` WHERE `name` = '$name' AND `id` != '$comm[id]'"),0)!=0)$err[] = "Сообщество с таким названием уже есть";

elseif(strlen2($name) > 50 || strlen2($name) < 3)$err[] = "Название должно быть не меньше 3-х и не больше 50-ти символов!";
elseif(strlen2($deviz) > 80)$err[] = "Девиз должен быть не больше 80 символов!";
elseif(strlen2($interests) > 1000)$err[] = "Интересы должны быть не больше 1000 символов!";
elseif(strlen2($rules) > 1000)$err[] = "Правила должны быть не больше 1000 символов!";

$name = my_esc($name);
$deviz = my_esc($deviz);
$interests = my_esc($interests);
$rules = my_esc($rules);


if (!isset($err)){
	mysql_query("UPDATE `comm` SET `name` = '$name', `deviz` = '$deviz', `interests` = '$interests', `rules` = '$rules' WHERE `id` = '$comm[id]' LIMIT 1");
	$_SESSION['message'] = 'Изменения сохранены. ';
	header("Location:/comm/show/?id=$comm[id]");
	exit;
}

}


$set['title'] = 'Управление : ' . text($comm['name']) . ' : Сообщества';
include_once H.'sys/inc/thead.php';
title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/comm/">Сообщества</a> </span>  <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/comm/show/?id=<?= $comm['id']?>"><?= text($comm['name'])?></a> </span>   <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Управление</span> </span>       </div>
<?

err();

//style="max-width: 40%;max-height: 40%;"
?>
<div class="tabs_block oh">    
<div class="tab_item left tab_active black">  Редактирование  </div>   
<a href="/comm/settings/?id=<?= $comm['id']?>" class="tab_item left">  Настройки  </a>   
</div>
<div class="wrapper col_blocks">
<form action="/comm/edit/?id=<?= $comm['id']?>" method="post">
<div class="block bord-botm">



<div class="stnd_padd oh"> 
<div class="left dot_pic">      
<a class="tdn" href="/comm/logo/?id=<?= $comm['id']?>">   
<div class="inl_bl relative p40"> 
<?
if (is_file($logos_upload_dir.$comm['id'].'_'.$comm['mdi'].'.png')){
?>
<img src="<?= $logos_show_dir . $comm['id']?>_<?= $comm['mdi']?>.png" alt="" class="preview  s41_40">
<?
}
else{
?>
<img src="<?= $screens_show_dir?>comm.f.41.40.0.jpg" alt="" class="preview s41_40">   
<?
}
?>
</div>      
</a>        
</div> 
<div class="oh">    
<a href="/comm/logo/?id=<?= $comm['id']?>" class="inl-link ">  
<!--     --><img src="//c.spac.me/i/ico/pic.png" alt="" class="m"> <!--   --><span class="m">Сменить эмблему</span><!--   --><!-- --><!-- --><!-- -->
</a><!-- --> 
</div> 
</div>

<div class="stnd_padd">  <div>  
<label class="lbl">  Название сообщества:   </label>   
<div class="input-txt_wrapper">  
<input placeholder="Введите название сообщества" class="input-txt" name="comm_name" value="<?= text($comm['name'])?>" maxlength="50" type="text">  
</div>   
</div>   </div>

<div class="stnd_padd pdt grey">  <div>  
<label class="lbl">  Девиз   (не обязательно): </label>   
<div class="input-txt_wrapper">  
<input placeholder="Введите девиз" class="input-txt" name="deviz" value="<?= text($comm['deviz'])?>" maxlength="80" type="text">  
</div>   
</div>   </div>

<div class="stnd_padd pdt grey">  <div>  
<label class="lbl">  Интересы   (не обязательно): </label>   
<div class="input-txt_wrapper">  
<textarea placeholder="Введите интересы" class="input-txt" rows="5" cols="17" name="interests" maxlength="1000"><?= text($comm['interests'])?></textarea>  
</div>   
</div>   </div>

<div class="stnd_padd pdt grey">  <div>  
<label class="lbl">  Правила   (не обязательно): </label>   
<div class="input-txt_wrapper">  
<textarea placeholder="Введите правила" class="input-txt" rows="5" cols="17" name="rules" maxlength="1000"><?= text($comm['rules'])?></textarea>  
</div>   
</div>   </div>
</div>

<table class="table__wrap"> <tbody><tr> 
<td class="table__cell" width="50%"> <!-- --><!-- --><!-- --><!-- --><!-- -->
<button name="cfms" value="Сохранить" class="  link  blue full is_final    " id="cfms">
<!--   --><img src="//c.spac.me/i/ok_blue.png" alt="" class="m"> <!--   --><span class="m"> Сохранить</span><!-- -->
</button><!-- --><!-- --> </td> 
<td class="table__cell table__cell_last" width="50%">     
<a href="/comm/show/?id=<?= $comm['id']?>" class="link          "> <span>Отменить</span>  </a>    
</td> 
</tr> </tbody></table>


</form>
</div>
<a href="/comm/show/?id=<?= $comm['id']?>" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?

include_once H.'sys/inc/tfoot.php';
}
else{
	$_SESSION['err'] = 'Ошибка!';
	header("Location: /comm/?");
	exit;
}
?>