<?
include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';

include_once H.'comm/config.php';

$comm = mysql_fetch_assoc(mysql_query("SELECT * FROM `comm` WHERE `id` = '".intval($_GET['id'])."' LIMIT 1"));

if(!$comm){
	$_SESSION['err'] = 'Ошибка! Такого сообщества нет.';
	header("Location: /comm/cat/?");
	exit;
}

if (mysql_result(mysql_query("SELECT COUNT(*) FROM `comm_users` WHERE `id_comm` = '$comm[id]' AND `activate` = '1' AND `invite` = '0'"),0)==0){
	$comm['id_user'] = 0;
}

// Создатель
$ank = get_user($comm['id_user']);

if(isset($user) && $user['id'] == $ank['id'] || $user['level'] >= 3){


if (isset($_FILES['file']) && isset($_POST['cfms']))
{
$file_path = $_FILES['file']['tmp_name'];
$save_path = $logos_upload_dir;
$type = $_FILES['file']['type'];
if ($type!=='image/jpeg' && $type!=='image/jpg' && $type!=='image/gif' && $type!=='image/png')$err[] = "Это не изображение!";
else
{
if (is_file($logos_upload_dir.$comm['id'].'_'.$comm['mdi'].'.png')){
	unlink($logos_upload_dir.$comm['id'].'_'.$comm['mdi'].'.png');
}

$comm['mdi'] = md5(rand(12345, 99999999));
mysql_query("UPDATE `comm` SET `mdi` = '$comm[mdi]' WHERE `id` = '$comm[id]'");
$name = $comm['id'].'_'.$comm['mdi'].'.png';
if (create_preview($file_path, $save_path.$name, 96, 96)){
	$_SESSION['message'] = 'Эмблема сообщества обновлена.';
	header("Location: /comm/edit/?id=$comm[id]");
	exit;
}	
else{
	$err[] = 'Ошибка установки Эмблемы';
}
}

}
if(isset($_GET['Delete']) && $_GET['Delete'] == 1)
{
if (is_file($logos_upload_dir.$comm['id'].'_'.$comm['mdi'].'.png')){
unlink($logos_upload_dir.$comm['id'].'_'.$comm['mdi'].'.png');
	$_SESSION['message'] = 'Эмблема сообщества удалена. ';
	header("Location: /comm/edit/?id=$comm[id]");
	exit;
}
}


if(isset($_GET['rotate']) && ($_GET['rotate']=='right' || $_GET['rotate']=='left') && is_file($logos_upload_dir.$comm['id'].'_'.$comm['mdi'].'.png'))
{
$rotate = $_GET['rotate'];

if($rotate=='left')
$degrees=90;
else 
$degrees=270;

// Файл и угол поворота
$icon = $logos_upload_dir.$comm['id'].'_'.$comm['mdi'].'.png';

// Загрузка изображения
$source = imagecreatefromstring(file_get_contents($icon));

// Поворот
$rotate = imagerotate($source, $degrees, 0);

// Ввод
if (is_file($logos_upload_dir.$comm['id'].'_'.$comm['mdi'].'.png')){
	unlink($logos_upload_dir.$comm['id'].'_'.$comm['mdi'].'.png');
}

$comm['mdi'] = md5(rand(12345,99999999));

mysql_query("UPDATE `comm` SET `mdi` = '$comm[mdi]' WHERE `id` = '$comm[id]'");
imagepng($rotate,$logos_upload_dir.$comm['id'].'_'.$comm['mdi'].'.png');
header("Location: /comm/logo/?id=$comm[id]");
exit;
}

if (isset($_POST['turn_left'])){
header("Location: /comm/logo/?id=$comm[id]&rotate=left");
exit;
}
if (isset($_POST['turn_right'])){
header("Location: /comm/logo/?id=$comm[id]&rotate=right");
exit;
}


$set['title'] = 'Эмблема : ' . text($comm['name']). ' : Сообщества';
include_once H.'sys/inc/thead.php';
title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/comm/">Сообщества</a> </span>    <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/comm/show/?id=<?= $comm['id']?>"><?= text($comm['name'])?></a> </span> <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Эмблема</span> </span>       </div>
<?

err();

if (is_file($logos_upload_dir.$comm['id'].'_'.$comm['mdi'].'.png')){
$dopol = ' bord-botm';
}else{
$dopol = '';
}


?>
<div class="wrapper"> 
<div class="block t_center image_limit<?= $dopol?>">      
<div class="relative"> 
<?
if (is_file($logos_upload_dir.$comm['id'].'_'.$comm['mdi'].'.png')){
?>
<img src="<?= $logos_show_dir . $comm['id']?>_<?= $comm['mdi']?>.png" alt="" class="preview">
<br><br>
<div> 
<form method="post" action="?id=<?= $comm['id']?>"> 
<input name="turn_left" value="" class="form_button rotate_button turn_left m" type="submit"> 
<input name="turn_right" value="" class="form_button rotate_button turn_right m" type="submit">  
</form> 
</div>
<?
}
else{
?>
<img src="<?= $screens_show_dir?>comm.f.81.80.0.jpg" alt="" class="preview">   
<?
}
?>
</div>          
</div>
<?
if (is_file($logos_upload_dir.$comm['id'].'_'.$comm['mdi'].'.png')){
?>
<table class="table__wrap"> <tbody><tr>    
<td class="table__cell table__cell_last" width="50%">     
<a href="/comm/logo/?id=<?= $comm['id']?>&amp;Delete=1" class="link  red      "> <span><!--     --><img src="/style/i/delete.png" alt="" class="m"> <!--   --><span class="m">Удалить</span><!--   --></span>  </a>    
</td>  
</tr> </tbody></table>
<?
}
?> 
</div>
<?

if (!is_file($logos_upload_dir.$comm['id'].'_'.$comm['mdi'].'.png')){
?>
<div class="wrapper form-checkbox-native"> 
<form method="post" action="?id=<?= $comm['id']?>" enctype="multipart/form-data"> 
<div class="bord-botm"> <div class="block pdb">    <div>
<input id="myFile" name="file" accept="image/*,image/gif,image/png,image/jpeg" type="file">
</div>   
<div class="pad_t_a"> 
<label class="lbl">Можно загружать картинки форматов: GIF, JPG, PNG</label> 
</div> 
</div>   </div>  
<div>  
<input value="Загрузить" class="link blue full is_final" type="submit" name="cfms">  
</div> 
</form> 
</div>
<?
}






?>
<a href="/comm/edit/?id=<?= $comm['id']?>" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?

include_once H.'sys/inc/tfoot.php';
}
else{
	$_SESSION['err'] = 'Ошибка!';
	header("Location: /comm/?");
	exit;
}
?>