<?
include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';

include_once H.'comm/config.php';

$comm = mysql_fetch_assoc(mysql_query("SELECT * FROM `comm` WHERE `id` = '".intval($_GET['id'])."' LIMIT 1"));

if(!$comm){
	$_SESSION['err'] = 'Ошибка! Такого сообщества нет.';
	header("Location: /comm/cat/?");
	exit;
}

if (mysql_result(mysql_query("SELECT COUNT(*) FROM `comm_users` WHERE `id_comm` = '$comm[id]' AND `activate` = '1' AND `invite` = '0'"),0) == 0){
	$comm['id_user'] = 0;
}

// Создатель
$ank = get_user($comm['id_user']);

$set['title'] = 'Участники сообщества : ' . text($comm['name']). ' : Сообщества';
include_once H.'sys/inc/thead.php';
title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/comm/">Сообщества</a> </span>    <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/comm/show/?id=<?= $comm['id']?>"><?= text($comm['name'])?></a> </span> <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Участники</span> </span>       </div>
<?

err();

?>
<div class="wrapper-nobg"> 
<form action="/comm/users/?id=<?= $comm['id']?>" method="get">  
<table class="table__wrap search-wrap input-txt_grid"> <tbody><tr> 
<td class="input-txt_grid_input"> 
<div class="input-txt_wrapper_search relative"> <input class="input-txt" name="q" value="" maxlength="64" type="text"> </div> 
</td> 
<td class="input-txt_grid_sep"></td> 
<td class="input-txt_grid_btn"> <input class="search__btn" value="Найти" name="cfms" type="submit"> </td> 
</tr> </tbody></table>     
</form> 
</div>
<?

$_SESSION['user_sort'] = null;

if (isset($_GET['List']) && ($_GET['List'] == '0' || $_GET['List'] == '1' || $_GET['List'] == '2'))
{
if ($_GET['List'] == '0'){
	$_SESSION['user_sort'] = 0;
}
else if ($_GET['List'] == '1'){
	$_SESSION['user_sort'] = 1;
}
else if ($_GET['List'] == '2'){
	$_SESSION['user_sort'] = 2;
}
}


// Все юзеры
if($_SESSION['user_sort'] == 0){
?>
<div class="tabs_block oh">    
<div class="tab_item left tab_active black">  Все  </div>   
<a href="/comm/users/?id=<?= $comm['id']?>&amp;List=2" class="tab_item left">  Друзья  </a>   
<a href="/comm/users/?id=<?= $comm['id']?>&amp;List=1" class="tab_item left">  Администрация  </a>   
</div>
<?

$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `comm_users` WHERE `id_comm` = '$comm[id]' AND `activate` = '1' AND `invite` = '0'"),0);
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str']*$page-$set['p_str'];

if ($k_post == 0)
{
?>
<div class="wrapper block">   
<span class="grey m"> Учасников нет. </span>
</div>
<?
}
else{

$q = mysql_query("SELECT * FROM `comm_users` WHERE `id_comm` = '$comm[id]' AND `activate` = '1' AND `invite` = '0' LIMIT $start, $set[p_str]");

while($post = mysql_fetch_array($q))
{
$us_comm = get_user($post['id_user']);
//$for_comm = mysql_result(mysql_query("SELECT COUNT(*) FROM `comm_forum_komm` WHERE `id_comm` = '$comm[id]' AND `id_user` = '$us_comm[id]'"),0);

if($post['access'] == 'creator')$Administrations = 'Создатель сообщества';
elseif($post['access'] == 'adm')$Administrations = 'Администратор сообщества';
elseif($post['access'] == 'mod')$Administrations = 'Модератор сообщества';
else$Administrations = null;

?>
<div class="js-row block bord-botm oh grey relative">        
<div class="left font0">   
<a href="/user/?id=<?= $us_comm['id']?>" class="tdn">       
<span class="pr">   
<div class="inl_bl relative"> <?= ava40($us_comm['id'])?> </div>     
</span>        
</a>  
</div>   
<div class="pre_content_wrap break-word"> <?= group($us_comm['id'])?>   
<a href="/user/?id=<?= $us_comm['id']?>" class="black full_link">   <b><?= unick($us_comm['id'])?></b>  </a>   
<?= medal($us_comm['id'])?> 
<?
/*             
<div>Комментариев на форуме: 1</div> 
*/
if($Administrations != NULL){
?>
<div class="green"><?= $Administrations?></div> 
<?
}
?>
<div>Последний визит: <?= vremja($us_comm['date_last'])?></div>             
</div>     
<?
if(isset($user) && $ank['id'] == $user['id']){
if($us_comm['id'] != $user['id']){
?>
<div class="menu_btn" title="Действия">  
<a href="/comm/user_settings/?id=<?= $comm['id']?>&user=<?= $us_comm['id']?>" class="right "> <span><img src="/style/i/ico/settings.png" alt="" class="m"> </span>  </a>
</div> 
<?
}
}
?>
</div>
<?

}

if ($k_page > 1)str("?id=$comm[id]&",$k_page,$page); // Вывод страниц

}

}

// Администрация
elseif($_SESSION['user_sort'] == 1){
?>
<div class="tabs_block oh">    
<a href="/comm/users/?id=<?= $comm['id']?>&amp;List=0" class="tab_item left">  Все     </a>  
<a href="/comm/users/?id=<?= $comm['id']?>&amp;List=2" class="tab_item left">  Друзья  </a>   
<div class="tab_item left tab_active black">  Администрация  </div> 
</div>
<?

$k_post = mysql_result(mysql_query("SELECT COUNT(*) FROM `comm_users` WHERE `id_comm` = '$comm[id]' AND `activate` = '1' AND `invite` = '0'  AND `access` != 'user'"),0);
$k_page = k_page($k_post,$set['p_str']);
$page = page($k_page);
$start = $set['p_str']*$page-$set['p_str'];

if ($k_post == 0)
{
?>
<div class="wrapper block">   
<span class="grey m"> Учасников нет. </span>
</div>
<?
}
else{

$q = mysql_query("SELECT * FROM `comm_users` WHERE `id_comm` = '$comm[id]' AND `activate` = '1' AND `invite` = '0' AND `access` != 'user' LIMIT $start, $set[p_str]");

while($post = mysql_fetch_array($q))
{
$us_comm = get_user($post['id_user']);
//$for_comm = mysql_result(mysql_query("SELECT COUNT(*) FROM `comm_forum_komm` WHERE `id_comm` = '$comm[id]' AND `id_user` = '$us_comm[id]'"),0);

if($post['access'] == 'creator')$Administrations = 'Создатель сообщества';
elseif($post['access'] == 'adm')$Administrations = 'Администратор сообщества';
elseif($post['access'] == 'mod')$Administrations = 'Модератор сообщества';
else$Administrations = null;

?>
<div class="js-row block bord-botm oh grey relative">        
<div class="left font0">   
<a href="/user/?id=<?= $us_comm['id']?>" class="tdn">       
<span class="pr">   
<div class="inl_bl relative"> <?= ava40($us_comm['id'])?> </div>     
</span>        
</a>  
</div>   
<div class="pre_content_wrap break-word"> <?= group($us_comm['id'])?>   
<a href="/user/?id=<?= $us_comm['id']?>" class="black full_link">   <b><?= unick($us_comm['id'])?></b>  </a>   
<?= medal($us_comm['id'])?> 
<?
/*             
<div>Комментариев на форуме: 1</div> 
*/
if($Administrations != NULL){
?>
<div class="green"><?= $Administrations?></div> 
<?
}
?>
<div>Последний визит: <?= vremja($us_comm['date_last'])?></div>             
</div>     
<?
if(isset($user) && $ank['id'] == $user['id']){
if($us_comm['id'] != $user['id']){
?>
<div class="menu_btn" title="Действия">  
<a href="/comm/user_settings/?id=<?= $comm['id']?>&user=<?= $us_comm['id']?>" class="right "> <span><img src="/style/i/ico/settings.png" alt="" class="m"> </span>  </a>
</div> 
<?
}
}
?>
</div>
<?

}

if ($k_page > 1)str("?id=$comm[id]&",$k_page,$page); // Вывод страниц

}


}
// Друзья
elseif($_SESSION['user_sort'] == 2){

?>
<div class="tabs_block oh">    
<a href="/comm/users/?id=<?= $comm['id']?>&amp;List=0" class="tab_item left">  Все     </a>  
<div class="tab_item left tab_active black">  Друзья   </div>
<a href="/comm/users/?id=<?= $comm['id']?>&amp;List=1" class="tab_item left">  Администрация  </a>   
</div>

<div class="wrapper block">   
<span class="grey m"> Пока в разработке. </span>
</div>
<?



}

?>
<a href="/comm/show/?id=<?= $comm['id']?>" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?

include_once H.'sys/inc/tfoot.php';

?>