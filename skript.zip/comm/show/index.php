<?
include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';

include_once H.'comm/config.php';

$comm = mysql_fetch_assoc(mysql_query("SELECT * FROM `comm` WHERE `id` = '".intval($_GET['id'])."' LIMIT 1"));
$cat = mysql_fetch_assoc(mysql_query("SELECT * FROM `comm_cat` WHERE `id` = '".$comm['id_cat']."' LIMIT 1"));
$count = mysql_result(mysql_query("SELECT COUNT(*) FROM `comm_users` WHERE `id_comm` = '$comm[id]' AND `activate` = '1' AND `invite` = '0'"),0);
$count_admin = mysql_result(mysql_query("SELECT COUNT(*) FROM `comm_users` WHERE `id_comm` = '$comm[id]' AND `activate` = '1' AND `invite` = '0' AND `access` != 'user'"),0);
$cases = array('учасник', 'учасника', 'учасник');



if (mysql_result(mysql_query("SELECT COUNT(*) FROM `comm_users` WHERE `id_comm` = '$comm[id]' AND `activate` = '1' AND `invite` = '0'"),0) == 0){
	$comm['id_user'] = 0;
}

if(!$comm){
	$_SESSION['err'] = 'Ошибка! Такого сообщества нет.';
	header("Location: /comm/cat/?");
	exit;
}

// Создатель
$ank = get_user($comm['id_user']);

$set['title'] = 'Сообщество : ' . text($comm['name']);
include_once H.'sys/inc/thead.php';
title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/comm/">Сообщества</a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text"><?= text($comm['name'])?></span> </span>       </div>
<?


if($comm['id_user'] != 0 && isset($user)){

//Вступление или вступ по приглашению
if(isset($_GET['join'])){

if(mysql_result(mysql_query("SELECT COUNT(*) FROM `comm_users` WHERE `id_comm` = '$comm[id]' AND `id_user` = '$user[id]' AND `activate` = '1'"),0)==0)
{
if(mysql_result(mysql_query("SELECT COUNT(*) FROM `comm_blist` WHERE `id_comm` = '$comm[id]' AND `id_user` = '$user[id]'"),0)!=0){
	$err[] = "Вы не можете вступить в данное сообщество, так как находитесь в черном списке сообщества!";
}
else{

if(mysql_result(mysql_query("SELECT COUNT(*) FROM `comm_users` WHERE `id_comm` = '$comm[id]' AND `id_user` = '$user[id]' AND `invite` = '1'"),0)!=0)
{
mysql_query("INSERT INTO `comm_journal` SET `id_comm` = '$comm[id]', `id_user` = '$user[id]', `type` = 'in_comm', `time` = '$time'");
mysql_query("UPDATE `comm_users` SET `activate` = '1', `invite` = '0', `time` = '$time' WHERE `id_comm` = '$comm[id]' AND `id_user` = '$user[id]' AND `invite` = '1'");

$_SESSION['message'] = 'Приглашение успешно принято.';
header("Location: /comm/show/?id=$comm[id]");
exit;
}
elseif($comm['join_rule'] != 3){

// Подаем заявку
if($comm['join_rule'] == 2){

if(mysql_result(mysql_query("SELECT COUNT(*) FROM `comm_users` WHERE `id_comm` = '$comm[id]' AND `id_user` = '$user[id]' AND `invite` = '0' AND `activate` = '0'"),0)==0)
{
mysql_query("INSERT INTO `comm_users` (`id_comm`, `id_user`, `time`, `activate`) VALUES ('$comm[id]', '$user[id]', '".time()."', '0')");
mysql_query("INSERT INTO `mail` (`id_user`, `id_kont`, `msg`, `time`) VALUES ('0', '$ank[id]', '$user[nick] хочет вступить в сообщество [url=/comm/?act=comm&id=$comm[id]]".htmlspecialchars($comm['name'])."[/url].', '$time')");

$_SESSION['message'] = 'Заявка на вступление успешно отправена.';
header("Location: /comm/show/?id=$comm[id]");
exit;
}
else{
	$err[] = "Вы уже подали заявку, дождитесь ее одобрения!";
}
}
// Если просто вступаем
else
{
mysql_query("INSERT INTO `comm_journal` SET `id_comm` = '$comm[id]', `id_user` = '$user[id]', `type` = 'in_comm', `time` = '$time'");
mysql_query("INSERT INTO `comm_users` (`id_comm`, `id_user`, `time`, `activate`) VALUES ('$comm[id]', '$user[id]', '$time', '1')");

$_SESSION['message'] = 'Вы стали новым участником сообщества.';
header("Location: /comm/show/?id=$comm[id]");
exit;
}
}
else $err[] = "Сообщество закрыто!";
}
}
else $err[] = "Вы уже являетесь участником сообществаю=.";
}
// Выход из сообшества
elseif(isset($_GET['leave'])){

if(mysql_result(mysql_query("SELECT COUNT(*) FROM `comm_users` WHERE `id_comm` = '$comm[id]' AND `id_user` = '$user[id]' AND `activate` = '1'"),0)!=0)
{
if($ank['id'] == $user['id'] && isset($user) && mysql_result(mysql_query("SELECT COUNT(*) FROM `comm_users` WHERE `id_comm` = '$comm[id]' AND `activate` = '1'"),0) > 1){
	
	$_SESSION['err'] = 'Вы создатель сообщества! Для начала удалите всех участников сообщества.';
	header("Location: /comm/show/?id=$comm[id]");
	exit;	
}
else
{
if($ank['id'] == $user['id'] && isset($user))
{
$comm['id_user'] = 0;
// Создатель
$ank = get_user($comm['id_user']); 
}

mysql_query("INSERT INTO `comm_journal` SET `id_comm` = '$comm[id]', `id_user` = '$user[id]', `type` = 'out_comm', `time` = '$time'");
mysql_query("DELETE FROM `comm_users` WHERE `id_comm` = '$comm[id]' AND `id_user` = '$user[id]' AND `activate` = '1'");

$_SESSION['message'] = 'Вы успешно покинули сообщество.';
header("Location: /comm/show/?id=$comm[id]");
exit;
}
}
else $err[] = "Вы не являетесь участником сообщества!";
}
}

// Если сообщество без главы
elseif(isset($user) && isset($_GET['creator']) && mysql_result(mysql_query("SELECT COUNT(*) FROM `comm_users` WHERE `id_comm` = '$comm[id]' AND `activate` = '1' AND `invite` = '0'"),0)==0)
{
mysql_query("INSERT INTO `comm_journal` SET `id_comm` = '$comm[id]', `id_user` = '$user[id]', `id_ank` = '0', `type` = 'access', `time` = '$time', `access` = 'creator'");
mysql_query("UPDATE `comm` SET `id_user` = '$user[id]' WHERE `id` = '$comm[id]'");
mysql_query("INSERT INTO `comm_users` (`id_comm`, `id_user`, `time`, `activate`, `access`) VALUES ('$comm[id]', '$user[id]', '".time()."', '1', 'creator')");

$_SESSION['message'] = 'Теперь вы создатель сообщества.';
header("Location: /comm/show/?id=$comm[id]");
exit;
$ank = get_user($user['id']);
}


err();

?>
<div class="wrapper">

<div class="block pdb"> 

<div class="t_center b word_break"> <?= text($comm['name'])?> </div>
<div class="oh pad_t_a"> 
<div class="left p80 dot_pic">      <span class="pr">   <div class="inl_bl relative"> 
<?
if (is_file($logos_upload_dir . $comm['id'].'_'.$comm['mdi'].'.png')){
?>
<img src="<?= $logos_show_dir . $comm['id']?>_<?= $comm['mdi']?>.png" alt="" class="preview s81_80">   
<?
}else{
?>
<img src="<?= $screens_show_dir?>comm.f.81.80.0.jpg" alt="" class="preview s81_80">   
<?
}
?>
</div>     </span>        </div> 
<div class="oh"> 
<div class="grey">  
<span class="m">
<!--     --><img src="/style/i/ico/user.png" alt="" class="m"> <!--   --><span class="m"><?= $count?></span><!--   -->
</span> 
</div> 
<div>   
<a href="/comm/view_cat/?id=<?= $cat['id']?>" class="inl-link ">  
<!--     -->
<img src="/style/i/cats/<?= $cat['icon']?>" alt="" class="m"> <!--   --><span class="m"><?= text($cat['name'])?></span>
<!--   --><!-- --><!-- --><!-- -->
</a>
<!-- -->
</div> 
<?
if($comm['adult'] == 1){
?>
<div class="red_item"> 
<!--     --><img src="/style/i/soo/soo_adult.png" alt="" class="m"> <!--   --><span class="m">Только для взрослых</span><!--   --> 
</div>
<?
}
?>  
</div> </div></div>
<div class="block">  
<?
if($comm['opis'] != null){
?> 
<div class="word_break">   
<?= output_text($comm['opis'])?>
</div>       
<?
}else{
if(isset($user) && $ank['id'] == $user['id'] || $user['level'] >= 3){
?>
<div class="grey">Заполните описание</div>        <!-- --><!-- --><!-- --></a><!-- --></div>
<?
}
}
if(isset($user) && $ank['id'] == $user['id'] || $user['level'] >= 3){
?>
<div class="pad_t_a">   <a href="/comm/description/?id=<?= $comm['id']?>" class="inl-link ">            <span>  Редактировать описание </span>          <!-- --><!-- --><!-- --></a><!-- --></div>
<?
}
if (!isset($_GET['Expand']))
{
?>
<div class="pad_t_a"> 
<a href="/comm/show/?Expand=1&id=<?= $comm['id']?>">Подробнее...</a> 
</div> 
<?
} 
if (isset($_GET['Expand']) && $_GET['Expand'] == 1)
{
?>
<div class="pad_t_a"> <span class="grey">Создано:</span> <?= vremja($comm['time'])?> </div>
<?
if($comm['interests'] != null){
?> 
<div class="pad_t_a"> <span class="grey">Интересы:</span> <div class="word_break"><?= text($comm['interests'])?> </div> </div>
<?
}
?>
<div class="pad_t_a"> <span class="grey">Создатель:</span>    
<a href="/user/?id=<?= $ank['id']?>" class="inl-link ">  <?= $ank['nick']?><!-- --><!-- --><!-- --></a><!-- --> 
</div>
<div class="pad_t_a"> <span class="grey">Администрация:</span>    
<a href="#" class="inl-link ">  <?= des2num($count_admin, $cases)?><!-- --><!-- --><!-- --></a><!-- --> 
</div>
<div class="pad_t_a"> <span class="grey">Участие:</span> <?= ($comm['read_rule'] == 1 ? "Свободное" : "Закрытое")?> </div>
<?
}
?>
</div>
</div>
<?

if(isset($user) && $ank['id'] == $user['id'] || $user['level'] >= 3){
?>
<div class="wrapper"> 
<table class="table__wrap"> <tbody><tr>  
<td class="table__cell table__cell_last" width="100%">     
<a href="/comm/edit/?id=<?= $comm['id']?>" class="link        "> 
<span><!--     --><img src="/style/i/ico/settings.png" alt="" class="m"> <!--   --><span class="m">Управление сообществом</span><!--   --></span>  
</a>    
</td>  
</tr> </tbody></table> 
</div>
<?
}

if(isset($user)){
if(mysql_result(mysql_query("SELECT COUNT(*) FROM `comm_users` WHERE `id_comm` = '$comm[id]' AND `id_user` = '$user[id]' AND `activate` = '1'"),0)!=0)
{
?>
<div class="wrapper">   
<table class="table__wrap table__links"> <tbody><tr>  
<td class="table__cell" width="50%">      
<a href="?id=<?= $comm['id']?>&leave=1" class="link          "> 
<span><!--     --><img src="/style/i/ico/exit.png" alt="" class="m"> <!--   --><span class="m">Покинуть</span><!--   --></span>  
</a>     
</td>
<td class="table__cell table__cell_last" width="50%">     
<a href="#" class="link          "> 
<span><!--     --><img src="/style/i/fav_grey.png" alt="" class="m"> <!--   --><span class="m">В закладки</span><!--   --></span>  
</a>       

</td>    </tr> </tbody></table>    
</div>
<?
}
else{
if($comm['id_user'] != 0)
{
?>
<div class="wrapper">   
<table class="table__wrap table__links"> <tbody><tr>  
<?

if(mysql_result(mysql_query("SELECT COUNT(*) FROM `comm_users` WHERE `id_comm` = '$comm[id]' AND `id_user` = '$user[id]' AND `invite` = '1'"),0) != 0){
?>
<td class="table__cell" width="50%">      
<a href="?id=<?= $comm['id']?>&&join=1" class="link          "> 
<span><!--     --><img src="/style/i/ico/enter_grey.png" alt="" class="m"> <!--   --><span class="m">Принять приглашение</span><!--   --></span>  
</a>     
</td>  
<?
}
elseif($comm['join_rule'] != 3){
?>
<td class="table__cell" width="50%">      
<a href="?id=<?= $comm['id']?>&&join=1" class="link          "> 
<span><!--     --><img src="/style/i/ico/enter_grey.png" alt="" class="m"> <!--   --><span class="m">Вступить</span><!--   --></span>  
</a>     
</td>  
<?
}
?>
<td class="table__cell table__cell_last" width="50%">     
<a href="#" class="link          "> 
<span><!--     --><img src="/style/i/fav_grey.png" alt="" class="m"> <!--   --><span class="m">В закладки</span><!--   --></span>  
</a>       

</td>    </tr> </tbody></table>    
</div>
<?
}
}
}
?>
<div class="tabs_block oh">    
<div class="tab_item left tab_active black">  Профиль  </div>   
<a href="#" class="tab_item left">  Активность  </a>   
</div>
<div class="wrapper">

<a href="/comm/info/?id=<?= $comm['id']?>" class="link  darkblue  arrow    "> 
<span>        <img src="/style/i/soo/soo_info.png" alt="" class="m">      <span class="m">  О сообществе </span>          </span>  
</a>

<a href="/comm/users/?id=<?= $comm['id']?>" class="link  darkblue  arrow    "> 
<span>        <img src="/style/i/ico/friends.png" alt="" class="m">      <span class="m">  Участники </span>   <span class="m">(<?= $count?>)</span>       </span>  
</a>






</div>
<?








include_once H.'sys/inc/tfoot.php';

?>