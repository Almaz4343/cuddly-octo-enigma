<?
include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';

include_once H.'comm/config.php';

$comm = mysql_fetch_assoc(mysql_query("SELECT * FROM `comm` WHERE `id` = '".intval($_GET['id'])."' LIMIT 1"));


if(!$comm){
	$_SESSION['err'] = 'Ошибка!';
	header("Location: /comm/?");
	exit;
}

if (mysql_result(mysql_query("SELECT COUNT(*) FROM `comm_users` WHERE `id_comm` = '$comm[id]' AND `activate` = '1' AND `invite` = '0'"),0)==0){
	$comm['id_user'] = 0;
}

// Создатель
$ank = get_user($comm['id_user']);

$post = mysql_fetch_assoc(mysql_query("SELECT * FROM `comm_users` WHERE `id_comm` = '$comm[id]' AND `activate` = '1' AND `invite` = '0' AND `id_user` = '".intval($_GET['user'])."' LIMIT 1"));
$as = $post['access'];
$ank2 = get_user($post['id_user']);


if(isset($_POST['cfms']))
{
$ank2 = get_user($post['id_user']);

if (isset($_POST['access']) && ($_POST['access'] == 0)){
mysql_query("UPDATE `comm_users` SET `access` = 'user' WHERE `id_user` = '$ank2[id]'");
if($post['access'] != user)
$_SESSION['message'] = 'Пользователь '.$ank2['nick'].' снят с дожности.';
else
$_SESSION['message'] = null;
}
if (isset($_POST['access']) && ($_POST['access'] == 1)){
mysql_query("UPDATE `comm_users` SET `access` = 'mod' WHERE `id_user` = '$ank2[id]'");
$_SESSION['message'] = 'Пользователь '.$ank2['nick'].' повышен до модератора.';
}
if (isset($_POST['access']) && ($_POST['access'] == 2)){
mysql_query("UPDATE `comm_users` SET `access` = 'adm' WHERE `id_user` = '$ank2[id]'");
}

if (isset($_POST['access']) && ($_POST['access'] == 3)){
if(mysql_result(mysql_query("SELECT COUNT(*) FROM `comm` WHERE `id_user` = '$ank2[id]'"),0) > 0)
{
$_SESSION['err'] = 'Даный пользователь имеет уже сообщество!'; 
header("Location: /comm/user_settings/?id=$comm[id]&user=$ank2[id]");
exit;
}
else{
mysql_query("UPDATE `comm_users` SET `access` = 'creator' WHERE `id_user` = '$ank2[id]'");
}
}

/*
$post['access'] = htmlspecialchars($_POST['access']);
// Если создака
if($post['access'] == 'creator')
{
$ank2 = get_user($post['id_user']);
if(mysql_result(mysql_query("SELECT COUNT(*) FROM `comm` WHERE `id_user` = '$ank2[id]'"),0) > 0)
{
$_SESSION['err'] = 'Даный пользователь имеет уже сообщество!'; 
header("Location: /comm/user_settings/?id=$comm[id]&user=$ank2[id]");
exit;
}
$new_time = time()+10800;
if(mysql_result(mysql_query("SELECT COUNT(*) FROM `comm_readmin` WHERE `id_comm` = '$comm[id]' LIMIT 1"),0) == 0)
{
mysql_query("INSERT INTO `comm_readmin` (`id_comm`, `id_user`, `time`) values ('$comm[id]', '$ank2[id]', '$new_time')");
//mysql_query("INSERT INTO `mail` (`id_user`, `id_kont`, `msg`, `time`) VALUES ('0', '$ank2[id]', '$user[nick] предлогает стать создателем сообщества [url=/comm/show/?id=$comm[id]]".text($comm['name'])."[/url]. [br]Вы принимаете предложение? [url=/comm/?act=readmin&id=$comm[id]&yes]Да[/url] | [url=/comm/?act=readmin&id=$comm[id]&no]Нет[/url]', '$time')");
$_SESSION['message'] = "Пользователю $ank2[nick] отправлено предложение стать создателем сообщества. Предложение действительно в течении 3-х часов!";
}
else $err[]="Вы уже отправили предложение ранее. Дождитесь пока ваше предложение рассмотрят.";
}
else{

if($as!=$post['access'])
{
if ($as == 'mod')$las = 'модератора';else $las = 'администратора';
mysql_query("INSERT INTO `comm_journal` SET `id_comm` = '$comm[id]', `id_user` = '$ank2[id]', `id_ank` = '$user[id]', `type` = 'access', `time` = '$time', `access` = '$post[access]'");
//mysql_query("INSERT INTO `mail` (`id_user`, `id_kont`, `msg`, `time`) VALUES ('0', '".$ank2['id']."', '".$user['nick']." ".($post['access'] != 'user' ? "назначил Вас ".($post['access'] == 'mod' ? "модератором" : "администратором") : "снял Вас с должности ".$las."")." сообщества [url=/comm/show/?id=".$comm['id']."]".text($comm['name'])."[/url].', '".$time."')");
mysql_query("UPDATE `comm_users` SET `access` = '$post[access]' WHERE `id_user` = '$post[id]'");
}*/






header("Location: /comm/users/?id=$comm[id]");
exit;

}

$set['title'] = 'Права участника : ' . text($comm['name']). ' : Сообщества';
include_once H.'sys/inc/thead.php';
title();


?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/comm/">Сообщества</a> </span>    <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/comm/show/?id=<?= $comm['id']?>"><?= text($comm['name'])?></a> </span> <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Права участника</span> </span>       </div>
<?

err();


if($ank['id'] == $user['id'] && isset($user) && mysql_result(mysql_query("SELECT COUNT(*) FROM `comm_users` WHERE `id_comm` = '$comm[id]' AND `activate` = '1' AND `invite` = '0' AND `id_user` = '".intval($_GET['user'])."'"),0)!=0)
{






if($post['access'] == 'creator')$Administrations = 'Создатель сообщества';
elseif($post['access'] == 'adm')$Administrations = 'Администратор сообщества';
elseif($post['access'] == 'mod')$Administrations = 'Модератор сообщества';
else$Administrations = null;

?>
<div class="js-row block bord-botm oh grey relative">        
<div class="left font0">   
<a href="/user/?id=<?= $ank2['id']?>" class="tdn">       
<span class="pr">   
<div class="inl_bl relative"> <?= ava40($ank2['id'])?> </div>     
</span>        
</a>  
</div>   
<div class="pre_content_wrap break-word"> <?= group($ank2['id'])?>   
<a href="/user/?id=<?= $ank2['id']?>" class="black full_link">   <b><?= unick($ank2['id'])?></b>  </a>   
<?= medal($ank2['id'])?> 
<?
/*             
<div>Комментариев на форуме: 1</div> 
*/
if($Administrations != NULL){
?>
<div class="green"><?= $Administrations?></div> 
<?
}
?>
<div>Последний визит: <?= vremja($ank2['date_last'])?></div>             
</div>     

</div>
<?

if($ank2['id'] != $ank['id']){
?>
<div class="wrapper"> 
<form action="/comm/user_settings/?id=<?= $comm['id']?>&user=<?= $ank2['id']?>" method="post"> 
<div class="block bord-botm">      
<label class="input-radio"> 
<input name="access" id="access0" value="0" <?= ($post['access'] == 'user' ? " checked='checked'" : NULL)?> type="radio"> Обычный участник </label>   <br> 
<label class="input-radio"> 
<input name="access" <?= ($post['access'] == 'mod' ? " checked='checked'" : NULL)?> id="access1" value="1" type="radio"> Модератор </label>   <br> 
<label class="input-radio"> 
<input name="access" <?= ($post['access'] == 'adm' ? " checked='checked'" : NULL)?> id="access2" value="2" type="radio"> Администратор </label>   <br> 
<label class="input-radio"> 
<input name="access" <?= ($post['access'] == 'creator' ? " checked='checked'" : NULL)?> id="access3" value="3" type="radio"> Создатель </label>       
</div>  
<table class="table__wrap"> <tbody><tr> 
<td class="table__cell" width="50%"> <!-- --><!-- --><!-- --><!-- --><!-- -->
<button name="cfms" value="Сохранить" class="  link  blue full is_final    " id="cfms">
<!--   --><img src="//c.spac.me/i/ok_blue.png" alt="" class="m"> <!--   --><span class="m"> Сохранить</span><!-- -->
</button><!-- --><!-- --> 
</td> 
<td class="table__cell table__cell_last" width="50%">     
<a href="/comm/users/?id=<?= $comm['id']?>" class="link -full          "> <span>Отменить</span>  </a>    
</td> 
</tr> </tbody></table> 
</form> 
</div>
<?
}



?>
<a href="/comm/users/?id=<?= $comm['id']?>" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?
}
else{
$_SESSION['err'] = 'Позьзователь не состоит в сообществе!'; 
header("Location: /comm/users/?id=$comm[id]");
exit;
}

include_once H.'sys/inc/tfoot.php';

?>