<?
include_once $_SERVER['DOCUMENT_ROOT'] . '/sys/inc/home.php';
include_once H.'sys/inc/start.php';
include_once H.'sys/inc/compress.php';
include_once H.'sys/inc/sess.php';
include_once H.'sys/inc/settings.php';
include_once H.'sys/inc/db_connect.php';
include_once H.'sys/inc/ipua.php';
include_once H.'sys/inc/fnc.php';
include_once H.'sys/inc/user.php';

$comm = mysql_fetch_assoc(mysql_query("SELECT * FROM `comm` WHERE `id` = '".intval($_GET['id'])."' LIMIT 1"));
$cat = mysql_fetch_assoc(mysql_query("SELECT * FROM `comm_cat` WHERE `id` = '".$comm['id_cat']."' LIMIT 1"));

if(!$comm){
	$_SESSION['err'] = 'Ошибка! Такого сообщества нет.';
	header("Location: /comm/cat/?");
	exit;
}

// Создатель
$ank_sozd = get_user($comm['id_user']);

if(isset($user) && $ank_sozd['id'] == $user['id'] || $user['level'] >= 3){


if(isset($_POST['cfms']) && isset($_POST['description']))
{
$description = $_POST['description'];

if(strlen2($description) > 250)$err[]="Описание должно быть больше 500 символов.";

$description = my_esc($description);

if (!isset($err)){
	mysql_query("UPDATE `comm` SET `opis` = '$description' WHERE `id` = '$comm[id]' LIMIT 1");
	$_SESSION['message'] = 'Описание сообщества сохранено.';
	header("Location:/comm/show/?id=$comm[id]");
	exit;
}

}

$set['title'] = 'Описание : ' . text($comm['name']) . ' : Сообщества';
include_once H.'sys/inc/thead.php';
title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/comm/">Сообщества</a> </span>  <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/comm/view/?id=<?= $comm['id']?>"><?= text($comm['name'])?></a> </span>   <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Описание</span> </span>       </div>
<?

err();


?>
<form action="/comm/description/?id=<?= $comm['id']?>" method="post">
<div class="wrapper"> 
<div class="title black"> Редактирование описания </div> 
<div class="bord-botm">   <div class="block  js-toolbar_wrap">  <div class="text-input__wrap"> 
<div class="cl" style="margin-bottom: 5px;"> <div class="relative">  <div class="input-txt_wrapper"> 
<textarea class="input-txt" tabindex="1" name="description" rows="5" id="textarea" data-maxlength="250" data-toolbar="{disable:{&quot;bgColor&quot;:1,&quot;smiles&quot;:1}}" cols="17"><?=  text($comm['opis'])?></textarea>
</div> </div> </div>    
</div> </div>             </div> 
<table class="table__wrap"> <tbody><tr> 
<td class="table__cell" width="50%"> <!-- --><!-- --><!-- --><!-- --><!-- -->
<button name="cfms" value="Сохранить" class="  link  blue full is_final    " id="cfms"><!--   --><img src="//c.spac.me/i/ok_blue.png" alt="" class="m"> <!--   --><span class="m"> Сохранить</span><!-- -->
</button><!-- --><!-- --> </td> 
<td class="table__cell table__cell_last" width="50%">     <a href="/comm/show/?id=<?= $comm['id']?>" class="link          "> <span>Отменить</span>  </a>    </td> 
</tr> </tbody></table> 
</div>
</form>
<?





?>
<a href="/comm/show/?id=<?= $comm['id']?>" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?

include_once H.'sys/inc/tfoot.php';
}
else{
	$_SESSION['err'] = 'Ошибка!';
	header("Location: /comm/?");
	exit;
}
?>