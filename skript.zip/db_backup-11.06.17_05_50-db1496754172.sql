DROP TABLE IF EXISTS `adm_chat`;

CREATE TABLE `adm_chat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL DEFAULT '0',
  `time` int(11) NOT NULL,
  `msg` varchar(1024) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `time` (`time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `admin_log`;

CREATE TABLE `admin_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_user` int(10) unsigned NOT NULL,
  `time` int(10) unsigned NOT NULL,
  `mod` int(11) NOT NULL,
  `act` int(11) NOT NULL,
  `opis` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `mod` (`mod`),
  KEY `act` (`act`)
) ENGINE=MyISAM AUTO_INCREMENT=264 DEFAULT CHARSET=utf8;

INSERT INTO admin_log VALUES("1","1","1483825293","1","1","Изменение системных настроек");
INSERT INTO admin_log VALUES("2","1","1484116616","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("3","1","1484383845","2","2","Выполнено 4 запрос(ов)");
INSERT INTO admin_log VALUES("4","1","1484546160","3","3","Бан пользователя \'[url=/adm_panel/ban.php?id=2]Тестер[/url]\' до 09:06:00 по причине \'111111111111111111111\'");
INSERT INTO admin_log VALUES("5","1","1484581571","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("6","1","1484599965","2","2","Выполнено 4 запрос(ов)");
INSERT INTO admin_log VALUES("7","1","1484629767","3","3","Бан пользователя \'[url=/amd_panel/ban.php?id=1]Tw1nGo[/url]\' (id#1) до 09:09:27 по причине \'Обнаружен мат: …и делал было [наёбом]\'");
INSERT INTO admin_log VALUES("8","1","1484631969","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("9","1","1484653962","3","4","Пользователю \'Тестер\' установлен новый пароль");
INSERT INTO admin_log VALUES("10","1","1484653962","3","5","Редактирование профиля пользователя \'Тестер\' (id#2)");
INSERT INTO admin_log VALUES("11","1","1484654237","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("12","1","1484654314","2","2","Выполнено 2 запрос(ов)");
INSERT INTO admin_log VALUES("13","1","1484654496","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("14","1","1484679167","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("15","1","1484732975","2","2","Выполнено 3 запрос(ов)");
INSERT INTO admin_log VALUES("16","1","1484802944","3","5","Редактирование профиля пользователя \'Тестер\' (id#2)");
INSERT INTO admin_log VALUES("17","1","1484814605","2","2","Выполнено 9 запрос(ов)");
INSERT INTO admin_log VALUES("18","1","1484815321","2","2","Выполнено 2 запрос(ов)");
INSERT INTO admin_log VALUES("19","1","1484818947","4","6","Создание раздела \'Мусор\' в подфоруме \'Беспредел\'");
INSERT INTO admin_log VALUES("20","1","1485068945","2","2","Выполнено 2 запрос(ов)");
INSERT INTO admin_log VALUES("21","1","1485069512","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("22","1","1485416357","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("23","1","1485601548","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("24","1","1485601623","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("25","1","1493289468","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("26","1","1493290718","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("27","1","1493290743","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("28","1","1493934491","5","7","Удаление сообщения от Bro");
INSERT INTO admin_log VALUES("29","1","1494104118","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("30","1","1494104188","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("31","1","1494165237","6","8","Удаление комментария к фото [url=/id1]Tw1nGo[/url]");
INSERT INTO admin_log VALUES("32","1","1494165242","6","8","Удаление комментария к фото [url=/id1]Tw1nGo[/url]");
INSERT INTO admin_log VALUES("33","1","1494228081","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("34","1","1494229047","2","2","Выполнено 2 запрос(ов)");
INSERT INTO admin_log VALUES("35","1","1494229154","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("36","1","1494238389","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("37","1","1494238616","2","2","Выполнено 5 запрос(ов)");
INSERT INTO admin_log VALUES("38","1","1494239594","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("39","1","1494239631","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("40","1","1494252091","2","2","Выполнено 6 запрос(ов)");
INSERT INTO admin_log VALUES("41","1","1494252452","2","2","Выполнено 3 запрос(ов)");
INSERT INTO admin_log VALUES("42","1","1494330514","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("43","1","1494423868","1","1","Изменение системных настроек");
INSERT INTO admin_log VALUES("44","1","1494423874","1","1","Изменение системных настроек");
INSERT INTO admin_log VALUES("45","1","1494442726","6","8","Переименование фото пользователя \'[url=/id2]Тестер[/url]\'");
INSERT INTO admin_log VALUES("46","1","1494674342","7","9","Добавлена комната \'Беспредел\', описание: В этой комнате разрешено всё, кроме нарушения законов РФ.\\r\\nМодераторы здесь абсолютно бессильны и лишены возможности банить.\\r\\nРекомендуем не обижаться на оскорбления и мат, которые вы можете услышать в этой комнате ;)\\r\\nМногие приходят в эту комнату просто ради эмоциональной разрядки.\\r\\nЛюдям со слабыми нервами и тонкой душевной организацией заходить в \\\\\\\"Беспредел\\\\\\\" настоятельно не рекомендуется.");
INSERT INTO admin_log VALUES("47","1","1494674366","7","9","Изменение комнаты Беспредел");
INSERT INTO admin_log VALUES("48","1","1494674900","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("49","1","1494676081","4","6","Переименование раздела \'Мусор\' в \'Тестовый\'");
INSERT INTO admin_log VALUES("50","1","1494676089","4","6","Переименование раздела \'Тестовый\' в \'Тестовый\'");
INSERT INTO admin_log VALUES("51","1","1494742942","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("52","1","1494758179","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("53","1","1494759022","4","6","Переименование раздела \'Тестовый\' в \'Тестовый\'");
INSERT INTO admin_log VALUES("54","1","1494759123","4","6","Переименование раздела \'Тестовый\' в \'Тестовый\'");
INSERT INTO admin_log VALUES("55","1","1494759146","4","6","Создание раздела \'11111\' в подфоруме \'Беспредел\'");
INSERT INTO admin_log VALUES("56","1","1494759160","4","6","Создание раздела \'44g5re\' в подфоруме \'Беспредел\'");
INSERT INTO admin_log VALUES("57","1","1494760218","4","10","Подфорум \'Новости форума\' переименован в \'Все о Xmyx.Ru\'");
INSERT INTO admin_log VALUES("58","1","1494760218","4","10","Изменено описание подфорума \'Все о Xmyx.Ru\'");
INSERT INTO admin_log VALUES("59","1","1494760266","4","10","Подфорум \'Общение и знакомство\' переименован в \'Игры\'");
INSERT INTO admin_log VALUES("60","1","1494760266","4","10","Изменено описание подфорума \'Игры\'");
INSERT INTO admin_log VALUES("61","1","1494760288","4","10","Подфорум \'Тематические форумы\' переименован в \'Моб. связь и Интернет\'");
INSERT INTO admin_log VALUES("62","1","1494760288","4","10","Изменено описание подфорума \'Моб. связь и Интернет\'");
INSERT INTO admin_log VALUES("63","1","1494760310","4","10","Подфорум \'Секс и отношения\' переименован в \'Android\'");
INSERT INTO admin_log VALUES("64","1","1494760310","4","10","Изменено описание подфорума \'Android\'");
INSERT INTO admin_log VALUES("65","1","1494760330","4","10","Подфорум \'Досуг и увлечения\' переименован в \'iPhone и др платформы\'");
INSERT INTO admin_log VALUES("66","1","1494760330","4","10","Изменено описание подфорума \'iPhone и др платформы\'");
INSERT INTO admin_log VALUES("67","1","1494760348","4","10","Подфорум \'Музыка\' переименован в \'Компьютеры и др. техника\'");
INSERT INTO admin_log VALUES("68","1","1494760348","4","10","Изменено описание подфорума \'Компьютеры и др. техника\'");
INSERT INTO admin_log VALUES("69","1","1494760370","4","10","Подфорум \'Все о спорте\' переименован в \'Спорт\'");
INSERT INTO admin_log VALUES("70","1","1494760370","4","10","Изменено описание подфорума \'Спорт\'");
INSERT INTO admin_log VALUES("71","1","1494760390","4","10","Подфорум \'Мобильные телефоны\' переименован в \'Отношения\'");
INSERT INTO admin_log VALUES("72","1","1494760390","4","10","Изменено описание подфорума \'Отношения\'");
INSERT INTO admin_log VALUES("73","1","1494760410","4","10","Подфорум \'Все для телефона\' переименован в \'Разные темы\'");
INSERT INTO admin_log VALUES("74","1","1494760410","4","10","Изменено описание подфорума \'Разные темы\'");
INSERT INTO admin_log VALUES("75","1","1494760429","4","10","Подфорум \'Мобильная связь\' переименован в \'Symbian смартфоны\'");
INSERT INTO admin_log VALUES("76","1","1494760429","4","10","Изменено описание подфорума \'Symbian смартфоны\'");
INSERT INTO admin_log VALUES("77","1","1494760451","4","10","Подфорум \'Symbian смартфоны\' переименован в \'Моб. телефоны\'");
INSERT INTO admin_log VALUES("78","1","1494760451","4","10","Изменено описание подфорума \'Моб. телефоны\'");
INSERT INTO admin_log VALUES("79","1","1494760481","4","10","Подфорум \'Компьютеры\' переименован в \'Моб. загрузки\'");
INSERT INTO admin_log VALUES("80","1","1494760481","4","10","Изменено описание подфорума \'Моб. загрузки\'");
INSERT INTO admin_log VALUES("81","1","1494760503","4","10","Подфорум \'Беспредел\' переименован в \'Увлечения\'");
INSERT INTO admin_log VALUES("82","1","1494760503","4","10","Изменено описание подфорума \'Увлечения\'");
INSERT INTO admin_log VALUES("83","1","1494760521","4","10","Создание подфорума \'Субкультуры\'");
INSERT INTO admin_log VALUES("84","1","1494760537","4","10","Создание подфорума \'Политика\'");
INSERT INTO admin_log VALUES("85","1","1494760552","4","10","Создание подфорума \'Песочница, Архив\'");
INSERT INTO admin_log VALUES("86","1","1494760592","4","6","Создание раздела \'Помощь новичкам\' в подфоруме \'Все о Xmyx.Ru\'");
INSERT INTO admin_log VALUES("87","1","1494760604","4","6","Создание раздела \'FAQ\' в подфоруме \'Все о Xmyx.Ru\'");
INSERT INTO admin_log VALUES("88","1","1494760626","4","6","Создание раздела \'Объявления. Обсуждения\' в подфоруме \'Все о Xmyx.Ru\'");
INSERT INTO admin_log VALUES("89","1","1494760637","4","6","Создание раздела \'Правила сайта. Информация.\' в подфоруме \'Все о Xmyx.Ru\'");
INSERT INTO admin_log VALUES("90","1","1494760717","4","6","Создание раздела \'Другие игры\' в подфоруме \'Игры\'");
INSERT INTO admin_log VALUES("91","1","1494760721","4","6","Создание раздела \'Форумные игры и виктoрины\' в подфоруме \'Игры\'");
INSERT INTO admin_log VALUES("92","1","1494760726","4","6","Создание раздела \'Java-игры\' в подфоруме \'Игры\'");
INSERT INTO admin_log VALUES("93","1","1494760733","4","6","Создание раздела \'Windows Phone - Игры\' в подфоруме \'Игры\'");
INSERT INTO admin_log VALUES("94","1","1494760738","4","6","Создание раздела \'Windows Mobile - Игры\' в подфоруме \'Игры\'");
INSERT INTO admin_log VALUES("95","1","1494760744","4","6","Создание раздела \'Игровое видео и стримы\' в подфоруме \'Игры\'");
INSERT INTO admin_log VALUES("96","1","1494760750","4","6","Создание раздела \'DotA 2\' в подфоруме \'Игры\'");
INSERT INTO admin_log VALUES("97","1","1494760756","4","6","Создание раздела \'GTA\' в подфоруме \'Игры\'");
INSERT INTO admin_log VALUES("98","1","1494760763","4","6","Создание раздела \'Minecraft\' в подфоруме \'Игры\'");
INSERT INTO admin_log VALUES("99","1","1494760772","4","6","Создание раздела \'World of Tanks\' в подфоруме \'Игры\'");
INSERT INTO admin_log VALUES("100","1","1494760783","4","6","Создание раздела \'World of Warcraft (WoW)\' в подфоруме \'Игры\'");
INSERT INTO admin_log VALUES("101","1","1494760788","4","6","Создание раздела \'S.T.A.L.K.E.R.\' в подфоруме \'Игры\'");
INSERT INTO admin_log VALUES("102","1","1494760794","4","6","Создание раздела \'Counter-Strike\' в подфоруме \'Игры\'");
INSERT INTO admin_log VALUES("103","1","1494760802","4","6","Создание раздела \'Symbian игры\' в подфоруме \'Игры\'");
INSERT INTO admin_log VALUES("104","1","1494760813","4","6","Создание раздела \'iPhone игры\' в подфоруме \'Игры\'");
INSERT INTO admin_log VALUES("105","1","1494760824","4","6","Создание раздела \'Sony PlayStation\' в подфоруме \'Игры\'");
INSERT INTO admin_log VALUES("106","1","1494760831","4","6","Создание раздела \'Android Игры\' в подфоруме \'Игры\'");
INSERT INTO admin_log VALUES("107","1","1494760837","4","6","Создание раздела \'PC игры\' в подфоруме \'Игры\'");
INSERT INTO admin_log VALUES("108","1","1494760844","4","6","Создание раздела \'Онлайн-игры\' в подфоруме \'Игры\'");
INSERT INTO admin_log VALUES("109","1","1494760850","4","6","Создание раздела \'Новости игрового мира\' в подфоруме \'Игры\'");
INSERT INTO admin_log VALUES("110","1","1494760920","4","6","Создание раздела \'Общие вопросы\' в подфоруме \'Моб. связь и Интернет\'");
INSERT INTO admin_log VALUES("111","1","1494760926","4","6","Создание раздела \'Другие операторы\' в подфоруме \'Моб. связь и Интернет\'");
INSERT INTO admin_log VALUES("112","1","1494760930","4","6","Создание раздела \'Tele2\' в подфоруме \'Моб. связь и Интернет\'");
INSERT INTO admin_log VALUES("113","1","1494760935","4","6","Создание раздела \'Мегафон\' в подфоруме \'Моб. связь и Интернет\'");
INSERT INTO admin_log VALUES("114","1","1494760940","4","6","Создание раздела \'Билайн\' в подфоруме \'Моб. связь и Интернет\'");
INSERT INTO admin_log VALUES("115","1","1494760945","4","6","Создание раздела \'МТС\' в подфоруме \'Моб. связь и Интернет\'");
INSERT INTO admin_log VALUES("116","1","1494760951","4","6","Создание раздела \'SMS/MMS\' в подфоруме \'Моб. связь и Интернет\'");
INSERT INTO admin_log VALUES("117","1","1494760956","4","6","Создание раздела \'WAP, GPRS, EDGE, 3G, Wi-Fi\' в подфоруме \'Моб. связь и Интернет\'");
INSERT INTO admin_log VALUES("118","1","1494760962","4","6","Создание раздела \'E-mail\' в подфоруме \'Моб. связь и Интернет\'");
INSERT INTO admin_log VALUES("119","1","1494760969","4","6","Создание раздела \'Opera Mini и др. браузеры\' в подфоруме \'Моб. связь и Интернет\'");
INSERT INTO admin_log VALUES("120","1","1494760974","4","6","Создание раздела \'ICQ, Jimm и др мобильн. клиенты\' в подфоруме \'Моб. связь и Интернет\'");
INSERT INTO admin_log VALUES("121","1","1494760993","4","6","Создание раздела \'Программирование\' в подфоруме \'Android\'");
INSERT INTO admin_log VALUES("122","1","1494760997","4","6","Создание раздела \'Root и прошивки\' в подфоруме \'Android\'");
INSERT INTO admin_log VALUES("123","1","1494761002","4","6","Создание раздела \'Украшательства\' в подфоруме \'Android\'");
INSERT INTO admin_log VALUES("124","1","1494761008","4","6","Создание раздела \'Статьи\' в подфоруме \'Android\'");
INSERT INTO admin_log VALUES("125","1","1494761014","4","6","Создание раздела \'Программы\' в подфоруме \'Android\'");
INSERT INTO admin_log VALUES("126","1","1494761020","4","6","Создание раздела \'Устройства\' в подфоруме \'Android\'");
INSERT INTO admin_log VALUES("127","1","1494761025","4","6","Создание раздела \'Помощь и общие вопросы\' в подфоруме \'Android\'");
INSERT INTO admin_log VALUES("128","1","1494761054","4","6","Создание раздела \'Прочие платформы\' в подфоруме \'iPhone и др платформы\'");
INSERT INTO admin_log VALUES("129","1","1494761059","4","6","Создание раздела \'iPhone программы\' в подфоруме \'iPhone и др платформы\'");
INSERT INTO admin_log VALUES("130","1","1494761064","4","6","Создание раздела \'iPhone статьи\' в подфоруме \'iPhone и др платформы\'");
INSERT INTO admin_log VALUES("131","1","1494761069","4","6","Создание раздела \'iPhone общие вопросы\' в подфоруме \'iPhone и др платформы\'");
INSERT INTO admin_log VALUES("132","1","1494761089","4","6","Создание раздела \'Прочие вопросы\' в подфоруме \'Компьютеры и др. техника\'");
INSERT INTO admin_log VALUES("133","1","1494761095","4","6","Создание раздела \'Прочая техника\' в подфоруме \'Компьютеры и др. техника\'");
INSERT INTO admin_log VALUES("134","1","1494761100","4","6","Создание раздела \'Фото и видеокамеры\' в подфоруме \'Компьютеры и др. техника\'");
INSERT INTO admin_log VALUES("135","1","1494761105","4","6","Создание раздела \'Аудио/видео техника\' в подфоруме \'Компьютеры и др. техника\'");
INSERT INTO admin_log VALUES("136","1","1494761121","4","6","Создание раздела \'Ноутбуки\' в подфоруме \'Компьютеры и др. техника\'");
INSERT INTO admin_log VALUES("137","1","1494761126","4","6","Создание раздела \'Игровые консоли\' в подфоруме \'Компьютеры и др. техника\'");
INSERT INTO admin_log VALUES("138","1","1494761132","4","6","Создание раздела \'Создание сайтов и программирован\' в подфоруме \'Компьютеры и др. техника\'");
INSERT INTO admin_log VALUES("139","1","1494761143","4","6","Создание раздела \'ПК + Телефон\' в подфоруме \'Компьютеры и др. техника\'");
INSERT INTO admin_log VALUES("140","1","1494761151","4","6","Создание раздела \'Операционные системы\' в подфоруме \'Компьютеры и др. техника\'");
INSERT INTO admin_log VALUES("141","1","1494761158","4","6","Создание раздела \'Интернет\' в подфоруме \'Компьютеры и др. техника\'");
INSERT INTO admin_log VALUES("142","1","1494761164","4","6","Создание раздела \'Железо\' в подфоруме \'Компьютеры и др. техника\'");
INSERT INTO admin_log VALUES("143","1","1494761168","4","6","Создание раздела \'Софт\' в подфоруме \'Компьютеры и др. техника\'");
INSERT INTO admin_log VALUES("144","1","1494761196","4","6","Создание раздела \'Спортивные тотализаторы\' в подфоруме \'Спорт\'");
INSERT INTO admin_log VALUES("145","1","1494761208","4","6","Создание раздела \'Здоровый образ жизни\' в подфоруме \'Спорт\'");
INSERT INTO admin_log VALUES("146","1","1494761218","4","6","Создание раздела \'Другие виды спорта\' в подфоруме \'Спорт\'");
INSERT INTO admin_log VALUES("147","1","1494761222","4","6","Создание раздела \'Боевые искусства\' в подфоруме \'Спорт\'");
INSERT INTO admin_log VALUES("148","1","1494761228","4","6","Создание раздела \'Бодибилдинг\' в подфоруме \'Спорт\'");
INSERT INTO admin_log VALUES("149","1","1494761233","4","6","Создание раздела \'Авто/Вело/Мотоспорт\' в подфоруме \'Спорт\'");
INSERT INTO admin_log VALUES("150","1","1494761239","4","6","Создание раздела \'Хоккей\' в подфоруме \'Спорт\'");
INSERT INTO admin_log VALUES("151","1","1494761245","4","6","Создание раздела \'Футбол\' в подфоруме \'Спорт\'");
INSERT INTO admin_log VALUES("152","1","1494761250","4","6","Создание раздела \'Спортивные новости\' в подфоруме \'Спорт\'");
INSERT INTO admin_log VALUES("153","1","1494761267","4","6","Создание раздела \'Родители и дети\' в подфоруме \'Отношения\'");
INSERT INTO admin_log VALUES("154","1","1494761274","4","6","Создание раздела \'Дружба\' в подфоруме \'Отношения\'");
INSERT INTO admin_log VALUES("155","1","1494761278","4","6","Создание раздела \'Семья\' в подфоруме \'Отношения\'");
INSERT INTO admin_log VALUES("156","1","1494761285","4","6","Создание раздела \'Секс\' в подфоруме \'Отношения\'");
INSERT INTO admin_log VALUES("157","1","1494761290","4","6","Создание раздела \'Любовь\' в подфоруме \'Отношения\'");
INSERT INTO admin_log VALUES("158","1","1494761310","4","6","Создание раздела \'Прочие темы\' в подфоруме \'Разные темы\'");
INSERT INTO admin_log VALUES("159","1","1494761321","4","6","Создание раздела \'Lifehack\' в подфоруме \'Разные темы\'");
INSERT INTO admin_log VALUES("160","1","1494761328","4","6","Создание раздела \'Криминал и право\' в подфоруме \'Разные темы\'");
INSERT INTO admin_log VALUES("161","1","1494761332","4","6","Создание раздела \'Кулинария\' в подфоруме \'Разные темы\'");
INSERT INTO admin_log VALUES("162","1","1494761337","4","6","Создание раздела \'Юмор\' в подфоруме \'Разные темы\'");
INSERT INTO admin_log VALUES("163","1","1494761343","4","6","Создание раздела \'Туризм и путешествия\' в подфоруме \'Разные темы\'");
INSERT INTO admin_log VALUES("164","1","1494761348","4","6","Создание раздела \'Бизнес/Финансы\' в подфоруме \'Разные темы\'");
INSERT INTO admin_log VALUES("165","1","1494761354","4","6","Создание раздела \'Медицина/ Здоровье\' в подфоруме \'Разные темы\'");
INSERT INTO admin_log VALUES("166","1","1494761360","4","6","Создание раздела \'Армия/Служба\' в подфоруме \'Разные темы\'");
INSERT INTO admin_log VALUES("167","1","1494761366","4","6","Создание раздела \'Работа/Учеба\' в подфоруме \'Разные темы\'");
INSERT INTO admin_log VALUES("168","1","1494761376","4","6","Создание раздела \'За жизнь!\' в подфоруме \'Разные темы\'");
INSERT INTO admin_log VALUES("169","1","1494761398","4","6","Создание раздела \'Общие вопросы\' в подфоруме \'Моб. телефоны\'");
INSERT INTO admin_log VALUES("170","1","1494761404","4","6","Создание раздела \'Другие производители\' в подфоруме \'Моб. телефоны\'");
INSERT INTO admin_log VALUES("171","1","1494761409","4","6","Создание раздела \'LG\' в подфоруме \'Моб. телефоны\'");
INSERT INTO admin_log VALUES("172","1","1494761413","4","6","Создание раздела \'BenQ-Siemens\' в подфоруме \'Моб. телефоны\'");
INSERT INTO admin_log VALUES("173","1","1494763179","4","6","Создание раздела \'Samsung\' в подфоруме \'Моб. телефоны\'");
INSERT INTO admin_log VALUES("174","1","1494763187","4","6","Создание раздела \'Motorola\' в подфоруме \'Моб. телефоны\'");
INSERT INTO admin_log VALUES("175","1","1494763191","4","6","Создание раздела \'Sony Ericsson\' в подфоруме \'Моб. телефоны\'");
INSERT INTO admin_log VALUES("176","1","1494763196","4","6","Создание раздела \'Nokia\' в подфоруме \'Моб. телефоны\'");
INSERT INTO admin_log VALUES("177","1","1494763258","4","6","Создание раздела \'Общие вопросы\' в подфоруме \'Моб. загрузки\'");
INSERT INTO admin_log VALUES("178","1","1494763262","4","6","Создание раздела \'Видео\' в подфоруме \'Моб. загрузки\'");
INSERT INTO admin_log VALUES("179","1","1494763269","4","6","Создание раздела \'Мелодии и звуки\' в подфоруме \'Моб. загрузки\'");
INSERT INTO admin_log VALUES("180","1","1494763273","4","6","Создание раздела \'Картинки и темы\' в подфоруме \'Моб. загрузки\'");
INSERT INTO admin_log VALUES("181","1","1494763278","4","6","Создание раздела \'Java-программы\' в подфоруме \'Моб. загрузки\'");
INSERT INTO admin_log VALUES("182","1","1494763316","4","6","Переименование раздела \'Тестовый\' в \'Хобби\'");
INSERT INTO admin_log VALUES("183","1","1494763336","4","6","Переименование раздела \'11111\' в \'Охота/Рыбалка\'");
INSERT INTO admin_log VALUES("184","1","1494763347","4","6","Переименование раздела \'44g5re\' в \'Непознанное\'");
INSERT INTO admin_log VALUES("185","1","1494763360","4","6","Создание раздела \'Наука\' в подфоруме \'Увлечения\'");
INSERT INTO admin_log VALUES("186","1","1494763366","4","6","Создание раздела \'Философия и Религия\' в подфоруме \'Увлечения\'");
INSERT INTO admin_log VALUES("187","1","1494763371","4","6","Создание раздела \'Культура/Искусство\' в подфоруме \'Увлечения\'");
INSERT INTO admin_log VALUES("188","1","1494763377","4","6","Создание раздела \'Животные и Природа\' в подфоруме \'Увлечения\'");
INSERT INTO admin_log VALUES("189","1","1494763382","4","6","Создание раздела \'История\' в подфоруме \'Увлечения\'");
INSERT INTO admin_log VALUES("190","1","1494763389","4","6","Создание раздела \'Литература\' в подфоруме \'Увлечения\'");
INSERT INTO admin_log VALUES("191","1","1494763395","4","6","Создание раздела \'Авто/Мото\' в подфоруме \'Увлечения\'");
INSERT INTO admin_log VALUES("192","1","1494763400","4","6","Создание раздела \'Кино и ТВ\' в подфоруме \'Увлечения\'");
INSERT INTO admin_log VALUES("193","1","1494763406","4","6","Создание раздела \'Музыка\' в подфоруме \'Увлечения\'");
INSERT INTO admin_log VALUES("194","1","1494763450","4","6","Создание раздела \'Другие субкультуры\' в подфоруме \'Субкультуры\'");
INSERT INTO admin_log VALUES("195","1","1494763456","4","6","Создание раздела \'Эмо\' в подфоруме \'Субкультуры\'");
INSERT INTO admin_log VALUES("196","1","1494763462","4","6","Создание раздела \'Хардкор\' в подфоруме \'Субкультуры\'");
INSERT INTO admin_log VALUES("197","1","1494763467","4","6","Создание раздела \'РЭП\' в подфоруме \'Субкультуры\'");
INSERT INTO admin_log VALUES("198","1","1494763472","4","6","Создание раздела \'РОК\' в подфоруме \'Субкультуры\'");
INSERT INTO admin_log VALUES("199","1","1494763478","4","6","Создание раздела \'Панк\' в подфоруме \'Субкультуры\'");
INSERT INTO admin_log VALUES("200","1","1494763484","4","6","Создание раздела \'Метал\' в подфоруме \'Субкультуры\'");
INSERT INTO admin_log VALUES("201","1","1494763489","4","6","Создание раздела \'Клубная жизнь\' в подфоруме \'Субкультуры\'");
INSERT INTO admin_log VALUES("202","1","1494763494","4","6","Создание раздела \'Готика\' в подфоруме \'Субкультуры\'");
INSERT INTO admin_log VALUES("203","1","1494763499","4","6","Создание раздела \'Аниме\' в подфоруме \'Субкультуры\'");
INSERT INTO admin_log VALUES("204","1","1494763505","4","6","Создание раздела \'Альтернатива\' в подфоруме \'Субкультуры\'");
INSERT INTO admin_log VALUES("205","1","1494763527","4","6","Создание раздела \'Политика стран бывшего СССР\' в подфоруме \'Политика\'");
INSERT INTO admin_log VALUES("206","1","1494763538","4","6","Создание раздела \'Теории заговора\' в подфоруме \'Политика\'");
INSERT INTO admin_log VALUES("207","1","1494763548","4","6","Создание раздела \'Мировая политика\' в подфоруме \'Политика\'");
INSERT INTO admin_log VALUES("208","1","1494763558","4","6","Создание раздела \'Российско-Украинская полемика\' в подфоруме \'Политика\'");
INSERT INTO admin_log VALUES("209","1","1494763569","4","6","Создание раздела \'Украинская политика\' в подфоруме \'Политика\'");
INSERT INTO admin_log VALUES("210","1","1494763581","4","6","Создание раздела \'Политика РФ\' в подфоруме \'Политика\'");
INSERT INTO admin_log VALUES("211","1","1494763621","4","6","Создание раздела \'Архив тем\' в подфоруме \'Песочница, Архив\'");
INSERT INTO admin_log VALUES("212","1","1494763623","4","6","Создание раздела \'Песочница\' в подфоруме \'Песочница, Архив\'");
INSERT INTO admin_log VALUES("213","1","1494778741","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("214","1","1495092066","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("215","1","1495105461","2","2","Выполнено 2 запрос(ов)");
INSERT INTO admin_log VALUES("216","1","1495136838","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("217","1","1495136877","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("218","1","1495137001","2","2","Выполнено 2 запрос(ов)");
INSERT INTO admin_log VALUES("219","1","1495263538","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("220","1","1495272136","1","1","Изменение системных настроек");
INSERT INTO admin_log VALUES("221","1","1495272142","1","1","Изменение системных настроек");
INSERT INTO admin_log VALUES("222","1","1495273350","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("223","1","1495274553","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("224","1","1495274685","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("225","1","1495276670","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("226","1","1495290559","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("227","1","1495357941","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("228","1","1495359266","2","2","Выполнено 2 запрос(ов)");
INSERT INTO admin_log VALUES("229","1","1495360405","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("230","1","1495374406","3","3","Бан пользователя \'[url=/amd_panel/ban.php?id=1]Tw1nGo[/url]\' (id#1) до 17:46:46 по причине \'Обнаружен мат: а [бля]такой мод есть а…\'");
INSERT INTO admin_log VALUES("231","1","1495376517","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("232","1","1495376529","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("233","1","1495404507","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("234","1","1495449260","3","3","Бан пользователя \'[url=/adm_panel/ban.php?id=2]Тестер[/url]\' до 13:44:20 по причине \'............................\'");
INSERT INTO admin_log VALUES("235","1","1495449453","3","3","Бан пользователя \'[url=/adm_panel/ban.php?id=2]Тестер[/url]\' до 13:47:33 по причине \'hhhhhhhhhhhh\'");
INSERT INTO admin_log VALUES("236","1","1495449753","3","3","Удаление нарушения с пользователя \'[url=/amd_panel/ban.php?id=2]Тестер[/url]\'");
INSERT INTO admin_log VALUES("237","1","1495450194","3","3","Удаление нарушения с пользователя \'[url=/amd_panel/ban.php?id=2]Тестер[/url]\'");
INSERT INTO admin_log VALUES("238","1","1495450233","3","3","Бан пользователя \'[url=/adm_panel/ban.php?id=2]Тестер[/url]\' до 14:00:33 по причине \'....................................\'");
INSERT INTO admin_log VALUES("239","1","1495974515","2","2","Выполнено 2 запрос(ов)");
INSERT INTO admin_log VALUES("240","1","1495977402","2","2","Выполнено 2 запрос(ов)");
INSERT INTO admin_log VALUES("241","1","1495977424","2","2","Выполнено 2 запрос(ов)");
INSERT INTO admin_log VALUES("242","1","1495977438","2","2","Выполнено 2 запрос(ов)");
INSERT INTO admin_log VALUES("243","1","1496003719","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("244","1","1496047034","2","2","Выполнено 2 запрос(ов)");
INSERT INTO admin_log VALUES("245","1","1496051264","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("246","1","1496051629","2","2","Выполнено 2 запрос(ов)");
INSERT INTO admin_log VALUES("247","1","1496137096","2","2","Выполнено 2 запрос(ов)");
INSERT INTO admin_log VALUES("248","1","1496137139","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("249","1","1496137185","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("250","1","1496176436","4","10","Подфорум \'Все о Xmyx.Ru\' только для администрации");
INSERT INTO admin_log VALUES("251","1","1496393231","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("252","1","1496399594","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("253","1","1496414004","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("254","1","1496576798","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("255","1","1496576819","2","2","Выполнено 2 запрос(ов)");
INSERT INTO admin_log VALUES("256","1","1496579191","2","2","Выполнено 2 запрос(ов)");
INSERT INTO admin_log VALUES("257","1","1496655755","2","2","Выполнено 3 запрос(ов)");
INSERT INTO admin_log VALUES("258","1","1496655875","2","2","Выполнено 43 запрос(ов)");
INSERT INTO admin_log VALUES("259","1","1496656472","2","2","Выполнено 43 запрос(ов)");
INSERT INTO admin_log VALUES("260","1","1496663499","2","2","Выполнено 2 запрос(ов)");
INSERT INTO admin_log VALUES("261","1","1496729470","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("262","1","1496734456","2","2","Выполнено 1 запрос(ов)");
INSERT INTO admin_log VALUES("263","1","1496868943","2","2","Выполнено 1 запрос(ов)");



DROP TABLE IF EXISTS `admin_log_act`;

CREATE TABLE `admin_log_act` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_mod` int(11) NOT NULL,
  `name` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `act` (`name`),
  KEY `id_mod` (`id_mod`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

INSERT INTO admin_log_act VALUES("1","1","Система");
INSERT INTO admin_log_act VALUES("2","2","MySQL");
INSERT INTO admin_log_act VALUES("3","3","Бан");
INSERT INTO admin_log_act VALUES("4","3","Смена пароля");
INSERT INTO admin_log_act VALUES("5","3","Профиль");
INSERT INTO admin_log_act VALUES("6","4","Разделы");
INSERT INTO admin_log_act VALUES("7","5","Удаление сообщения");
INSERT INTO admin_log_act VALUES("8","6","Фотографии");
INSERT INTO admin_log_act VALUES("9","7","Параметры комнат");
INSERT INTO admin_log_act VALUES("10","4","Подфорумы");



DROP TABLE IF EXISTS `admin_log_mod`;

CREATE TABLE `admin_log_mod` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO admin_log_mod VALUES("1","Настройки");
INSERT INTO admin_log_mod VALUES("2","Админка");
INSERT INTO admin_log_mod VALUES("3","Пользователи");
INSERT INTO admin_log_mod VALUES("4","Форум");
INSERT INTO admin_log_mod VALUES("5","Гостевая");
INSERT INTO admin_log_mod VALUES("6","Фотогалерея");
INSERT INTO admin_log_mod VALUES("7","Чат");



DROP TABLE IF EXISTS `all_accesses`;

CREATE TABLE `all_accesses` (
  `type` varchar(32) NOT NULL,
  `name` varchar(64) NOT NULL,
  KEY `type` (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO all_accesses VALUES("adm_panel_show","Админка - доступ к разделам админки");
INSERT INTO all_accesses VALUES("loads_file_upload","Загрузки - выгрузка файлов");
INSERT INTO all_accesses VALUES("loads_dir_mesto","Загрузки - перемещение папок");
INSERT INTO all_accesses VALUES("loads_dir_delete","Загрузки - удаление папок");
INSERT INTO all_accesses VALUES("loads_dir_rename","Загрузки - переименование папок");
INSERT INTO all_accesses VALUES("loads_dir_create","Загрузки - создание папок");
INSERT INTO all_accesses VALUES("loads_file_edit","Загрузки - параметры файлов");
INSERT INTO all_accesses VALUES("loads_file_delete","Загрузки - удаление файлов");
INSERT INTO all_accesses VALUES("loads_unzip","Загрузки - Распаковка ZIP");
INSERT INTO all_accesses VALUES("lib_stat_zip","Библиотека - выгрузка статей в ZIP");
INSERT INTO all_accesses VALUES("lib_stat_txt","Библиотека - выгрузка статей в txt");
INSERT INTO all_accesses VALUES("lib_stat_create","Библиотека - создание статей");
INSERT INTO all_accesses VALUES("lib_dir_delete","Библиотека - удаление папок");
INSERT INTO all_accesses VALUES("lib_dir_mesto","Библиотека - перемещение папок");
INSERT INTO all_accesses VALUES("lib_dir_edit","Библиотека - редактирование папок");
INSERT INTO all_accesses VALUES("lib_dir_create","Библиотека - создание папок");
INSERT INTO all_accesses VALUES("lib_stat_delete","Библиотека - удаление статей");
INSERT INTO all_accesses VALUES("votes_settings","Голосования - закрытие/удаление");
INSERT INTO all_accesses VALUES("votes_create","Голосования - создание");
INSERT INTO all_accesses VALUES("guest_clear","Гостевая - очистка");
INSERT INTO all_accesses VALUES("guest_delete","Гостевая - удаление постов");
INSERT INTO all_accesses VALUES("obmen_dir_delete","Обменник - удаление папок");
INSERT INTO all_accesses VALUES("obmen_dir_edit","Обменник - управление папками");
INSERT INTO all_accesses VALUES("obmen_dir_create","Обменник - создание папок");
INSERT INTO all_accesses VALUES("obmen_file_delete","Обменник - удаление файлов");
INSERT INTO all_accesses VALUES("obmen_file_edit","Обменник - редактирование файлов");
INSERT INTO all_accesses VALUES("obmen_komm_del","Обменник - удаление комментариев");
INSERT INTO all_accesses VALUES("foto_foto_edit","Фотогалерея - редактирование/удаление фото");
INSERT INTO all_accesses VALUES("foto_alb_del","Фотогалерея - удаление альбомов");
INSERT INTO all_accesses VALUES("foto_komm_del","Фотогалерея - удаление комментариев");
INSERT INTO all_accesses VALUES("forum_razd_create","Форум - создание разделов");
INSERT INTO all_accesses VALUES("forum_for_delete","Форум - удаление подфорумов");
INSERT INTO all_accesses VALUES("forum_for_edit","Форум - редактирование подфорумов");
INSERT INTO all_accesses VALUES("forum_for_create","Форум - создание подфорумов");
INSERT INTO all_accesses VALUES("forum_razd_edit","Форум - управление разделами");
INSERT INTO all_accesses VALUES("adm_info","Админка - общая информация");
INSERT INTO all_accesses VALUES("forum_them_edit","Форум - редактирование тем");
INSERT INTO all_accesses VALUES("forum_them_del","Форум - удаление тем");
INSERT INTO all_accesses VALUES("forum_post_ed","Форум - редактирование сообщений");
INSERT INTO all_accesses VALUES("chat_clear","Чат - очистка");
INSERT INTO all_accesses VALUES("chat_room","Чат - управление комнатами");
INSERT INTO all_accesses VALUES("adm_statistic","Админка - статистика");
INSERT INTO all_accesses VALUES("adm_banlist","Админка - список забаненых");
INSERT INTO all_accesses VALUES("adm_menu","Админка - главное меню");
INSERT INTO all_accesses VALUES("adm_news","Админка - новости");
INSERT INTO all_accesses VALUES("adm_rekl","Админка - реклама");
INSERT INTO all_accesses VALUES("adm_set_sys","Админка - настройки системы");
INSERT INTO all_accesses VALUES("adm_set_loads","Админка - настройки загруз-центра");
INSERT INTO all_accesses VALUES("adm_set_user","Админка - пользовательские настройки");
INSERT INTO all_accesses VALUES("adm_set_chat","Админка - настройки чата");
INSERT INTO all_accesses VALUES("adm_set_forum","Админка - настройки форума");
INSERT INTO all_accesses VALUES("adm_set_foto","Админка - настройки фотогалереи");
INSERT INTO all_accesses VALUES("adm_forum_sinc","Админка - синхронизация таблиц форума");
INSERT INTO all_accesses VALUES("adm_themes","Админка - темы оформления");
INSERT INTO all_accesses VALUES("adm_log_read","Админка - лог действий администрации");
INSERT INTO all_accesses VALUES("adm_log_delete","Админка - удаление лога");
INSERT INTO all_accesses VALUES("adm_mysql","Админка - MySQL запросы !!!");
INSERT INTO all_accesses VALUES("adm_ref","Админка - рефералы");
INSERT INTO all_accesses VALUES("adm_show_adm","Админка - список администрации");
INSERT INTO all_accesses VALUES("adm_ip_edit","Админка - редактирование IP операторов");
INSERT INTO all_accesses VALUES("adm_ban_ip","Админка - бан по IP");
INSERT INTO all_accesses VALUES("adm_accesses","Привилегии групп пользователей !!!");
INSERT INTO all_accesses VALUES("user_delete","Пользователи - удаление");
INSERT INTO all_accesses VALUES("user_mass_delete","Пользователи - массовое удаление");
INSERT INTO all_accesses VALUES("user_ban_set","Пользователи - бан");
INSERT INTO all_accesses VALUES("user_ban_unset","Пользователи - снятие бана");
INSERT INTO all_accesses VALUES("user_prof_edit","Пользователи - редактирование профиля");
INSERT INTO all_accesses VALUES("user_collisions","Пользователи - совпадения ников");
INSERT INTO all_accesses VALUES("user_show_ip","Пользователи - показывать IP");
INSERT INTO all_accesses VALUES("user_show_ua","Пользователи - показ USER-AGENT");
INSERT INTO all_accesses VALUES("user_show_add_info","Пользователи - показ доп. информации");
INSERT INTO all_accesses VALUES("guest_show_ip","Гости - показ IP");
INSERT INTO all_accesses VALUES("user_change_group","Пользователи - смена группы привилегий");
INSERT INTO all_accesses VALUES("user_ban_set_h","Пользователи - бан (max 1 сутки)");
INSERT INTO all_accesses VALUES("forum_post_close","Форум - возможность писать в закрытой теме");
INSERT INTO all_accesses VALUES("user_change_nick","Пользователи - смена ника");
INSERT INTO all_accesses VALUES("loads_file_import","Загрузки - импорт файлов");
INSERT INTO all_accesses VALUES("adm_lib_repair","Восстановление библиотеки");
INSERT INTO all_accesses VALUES("notes_edit","Дневники - редактирование");
INSERT INTO all_accesses VALUES("notes_delete","Дневники - удаление");



DROP TABLE IF EXISTS `ban`;

CREATE TABLE `ban` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `time` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_ban` int(11) NOT NULL,
  `prich` varchar(1024) NOT NULL,
  `view` set('1','0') NOT NULL DEFAULT '0',
  `razdel` varchar(10) DEFAULT 'all',
  `post` int(1) DEFAULT '0',
  `pochemu` int(11) DEFAULT '0',
  `navsegda` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_user` (`id_user`,`id_ban`),
  KEY `time` (`time`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO ban VALUES("3","1495450833","2","1","....................................","1","all","0","1","0");



DROP TABLE IF EXISTS `ban_ip`;

CREATE TABLE `ban_ip` (
  `min` bigint(20) NOT NULL,
  `max` bigint(20) NOT NULL,
  KEY `min` (`min`,`max`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `bookmarks`;

CREATE TABLE `bookmarks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  `id_object` int(11) DEFAULT NULL,
  `time` int(11) DEFAULT NULL,
  `type` varchar(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

INSERT INTO bookmarks VALUES("11","1","2","1496743027","people");
INSERT INTO bookmarks VALUES("2","1","14","1495662373","foto");
INSERT INTO bookmarks VALUES("3","1","12","1495662395","notes");
INSERT INTO bookmarks VALUES("4","1","4","1495662405","forum");
INSERT INTO bookmarks VALUES("5","1","8","1495662417","foto");
INSERT INTO bookmarks VALUES("9","13","5","1496401469","forum");
INSERT INTO bookmarks VALUES("12","1","23","1496744960","notes");
INSERT INTO bookmarks VALUES("13","17","9","1497191140","people");



DROP TABLE IF EXISTS `bookmarks_like`;

CREATE TABLE `bookmarks_like` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  `id_object` int(11) DEFAULT NULL,
  `time` int(11) DEFAULT NULL,
  `type` varchar(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO bookmarks_like VALUES("1","1","16","1496729956","blog");
INSERT INTO bookmarks_like VALUES("2","1","20","1496739941","photo");
INSERT INTO bookmarks_like VALUES("3","6","19","1496748856","blog");
INSERT INTO bookmarks_like VALUES("4","15","21","1497128219","blog");
INSERT INTO bookmarks_like VALUES("5","17","23","1497192517","blog");



DROP TABLE IF EXISTS `chat_post`;

CREATE TABLE `chat_post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `room` int(11) NOT NULL,
  `id_user` int(11) DEFAULT NULL,
  `time` int(11) NOT NULL,
  `msg` varchar(1024) DEFAULT NULL,
  `vopros` int(11) DEFAULT NULL,
  `umnik_st` set('0','1','2','3','4') DEFAULT '0',
  `shutnik` set('0','1') NOT NULL DEFAULT '0',
  `privat` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `room` (`room`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `chat_rooms`;

CREATE TABLE `chat_rooms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pos` int(11) NOT NULL,
  `name` varchar(32) NOT NULL,
  `umnik` set('0','1') DEFAULT '0',
  `shutnik` set('0','1') DEFAULT '0',
  `opis` varchar(256) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pos` (`pos`,`umnik`,`shutnik`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO chat_rooms VALUES("1","0","Беспредел","0","0","");



DROP TABLE IF EXISTS `chat_shutnik`;

CREATE TABLE `chat_shutnik` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `anek` varchar(1024) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=501 DEFAULT CHARSET=utf8;

INSERT INTO chat_shutnik VALUES("1","По просьбе своих соплеменников поехал Чукча в Москву узнать, когда будет коммунизм. Приходит Чукча на прием к Горбачеву и спрашивает: - Когда будет коммунизм ? - Вот смотри: видишь, стоит моя \"Волга\", \"Волга\" Лукьянова, \"Волга\" Лигачева. Вот когда будет рядом стоять твоя \"Волга\", тогда, считай, и будет коммунизм. Вернулся Чукча в стойбище.\n- Узнал ? - Узнал. Вот видишь, стоят мои унты, твои унты и еще унты. Вот когда рядом будут стоять унты Горбачева, тогда, считай, и будет коммунизм.");
INSERT INTO chat_shutnik VALUES("2","Судья: - Вы должны попробовать стать другим человеком.\n- Я уже пытался, меня сразу посадили за подделку документов.");
INSERT INTO chat_shutnik VALUES("3","На недавней компютерной выставке (COMDEX) Билл Гейтс сравнил компьютерную промышленность с автомобильной и, в частности, сказал: - Если бы Дженерал Моторс осваивала достижения технологии с таким же эффектом, как это происходит в компьютерной промышленности, то мы все уже бы ездили на 25-ти долларовых машинах с расходом бензина 10 литров на 1000 километров. На что Дженерал Моторс отреагировала: - Да, но хотели бы вы чинить ваш автомобиль дважды в день?...");
INSERT INTO chat_shutnik VALUES("4","- Скажи, вот если мужчина говорит, что у меня волосы хорошо пахнут, это домогательство или нет? - Да нет, это комплимент, по-моему.\n- А если он карлик ....????");
INSERT INTO chat_shutnik VALUES("5","- Когда я иду с женой в гости, то пью очень мало.\n- Тебе не разрешает жена? - Вовсе нет. Просто однажды я здорово перебрал, и мне показалось, что у меня две жены. Такого ужаса я никогда не испытывал!");
INSERT INTO chat_shutnik VALUES("6","Два наркомана, обкурившись, лежат на кровати. Звонок в дверь... Через полчаса один другому: \"Кажется, в дверь звонят...\" Через полчаса другой первому: \"Может, пойти, открыть дверь?..\" Через полчаса первый: \"Ну, сходи, открой...\" Через полчаса второй встает, медленно идет к двери, открывает... На пороге, облокотившись о дверной косяк, стоит третий наркоман: \"Ох-х! Не успел позвонить, уже дверь открывают!\"");
INSERT INTO chat_shutnik VALUES("7","Наташа Ростова вышла вечером подышать на веранду. Внизу в лопухах что-то темнело. НР: Поручик, это Вы? Ржевский: Я! НР: А что это Вы такой маленький? Ржевский: Я не маленький. Я сру.");
INSERT INTO chat_shutnik VALUES("8","- А я не встану под музыку нового гимна! - Ну и будешь смотреть в задницу поющему... Коклюшкин");
INSERT INTO chat_shutnik VALUES("9","Семь раз отмерь - один раз отрежь! (еврейская народная пословица)");
INSERT INTO chat_shutnik VALUES("10","К мужику на вокзале подбегает цыганка: - Драгоценный мой, дай руку, погадаю, все скажу, что будет, что было. Мужик пожимает плечами, протягивает руку: - Hу, погадай. Цыганка некоторое время смотрит на ладонь, потом в ужасе кричит: - Страшной смертью помрешь! Зарежут тебя, сдерут шкуру, четвертуют, зажарят и съедят! - Ах да, я ж перчатку не снял...");
INSERT INTO chat_shutnik VALUES("11","Мадам готовит завтрак, муж перелистывает газету. Вдруг раздается странный гортанный звук.\n- Что там с тобой? - кричит она мужу.\n- Я случайно проглотил пуговицу от воротничка! Мадам удовлетворенно: - Хоть теперь мы будем знать, где она находится!");
INSERT INTO chat_shutnik VALUES("12","Военный говорит жене: - Поздравь меня - мне дали майора.\n- Поздравляю. И что ты с ним сделал?..");
INSERT INTO chat_shutnik VALUES("13","- Что делать, профессор, все готово к операции, а пациента еще нет.\n- Это ничего, начнем без него.");
INSERT INTO chat_shutnik VALUES("14","- Доктор, что означают буквы \"ЧЗ\" в моем диагнозе? - \"Черт его знает\".");
INSERT INTO chat_shutnik VALUES("15","Купил искусственную электронную вагину. Вы даже не представляете, что сбой процессора может быть так приятен...");
INSERT INTO chat_shutnik VALUES("16","Люди, которые думают, что они знают все на свете, раздражают нас, людей, которые действительно все на свете знают.");
INSERT INTO chat_shutnik VALUES("17","- Вчера я видел, как ты выходил из пивной.\n- Что поделаешь, не могу же я там жить.");
INSERT INTO chat_shutnik VALUES("18","Мать с дочкой идут через густой лес. Вокруг никого. страшно. Дочь: - Мама, а вдруг нас изнасилуют?!! - Не с нашим счастьем, доченька....");
INSERT INTO chat_shutnik VALUES("19","ЗВОНОК ОТ ХИЛЛАРИ Хиллари пошла к гинекологу, чтобы провериться. Когда она закончила, она спросила его, все ли в порядке. Он ответил, что он очень рад ее состоянием, но...........она беременна! - Как это возможно? Этого не может быть! - Но это так! Вы беременны уже месяц! Она выбежала из оффиса и побежала к секретарю. Взяла телефон и позвонила в Белый Дом. Когда ответил оператор, она сказала, что это Хиллари и хочет говорить с Биллом срочно! Оператор соединил ее с Овальным оффисом и Билл ответил. Хиллари начала кричать: - Ты знаешь, что ты сделал, ты кретин! Ты сделал меня беременной!!! Никакого ответа не последовало. Хиллари опять повторила, крича: - Ты знаешь, что ты сделал, ты никому не нужный кретин! Ты сделал меня беременной!!!!!!!!!! Наконец, послышался ответ: - Кто это???................");
INSERT INTO chat_shutnik VALUES("20","Управляющий беседует с молодым человеком, который хочет устроиться на работу: - В нашей фирме, - говорит управляющий, - очень заботятся о чистоте. Вы вытерли ноги о коврик перед тем как войти? - О да, разумеется.\n- Во-вторых, - продолжает управляющий, - мы требуем от наших сотрудников правдивости. Никакого коврика там нет.");
INSERT INTO chat_shutnik VALUES("21","Если к поэту приходит муза, к поэтессе приходит музык.");
INSERT INTO chat_shutnik VALUES("22","- Не понимаю, почему ты развелась с мужем? - Мне вообще не повезло с замужеством. Сначала оно напоминало мираж в пустыне: дворцы, фонтаны, пальмы, яхты, путешествия на верблюдах по Африке...\n- А потом? - Потом дворцы, фонтаны исчезли, яхта пришла в негодность, осталась одна верблюжья работа.");
INSERT INTO chat_shutnik VALUES("23","Директор мебельной фабрики поехал в командировку в Париж. Возвращается - масса впечатлений. Рассказывает своим приятелям: - О, такой город! Такие улицы! Такие магазины! - Ну а женщины? - О-о! Это что-то невероятное! Мечта! Главное - любого мужика понимают с полуслова. Вот например: захожу я в маленький ресторанчик, сажусь за столик. Ко мне подсаживается умопомрачительная красотка. Ну сразу сообразила, что я по ихнему - ни слова. Рисует мне на салфетке рюмку. Я - наливаю ей шампанского. Рисует сигарету. Я - даю закурить. Рисует две танцующие фигурки. Я - приглашаю ее на танец.\n- Ну а потом? - Рисует кровать...\n- А ты? - Хмм... До сих пор не пойму - как она узнала, что я - директор мебельной фабрики...");
INSERT INTO chat_shutnik VALUES("24","Молодой офицер попадает служить на боевой корабль, который немедленно направляется в длительный поход. \"Товарищ капитан первого ранга, я и с девушкой-то не успел побыть, а тут такой длительный поход - жалуется он командиру. \"Ничего, лейтенант, у нас для этих целей кок есть.\" \"Как можно - возмущается лейтенант - ведь он мужчина.\" \"Ну не хотите, как хотите, но если что, посодействую.\" Проходит три месяца. Лейтенант подходит к командиру: \"Товарищ капитан первого ранга, Вы что-то насчет кока говорили...\" \"Мичман! - зовет тот - приведи кока в каюту лейтенанта и не забудь взять еще троих.\" \"Зачем троих? - смущается лейтенант - а нельзя ли нам с коком один на один?\" \"Ты один с ним не справишься, сынок. Его же сначала надо с ног сбить и к кровати прижать.\"");
INSERT INTO chat_shutnik VALUES("25","На балу к поручику подскочил корнет и решив блеснуть остроумием и поетическим даром сказал: \"Поручик-ключик-чайничек\" Ржевский ответил: \"Корнет-кларнет-тромбон-гандон- и вообще ты пидарас\"");
INSERT INTO chat_shutnik VALUES("26","Самое сложное для артиста пародирующего Баскова - также не попасть в ноты.");
INSERT INTO chat_shutnik VALUES("27","Анекдот из сериала \"Скорая помощь\". Врач дает указания практикантке: - В третьей смотровой пациент повредил прямую кишку большой морковью. Составьте анамнез и заполните его карточку. Практикантка изумленно: - Как он проглотил целую морковь?!!");
INSERT INTO chat_shutnik VALUES("28","Ночь была темной. Часовому хотелось курить.\n- Эй, Мак! - окликнул он, как ему показалось, своего товарища, проходившего недалеко от поста.\n- У тебя нет сигаретки? И тут он рассмотрел, что окликнул генерала.\n- Виноват, сэр! - гаркнул он и принял стойку \"смирно\".\n- Вольно, рядовой, - отдал команду генерал.\n- И считай, тебе повезло, что я не лейтенант!");
INSERT INTO chat_shutnik VALUES("29","В фотоателье мастер долго и пристально смотрит на клиента. Тот заерзал в кресле: - Что-то не так ? - Да Вы не волнуйтесь, все в порядке - просто если б не усы, Вы были бы вылитая моя теща.\n- Но у меня нет усов ! - А вот у нее есть.");
INSERT INTO chat_shutnik VALUES("30","- Как получить миллиард долларов? - Очень просто. Надо поймать Березовского и продать его Гусинскому.");
INSERT INTO chat_shutnik VALUES("31","Вернулся мужик из командировки. Приехал домой, открывает дверь и видит на вешалке чужое мужское пальто. Заходит в спальню. В постели жена лежит, всюду мужская одежда разбросана, а тут еще из ванной выходит голый мужчина. Муж только открывает рот, но его тут же перебивает жена: - Ну, конечно, всегда так ! Ты сейчас будешь верить своим бесстыжим глазам, а не любимой жене !");
INSERT INTO chat_shutnik VALUES("32","Молодой, талантливый пианист пришел записываться на радиостудию. Но вот непруха! Чем больше играет, тем хуже получается. И дальше - хуже... Время 12 часов ночи. За стеклышком сидит оператор грустный... Кофе кончился, сигарет нет, жена три раза звонила, обещала из дому выгнать. Надоело ему это все. Включает он микрофон в студии и говорит: - \"Слушай, мужик! Ладно, все, хорош! Ну не получается. Но ты хоть гамму-то сыграть можешь?\" Тот ему: - Гамму! Нет проблем! - Сыграй, а я потом нарежу!");
INSERT INTO chat_shutnik VALUES("33","- Какая разница между женщиной без груди и брюками без карманов? - Никакой. Некуда руки девать.");
INSERT INTO chat_shutnik VALUES("34","Около ранчо остановилось стадо баранов и уставилось на ворота.\n- Чего они смотрят? - спросили у пастуха.\n- Ведь ворота старые? - Бараны новые, - ответил пастух.");
INSERT INTO chat_shutnik VALUES("35","Встречаются на том свете три старых седых мужика, узнают друг у друга, как и отчего приключилась смерть. Первый говорит: - Я всю жизнь работал и смерть меня настигла в процессе труда. А работа была нелегкой, и поседел я лет в шестьдесят. Второй говорит: - А я всю жизнь воровал потихоньку, в конце концов меня и убили из-за денег. И при этом лет в сорок поседел, понимая, чем кончится мой промысел. Третий говорит: - Ну, вы, мужики, круты, хоть чего-то в жизни добились, а вот я вообще не делал ни хрена, и, как услышал, что моя собственная жена хочет меня на пересадку органов пустить, сначала поседел, а потом - при операции - сердце не выдержало... Голем");
INSERT INTO chat_shutnik VALUES("36","Жили в одной избушке Медведь, Волк и Заяц. У Медведя была заначка водки. Как-то раз ушел он в лес, а Волк с Зайцем остались дома. Заяц подходит к Волку и говорит: - Давай выпьем! - Да ты что, Медведь нам потом головы оторвет.\n- Ничего, когда он станет про водку спрашивать, ты, главное, глаза побольше сделай, мол, и не видели ее даже, а там как-нибудь выкрутимся. Выпили они медвежью заначку. Вечером Медведь обнаружил пропажу и спрашивает - А где моя водка? У Волка глаза по пятаку, а Заяц ему и говорит: - Ну что глазенки-то выпятил, рассказывай все дяде Мише!");
INSERT INTO chat_shutnik VALUES("37","Мужики взбунтовались, взяли вилы, топоры, дубье и поперли к усадьбе. Шумят, матерятся, гул стоит. Подходят к усадьбе. Выходит староста, пытается уговорить мужиков разойтись, потом управляющий - не слушают, матерятся, требуют, чтоб Сам вышел. Выходит помещик, после завтрака, халат расстегнут, левой рукой чешет брюхо, правой зубочистку держит, во рту ковыряется. Мужики притихли. Барин зевает, поворачивается к толпе и негромким голосом спрашивает: - Ну, чего вам, мужики? Мужики стоят молча. Барин смотрит на них, ждет ответа минуты три, потом лениво уходит. Мужики стоят, молчат, потом, спустя полчаса понемногу расходятся. Дня через три один из зачинщиков обедает дома, ест шти. Вдруг посреди обеда останавливается, задумывается, потом бах ложкой об стол и орет: - ЧАВО, ЧАВО, А НИЧАВО!");
INSERT INTO chat_shutnik VALUES("38","- Что можно снять с голой женщины? - Только голого мужчину.");
INSERT INTO chat_shutnik VALUES("39","Учительница прибегает к директору в слезах: - Ах это просто невыносим ! Не ученики - животные, скоты ! А один даже грозился меня изнасиловать ! Представляете ?! Директор встает и идет в класс. Входит. Молча осматривает ряды учеников и тыкает пальцем в Вовочку: - Этот сказал ? Понимаю: этот раз сказал - сделает.");
INSERT INTO chat_shutnik VALUES("40","\"Хуюшки вам, а не Кунашир!\" - сказал японцам Владимир Путин. И остров Хуюшки из Курильской гряды пришлось отдать.");
INSERT INTO chat_shutnik VALUES("41","- Любите ли вы Шекспира? - Трудно сказать. Скорее, мы просто приятели.");
INSERT INTO chat_shutnik VALUES("42","Начало чемнионата России по футболу. Матч \"Динамо\" - \"Спартак\". Опоздавший болельщик - соседу: - Ну и кто из наших лучше всех играет, точнее всех бьет? - Ковтун.\n- Но на табло 2:2, и два гола забил Терехин....\n- Много ты понимаешь! Терехин десять раз ударил и два раза забил, а Ковтун три раза ударил, и для всех троих сезон уже закончился!");
INSERT INTO chat_shutnik VALUES("43","- Кто, в конце концов, в доме хозяин?! - набравшись духу, закричал муж.\n- Я,- спокойно ответила жена,- А что? - Да нет, ничего... Все в порядке. Я просто так спросил.");
INSERT INTO chat_shutnik VALUES("44","- Где у женщин расположен аппендикс? - Как войдешь - налево.");
INSERT INTO chat_shutnik VALUES("45","Где-то загорелся дом. Все тушат. Прибегает хозяин и кричит: - Hа меня ведро воды! Выплеснули на него ведро, вбежал в горящий дом, через какое-то время выскоч ил. Проходит минут 15, мужик опять: - Hа меня ведро воды! Снова забежал в дом, через некоторое время выскочил. Прошло еще минут 15, у дома крыша уже обваливается, мужик опять: - Hа меня 10 ведер! Ему говорят, мол, куда ты полезешь, и вещей не спасешь, и сам погибнешь.\n- Какие вещи! Там моя теща, а я ее переворачиваю.");
INSERT INTO chat_shutnik VALUES("46","Однажды пришли к габровцам гости, да слишком засиделись. Не вытерпела хозяйка и громко сказала мужу, чтобы все услышали: - Давай, муженек, ляжем спать, а то, наверное, гости уже хотят идти домой!..");
INSERT INTO chat_shutnik VALUES("47","Революция кончилась. Петька с Василием Ивановичем думают о новой жизни: - Петька, что бы нам теперь построить? - Построим консерваторию! - Точно! А на крышу пулемет поставим! - А это зачем? - Чтобы все консервы не растащили!");
INSERT INTO chat_shutnik VALUES("48","Мужик жалуется приятелю: - А ведь когда-то у меня было все: деньги, роскошный дом, мерс, красивая женщина, которая меня по-настоящему любила. И всего этого я лишился в одночасье.\n- А что случилось? - Да какой-то козел рассказал об этом моей жене!");
INSERT INTO chat_shutnik VALUES("49","Из письма А. Б. Чубайсу. Уважаемый Анатолий Борисович, пишет вам электрик Эрнест Петрович Сидоров. Сделайте что-нибудь. Ввиду огромного внешнего сходства с вами, мне очень часто бьют морду. С уважением Э. П. Сидоров");
INSERT INTO chat_shutnik VALUES("50","Глубокой ночью Сталин поднимает трубку.\n- Слушай, товарищ Молотов, а ты так же все заикаешься? - Заикаюсь, товарищ Сталин, но если нужно будет для дела строительства социализма, тоЄ - Нет, ничего не надо. Спи спокойно. И кладет трубку. Звонит Микояну.\n- Слушай, товарищ Микоян, сколько там было бакинских комиссаров? - 27, товарищ СталинЄ - А сколько погибло? - 26, товарищ Сталин.\n- Ну, спи спокойно, наш двадцать седьмой бакинский комиссар! И кладет трубку. Звонит Берии.\n- Слушай, товарищ Берия, ты Бухарина надежно расстрелял? - Надежно, товарищ Сталин. А что? - Да ничего. Спи спокойно. Кладет трубку и говорит: - Ну вот, их успокоил, теперь можно м самому уснуть.");
INSERT INTO chat_shutnik VALUES("51","Англичанин среднего достатка заходит в респектабельный магазин. Немного оглядевшись спрашивает продавца.\n- Скажите, сколько стоит вон та шляпа? -Тысячу долларов, Сэр.\n-Черт.., А вон та? -Два черта, Сэр. FiL");
INSERT INTO chat_shutnik VALUES("52","Гpузин в pестоpане любуется новыими \"коpочками\" кандидата наук. Официант ехидно спpашивает: - Что, только что купил ? - Вах ! Зачэм стpашиваэш ! Зачэм сpазу: Купиль ! Дpуззя подаpиль !!");
INSERT INTO chat_shutnik VALUES("53","Встречаются два директора советского и японского предприятий. Предприятия изготавливают совершенно одинаковую продукцию и в одинаковых количествах. Директор нашего завода спрашивает: - Сколько людей у тебя работает? - Девять. А у тебя? У нашего вообще-то пятьсот, но он говорит: - Десять! На следующий день японец говорит: - Слушай, я всю ночь думал и никак не могу понять: что у тебя этот десятый делает?");
INSERT INTO chat_shutnik VALUES("54","\"Фанта. Вкус апельсина.\" До сих пор не могу понять, что именно дает этот вкус. То ли вода с сахаром и диоксидом углерода, то ли регулятор кислотности и стабилизатор гуммиарабик. А может, изо-бутират ацетат сахарозы с антиоксидантом аскорбиновая кислота? Хотя, вероятнее всего, краситель \"желтый солнечный загар\" с идентичными натуральным ароматизаторами... Нет, наверное, все-таки бензоат натрия!..");
INSERT INTO chat_shutnik VALUES("55","Жена: - Не могли бы мы как-нибудь сходить в кино ? Муж: - Мы же были в кино.\n- Да, но теперь там идут звуковые фильмы...");
INSERT INTO chat_shutnik VALUES("56","Садятся старик со старухой ужинать. Старуха поставила перед стариком сковородку картошки. Он поковырялся вилкой, взял сковородку да как треснет старухе по лбу.\n- Старик, ты одурел, что ли? - Как вспомню что не целкой взял, так аппетит пропадает!!!");
INSERT INTO chat_shutnik VALUES("57","У минетчицы спрашивают: - как дела? - Да вот вот хреново! Всякая пошлятина в голову лезет!");
INSERT INTO chat_shutnik VALUES("58","Выполз уж из ресторана: \"Гав. Неа.. Ку-ка-реку Неа.. Мяу Неа... Шшшш, бля буду, шшшшш!\"");
INSERT INTO chat_shutnik VALUES("59","Леди не захочет, джентльмен не вскочит.");
INSERT INTO chat_shutnik VALUES("60","- Ва-ань, а Ва-ань, ты за ско-олько доходишь от кровати до двери? - Я - за час, а ты за сколько? - За полчаса! - Ну, ты вообще, как метеор!");
INSERT INTO chat_shutnik VALUES("61","Фиpма, пpодающая пилюли для похудения, получила письмо: \"Ваши пилюли бесподобны. За пеpвые две недели моя жена похудела на шесть кг, а вскоpе исчезла вообще.\"");
INSERT INTO chat_shutnik VALUES("62","Врач - пациенту, глядя в историю болезни: - Э-э ,батенька, с сегодняшнего дня бросайте курить - положение серьезное! - Доктор, но я не курю! Не люблю.\n- Да? Тогда ни капли спиртного!! - Но, доктор, я не пью! Не люблю! - Да??... Но что-нибудь вы любите!!?? - Картошку...\n- Так вот! С сегодняшнего дня я вам решительно запрещаю есть картошку!!!");
INSERT INTO chat_shutnik VALUES("63","- Рабинович, говорят, вы большой интриган? - Да, а кто это ценит...");
INSERT INTO chat_shutnik VALUES("64","Социальная реклама Мы yже не pаз обманывали вас. Вы защищали нас осенью 91-го, мы стpеляли в вас осенью 93-го. Мы pазвалили вашy стpанy в 90-м, обокpали в 92-м, надyли с двyмя Волгами в 93-м, с помощью МММ-ов pаскpyтили на бабки в 94-м, посылали ваших детей на бойню в 95-м, неплохо \"повтоpничали\" в 96-м, и полностью огpабили в 98-м. Hо y нас опять кончились деньги. Пожалyйста, заплатите налоги...");
INSERT INTO chat_shutnik VALUES("65","- Дорогой! Наш сосед подарил тебе на день рождения двухрожковую люстру! - Это он на что намекает?!");
INSERT INTO chat_shutnik VALUES("66","Недавно на ж/д переезде № 37 пожарный инспектор Василий М. обнаружил цистерну со спиртом, близкую к самовозгоранию. Лишь к вечеру силами жителей семи окрестных сел риск самовозгорания уменьшился ровно наполовину.");
INSERT INTO chat_shutnik VALUES("67","Молодой фермер, призванный на военную службу, в письме домой написал: \"Эта армейская жизнь - сплошное удовольствие. Можно валяться в постели до пяти часов утра\".");
INSERT INTO chat_shutnik VALUES("68","- Что вы будете делать, сержант Тейер, если запасы воды в вашем взводе окажутся зараженными? - Лучшим выходом было бы перейти на пиво.");
INSERT INTO chat_shutnik VALUES("69","Встречаются две подруги. Одна две недели назад вышла замуж. Вторая любопытствует: - Ну и как тебе семейная жизнь? - Да так себе, ничего. Только вот, представляешь, а Жан-то, оказывается, пьет...\n- Как пьет! Вы же два года были знакомы! И ты не знала? - Так ведь два года все было нормально, но вот вчера он пришел трезвым!");
INSERT INTO chat_shutnik VALUES("70","Почему евреи так популярны у женщин? Потому, что у них есть длинный, большой и толстый... Нет, не то, о чем Вы подумали: длинный - рубль, большой - счет в банке, а толстый - бумажник! Голем");
INSERT INTO chat_shutnik VALUES("71","\"micro soft works for micro soft windows\" означает \"Микро программное обеспечение работает для микро окон программного обеспечения\" (Перевод выполнен ПО Stylus for Windows 95, в. 3.0)");
INSERT INTO chat_shutnik VALUES("72","Больной вызывает врача в три часа ночи. После осмотра врач задумывается, потом говорит: - Вы составили завещание? - Нет, доктор.\n- Так вызовите, пожалуйста, нотариуса и двух свидетелей.\n- Боже мой, это так серьезно? - Нет, но я не хотел бы быть единственным дураком, которого вы подняли в три часа ночи.");
INSERT INTO chat_shutnik VALUES("73","Ж) - Смотри какие тени длинные, и облака тяжелые... Х) - Длинные - потому что уже поздно, а тяжелые потому что мы уже 5-й день пьем.");
INSERT INTO chat_shutnik VALUES("74","- Хаим, я слышал - вы женитесь! - Таки-да! - И как вам ваша будущая жена? - Ой, сколько людей, столько и мнений. Маме нравится, мне - нет.");
INSERT INTO chat_shutnik VALUES("75","Племянник разговаривает с Лениным: - Дядя Вова, у тебя такая большая умная голова!? - Да, Витенька, ей я думаю, как людям лучше жить.\n- У тебя такие руки!? - Да, Витенька, ими я указываю людям верную дорогу.\n- А усы тебе зачем? - А чтобы тетю Надю щекотать!");
INSERT INTO chat_shutnik VALUES("76","Один еврей рассказывает: - Представляешь, прихожу домой, а там жена с любовником. А глаза у них хитрые-хитрые... Думаю, что за черт! Бегу прямо к холодильнику, открываю его, так и есть! Всю фаршированную рыбу съели, сволочи!");
INSERT INTO chat_shutnik VALUES("77","Дочка спрашивает у мамы: - Мама, а что такое фаллоимитатор? Мама, немного смутившись, отвечает - Ну, доченька, это прибор, который заменяет мужа. Дочка (с восхищением): - Классно! И он сам по ночам жрет котлеты из холодильника и храпит?");
INSERT INTO chat_shutnik VALUES("78","Встречаются два приятеля: - Говорят, ты женился на девушке, о которой даже не мог и мечтать.\n- Правильно говорят... Неужели ты думаешь, что я мог мечтать о такой стерве?");
INSERT INTO chat_shutnik VALUES("79","Начальник лагеря объявляет: - Сегодня день смены белья. Первый барак меняется со вторым.");
INSERT INTO chat_shutnik VALUES("80","Вышел как-то Брежнев на балкон - на звезды посмотреть. Глянул - а луна-то не красная! Он позвонил кому надо, ему ответили, мол, все ОК, будет сделано! Выходит на следующий день - луна красная, как мак! Ильич лег спать довольным. На следующий день вышел - у луны снизу треугольник белый и надпись черным - Marlboro. Он звонит, ему - будет сделано! Он ложится спать. На следующий день - красная луна, белый треугольник, Мальборо и подпись внизу - \"московская фабрика Дукат\". Ильич ложится довольным. Следующий день. Глянул Брежнев - красная луна, Мальборо, фабрика Дукат, а внизу подпись - по лицензии компании Phillip Morris Ltd. Звонит, ему - будет сделано. Следующий день. Брежнев на балконе. Красная луна, белый треугольник, надпись Marlboro, подпись \"московская фабрика Дукат\", еще подпись \"по лицензии компании Phillip Morris Ltd.\", а внизу крупными буквами - МИНИСТЕРСТВО ОБОРОНЫ СССР ПРЕДУПРЕЖДАЕТ...");
INSERT INTO chat_shutnik VALUES("81","Вовочка пpедлагает Машеньке: - Машка, а давай мы с тобой в семью поигpаем? - А как? - Сначала потp#хаемся - а потом хаpактеpами не сойдёмся!");
INSERT INTO chat_shutnik VALUES("82","После того, как хирург сделал даме пластическую операцию, удалив двойной подбородок и придав носу классическую форму, она попросила, чтобы он расширил ей глаза.\n- Это уже лишнее, - заявил хирург, - у вас глаза станут и без того широкими, когда вы увидите счет за две первые операции.");
INSERT INTO chat_shutnik VALUES("83","Новый русский приходит к дантисту. Садится в кресло, открывает рот и дантист обалдевает: верхняя челюсть платиновая, а нижняя - золотая! Обалдевши дантист спрашивает: - А чем я могу помочь !??? - Как чем? Ты сигнализатцию поставь.");
INSERT INTO chat_shutnik VALUES("84","И настали в России смутные времена - лица кавказской национальности стали проверять прописку у работников милиции, а гаишники давать взятки водителям...");
INSERT INTO chat_shutnik VALUES("85","- Что-нибудь поймали? - интересуется прохожий.\n- Да, - мрачно отвечает рыбак.\n- Поймал одного и бросил в реку.\n- Наверное, маленький был? - Да, ростом примерно с вас и такой же назойливый.");
INSERT INTO chat_shutnik VALUES("86","- Мадам, почему вы уменьшили свой возраст на шесть лет? - Дело в том, что первые шесть лет я не умела считать.");
INSERT INTO chat_shutnik VALUES("87","Ленин с Крупской сидят и пьют чай. Вдруг на лестнице раздался страшный грохот и лязг.\n- Наденька, кажется, в прихожей упал несгораемый шкаф...\n- Нет, Володя, это железный Феликс на перилах катается.");
INSERT INTO chat_shutnik VALUES("88","Вопрос: Почему большинство женщин не может уснуть после оргазма? Ответ: Потому что им нужно еще до дома добираться!");
INSERT INTO chat_shutnik VALUES("89","- Доктор, я после ампутации не чувствую правую ногу.\n- Как же вы, голубчик, хотите ее чувствовать, если она у вас ампутирована?.\n- Так мне же ампутировали левую!");
INSERT INTO chat_shutnik VALUES("90","С завистью про одну знакомую: - Она только что вернулась с черноморского побережья с чудесно загоревшим языком!");
INSERT INTO chat_shutnik VALUES("91","Винни-Пух полез за медом и застрял.\n- Пятачок! Пятачок! Отдери меня! Ну Пятачок и отодрал. Через два дня пошел дождь, Винни-Пух отлип и упал.");
INSERT INTO chat_shutnik VALUES("92","Как пытают Саддама Хусейна? - показывают портрет Мадлен Олбрайт");
INSERT INTO chat_shutnik VALUES("93","У нового рyсского спрашивают: \"За сколько минимyм Вы пробежите 100 метровкy?\" (HР): \"Минимyм за $800.\"");
INSERT INTO chat_shutnik VALUES("94","\"Как я учился трахаться\" - руководство по установке \"Windows\"");
INSERT INTO chat_shutnik VALUES("95","Парочка едет на спортивном автомобиле. Она: - Дорогой, не надо ехать так быстро, я боюсь. Он: - А ты закрой глаза, как я.");
INSERT INTO chat_shutnik VALUES("96","Вопpос к аpмянскому pадио: - Женятся ли онанисты? Ответ: - Да. Hа дояpках!");
INSERT INTO chat_shutnik VALUES("97","Солдат стройбата берет пачку \"Беломора\" и по слогам читает: - Минздрав предупреждает...\n- прикурил, затянулся, поглядел мечтательно вдаль и произнес: - Вот же гады, на лопатах-то такое не пишут.");
INSERT INTO chat_shutnik VALUES("98","- Pядовой Петpов - выйти из cтpоя - 15 шагов впеpед! - Pаз, два, тpи... Cемь! Дальше не могy, товаpищ майоp, - стена! - А дальше и не надо! Pота - ПЛИ !!!");
INSERT INTO chat_shutnik VALUES("99","Все хорошо, что хорошо конча...");
INSERT INTO chat_shutnik VALUES("100","Встречаются два друга. Один спрашивает другого: - Ты, я вижу, к Интернету подключился! - Как ты узнал? - По глазам.\n- Стали умнее? - Нет, краснее... (с) АС");
INSERT INTO chat_shutnik VALUES("101","Нынче очень легко стало отличить КТО есть КТО в американской политике. Демократы называют его Кеннет Старр, а Республиканцы уважительно Судья Старр...");
INSERT INTO chat_shutnik VALUES("102","К врачу приходит пациент с полностью черным языком.\n- Что это с вами? - Да вот, пролил водку на свежеуложенный асфальт...");
INSERT INTO chat_shutnik VALUES("103","В кабинет врача входит девушка: - Раздевайтесь, пожалуйста, - говорит ей врач.\n- Зачем?! - вспыхивает девушка.\n- У меня ведь болит ухо! - В таком случае вам не ко мне, - отвечает врач.\n- Я глазник.");
INSERT INTO chat_shutnik VALUES("104","Похороны. Катафалк, после того как на него погрузили гроб, трогается с места. Случайные свидетели наблюдают такую душераздирающую сцену: за катафалком бежит мальчуган лет восьми и рыдает: - Папа, папочка, куда же ты, не оставляй меня, я хочу с тобой!!! Но тут вдруг катафалк останавливается, из кабины выходит шофер и орет мальчику: - А ну марш домой, кому сказал! Не сделаешь уроки к моему приходу - я тебе ремня дам!");
INSERT INTO chat_shutnik VALUES("105","Сдают мужики сперму в больнице. Очередь большая. Вдруг подходит девушка и становится молча в очередь. Пять минут стоит и молчит. Десять. Народ удивляется. Подходит к ней мужик и спрашивает: - А вы что, тоже сперму сдаете ? А она отвечает, не раскрывая рта: - Угу.");
INSERT INTO chat_shutnik VALUES("106","В кабинет врача входит девушка: - Раздевайтесь, пожалуйста, - говорит ей врач.\n- Зачем?! - вспыхивает девушка.\n- У меня ведь болит ухо! - В таком случае вам не ко мне, - отвечает врач.\n- Я глазник.");
INSERT INTO chat_shutnik VALUES("107","Похороны. Катафалк, после того как на него погрузили гроб, трогается с места. Случайные свидетели наблюдают такую душераздирающую сцену: за катафалком бежит мальчуган лет восьми и рыдает: - Папа, папочка, куда же ты, не оставляй меня, я хочу с тобой!!! Но тут вдруг катафалк останавливается, из кабины выходит шофер и орет мальчику: - А ну марш домой, кому сказал! Не сделаешь уроки к моему приходу - я тебе ремня дам!");
INSERT INTO chat_shutnik VALUES("108","Сдают мужики сперму в больнице. Очередь большая. Вдруг подходит девушка и становится молча в очередь. Пять минут стоит и молчит. Десять. Народ удивляется. Подходит к ней мужик и спрашивает: - А вы что, тоже сперму сдаете ? А она отвечает, не раскрывая рта: - Угу.");
INSERT INTO chat_shutnik VALUES("109","Приходит барышня к гинекологу.\n- Доктор, вы мне вчера спиральку поставили...\n- Да, помню.\n- Но она слишком длинная.\n- Присядьте пока, через 5 минут поменяю. Барышня садится: пау-уау-уау!");
INSERT INTO chat_shutnik VALUES("110","Тяпница (день недели - время выпить)");
INSERT INTO chat_shutnik VALUES("111","Три секретарши в кафе обсуждают своего негодяя-босса.\n- Я вылила пузырек чернил в ящик его письменного стола.\n- А я нашла у него в столе презерватив и проколола его иглой. Третья падает в обморок.");
INSERT INTO chat_shutnik VALUES("112","Чукча приехал домой из Москвы и говорит: - Чукча в Москве был, чукча умным стал, все знает. Оказывается, Карл, Маркс, Фридрих, Энгельс не четыре человека, а два, а Слава КПСС - вообще не человек.");
INSERT INTO chat_shutnik VALUES("113","Если бы люди водили автомобили также, как они работают на компьютерах (разговор по телефону Водителя и Техника из тех. поддержки) Техник: Водительская тех. поддержка. Чем можем помочь? Водитель: Эта... Машина у меня не заводится. Техник: Ясненько. Какая у вашей машины марка, модель, и год выпуска? Водитель: А я... хрен его знает! Я ее купил в магазин ездить, откуда мне знать... Техник: Хорошо-хорошо, успокойтесь. Попробуем обойтись без этой информации... (вздох) У вас есть бензин в баке? Водитель: Гм... Бензин в баке, говоришь... А как я узнаю? Техник: На передней панели посмотрите. Куда стрелка показывает, на \"Е\" или на \"F\"? Водитель: А где передняя панель? Техник: Она находится сразу за рулем если вы сидите в водительском кресле. Водитель: А! Вижу. .. Тэкс... А тут стрелок много, которую из них смотреть? Техник: Смотрите на ту, рядом с которой написано Е или F. Там еще может быть бензоколонка нарисована. Водитель: Ааа! Вижу. Стрелка показывает на ноль. Техник: Как на ноль? Водитель: Ага. Прямо на ноль. А ещ");
INSERT INTO chat_shutnik VALUES("114","- Алло! Это \"секс по-телефону\"? - Да.\n- Значит, так. Hикаких кружевных трусиков, чулочек. Ты - блондинка, толстая, раскрасневшаяся. Абсолютно голая, но в резиновых сапогах. Звать тебя Клава. Hедавно кончилась война, примерно сорок шестой год. Мы - на сеновале. Пахнет конским навозом. Лучик света сквозь дыру в крыше упал на мою спину... Поехали, Клавка!");
INSERT INTO chat_shutnik VALUES("115","Отправляют первого китайца в космос. В напутствие ему говорят: Летишь ты не надолго, но еды мы тебе дадим много - кушай сколько хочешь, а мешочек (для естественных отходов организма) в скафандр пришили небольшой (ну на сутки, зачем большой?)... Приземлятся китайский космонавт. Еда нетронута, а вот мешочек порвался :( (c) Toha, onliner.by");
INSERT INTO chat_shutnik VALUES("116","Разговор мужа и жены: - Слушай, что мы подарим на этот раз моей маме на день рождения ? - А что мы дарили в прошлый раз ? - В прошлый раз мы подарили ей стул.\n- Hу а теперь подведем к нему электричество.");
INSERT INTO chat_shutnik VALUES("117","- Моня, ты что делаешь сегодня вечером? - Да, вроде, ничего.\n- Давай пойдем в клуб \"Кому за тридцать\". Договорились, но Моня не пришел. Встречаются на другой день.\n- Ну чего же ты не пришел? Я так хорошо провел время, там такие женщины...\n- Хаим, а я померил, у меня только двадцать четыре... Ну я и не пошел.");
INSERT INTO chat_shutnik VALUES("118","На еврейском кладбище в Одессе три землекопа присели отдохнуть у трех могил известных людей.\n- Хотел бы я лежать вот здесь, рядом с Рабиновичем, а ты? - говорит один.\n- Нет, я предпочел бы рядом с Абрамовичем.\n- А я предпочел бы прямо сейчас лежать с женой Когана...\n- Так она же жива! - Вот и я про то же!");
INSERT INTO chat_shutnik VALUES("119","Один приятель другому: - Ты знаешь, я когда в командировку последний раз уезжал, в шкафу капкан на медведя оставил. Представляешь - приезжаю и сразу к шкафу бегу, смотрю - сидит красавец! - Кто? Любовник? - Да нет... Медведь!");
INSERT INTO chat_shutnik VALUES("120","Явлинский-Болдырев-Лукин - ЯБЛоко. Немцов-Хакамада-Чубайс - НеХаЧу. Коалиция: \"НЕХАЧУ ЯБЛОКО\". &copy; Хрюн");
INSERT INTO chat_shutnik VALUES("121","- У этой пьесы был счастливый конец? - Конечно, все были так рады, что она закончилась.");
INSERT INTO chat_shutnik VALUES("122","Как называется человек, который не дарит подарков своей любовнице? Ответ: Дармоёб");
INSERT INTO chat_shutnik VALUES("123","- Доктоp, я пеpестала получать удовольствие от колбасы.\n- А что вы с ней, пpостите, делаете? - Я ее ем...");
INSERT INTO chat_shutnik VALUES("124","Пришел муж домой, уставший с работы. Поел и лег с женой спать. Всю ночь жена ластится к нему и так, и сяк, а он ворчит: - Отстань, Машка, у меня еще колосок не созрел... Спать хочу! На следующую ночь повторяется то же самое. На третью ночь муж начал сам к ней ластиться - и так, и сяк. А она ему отвечает: - Чё пристал? - Колосок-то созрел, - отвечает муж.\n- Ну вот еще, - ворчит жена, - буду из-за одного колоска весь комбайн заводить!");
INSERT INTO chat_shutnik VALUES("125","Два часа ночи. Звонок в дверь. Жена открывает дверь и... тело мужа падает в коридор.\n- Свинья! Ну что за радость каждый раз напиваться до полусмерти..!? - Прасти, драгая, ккак вседа денег неххватило....!!!");
INSERT INTO chat_shutnik VALUES("126","Заходит мужик в аптеку. М. У вас бананы есть? А. Нет. Здесь дорогой аптека и бананов не бывает. а следующий день снова он же заходит в аптеку. М. У вас Бананы есть? А. Да нет же здесь аптека здесь лекарства разные банки и т.д. Так повторяется в течении пяти дней, заебанный аптекарь на большом ватмане крупными буквами пишет объявление \"БАНАНОВ НЕТ! \" Заходит тот же мужчина, внимательно читает объявление, Подходит к Аптекарю и с обидой говорит \"А значит были бананы!\"");
INSERT INTO chat_shutnik VALUES("127","Дерется Чебурашка с Кощеем Бессмертным. Кощей говорит: - Все равно ты меня не убьешь. У меня смерть в яйце. Последовал удар.\n- У... да не в том!!!");
INSERT INTO chat_shutnik VALUES("128","В роддоме. Из операционной выходит молоденькая медсестра и говорит мужчине, ждущему результатов родов своей жены: - Поздравляю вас! У вас родился сын с шестью кулачками. Мужик побледнел и чуть не упал в обморок. А медсестра, хохоча: - Обманули дурачка на четыре кулачка!");
INSERT INTO chat_shutnik VALUES("129","Двое охранителей купили Мерседесы. И сразу же возник вопрос: дескать, как мы эти Мерседесы отличать будем? Вот один и говорит: - Послушай, давай разобьем у твоего левую фару, а у моего - правую. Так и будем отличать... Другой согласился. Так и сделали. Второй посмотрел-посмотрел и спрашивает: - Послушай, братан. Фары-то мы разбили, а ты помнишь, какая фара у твоей разбита - правая или левая? - Не-а.\n- Давай разобьем и другую фару. Разбили обе фары обеих машин, сидят и смотрят...\n- Послушай, братан, а ведь опять машины не отличишь.У обеих обе фары разбиты! - Ну, слушай, надоело с этими Мерседесами цацкаться. Ты бери черную, а мне таки-да достанется белая.");
INSERT INTO chat_shutnik VALUES("130","- Эй мужик, ты пиво будешь? - Буду, конечно! - Когда будешь, то меня позови...");
INSERT INTO chat_shutnik VALUES("131","Осмотрев кран, сантехник говорит девушке - хозяйке квартиры: - А прокладку-то вам пора менять! Девушка, смущенно покраснев, бормочет: - А вы-то откуда знаете?");
INSERT INTO chat_shutnik VALUES("132","Приходит Вовочка из школы и говорит отцу: - Мне двойку по биологии поставили. Папаша: - За что? - Да спросили у кого самые большие яйца.\n- Ну а ты? - Я сказал у верблюда.\n- Правильно, а учительница? - А она говорит что у страуса. Отец (задумчиво): - У Страуса ... так вот он почему такие медленные вальсы писал.");
INSERT INTO chat_shutnik VALUES("133","Когда АбрамОвич родился, АбрАмович три дня плакал...");
INSERT INTO chat_shutnik VALUES("134","Приходит женщина к врачу: - Доктор, я хотела бы подправить форму одной груди. А то они у меня не одинаковые.\n- Ну показывайте.\n- Вот эта (вытаскивает) нормальная.\n- Вполне.\n- А вот эта (вытаскивает, грудь пля-ф-ф-ф-ф на пол) видите, какая? Доктор чешет в затылке: - Да, такое я в первый раз вижу.\n- Это, наверно, из-за моего мужа. Он, понимаете, не может заснуть, если за мою грудь не держится.\n- Ну что вы такое рассказываете? Я вам признаюсь, у меня самого есть такая маленькая мания, но у моей супруги грудь нормальная.\n- Так вы, наверно, доктор, с женой в одной комнате спите?");
INSERT INTO chat_shutnik VALUES("135","В нью-йоркском отеле вывешено объявление: \"Гасите сигареты! Помните о пожаре в Чикаго!\" Под этим объявлением кто-то подписал: \"Hе плюйте на пол, помните о весенних разливах Миссисипи!\"");
INSERT INTO chat_shutnik VALUES("136","По дороге на мопеде ехал \"голубой\". Ну и заглох его мопед. Встал он на обочине, пригорюнился. Тут к нему на \"Мерседесе\" подъезжает \"крутой\" и небрежно так открывая окно спрашивает: - Ну что, мужик, толкнем твое говно? Педик (с радостью в голосе): - Конечно, толкнем!! А потом и мопед починим!!");
INSERT INTO chat_shutnik VALUES("137","Мужик, недавно купивший себе \"Феppаpи\", несется на этой машине с огpомной скоpостью, наслаждаясь мощью двигателя. Вдpуг он видит табличку: \"Сбавь скоpость - 50 км\". Мужик думает: \"Можно ведь было пpосто установить соответствующий запpещающий знак. А pаз они этого не сделали, значит, тут что-то сеpьезное и скоpость действительно надо сбавить\". Сбавляет он скоpость до 50 км/ч - и чеpез некотоpое вpемя видит еще одну табличку: \"Сбавь скоpость - 20 км\". Он и на этот pаз сбавляет скоpость до 20 км/ч, хоть и с большой неохотой. Чеpез полчаса - опять табличка: \"Сбавь скоpость 10 км\". Пpоклиная все на свете, он замедляется до 10 км/ч. А еще чеpез час он видит такую вывеску: \"Добpо пожаловать в пpидоpожный pестоpан \"Сбавь скоpость!\"\"");
INSERT INTO chat_shutnik VALUES("138","В испанском публичном доме \"мадам\" кричит: - Донна Мария, дон Педро все еще на вас? - Да.\n- Не давайте ему кончить, он заплатил фальшивыми купюрами.");
INSERT INTO chat_shutnik VALUES("139","Пришел мужчина на пляж. Снимает майку - вся спина искусана. Народ: - Мужик, что у тебя со спиной-то?! Мужик, отмахиваясь: - Да вчера тут голубого трахал, дык всю спину изгрыз, зараза!");
INSERT INTO chat_shutnik VALUES("140","Мужик приходит в фирму по объявлению \"Требуется менеджер\". Показывает боссу свои дипломы - финансовый институт, школа управления, курсы менеджмента и т.п. Босс: - Это хорошо. Мне нужен сообразительный управленец. Он должен взять на себя главный наш больной вопрос - финансы. Кандидат: - С моим образованием это без проблем. А как насчет заработка? - Ну, вы начинающий, предполагаю вам пока положить 10000 $.\n- Да? Но откуда же ваша маленькая фирма берет средства, чтобы платить такие деньги? - Вот. Вот это первый вопрос, который вам предстоит решить.");
INSERT INTO chat_shutnik VALUES("141","Когда мужчины спрашивали ее о возрасте, она кокетливо смеялась и отвечала, что женщине столько лет, на сколько она выглядит. Некоторые ей верили и имели большие проблемы - паршивке еще не было 15-ти.");
INSERT INTO chat_shutnik VALUES("142","И волки сыты, и овцы целы. Светлая память пастуху!");
INSERT INTO chat_shutnik VALUES("143","\"Все зло от Б.А.Б.!\" В.В.П.");
INSERT INTO chat_shutnik VALUES("144","Заяц отслужил на флоте и возвращается домой. Идет по лесу, поет песню: - На побывку едет молодой моряк! В кустах его поджидает Волк, который тоже служил на флоте, и тоже тихонько напевает: - Напрасно старушка ждет сына домой!");
INSERT INTO chat_shutnik VALUES("145","В бане два маленьких мальчика увидели голого мужчину с большим животом. Спрашивают его: - Дядя, а что у тебя в животе? - Бомба. Один тихо говорит другому: - Давай взорвем ее.\n- Опасно очень короткий фитиль.");
INSERT INTO chat_shutnik VALUES("146","Два бpаконьеpа: - Вчеpа поймал огpомного осетpа. Закинyл его на спинy и идy домой.\n- Hy? - А тyт из-за кyстов - инспектоp pыбнадзоpа! - Hy?! - А я осетpа со спины - и в каpман!");
INSERT INTO chat_shutnik VALUES("147","- Твоя собака, сосед, укусила мою жену за ногу. Придется тебе заплатить штраф.\n- За то, что может быть возмещено,- отвечает Насреддин,- нельзя требовать выкупа. Пришли свою собаку, пусть она укусит за ногу мою жену. И мы в расчете!");
INSERT INTO chat_shutnik VALUES("148","Ползут по пустыне два унитаза. Один говорит другому: - Ген, а Ген ! Давай приколупаемся к той черепахе ! - Hе надо, Чебурашка, Мы уже к старику Хотабычу приколупались !");
INSERT INTO chat_shutnik VALUES("149","У Моллы был длиннорогий бык. Целые дни и ночи Молла думал: как бы хоть раз сесть быку на голову, между рогами. Но удачного случая не представлялось. Однажды ночью Молла вышел во двор и видит: бык лежит на земле, пережевывая свою жвачку. Вот подходящий момент! -подумал Молла. Подобрав полы своей чохи, он вскочил быку на голову и уселся между рогами. Бык, испугавшись, вскочил и, мотнув головой, сбросил Моллу на землю. Молла закричал и упал в обморок. Услышав крик Моллы, жена его выбежала из дому и видит: муж ее лежит в крови, без сознания. Она подняла крик. Сбежался народ. Моллу привели в чувство. Оказалось, он сломал ногу. Его подняли, внесли в дом и уложили в постель. Молла огляделся по сторонам и заметил, что жена плачет. Он поднял голову и сказал ей: - Жена, не плачь. Хотя я упал и разбился, но зато желание мое исполнилось.");
INSERT INTO chat_shutnik VALUES("150","Идет мужик пьяный, смотрит - лужа, а в луже луна отражается.\n- У, сейчас на луне покатаюсь. Сел на нее и сидит. Идет милиционер, увидел мужика и спрашивает: - Эй, мужик, ты что тут делаешь? - На луне сижу.\n- Ну сиди, сиди, сейчас луноход подойдет.");
INSERT INTO chat_shutnik VALUES("151","Разговор подруг: - Ты знаешь, что женщины совершают меньше аварий, чем мужчины? - Интересно? А почему? - Потому что женщины заботятся о машине, как о муже, а мужчины относятся к ней, как к собственной жене.");
INSERT INTO chat_shutnik VALUES("152","Врач, обследовав женщину, выходит в коридор и сообщает ее мужу: - У меня для вас две новости: хорошая и плохая.\n- Давайте сначала плохую.\n- Ваша жена больна сифилисом.\n- Какой ужас! А хорошая? - Она заразилась им не от вас.");
INSERT INTO chat_shutnik VALUES("153","В компьютер заложили множество всевозможных анекдотов, чтобы тот выдал средний. Результат начинался так: \"Лежат в постели три еврея: Чапаев, Чебурашка и Поручик Ржевский...\".");
INSERT INTO chat_shutnik VALUES("154","- Вася дома? - Нет, Васи больше нету... Он покинул наш мир - Он что, умер? :-( - Нет, к интернету подключился!");
INSERT INTO chat_shutnik VALUES("155","Пpиходит женщина к вpачy.\n- Доктоp, y меня такая маленькая гpyдь. Вы не посоветyете как ее yвеличить.\n- Пpотиpайте ее ежедневно тyалетной бyмагой.\n- И что, поможет ? :-O - Hy, глядя на Вашy задницy... должно помочь.");
INSERT INTO chat_shutnik VALUES("156","Суд осудил Вас на десять лет тюрьмы,- говорит судья обвиняемому.\n- Большое спасибо, не надеялся так долго прожить.");
INSERT INTO chat_shutnik VALUES("157","Объявление: \"Для переписки секретных документов срочно требуется машинистка, не умеющая читать\".");
INSERT INTO chat_shutnik VALUES("158","- Как живешь? - спрашивают Менделя.\n- Как пуговица.\n- Как это понять? - В петлю лезть охота.");
INSERT INTO chat_shutnik VALUES("159","На экзамене по праву: -Профессор, между прочим, шпаргалка является моей собственностью, а Вы её изъяли без соблюдения соответствующей прцессуально-правовой прцедуры! -Эх,молодой человек! Я же преподователь, а не милиционер. Не могу же я лупить вас по почкам перед тем, как забрать шпаргалку!");
INSERT INTO chat_shutnik VALUES("160","Кароче, Робинзон Крузо отсидел на своём острове уже 3 года. Всё у него было - и фрукты, и вода, и хлеб: не было только бабы. И вы сами понимаете, как он удовлетворял свои потребности. И вот однажды, только он хотел с собой поиграть - вдали показался корабль. Робинзон быстро забежал на утес и стал жечь костёр и палить из мушкета. И свершилось чудо - на корабле его заметили и поплыли в его сторону. Робинзон размечтался: - Наконец-то! Сначала я приму ванну и помоюсь с мылом. Потом я выпью фунфырик рома. Затем они дадут мне красивую бабу. Я начну с ней танцевать, потрогаю её за попу, поглажу по спине, потом прикоснусь к её грудям, потом брошу её на кровать и раздену. И у неё будет кружевное бельё, и розовые чулочки на подвязках....... Тут он заметил, что у него наступила жестокая эрекция. Он быстро засунул руку в штаны и сказал: - А насчет корабля я-то пошутил! Ха-Ха-Ха-Ха.....");
INSERT INTO chat_shutnik VALUES("161","- Запомни раз и навсегда! - говорит жена мужу.- Если ты будешь приставать к горничной, я с тобой разведусь! - Из-за такого пустяка? - Ты ее разбалуешь. Пойми, такого мужа, как ты, я всегда найду, а такую горничную - вряд ли!");
INSERT INTO chat_shutnik VALUES("162","Штирлиц пришел к выводу. Но Вывода не оказалось дома.");
INSERT INTO chat_shutnik VALUES("163","Hовый русский заваливается к директору одной фирмы на работу (все как полагается - сотовый телефон,малиновый пиджак, etc). Директора нет на месте. Секретарша предлагает: - Вы телефончик оставьте, он позвонит. HР: - Да ты че, дура, ошалела, труба тыщу баков стоит!");
INSERT INTO chat_shutnik VALUES("164","Приехала Зыкина на гастроли в Грузию. Ей бурно аплодируют после каждой песни. Кончила петь - ее вызывают на бис. Спела на бис - ей аплодируют еще сильнее. Выходит она, наконец, на сцену и говорит, что репертуар исчерпан, петь нечего.\n- Зачем петь? - кричат ей из зала.\n- Ты ходи: туда ходи, сюда ходи!");
INSERT INTO chat_shutnik VALUES("165","Граница на карте обозначена точка-тире, точка-тире, что символизирует пограничник-собака, пограничник-собака.");
INSERT INTO chat_shutnik VALUES("166","Когда Рустем вернулся из Японии, где был в командировке, знакомые поинтересовались, как он там объяснялся, не зная японского языка.\n- Надо сказать, трудности бывали, - признался Рустем.\n- Вот, например, когда я хотел купить плавки и жестами объяснил, что мне нужно, продавец принес нож для харакири.");
INSERT INTO chat_shutnik VALUES("167","Урологическая операционная. Лежит больной, подготовленный к операции. Молоденькая сестричка. Входит хирург, с вымытыми руками, в стерильных перчатках: - Сестра, поправьте член.\n- Хмм..., - поправляет.\n- А теперь больному!");
INSERT INTO chat_shutnik VALUES("168","- Винтовка для солдата - лучший друг, не правда ли? - Не знаю, господин генерал! Вчера, когда я ее чистил, она выстрелила мне в ногу!");
INSERT INTO chat_shutnik VALUES("169","В больнице идет обход. Подходят к первому больному. Доктор: Что у вас? Больной: Геморрой! Д: Чем лечат? Б: Йодом мажут! Д: Продолжать! Подходят ко второму. Д: Что у вас? Б: Грибок на ногах! Д: Чем лечат? Б: Йодом мажут! Д: Продолжать! Подходят к третьему. Д: Что у вас? Б: Ангина! Д: Чем лечат? Б: Йодом мажут! Д: Продолжать! Б: Доктор, скажите сестре, чтобы мне первому мазали...");
INSERT INTO chat_shutnik VALUES("170","Жена сказала мужу: - Я очень не люблю твоих братьев. Как появятся у тебя деньги, они все тут как тут и вовсю пользуются твоей щедростью. А когда у тебя в кошельке пусто и ты сам бедствуешь, ни один из них на глаза не покажется. Муж ответил: - Они очень вежливые и не хотят доставлять мне лишних хлопот, когда нам нечем с ними поделиться.");
INSERT INTO chat_shutnik VALUES("171","- Ну что, помогла вам наша отрава избавиться от мышей? - О да, пан аптекарь! Мышам она так понравилась, что они растолстели и не смогли пролезть в нору. Наша кошка переловила их всех и съела!");
INSERT INTO chat_shutnik VALUES("172","Однажды в жаркий полдень молодой папаша вывез коляску с ребенком на улицу и стал с ней прогуливаться.\n- Послушай, Чарли! - послышалось из окна третьего этажа.\n- Оставь меня в покое, - огрызнулся муж, - у нас все в порядке. Через чес раздался тот же голос: - Чарли, Чарли... Ну, что ты хочешь? - стал ворчать муж.\n- Что там у тебя случилось? - Да нет, Чарли, ничего. Но ты вот уже больше часа катаешь в коляске куклу Ненси. Пожалуйста, погуляй немного и с ребенком...");
INSERT INTO chat_shutnik VALUES("173","Муж с женой собираются на свадьбу. Муж, понятное дело, быстренько собрался, а жена все крутится перед зеркалом, примеряет наряды. И то не так, и се не так...\n- Скорее собирайся, мы же опоздаем! Наконец вышли. Приходят к дому, где свадьбу играют, а там один пьянчужка спит под забором, а другой, еле держась на ногах, что-то лепечет. Увидев эту картину, муж сердито говорит жене: - Видишь, люди уже гуляют, а мы еще только идем!");
INSERT INTO chat_shutnik VALUES("174","Дирижер оркестра получает после концерта записку: \"Я не ябеда, но вон тот рыжий детина с усами бьет в барабан только тогда, когда вы на него смотрите!\"");
INSERT INTO chat_shutnik VALUES("175","Сказочка Жил-был мальчик. И подарил однажды этот мальчик девочке цветочек. На следующий день опять подарил, и дарил много-много дней подряд. И говорит однажды ему девочка: - Хватит херней страдать, пошли-ка лучше со мной спать! Мальчик заплакал и говорит: - Я не умею. И пошел прочь от девочки. Идет он, значит, по улице, и плачет. Тут навстречу ему - проститутка.\n- Почему ты плачешь, мальчик? - спрашивает она.\n- А мне девочка предложила с ней спать, а я не умею! - Ну ничего страшного, пошли со мной! И пошли они к проститутке домой, и научила она мальчика всем прелестям вагинального, орального и прочих видов секса. Обрадованный мальчик радостно выбежал на улицу и побежал к своей девочке. Прибегает, а девочка уже спит с другим мальчиком. Наш мальчик опять заплакал и пошел на почту.\n- Отправьте телеграмму.\n- сказал он тетеньке в окошке.\n- Какую? - спросила тетенька.\n- \"Мама, я больше не приду домой, я теперь буду жить своей особенной жизнью!\" - продиктовал мальчик.\n- А как тебя звать-то, мальчик? - спросила тетен");
INSERT INTO chat_shutnik VALUES("176","Интеллигентного вида мужчина садится в такси. Диалог с таксистом: - Вы не могли бы подбросить меня в аэропорт, только нужно на минуточку заскочить на базар? - Без базару! - Да? Ну тогда сразу в аэропорт...");
INSERT INTO chat_shutnik VALUES("177","- Куда девать пенсионеров? - поступают в центр вопросы с мест. Из центра шлют циркуляры: \"У кого трясутся руки из стороны в сторону посылать на мельницу сеять муку. У кого вертится голова направлять в торговлю. У кого трясется голова того сажать в президиум. Ожил Ленин и попросил подшивку газеты \"Правда\" за последние 70 лет. Читает: ЄПрием в Кремле Є3автрак в Кремле ЄОбед в КремлеЄ - Что же вы мне дали? - возмущается Ленин, Это же меню!");
INSERT INTO chat_shutnik VALUES("178","Служанка: - Извините, пожалуйста, но миссис Браун велела сказать, что ее нет дома. Гостья: - Ничего, ничего, голубушка. В таком случае передайте ей, что я очень рада, что не приходила.");
INSERT INTO chat_shutnik VALUES("179","Гpабитель на улице обpащается к хоpошо одетой женщине: - Деньги, мадам! Да поживее! Подумайте, что будет, если стpуя из этого водяного пистолета pазмоет косметику на вашем лице.");
INSERT INTO chat_shutnik VALUES("180","Шотландец и его сын в традиционных юбках идут по Эдинбургу. Навстречу - девушка в брюках. Отец - сыну: - Сколько тебе повторять - не оглядывайся на каждые брюки!");
INSERT INTO chat_shutnik VALUES("181","- Какой смысл вкладывается в выражение \"не тяни кота за хвост\"? - Сколько кота не тренируй, он ящерицей не станет!");
INSERT INTO chat_shutnik VALUES("182","- Доктор, - говорит ассистент, - пациент из второй палаты Иванов скверно себя чувствует.\n- Надо говорить: пациент Иванов думает, что он скверно себя чувствует. Это новейший взгляд на сущность болезней. На следующий день ассистент говорит врачу: - Доктор, больной Иванов думает, что он умер.");
INSERT INTO chat_shutnik VALUES("183","Шла мышка по темному лесу. И чтоб ей не было так страшно она пела песенку: - \"ЛА-ЛА-ЛА-ЛА\" (исполнять громко и страшно).");
INSERT INTO chat_shutnik VALUES("184","Утром...\n- Я жених... я женихххх... я же ниххххрена не помню...");
INSERT INTO chat_shutnik VALUES("185","Деревенский мальчик кричит: - Мама, там молочник пришел. Ты ему деньги отдашь или мне пойти погулять?");
INSERT INTO chat_shutnik VALUES("186","Встречаются два друга.\n- Как твои дела? - Да вот подозреваю, что моя жена мне изменяет с пекарем. Каждый раз раскрывая постель, обнаруживаю в ней хлебные крошки.\n- А..а..а. Теперь и я начинаю подозревать, что моя жена мне изменяет со слесарем из нашего ЖЭКа.\n- Ты что, инструменты в постели находишь? - Да нет. Понимаешь, как ни приду домой, так слесарь лежит в нашей постели.");
INSERT INTO chat_shutnik VALUES("187","Новая Шаума сделала мои волосы такими объемными, что даже ширинка не застегивается!!!");
INSERT INTO chat_shutnik VALUES("188","- Какие герои вышли из книги в реальную жизнь? - Гайдар и его команда!");
INSERT INTO chat_shutnik VALUES("189","Парень повредил палец на руке и пришел к врачу. Врачиха говорит: - Раздевайтесь. Парень: - Зачем? Я ведь всего лишь повредил палец. Мужской голос из-за ширмы: - Это что! Я вообще пришел телефон починить!");
INSERT INTO chat_shutnik VALUES("190","Идут два программера, мими них проходит обалденно красивая девушка. Оба провожают ее взглядом. Идут дальше... Первый: - Да... Плохо, что у девушек нету стандартного интерфейса. Второй: - Ошибаешься! Стандартный интерфейс у них как раз-то есть! Первый: - Действительно. И все же жаль, что не существует стандартного способа этот интерфейс получить.");
INSERT INTO chat_shutnik VALUES("191","20-летняя бабёнка вышла замуж за 90 летнего дедка. После первой брачной ночи она вышла из спальни еле передвигая ноги, вся разбитая и усталая.\n- Господи, что он с тобой сделал?! - спрашивает мать.\n- Он говорил мне, что копил 75 лет... Но я думала, что он имел ввиду деньги.");
INSERT INTO chat_shutnik VALUES("192","Два грузина смотрят фильм: Альпинист лезет на гору из последних сил, лезет, останавливается, опять лезет.\n- Слушай, Гоги, давай поспорим на 1000 баксов, что он не залезет? - Да ты что? Я знаю, он залезет! Поспорили. Альпинист все-таки взобрался. Первый: - Ну, Гоги, ты выиграл, забирай деньги, я проиграл, ты был прав.\n- Слушай, Вано, ну как так можно, ты же мой друг, я не могу взять деньги у друга... К тому же я уже смотрел этот фильм раньше.\n- Ну и что, я тоже смотрел этот фильм раньше, но был уверен, что второй раз точно не залезет!");
INSERT INTO chat_shutnik VALUES("193","- Э, слущай, я себе \"СУПЕРМАЗ\" купил! - А зачэм тэбэ \"СУПЕРМАЗ\"? - Ну как!? Памазал - все праходыт!");
INSERT INTO chat_shutnik VALUES("194","Чувство вины мучило доктора Х. весь день. Как ни пытался он забыть об этом, ничего не получалось. Нервы напряглись до предела. Но время от времени звучал этот подбадривающий внутренний голос: Да не переживай ты так. Ты не первый и не последний врач, который сношается с пациентами. Но тут же неизменно второй, подленький такой голос возвращал его в реальность: Но ты же все-таки ветеринар...");
INSERT INTO chat_shutnik VALUES("195","Возле стройки тормозит \"Мерседес\", из окошка высовывается новый русский и предлагает рабочим: - Мужики, нужен рубероид, даю сотню баксов! Что еще можете толкнуть? Те ошалели от неожиданности: - Все! Кирпич, цемент, стекло, прораба.");
INSERT INTO chat_shutnik VALUES("196","Чебурашка прибегает к крокодилу Гене: - Шапокляк родила! Беги к ней скорее - я своих утопил, а твои плавают!");
INSERT INTO chat_shutnik VALUES("197","На радио Эхо Москвы: - Сегодня, 22 апреля, солнце взошло в 6 утра, погода +12 градусов. Теперь кто из знаменитостей родился в этот день... Хм..., так, ну кто родился, все и так знают, а кто не знает, тем лучше и не надо...");
INSERT INTO chat_shutnik VALUES("198","Диктатору на заметку: если Вы хотите, чтобы все люди жили в одном большом концлагере, уделите должное внимание защите государственной границы.");
INSERT INTO chat_shutnik VALUES("199","Состоялась защита кандидатской диссертации на тему: \"Введение спиртного через задний проход\". Диссертант научно доказал, что этот способ имеет преимущества перед обычным: мало нужно, чтобы опьянеть;можно без закуски;изо рта не пахнет. Оппонент задал вопрос, как при этом способе выпивать на брудершафт.\n- Это тема моей докторской, - ответил диссертант.");
INSERT INTO chat_shutnik VALUES("200","- Смотри, какие тени длинные, и облака тяжелые...\n- Длинные, потому что уже поздно, а тяжелые, потому что мы уже пятый день пьем...");
INSERT INTO chat_shutnik VALUES("201","Знаменитая киноактриса: - А теперь хватит говорить обо мне. Поговорим о вас. Расскажите мне, как я понравилась вам в моем последнем фильме.");
INSERT INTO chat_shutnik VALUES("202","Продам китайский гарнитур из одиннадцати предметов - две циновки и девять портретов Мао Цзедуна.");
INSERT INTO chat_shutnik VALUES("203","Таможенник на границе входит в купе: - Коньяк? Табак? Наркотоки? - Чашечку кофе, пожалуйста.");
INSERT INTO chat_shutnik VALUES("204","Всем известна история о русском мастере Левше, подковавшем аглицкую блоху. Но почему-то история умалчивает о другом мастере Мойше, сделавшем той самой блохе обрезание.");
INSERT INTO chat_shutnik VALUES("205","- Вы помните Нухима Спивака? Когда 20 лет назад он приехал в Америку, у него была только пара рваных штанов. Сейчас он имеет миллион! - Господи! Что будет делать этот ненормальный в Америке с миллионом рваных штанов!?!");
INSERT INTO chat_shutnik VALUES("206","Лежат парень с девушкой в постели. Она(томно): - Трахни меня! Он(напряженно): - Уже трахаю! -=Nail=-");
INSERT INTO chat_shutnik VALUES("207","Школьница спрашивает у матери: - Мама, скажи мне, что такое пятилетка? - Пятилетка, дочка, это трудовой порыв. Через пять лет в стране всего станет в пять раз больше! - Всего-всего? - Да, дочка, и мы в пять раз будем жить лучше! В школе учительница задает вопрос: - Дети, скажите, что такое пятилетка? Желая блеснуть знаниями, ученица подняла руку.\n- Пятилетка - это трудовой порыв, когда всего становится в пять раз больше - и хлеба, и масла, и людейЄ Увидела в окно - покойника везут.\n- ЄИ покойников, и воров, и нищих, и двоечников.");
INSERT INTO chat_shutnik VALUES("208","Хоpонят авторитета. К гpобу очеpедь попpощаться. Один мужик подходит, пpипадает и долго-долго не может отоpваться от усопшего. Его подталкивют, мол, пpоходи, видишь, сколько наpоду еще. А мужик: - Погодите вы, я с бодуна, а он такой холодненький...");
INSERT INTO chat_shutnik VALUES("209","- Почему твой муж часто уходит по вечерам из дому? - спрашивает подруга.\n- Бедняжка, он не любит сидеть дома один.");
INSERT INTO chat_shutnik VALUES("210","Мужчина стоит на набережной и бросает монеты в воду.\n- Что случилось? - удивленно спрашивает прохожий.\n- У меня упала в канал монета.\n- Но для чего вы бросаете туда другие монеты? - Чтобы не лезть в воду ради одной.");
INSERT INTO chat_shutnik VALUES("211","Шел мимо крутой усадьбы бродяга, и потянуло его на халяву.\n- А я так просто не подаю, мужик! - заявил хозяин, лениво развалившись в шезлонге с журналом.\n- Хочешь деньжат - заработай! Вон, пойди на задний двор, там найдёшь краску и покрасишь мне забор... Бомж поплёлся за особняк. А хозяин продолжил листать «Плейбой», да так увлекся, что совсем забыл о «маляре». Опомнился он только тогда, когда тот постучал его по плечу.\n- Закончил я! - бодренько сообщил бродяга, потирая руки.\n- Только вы мне неправильно сказали: у вас там не «Запор», а BMW.");
INSERT INTO chat_shutnik VALUES("212","- Что за кривоногая девчонка была с тобой сегодня утром? - спросил один студент другого.\n- Это та со стройными ножками, с которой ты познакомил меня вчера вечером.");
INSERT INTO chat_shutnik VALUES("213","На вокзале в Риме провинциального вида старушка подходит к окошку кассы и спрашивает, сколько стоит билет на Палермо.\n- Десять тысяч лир, синьора. Старушка оборачивается к своей спутнице и говорит: - Придется, видимо, купить. Я уже спрашивала во всех кассах, и всюду цена у них одинаковая. Не иначе, как договорились...");
INSERT INTO chat_shutnik VALUES("214","- Пани Ковальская, очень прискорбно, но мы вынуждены сообщить, что ваш муж скончался прямо на работе. Пани Ковальская продолжает спокойно обедать.\n- Разве вы не слышите - ваш муж умер! - Слышу, слышу! Подождите, вот я сейчас закончу, тогда вы увидите, какая со мной будет истерика!");
INSERT INTO chat_shutnik VALUES("215","Российскими ученными было доказано, что смешивание водки с молоком приводит к раздражению желудочно-кишечного тракта вследствие недостаточно изученных свойств молока.");
INSERT INTO chat_shutnik VALUES("216","У генерала родился внук. Чтобы узнать, на кого он похож, генерал посылает в роддом адъютанта.\n- На вас! - радостно сообщает вернувшийся адъютант.\n- Вот это да! Докладывай детали! - Внучок ваш лысый, пузатый, ничего не соображает и все время орет.");
INSERT INTO chat_shutnik VALUES("217","В метро едут два парня, а напротив - две девушки. Один парень говорит другому: - Ну что, познакомимся с подругами? - Почему нет? - Ну и отлично. Твоя, правда, страшноватенькая...");
INSERT INTO chat_shutnik VALUES("218","Однажды в Сенате Разумовский отказался подписать решение, которое считал несправедливым.\n- Государыня желает, чтоб дело решено было таким образом,- объявили ему сенаторы.\n- Если так - не смею ослушаться,- сказал Разумовский и подписал свою фамилию \"вверх ногами\". Этот поступок сразу же стал известен императрице, та потребовала объяснений.\n- Я исполнил вашу волю, но так как покривил совестью, то и подпись моя кривая.");
INSERT INTO chat_shutnik VALUES("219","Выходит пеpвый мощный MEN - ТААКОЙ КРУТООЙ ! Снимает доpогенный плащ, достает pоскошный лук и БАЦ !!! Попал в самую точку, не задев добpовольца! Все:\"ООООО\". Мужик:\"I`m ROBIN GOOD\" и удаляется.");
INSERT INTO chat_shutnik VALUES("220","Альпинист покорил вершину. В восторге он стоит наверху и кричит: - Ура, я первый! Эхо доносит: \"Не первый! Не первый!\" Он снова кричит... А эхо снова: \"Не первый! Не первый!\" Альпинист: - Кто это со мной разговаривает? Из-за гребня к нему подходит седенький старичок.\n- Сынок! Это я с тобой разговариваю! - Дедушка, а ты кто? - Я? Волшебник! - И ты можешь выполнить три моих желания? - Конечно! Загадывай! - Во-первых, хочу чтобы у меня был миллион рублей денег! Во-вторых, чтобы моей женой стала \"мисс СССР\"! В третьих, хочу быть не здесь, а дома, в своей квартире! - Хорошо, сынок! Я исполню все три твои желания, если ты исполнишь одно мое? - Какое, дедушка? - Отсоси у меня! - А если я не захочу? - Тогда и твои желания не исполнятся! Альпинист подумал: \"Так уж быть! Ради своих желаний можно и пойти на уступки, тем более, что нас никто не видит... \" - Ладно, дедушка, давай! Взял в рот, сосет. Старичок нежно гладит его по голове: - Такой большой, а в сказки веришь!");
INSERT INTO chat_shutnik VALUES("221","Долго думали в армии, куда чукчу пристроить, и определили в пожарники. Через неделю начальник расчета приходит к начальнику пожарной части: - Опять у нас с чукчей ЧП.\n- Мать вашу етить! сколько раз уже говорил вам, чтоб технику безопасности соблюдали! - Так мы соблюдаем. Вон, ему на верхушке лестницы прибили плакат - СТОП! - Ну и чего ж? - Так он, оказывается, читает медленно.");
INSERT INTO chat_shutnik VALUES("222","Учительница спрашивает: - Петенька, кем ты хочешь стать, когда вырастешь? - Врачом.\n- Молодец. А ты, Ванечка? - Юристом.\n- Умница. А ты, Вовочка? - А я хочу стать придурком.\n- Почему придурком?! - Потому что когда мы с папой выходим из дома, он все время говорит: \"Роскошный дом у этого придурка!\" Или: \"Клевая тачка у этого придурка!\"");
INSERT INTO chat_shutnik VALUES("223","Двое кавказцев играют в шахматы. Один ставит ферзя на центр поля: - Мат! Другой ставит своего рядом: - Отэц!");
INSERT INTO chat_shutnik VALUES("224","- Я слышал, Пол Маккартни к нам приезжает. Будет выступать на Красной площади.\n- А ну его, не пойду.\n- Почему? - Пол без Джона - деньги на ветер.");
INSERT INTO chat_shutnik VALUES("225","Сидят две вороны на дереве.\n- Какие все-таки люди неблагодар-р-рные! - Мы их о дожде пр-редупреждали - предупреждали, а они говорят, что мы его накар-р-ркали!");
INSERT INTO chat_shutnik VALUES("226","Слуга обращается к лорду: - Сэр, осмелюсь доложить, что на кухне некоторым образом возник пожар. Хозяин дома медленно отложил \"Таймс\" и сказал: - Сообщите это леди. Вы же знаете, Робинс, что я не занимаюсь домашним хозяйством.");
INSERT INTO chat_shutnik VALUES("227","Сенбернары - это такие собаки, которые живут в Альпах, они зимой ищут потерявшихся лыжников... тем и живут.");
INSERT INTO chat_shutnik VALUES("228","Штирлиц заходит в кабинет Мюллера, смотрит, Мюллер сидит в фуфайке и играет на балалайке.\n- Группенфюрер, что с вами? - удивился Штирлиц.\n- Полноте вам, Штирлиц, не вы один по Родине скучаете.");
INSERT INTO chat_shutnik VALUES("229","Мужик приходит в кабак.\n- Я здесь вчера сидел.\n- Да.\n- Я всю зарплату пропил? - Да.\n- Фу ты (облегченно вздыхая) Думал потерял.");
INSERT INTO chat_shutnik VALUES("230","Встретились как-то три бывшие шлюхи-пенсионерки: Первая шлюха: - Когда я занималась проституцией, я получала всего лишь 20 баков за минет. Вторая шлюха: - Ну это не так уж плохо, мне в свое время платили за это только 10 баков. Третья шлюха слушала, слушала и тоже решила высказаться: - Я занималась проституцией во время Великой Депресии и делала минет за так - лишь бы набить живот чем-нибудь теплым.");
INSERT INTO chat_shutnik VALUES("231","- Потерпевший, вы напились до такой степени, что упали в оркестровую яму.\n- Гражданин следователь, каюсь - я попал в нехорошую компанию. На троих была одна бутылка водки, и никто, кроме меня, не пил.");
INSERT INTO chat_shutnik VALUES("232","Hа пеpвую годовщину Чеpнобыля все киевские евpеи получили по 2 юбилейных медали: (1-я) За освобождение Киева (2-я) За взятие Одессы.");
INSERT INTO chat_shutnik VALUES("233","Мужской возраст: 1. Взялся за грудь и... поел 2. Взялся за грудь и... кончил 3. Взялся за грудь и... возбудился 4. Взялся за грудь и... уснул");
INSERT INTO chat_shutnik VALUES("234","Сидят два мужика и ловят рыбу. А один грустный такой. Друг его спрашивает: - Что случилось? - Да у жены день рождения был, а я забыл поздравить. Посидели, помолчали. Тут друг успокаивать начал: - Знаешь, я тебе сейчас всё объясню. Ты вот, например, помнишь день, когда ты поймал самую большую рыбу? - Конечно, помню! - Так вот, а рыба - не помнит!");
INSERT INTO chat_shutnik VALUES("235","Мужик в подавленном состоянии приходит к психиатру и жалуется: - Доктор, помогите, я никогда не пользовался успехом у женщин, они от меня разбегаются, а ведь мне уже 35 лет, я больше не могу так жить! - Успокойтесь, эта проблема на самом деле легко решается, просто вам необходимо вырабатывать уверенность в себе. Каждое утро вставайте перед зеркалом, оглядывайте себя с ног до головы и повторяйте: я уважаемый человек, люди мною восхищаются и завидуют мне, я сильный и чертовски привлекательный. Поверьте мне, как только у вас появится уверенность в себе, женщины так и будут липнуть к вам. У пациента заметно улучшается настроение, и он уходит. Но через неделю он снова приходит подавленным. Психиатр спрашивает: - Вы не последовали моему совету? - Последовал, и все получилось именно так как вы сказали.\n- Так в чем же тогда у вас проблема? - Да это не у меня, это у жены проблема.");
INSERT INTO chat_shutnik VALUES("236","Встретились как-то грузин и американец. Спорят, кто лучше живет.\n- У нас каждый американец имеет квартиру отдельную - У нас кажадый грузин имеет большой коттедж.\n- У нас каждый американец имеет машину.\n- А у нас каждый грузин имеет самолет.\n- Слушай, а что ты все про грузин да про грузин? А русские-то у вас как живут? - Я же у тебя про негров не спрашиваю...");
INSERT INTO chat_shutnik VALUES("237","- Слышал, говорят, что на рынке уже можно купить говядину по рублю за килограмм.\n- Ну, это вранье! - Пускай, лишь бы дешево!");
INSERT INTO chat_shutnik VALUES("238","Сидят чукчи у моря.\n- Смотри, самолет полетел! - Да-а-а! Наверное правительственный.\n- Нет.\n- Почему? - Мотоцикла впереди нету!");
INSERT INTO chat_shutnik VALUES("239","Заходит в купе парень без уха и смеется! Его спрашивают: - Ты что? Ухо потерял - плакать нужно! - Что там ухо! На свадьбе драка была! Мне ухо оторвали, а член жениха - вот, у меня в кармане!");
INSERT INTO chat_shutnik VALUES("240","На скамье в парке сидит человек и, с негодованием глядя на идущего мимо пьяного, говорит: - Безобразие! Я бы вылил весь мировой запас спиртного в океан! Сидящий рядом мужчина аплодирует: - Браво! Отличная идея! - Вы тоже трезвенник? - Нет, я водолаз...");
INSERT INTO chat_shutnik VALUES("241","- Карлссон, опять щенок в углу насрал...\n- А где ж ему срать, на шкафу, что ли? Так только я могу!");
INSERT INTO chat_shutnik VALUES("242","- Мой муж хочет, чтобы я поступила на кулинарные курсы.\n- Вот как! А я и не знала, что вы приобрели собаку.");
INSERT INTO chat_shutnik VALUES("243","Стали Винни с Пятачком альпинистами. Ползут по стене.\n- Винни, Винни я прополз 15 метров и не вбил ни одного крюка.\n- Бей шлямбур, толстая свинья.\n- Но Винни, если я его забью он испортится.\n- Если ты его не забьешь, то испортимся мы оба.");
INSERT INTO chat_shutnik VALUES("244","После жуткого перепоя просыпается утром тетка. Во рту - кошки насрали, под глазами - черные круги, волосы торчком. Смотрит на себя в зеркало и говорит: - Я тебя не знаю, но я тебя накрашу.");
INSERT INTO chat_shutnik VALUES("245","Реальная история (вот так анекдоты и размножаются). Приятели заказали другу на день рождения семь девочек по вызову (ну процветает разврат среди молодежи, процветает!). Отметили отлично. На следующий день стадия \"разбор полета\". Довольный именниник благодарит: - Да, спасибо, все было классно, только я всего пятерых смог, но я же здорово пьяный был. А вот если бы трезвый был, то я бы, конечно, больше смог...\n- Знаешь, если б ты был трезвый... ТЫ БЫ НИ ОДНУ ИЗ НИХ НЕ СТАЛ!!!");
INSERT INTO chat_shutnik VALUES("246","Лукашенко перед вылетом в Москву на встречу с Путиным: «Я рад, что госпожа Райс, пролетая над Белоруссией, могла убедиться, что терроризма в ней нет. Никто ракеты по ней не выпустил». А руки так чесались...");
INSERT INTO chat_shutnik VALUES("247","Пожелание врагу: -Чтобы я увидел тебя на костылях, а ты меня одним глазом!");
INSERT INTO chat_shutnik VALUES("248","Тесть и зять работают на одной шахте, но в разные смены. Видятся только когда одного поднимают, а другого опускают в забой. Как-то раз происходит следущее... Поравнявшись в своих подъемниках и увидев друг друга, зять крутит пальцем около виска. Тесть, в ответ, крутит обеими пальцами у своих висков. Зять - резко сгибает одну руку в локте, а другой перекрещивает согнутую. Тесть - вытягивает одну руку, а другой бьет себя по ней в области плеча и показывает на свой зад. Народ - в шоке... Старый шахтер говорит зятю: - Что же ты со своим тестем никак общий язык не найдешь? Я его столько лет знаю - мужик просто замечательный! - Да вы ничего не поняли! - отвечает зять, - У нас великолепные отношения! Я его спросил знаком: \"Моя дура дома?\" - он ответил знаком: \"Обе - дома\". Дальше я его спросил: \"0,5 есть?\", на что он ответил: \"Есть 0,7 и стоит за унитазом!\" Вообще-то, этот анекдот надо показывать.");
INSERT INTO chat_shutnik VALUES("249","Просыпаются утром отец и сын.\n- А что, сынок, неплохо бы нам с тобой сейчас принять по сто грамм.\n- Дело говоришь, батя, дело. Сбегал сын в магазин, принес водки. Посидели, выпили.\n- Hу что, сынок, неплохо бы нам еще по-немногу? - Дело говоришь, батя, дело! Сбегал, еще принес. Выпили.\n- Hу что, сынок, теперь и поработать можно? - Hу, батя, ты как выпьешь - такую фигню нести начинешь!");
INSERT INTO chat_shutnik VALUES("250","С того времени, как нашего соседа сняли с должности генерального директора, он растерял половину своих друзей.\n- А как та... вторая половина? - Они еще не знают об его отставке.");
INSERT INTO chat_shutnik VALUES("251","Адвокат(А): - Итак, утром,25 июля, Вы шли со своей фермы по направлению к пастбищу? Свидетель(С): - Да. А: - Значит, Вы прошли всего в нескольких метрах от водоема с утками? С: - Да. А: - Заметили ли Вы что-то необычное? С: - Да. (Молчит) А: - Могли бы Вы сообщить суду, ЧТО Вы видели? С.\n- Я увидел Джорджа. А: - Вы увидели Джорджа.....обвиняемого в данном случае? С: - Да. А: - Могли бы Вы сказать суду, что Джордж...э.э.э.э....делал в это время? С: - Да. (Молчит) А: - Ну, ну, так что же он делал? С: - Ну....он засунул свою...э.э.э.... штучку....в одну из уток. А: - Свою \"штучку\" ? С: - Ну....Вы знаете...ну, штучку....свой ху......ну....свой пенис. А: - Итак, Вы проходили возле пруда, было уже светло, Вы были совершенно трезвы, у Вас хорошее зрение и Вы все это видели совершенно четко? С: - Да. А: - Сказали ли Вы что-нибудь Джорджу? С: - Разумеется! А: - И ЧТО Вы ему сказали?!! С: - Доброе утро, Джордж.");
INSERT INTO chat_shutnik VALUES("252","Один чудак в гостинице спрашивает номер, ему отвечают: \"Нет, мол, номеров\". А он ну очень упрашивает - ну хоть каморку какую-нибудь. Ему и говорят: - Ну ладно, есть один люкс, но у него слава дурная, там уже восемь человек повесилось. Чудак в ответ: - Я не суеверный. Отводят его в номер, показывают ему все, а он спрашивает: - А как, мол, повесились-то? - Все вот на этой дверной ручке.\n- Не может быть! - Да вот, уж, смогли. Утром уборщица открывает дверь - мужик висит на ручке двери, мертвый.\n- Елки зеленые, еще один любопытный.");
INSERT INTO chat_shutnik VALUES("253","Звезда Голливуда говорит своей приятельнице: - Я купила тебе в подарок книгу. По-моему, это учебник танцев под названием \"Оливер Твист\".");
INSERT INTO chat_shutnik VALUES("254","Пришел наркоман к стоматологу и говорит: - Доктор, вырвите мне зуб.\n- Вам под местным или под общим наркозом? - Что, одурел!? Под общим, конечно! И так 32 раза...");
INSERT INTO chat_shutnik VALUES("255","Песня пилота самолета МИГ, занимающегося сексом с девушкой за штурвалом самолета: Чем дорожу, чем рискую на Свете я, МИГом одним, только МИГом одним...");
INSERT INTO chat_shutnik VALUES("256","Конец мая. Училка на последнем в учебном году классном часе: - Дети, что для вас тpуднее всего было в 3-м классе? - Объяснять пpодавщице для кого покупается водка!!!");
INSERT INTO chat_shutnik VALUES("257","В троллейбусе едут два друга. Один рассказывает анекдот другому: - Ты, говорит, знаешь, почему менты всегда по трое ходят? Один имеет читать, второй писать, а третий следит за этими интеллектуалами! Тут с задней площадки протискиваются два мента. Предъявите, мол, документы и все такое... Один берет паспорт и говорит другому: - Вась, записывай...");
INSERT INTO chat_shutnik VALUES("258","Волк поймал Красную Шапочку в лесу.\n- Я тебя съем, - говорит. Красная Шапочка: - Не надо меня есть, я еще такая маленькая. Лучше вые@и меня. Волк подумал, подумал: - Ну ладно, говорит, только ты меня обеими руками за уши держи.\n- А у тебя там что, эрогенные зоны? - Да нет, просто знаю я вас, таких... Вечно по карманам шарите.");
INSERT INTO chat_shutnik VALUES("259","Мне сказали, Что от веснушек можно избавиться, если опустить лицо в муравейник на 5-6 минут.");
INSERT INTO chat_shutnik VALUES("260","- Ну, что? Опять вчера дома выволочка была? - Не то слово. На порог не пустила. В подъезде ночевал.\n- Чудак. Ты, прежде чем позвонить, разденься догола. А как она дверь откроет, бросай туда свои шмотки. Голого не оставит в подъезде. На другой день.\n- Ну как, пригодился мой совет? - Все сделал, как ты говорил. Двери открылись, я бельишко туда - шварк! Тут она чужим голосом громко говорит: \"Осторожно, двери закрываются. Следующая станция \"Маяковская\".");
INSERT INTO chat_shutnik VALUES("261","Ноги позволяют мужчине идти, а женщине еще и продвигаться.");
INSERT INTO chat_shutnik VALUES("262","- Девушки 90-60-90! Hе ищите пpиключений на свои 90!");
INSERT INTO chat_shutnik VALUES("263","Преподаватель автошколы спрашивает у студентов, сколько дел может одновременно делать водитель? Они начали перечислять: - 2 дела- управлять автомобилем и говорить по мобильнику.\n- 3 дела- управлять автомобилем, говорить по мобильнику и слушать музыку.\n- 4 дела- управлять автомобилем, говорить по мобильнику, слушать музыку и жевать бутерброд.\n- 5 дел- управлять автомобилем, говорить по мобильнику, слушать музыку, жевать бутерброд и отливать в памперсы... Ну, вроде все! Преподаватель: - Нет! Вы забыли еще одно дело.\n- Какое?! - Давить пешеходов!");
INSERT INTO chat_shutnik VALUES("264","Три проститутки сидят в баре, и одна жалуется остальным: - Сегодня неудачный день... Я заработала всего $100 -взяла в рот 4 раза по $50, а половину забрал сутенер... Другая отвечает ей: - Это еще ничего - я сегодня заработала $50 - всего 2 минета по $50, и тоже половину сутенеру... Сидящая рядом старая проститутка заявляет: - Вы не знаете, что такое плохая жизнь... Во времена Великой Депрессии мне иной раз приходилось по 10 раз в день делать минет бесплатно, только для того, чтобы иметь в пищу что-нибудь горячее...");
INSERT INTO chat_shutnik VALUES("265","Объявление о приеме на работу. Условия: Два дня работаешь, пять лет сидишь, зарплата сдельная.");
INSERT INTO chat_shutnik VALUES("266","Один умелец сделал часы, которые при произнесении матерного слова спешат на одну минуту. Для испытания повесили часы в детском саду, в училище, и в воинской части. Через месяц решили проверить результаты эксперимента. В детском саду часы ушли вперед на 10 минут, в училище - на полчаса. Пришли в воинскую часть - часов нет! Спросили у дневального: - Куда часы подевались? - Какие часы?! А... этот вентилятор командир приказал снять на следующий же день.");
INSERT INTO chat_shutnik VALUES("267","В 30-е годы мужик заполняет анкету и дошел до вопроса \"Как спите с женой ?\" Что писать? Напишешь \"слева\" - пришьют левый уклон. \"Справа\" - правый уклон. \"Сверху\" - возвышение над массами. \"Снизу\" - идешь на поводу у масс. Написал: \"сплю отдельно, занимаюсь онанизмом\". Ему дали 10 лет \"за кулацкий уклон и растрату семенного фонда\".");
INSERT INTO chat_shutnik VALUES("268","Если, проснувшись с глубокого похмелья, вы взглянули в зеркало и никого там не увидели - значит, вы стали просто неотразимы.");
INSERT INTO chat_shutnik VALUES("269","- Почему в Люксембурге не любят играть в футбол? - Очень неудобная игра: посильнее ударил по мячу и за ним надо бежать то в Бельгию, то в Германию, а то и во Францию... jonas");
INSERT INTO chat_shutnik VALUES("270","Человек приходит к директору завода и спрашивает: - Вам нужен начальник отдела кадров? - Нет.\n- А зачем вы его тогда держите?");
INSERT INTO chat_shutnik VALUES("271","Hовый русский на \"Мерседесе\" на огромной скорости въезжает в небольшой городок. Его тут же останавливает инспектор и говорит: - С вас штраф за превышение скорости свыше 30 километров в час в размере 500 рублей.\n- Hа тебе тысячу без сдачи - я на такой же скорости хочу покинуть ваш гнусный городишко!");
INSERT INTO chat_shutnik VALUES("272","Певичка была заранее уверена в своем успехе: - Пусть только попробуют плохо аплодировать - я буду петь песни о Сталине!");
INSERT INTO chat_shutnik VALUES("273","- Папа, мы евреи? - Нет, сынок.\n- А когда будем?!");
INSERT INTO chat_shutnik VALUES("274","- Дети! Я сейчас проходила мимо столовой и видела на полу булку хлеба. Кто-то бросил хлеб на пол и играл им в футбол. А вы знаете, сколько он стоит?! Да он полторы штуки стоит! Довели страну, реформаторы хреновы!");
INSERT INTO chat_shutnik VALUES("275","Пожилая женщина сделала молодежную стрижку и спрашивает мужа: - Дорогой, правда, я теперь не похожа на старуху? - Да, ты теперь похожа на старика.");
INSERT INTO chat_shutnik VALUES("276","Российский политик перед выборами: - Мой конкурент, находясь при власти, бессовестно обворовывал вас все эти годы! Все, о чем я вас прошу сегодня , это дать мне шанс!");
INSERT INTO chat_shutnik VALUES("277","В зоопарк сам прилетел попугай. Хочу, говорит, у вас поселиться. Ну, звери его обступили, говорят, рассказывай, как случилось такое, чтоб кто-то сам явился жить в зоопарк. Попугай говорит, это долгая история. Я 10 лет жил у одного дрессировщика. Мы выступали в разных цирках с большим успехом, потому что я умел имитировать самые разные голоса и звуки. Я подражал паровозному гудку, клаксонам машин, тиканью ходиков, крикам льва, мурлыканью кота, воплям обезьян... Но потом я состарился, и мне стало уже трудно заниматься этим ремеслом. Контракты прекратились. Нам просто стало нечего есть. И однажды вечером мой хозяин затопил печь, посмотрел на меня долгим взглядом и сказал: - Ну чего, братан, сымитируй крик фазана.");
INSERT INTO chat_shutnik VALUES("278","Телефонный звонок.\n- Позовите, пожалуйста, Рабиновича.\n- Его нет.\n- Он на работе ? - Нет.\n- В командировке ? - Нет.\n- В отпуску ? - Нет.\n- Я вас правильно понял ? - Да !");
INSERT INTO chat_shutnik VALUES("279","Приводит Дочь(Д) Нового Русского(НР) домой жениха-Выпускника семинарии.(В) (НР)с ним наедине: (НР)-Ты знаешь,моя дочь любит каждые три месяца отдыхать за границей!Что ты будешь делать? (В)-Боженька поможет. (НР)-А шубы она меняет как перчатки!Что будешь делать? (В)-Боженька поможет. (НР)-И машины меняет одну за другой...Что будешь делать? (В)-Боженька поможет. Короче на все вопросы отвечал-Боженька поможет! После его ухода,дочь спрашивает отца: (Д)-Пап,ну как он тебе? (НР)-Да так себе...Но то,что он меня Боженькой называет,мне нравится!!! :)");
INSERT INTO chat_shutnik VALUES("280","Троллейбус. Контроллер: - Ваш билет.\n- А ты кто такой? - Контроллер. [Громко, на весь троллейбус] - А! Контроллер! [Все щелкают компостерами]");
INSERT INTO chat_shutnik VALUES("281","- Вчера на меня напал бандит, но я даже не заявил в полицию.\n- Почему же? - Он обшарил все мои карманы, вздохнул и дал мне доллар.");
INSERT INTO chat_shutnik VALUES("282","У окулиста: - Доктор, у меня после свадьбы начались проблемы со зрением: я не вижу денег !");
INSERT INTO chat_shutnik VALUES("283","Молодая девушка в день своего совершеннолетия получает нарядное вечернее платье.\n- Мама, что это за материал? - Разве ты не видишь, это шелк.\n- Смотри, какая прелесть. И это все от маленького, никудышного червячка? - Как тебе не стыдно называть так своего собственного отца!");
INSERT INTO chat_shutnik VALUES("284","Из сообщений \"Дорожного патруля\". В лесопарковой зоне Михино было найдено тело с документами на имя гражданина К. Неожиданное осложнение в работу прибывших на место происшествия сотрудников милиции внесло то обстоятельство, что сам гражданин К. решительно отказался признавать свое тело и потребовал вызвать для опознания супругу, находящуюся в данное время в служебной командировке.");
INSERT INTO chat_shutnik VALUES("285","Социологический опрос: \"Как военное положение влияет на семейную жизнь?\" Самый популярный ответ: \"Очень хорошо! а) Жена в противогазе молчит все время. б) Лица жены я под противогазом не вижу. в) А если находясь в постели дырочку в баллоне заткнуть, то она даже пошевелиться может\".");
INSERT INTO chat_shutnik VALUES("286","- Папа! А почему бабушка по огороду бегает зигзагами? - Кому бабушка, а кому и теща. Дай-ка, сынок, вторую обойму!");
INSERT INTO chat_shutnik VALUES("287","Мyж c женой загоpают на пляже. Мyж, щyплый человек небольшого pоcта заметил, что его жена не отpывает глаз от cидевшего неподалекy кpyпного, мycкyлиcтого кpаcавца. Hе выдеpжав, мyж обpащаетcя к жене: - Зpя ты пялишьcя на него, доpогая. Вcпомни - y нашего cоcеда гаpаж на два \"кадиллака\", а он деpжит там велоcипед.");
INSERT INTO chat_shutnik VALUES("288","ртист пригласил на спектакль своего друга. После спектакля он сидит в гримерной, вытирает грим. Артист: - Ну что, как спектакль? Друг: - Чудесно! Все актеры играли как боги, сцена слилась с залом, просто полное проникновение, но ты... то слова забудешь, то на бабу в зале засмотришься.\n- Угу... А музыка тебе как? - Прекрасно, чувствуется, что композитор чувствовал пьесу, от драматических актеров не ожидал такого вокального таланта, правда, ты то не в такт запоешь, то петуха пустишь.\n- Умм... А декорации понравились? - Бесподобно!!! На всех актерах костюмы с иголочки, ну как в прошлом веке, правда, у тебя пуговица оторвана, ботинки нечишены, не понимаю.\n- Ага... а что, жена-то твоя все блядует?");
INSERT INTO chat_shutnik VALUES("289","Бог создал три качества - честность, ум и партийность, - но никому не дал больше двух. Так что если человек умный и честный, то он беспартийный. Если он честный и партийный, то он не умный. А если он умный и партийный, то он нечестный.");
INSERT INTO chat_shutnik VALUES("290","А вы пробовали принять слабительное одновременно со снот- ворным? Интересный эффект получается.");
INSERT INTO chat_shutnik VALUES("291","Журналист спрашивает у Карпова: - Ваше мнение о Deep Blue? - Душно и тесно.");
INSERT INTO chat_shutnik VALUES("292","Новый русский обсуждает с архитектором проект новой виллы.\n- Кароче, а тут рядом с сауной - чтобы три бассейна... один с горячей водой, другой с холодной, а третий - без воды! Архитектор: - А зачем вам бассейн без воды??? ж:-[] НР: - Ну ты прикинь, а вдруг у меня в сауне будут гости, которые плавать не умеют?");
INSERT INTO chat_shutnik VALUES("293","Пpишла весна. Зазвенела капель. Запели птички. Двоpник Hикодим вышел на улицу. Соpвавшаяся с кpыши сосулька убила двоpника Hикодима... Пpозектоp в моpге задумался над гpафой о пpичине смеpти и, улыбнувшись, написал: \"Весна пpишла\".");
INSERT INTO chat_shutnik VALUES("294","Сколько нужно ирландцев, чтобы закрутить лампочку? - Двое. Один держит лампочку, а второй пьёт виски, чтобы комната пошла кругом.");
INSERT INTO chat_shutnik VALUES("295","Судят грузина за изнасилование мальчика... Судья: - Расскажытэ, как это било? - Море - синий, синий; солнцэ - жолтый, жолтый; мальчык - попа розовый, розовый... Эх! Судья: - Эх! Расскажытэ еше раз, как это било...\n- Море - синий, синий; солнцэ - жолтый, жолтый; мальчык - попа розовый... розовый, розовый... Эх! Судья: - Суд удаляется на совещание! Через несколько минут...\n- Народный суд города Тбилиси постановил! Солнце желтый-желтый - продолжать светить. Мальчикам с розовой попкой по берегу синий-синий моря - нэ ходить, а подсудимый Габелия - па-автарите, пожалуйста, свой рассказ!");
INSERT INTO chat_shutnik VALUES("296","Сидя в джипе, бывший не в духе сержант приказал водителю: - Мне что-то не нравятся физиономии вон тех солдат около лужи. Ну-ка дай по газам и обдай их водой. Водитель послушно нажал на педаль газа и направил джип на лужу, в которую автомобиль буквально нырнул, так что на поверхности остались только головы сержанта и водителя. Это была канава, доверху наполнившаяся водой.");
INSERT INTO chat_shutnik VALUES("297","Один норвежец решил разводить птицу, купил 500 цыплят и... закопал их у себя в саду. Результат: все цыплята сдохли. Тогда он заказал еще 500 цыплят, посадил их в грядку головками наружу, но цыплята все равно сдохли. Норвежец написал письмо в Осло в тамошний университет, подробно описал свою проблему и попросил совета. Через несколько недель из Осло пришла телеграмма: \"Просьба прислать образцы почвы\".");
INSERT INTO chat_shutnik VALUES("298","Винни-Пух спрашивает у Пятачка, кем был его дед.\n- Мой дед был отбивной.\n- А кем был твой отец? - Мой отец был шашлыком! - Слушай, Пяточок, а кем ты хочешь стать? - Да вот, космонавтом...\n- А чё так грустно? - Да боюсь, в тюбик не влезу...");
INSERT INTO chat_shutnik VALUES("299","Врач говорит пациенту, очнувшемуся от наркоза: - Операцию вы перенесли хорошо, а вот перед ней вы вели себя просто невозможно: вырывались, кричали... А ваш знакомый с соседней койки вел себя еще хуже! - Еще бы! Ведь нас в клинику послали окна мыть.");
INSERT INTO chat_shutnik VALUES("300","Мой компьютер постоянно обыгрывает меня в шахматы. Зато я всегда побеждаю его в боксерском поединке!");
INSERT INTO chat_shutnik VALUES("301","- Что такое Советская власть? - спрашивает сын программиста у своего папы.\n- Это сынок, такая жутко глючная программа: пять лет ее устанавливают, затем 50 лет перезагружают компьютер, а потом оказывается, что вся система полетела и ее менять надо! Голем");
INSERT INTO chat_shutnik VALUES("302","Стоит наркоман, косяк забивает ( в ладони левой руки анаша). Подбегает девочка: - Дяденька, сколько время? Наркоман молчит. Девочка снова: - Дяденька, сколько время? Молчит. Девочка: - Дяденька, дяденька, ну сколько время? Hаркоман переворачивет ладонь и смотрит на часы: - Пи##ец тебе, девочка.");
INSERT INTO chat_shutnik VALUES("303","У речки с удочками сидят Счастливчик и Неудачник. У одного, естественно, клюет, у другого - нет. Неудачник интересуется: - На что ловишь? - На червя,- отвечает Счастливчик,- хочешь, бери! Вынимая жирного червя, тот спрашивает: - Ты где берешь таких красавцев? - Все очень просто. Отвожу от розетки провода и втыкаю их в огороде на грядке. Черви ползут как миленькие, собирай - не хочу. На следующий день Неудачник приходит весь в синяках.\n- Что с тобой? - изумился Счастливчик.\n- Да мало мне показалось двести двадцать вольт. Вышел в поле, там, где ЛЭП проложена, закинул провода, воткнул в землю и жду, когда черви появятся. А тут вылезли шахтеры и так морду набилиЄ");
INSERT INTO chat_shutnik VALUES("304","Опять же к доктору приходит женщина : - Доктор, у Вас есть 100%-ное противозачаточное средство. Доктор:(достает какие-то таблетки) - Вот, пожалуйста.\n- А это 100%-ное ? - Hет, 90.\n- А мне нужно 100. Доктор:(достает таблетки побольше) - Вот.\n- Это 100 ? - Hет, 95.\n- Hо мне-то нужно 100 ! Доктор: - Подождите. (достает таблетку величиной с ладонь) - Вот.\n- Hу это-то хоть 100 ? - Hет, 97.\n- Я вижу, Вы меня не понимаете... Доктор: - Hу, тогда... (двумя руками достает из шкафа таблетку величиной с автомобильное колесо) ... вот ! - О-о-о ! 8-0 Hу это наверно все 100...\n- Hет, Вы знаете, это 99.\n- Hо что-же мне делать ? Доктор: - Я кажется знаю... (долго копается в столе и наконец достает маленький металлический шарик) ...Вот что Вам нужно ! - И это 100%-ное ??? Доктор:(облегченно) - Да.\n- А как-же его использовать ??? - Держать между ногами во время полового акта !");
INSERT INTO chat_shutnik VALUES("305","Он был таким интеллигентным. Маму называл на вы.\n- Мама, вы что, охренели?");
INSERT INTO chat_shutnik VALUES("306","Если ваша жена хочет научиться водить автомобиль, самое главное - не стоять у нее на пути.");
INSERT INTO chat_shutnik VALUES("307","- А вот я тёще на день рождения подарил стиралку и сушилку! - Наверно, кучу денег выкинул? - Да не, всего баксов за 18! - ??????????? Это что ж за техника такая? - Тазик и полотенце!");
INSERT INTO chat_shutnik VALUES("308","Во время войсковых маневров начальник артиллерии замечает, что одно из орудий не стреляет. Он вызывает по рации командира батареи и требует доложить, в чем дело.\n- Дело в том, - докладывает тот, - что орудийный расчет так замаскировал свою пушку, что теперь не может ее найти.");
INSERT INTO chat_shutnik VALUES("309","- Когда читаю медицинскую энциклопедию, я обнаруживаю у себя все болезни.\n- Это бывает. Когда я читаю уголовный кодекс, то на каждой странице чувствую себя за решеткой.");
INSERT INTO chat_shutnik VALUES("310","Один мужик видя, что его сосед играет в карты со своей собакой восхищенно говорит ему: - Какая у Вас умная собака - Какая же она умная, видишь хвостом виляет, значит ей хорошая карта пришла.");
INSERT INTO chat_shutnik VALUES("311","Играют в карты Кощей Бессмертный, Баба Яга, Умный Мент и Глупый Мент. На столе лежит куча денег. Внезапно гаснет свет. Когда свет зажигается, денег нет. Вопрос: Кто украл деньги? Ответ: Глупый Мент. Вопрос: Почему? Ответ: Потому что все остальные - вымышленные персонажи.");
INSERT INTO chat_shutnik VALUES("312","- Я всегда любил слушать хорошие анекдоты, но быстро их забывал. Поэтому я стал их придумывать сам. Получилось совсем не хуже, и даже лучше.\n- Почему ты так решил? - Потому что не только я, но и все мои знакомые, которые слышали эти анекдоты, тоже их быстро забывают!");
INSERT INTO chat_shutnik VALUES("313","Из отчета слyжб безопасности \"... по поводy взлома китайцами сеpвеpа Пентагона\": ....... 1) Каждый китаец попpобовал один паpоль. 2) Каждый втоpой паpоль был \"maodzedun\" 3) Hа -й попытке сеpвеp согласился что y него паpоль \"maodzedun\"");
INSERT INTO chat_shutnik VALUES("314","Звонок в двеpь. Hа поpоге Дед Моpоз. Маленький мальчик кpичит: - Здpавствyй, Дедyшка Моpоз! Ты подаpки... Дед Моpоз: - Hе тpанди, пацан! Штопоp есть?!");
INSERT INTO chat_shutnik VALUES("315","Муж возвращается из командировки и видит у подъезда припаркованный \"Мерседес-600\". Заходит домой. Hа вешалке - красный пиджак, на столе - радиотелефон, в постели - жена с каким-то мужиком. Муж толкает мужика в бок: - Ты чего здесь делаешь? - Как чего? Hе видишь - новых русских делаем.");
INSERT INTO chat_shutnik VALUES("316","У него было трудное детство - до пяти лет, он был уверен, что его зовут: -\"Идитынах%й\"");
INSERT INTO chat_shutnik VALUES("317","Анекдот для москвичей: А раньше \"Лысый в кепке\" означало: \"Ленин\"...");
INSERT INTO chat_shutnik VALUES("318","Приходит пролетарий домой и, увидев свою жену с соседом, гово- рит: \"Вот вы тут глупостями занимаетесь, а в магазине, между про- чим, колбасу дают!\"");
INSERT INTO chat_shutnik VALUES("319","У фотографа: - Товарищ фотограф, это не моя фотография.\n- Как же не ваша, а, по-моему, похоже получилось.\n- А вот смотрите, нос же не мой.\n- Да, как будто не ваш.\n- А эта бородавка! У меня нет никакой бородавки.\n- Гм, действительно нет.\n- И потом, этот лежит в гробу, а я еще живой.");
INSERT INTO chat_shutnik VALUES("320","Женская мысль давно хотела попасть в мужскую голову... И вот она наконец-то туда залетает, счастливая.. А там никого нет. Пусто. Она смотрит по сторонам и вдалека видит летящую мужскую мысль. Женская мысль зовет мужскую, та подлетает... Женская мысль говорит: - Я так хотела сюда попасть.... А тут нет никого? Мужская мысль ей отвечает: - Ах, дурочка! Мы уже все внизу тусуемся...!");
INSERT INTO chat_shutnik VALUES("321","Инженер, парикмахер и экономист путешествовали по сельской местности. Устав, они остановились в маленькой харчевне.\n- У меня только две комнаты, - извинился хозяин.\n- Одному из вас придется спать в амбаре. Как водится, в амбар добровольно подался инженер. Вскоре уже засыпавших его товарищей разбудил стук. За дверью стоял инженер: - В амбаре корова. А я - индуист и по своей вере не имею права спать рядом со священным животным, - объяснил инженер. В амбар направился парикмахер. Не успели путники заснуть, в дверь снова постучали. За дверью стоял парикмахер: - Там свинья. Я, как еврей, не могу спать рядом с нечистым животным. Не оставалось ничего другого, как пойти в амбар экономисту. Под утро снова раздался стук. Удивленные приятели увидели за дверью корову и свинью.");
INSERT INTO chat_shutnik VALUES("322","В больнице две дамы говоpят о только что умеpшей подpуге: - Хотелось бы мне иметь ее ноги - у нее были пpелестные ноги! Жалко - тепеpь пpопадут...");
INSERT INTO chat_shutnik VALUES("323","Разговаривают два алкаша: - Я намедни пить бросил...\n- ??? - А вот куда - не помню!..");
INSERT INTO chat_shutnik VALUES("324","Осень, сыро, холодно. В пивную заходит оборванец и просит налить кружечку похмелиться. Бармен говорит жалостливо: - Ты бы лучше себе носки потеплее купил.\n- На хрена? Здоровье дороже!");
INSERT INTO chat_shutnik VALUES("325","Корсиканец с гордостью говорит приезжему: - У нас воруют так, что во многих местах железная дорога проложена кольцами.\n- А зачем? - Чтобы машинист мог убедиться, что все вагоны на месте.");
INSERT INTO chat_shutnik VALUES("326","Как известно, спартанцы учили детей плавать, попросту сбрасывая их со скалы в море. Интересно, если начать сбрасывать детей с самолета, хоть некоторые из них научатся летать?");
INSERT INTO chat_shutnik VALUES("327","Уход за волосами - смерть лысого человека.");
INSERT INTO chat_shutnik VALUES("328","Взвод морских пехотинцев пришол в кинотеaтр нa просмотр голивудского боевикa. В сaмый кульминaционный момент героиня зaстреливaет своего любовникa и трaгическим голосом вопрошaет: - Hу чтоже мне теперь делaть ?! Kомaндный голос из зaлa: - Осмотреть оружие и отойти зa огневой рубеж!");
INSERT INTO chat_shutnik VALUES("329","- Мадам, вы, очевидно, принимаете меня за дурака? - Что вы, я никогда не сужу о людях по первому впечатлению.");
INSERT INTO chat_shutnik VALUES("330","Как и полагается, у сексопатолога: - Доктор, Вы знаете, у меня не стоит...\n- А Вы, батенька, сюда трахаться, что ли, пришли ?!.");
INSERT INTO chat_shutnik VALUES("331","Что делают чукчи, когда холодно? Закрывают в юрту дверь и садятся вокруг свечки. Что делают чукчи, когда очень-очень холодно? Они ее зажигают.");
INSERT INTO chat_shutnik VALUES("332","Два человека выходят на улицу: - Какая ужасная погода, снег с дождем! - Подонки, что хотят, то и творят...");
INSERT INTO chat_shutnik VALUES("333","Получилось так, что две женщины отсидели в тюрьме 10 лет. В одной камере. Выпустили их в один день. Вышли за ворота, одной надо направо, другой налево. Hу, обнялись, расцеловались. Одна другой: - Ладно, остальное я тебе завтра по телефону расскажу . . .");
INSERT INTO chat_shutnik VALUES("334","Приходят к Сталину украинские националисты и говорят, что надо, мол, составить украинско-русский словарь. Сталин закурил трубку, задумался: - Словарь, говорите, ну а как по-украински будет рука? - Рука.\n- Ну а как нога? - Нога.\n- Ну а как голова? - Голова.\n- А как будет жопа? - Срака.\n- Так что же это, из-за одного слова словарь составлять!");
INSERT INTO chat_shutnik VALUES("335","- Ты потребовала бы развод, если бы узнала, что муж тебе изменяет? - Ты что?! За такое его еще и награждать?...");
INSERT INTO chat_shutnik VALUES("336","В церкви большой переполох. Скоро приедет архиепископ с проверкой. Подбегает к пастору монашка и грит: - Святой отец, мне кажется, что ваши стулья надо заново покрыть лаком. Они совсем облупились! - Не ВАШИ, а НАШИ, сестра - здесь ничего нет личного, а только НАШЕ, понятно!? На следущий день опять эта монашка грит пастору: - Святой отец, надо бы ваш потолок заново побелить, а то он уже черный весь! - Дочь моя, не ВАШ, а НАШ потолок, я же вам говорил...! И вот приехал архиепископ. Ходит он с пастором, смотрит вокруг, всем вроде доволен. Тут подбегает монашка и грит пастору: - Святой отец, я нашла ваши часы...\n- Очень мило, сестра, и где же они были? - Под НАШЕЙ кроватью...!!!!");
INSERT INTO chat_shutnik VALUES("337","Свеpхмодный молодой человек обpащается к поpтному: - Вы могли бы сшить мне костюм цвета кофе с кипящим молоком ? - С сахаpом или без ? - спокойно осведомился поpтной. ;););)");
INSERT INTO chat_shutnik VALUES("338","Война. В окопе сидят два солдата и раскуриваются, на них едет танк. Один солдат говорит другому: \"Вань бросай гранату\". Тот говорит: \"Давай сделаем по напасу и тогда бросим\". Сделали по напасу. Первый говорит: \" Вань танк уже близко, давай бросай гранату\". А второй ему: \"Ну ты чего пристал, хочешь, бросай сам\". Подъезжает танк, из люка вываливается накуренный фашист и спрашивает: \"Ну вы чего, гранату то будете кидать?\" А те ему: \"Да что-то нам влом. А вы почему не стреляете?\" Фашисты: \" А мы ствол запаяли чтобы кумар не уходил!\"");
INSERT INTO chat_shutnik VALUES("339","Bесна. Половодье. Mаленький остpовок суши, на котоpом спасаются от воды Cобака и Заяц. A вода все пpибывает и пpибывает, вот-вот затопит остpовок... Чу... Bдали показалась лодка.\n- Уpа, мы спасены!!! - закpичал Заяц.\n- Это Дед Mазай!!! Cобака долго вглядывалась в даль, а потом гpустно сказала: - Hет, Заяц, это не Mазай, это ГEPACИM!!!");
INSERT INTO chat_shutnik VALUES("340","Маленький сын был с папой в зоопарке. У клетки со львом он спросил: - Папа, а если он съест кого-нибудь из нас, на каком номере автобуса мне ехать домой?");
INSERT INTO chat_shutnik VALUES("341","Директор коммерческого магазина учит молодую продавщицу: - Если покупатель спросит: \"Почем очки?\", ты скажи: \"Три штуки\". Если он не дрогнет, скажи: \"За оправу\". Если он опять не дрогнет, скажи: \"И за стекла три штуки\". И если опять не дрогнет, скажи: \"За каждое\".");
INSERT INTO chat_shutnik VALUES("342","- Доктор, я - импотент. И это у меня наследственное.");
INSERT INTO chat_shutnik VALUES("343","У миссис Смит умер муж и страховое агентство платит пятьдесят тысяч долларов бедной вдове. Она горько плачет: - Ах, я бы отдала треть этих денег, лишь бы он был опять со мной...");
INSERT INTO chat_shutnik VALUES("344","На приеме у психиатра.\n- Так, милейший, не волнуйтесь, на что жалуемся? - Не поверите, доктор! Иду я вчера с работы мимо нашего Вычислительного центра, и...\n- Ну-ну! - А там из всех окон Билл Гейтс выглядывает!!! - Так-так! - А по бокам... интерфейсы с кнопками стоят!!! - Да, батенька, пора вам перезагружаться. В новую рубашечку!");
INSERT INTO chat_shutnik VALUES("345","- Гарсон! Кажется, я хватил лишнего. Принесите чего-нибудь отрезвляющего.\n- Пожалуйста, счет.");
INSERT INTO chat_shutnik VALUES("346","Идет по Арбату новый русский в белом костюме с букетом белых роз, спешит на свидание. Погода прекрасная, настроение тоже. Вдруг он видит аппарат, типа автомата с газировкой, с надписью: \"Портим настроение. 1$\" \"Что мне может испортить настроение\" - подумал он и спокойно опустил доллар в автомат. И в тот же момент автомат выплюнул ему ложечку говна прямо на лацкан белого костюмчика. Расстроился новый русский: костюм испорчен, настроение тоже. Вдруг видит рядом стоит точно такой же автомат с надписью: \"Поднимаем настроение. 100$\" \"Что мне может поднять настроение\" - удивился он и быстренько опустил в автомат стольник. И в тот же момент на всех окружающих автомат выплюнул ведро говна...");
INSERT INTO chat_shutnik VALUES("347","Прочитав кое-что на женском форуме понял, что все русские мужчины - импотенты. Эти же козлы, все поголовно, изменяют своим женам.");
INSERT INTO chat_shutnik VALUES("348","Объявили вепсы войну Китаю! Китайцы присылают парламентеров. Идут по деревне, видят идет мужичек, спрашивают (вежливо): \"Вы вепс?\", тот говорит \"Конечно вепс\". Китайцы говорят: \"Вот вы (вепсы) нам войну объявили, а вы знаете, что нас китайцев больше миллиарда?\". Мужичок: \"Ой блин! Где-же мы вас хоронить-то будем?\"");
INSERT INTO chat_shutnik VALUES("349","Когда канцлер князь Горчаков сделал камер-юнкером Акинифьева (в жену которого был влюблен), Тютчев сказал: \"Князь Горчаков походит на древних жрецов, которые золотили рога своих жертв\".");
INSERT INTO chat_shutnik VALUES("350","Идет судебный процесс. Слон обвиняется в изнасиловании змеи. Судья-лев вызывает пострадавшую: - Расскажи, как это было.\n- Мне до сих пор трудно говорить... В общем, он силой заставил меня взять в рот свой детородный орган.\n- Понятно. Теперь послушаем свидетеля. Выходит свидетель - легкомысленная обезьяна: - О! А! Вы бы видели, какая была эрекция! А когда началось семяизвержение, я подумала, что наступил конец света.\n- Ясно. Обвиняемый, что ты можешь сказать в свою защиту? Слон: - Прежде всего, это был не оральный секс, а анальный. И не со змеей, а с обезьяной и по взаимному согласию. А змею я просто применил в качестве презерватива.");
INSERT INTO chat_shutnik VALUES("351","По просьбе своих соплеменников поехал Чукча в Москву узнать, когда будет коммунизм. Приходит Чукча на прием к Горбачеву и спрашивает: - Когда будет коммунизм ? - Вот смотри: видишь, стоит моя \"Волга\", \"Волга\" Лукьянова, \"Волга\" Лигачева. Вот когда будет рядом стоять твоя \"Волга\", тогда, считай, и будет коммунизм. Вернулся Чукча в стойбище.\n- Узнал ? - Узнал. Вот видишь, стоят мои унты, твои унты и еще унты. Вот когда рядом будут стоять унты Горбачева, тогда, считай, и будет коммунизм.");
INSERT INTO chat_shutnik VALUES("352","Судья: - Вы должны попробовать стать другим человеком.\n- Я уже пытался, меня сразу посадили за подделку документов.");
INSERT INTO chat_shutnik VALUES("353","На недавней компютерной выставке (COMDEX) Билл Гейтс сравнил компьютерную промышленность с автомобильной и, в частности, сказал: - Если бы Дженерал Моторс осваивала достижения технологии с таким же эффектом, как это происходит в компьютерной промышленности, то мы все уже бы ездили на -ти долларовых машинах с расходом бензина литров на километров. На что Дженерал Моторс отреагировала: - Да, но хотели бы вы чинить ваш автомобиль дважды в день?...");
INSERT INTO chat_shutnik VALUES("354","- Скажи, вот если мужчина говорит, что у меня волосы хорошо пахнут, это домогательство или нет? - Да нет, это комплимент, по-моему.\n- А если он карлик ....????");
INSERT INTO chat_shutnik VALUES("355","- Когда я иду с женой в гости, то пью очень мало.\n- Тебе не разрешает жена? - Вовсе нет. Просто однажды я здорово перебрал, и мне показалось, что у меня две жены. Такого ужаса я никогда не испытывал!");
INSERT INTO chat_shutnik VALUES("356","Два наркомана, обкурившись, лежат на кровати. Звонок в дверь... Через полчаса один другому: \"Кажется, в дверь звонят...\" Через полчаса другой первому: \"Может, пойти, открыть дверь?..\" Через полчаса первый: \"Ну, сходи, открой...\" Через полчаса второй встает, медленно идет к двери, открывает... На пороге, облокотившись о дверной косяк, стоит третий наркоман: \"Ох-х! Не успел позвонить, уже дверь открывают!\"");
INSERT INTO chat_shutnik VALUES("357","Наташа Ростова вышла вечером подышать на веранду. Внизу в лопухах что-то темнело. НР: Поручик, это Вы? Ржевский: Я! НР: А что это Вы такой маленький? Ржевский: Я не маленький. Я сру.");
INSERT INTO chat_shutnik VALUES("358","- А я не встану под музыку нового гимна! - Ну и будешь смотреть в задницу поющему... Коклюшкин");
INSERT INTO chat_shutnik VALUES("359","Семь раз отмерь - один раз отрежь! (еврейская народная пословица)");
INSERT INTO chat_shutnik VALUES("360","К мужику на вокзале подбегает цыганка: - Драгоценный мой, дай руку, погадаю, все скажу, что будет, что было. Мужик пожимает плечами, протягивает руку: - Hу, погадай. Цыганка некоторое время смотрит на ладонь, потом в ужасе кричит: - Страшной смертью помрешь! Зарежут тебя, сдерут шкуру, четвертуют, зажарят и съедят! - Ах да, я ж перчатку не снял...");
INSERT INTO chat_shutnik VALUES("361","Мадам готовит завтрак, муж перелистывает газету. Вдруг раздается странный гортанный звук.\n- Что там с тобой? - кричит она мужу.\n- Я случайно проглотил пуговицу от воротничка! Мадам удовлетворенно: - Хоть теперь мы будем знать, где она находится!");
INSERT INTO chat_shutnik VALUES("362","Военный говорит жене: - Поздравь меня - мне дали майора.\n- Поздравляю. И что ты с ним сделал?..");
INSERT INTO chat_shutnik VALUES("363","- Что делать, профессор, все готово к операции, а пациента еще нет.\n- Это ничего, начнем без него.");
INSERT INTO chat_shutnik VALUES("364","- Доктор, что означают буквы \"ЧЗ\" в моем диагнозе? - \"Черт его знает\".");
INSERT INTO chat_shutnik VALUES("365","Купил искусственную электронную вагину. Вы даже не представляете, что сбой процессора может быть так приятен...");
INSERT INTO chat_shutnik VALUES("366","Люди, которые думают, что они знают все на свете, раздражают нас, людей, которые действительно все на свете знают.");
INSERT INTO chat_shutnik VALUES("367","- Вчера я видел, как ты выходил из пивной.\n- Что поделаешь, не могу же я там жить.");
INSERT INTO chat_shutnik VALUES("368","Мать с дочкой идут через густой лес. Вокруг никого. страшно. Дочь: - Мама, а вдруг нас изнасилуют?!! - Не с нашим счастьем, доченька....");
INSERT INTO chat_shutnik VALUES("369","ЗВОНОК ОТ ХИЛЛАРИ Хиллари пошла к гинекологу, чтобы провериться. Когда она закончила, она спросила его, все ли в порядке. Он ответил, что он очень рад ее состоянием, но...........она беременна! - Как это возможно? Этого не может быть! - Но это так! Вы беременны уже месяц! Она выбежала из оффиса и побежала к секретарю. Взяла телефон и позвонила в Белый Дом. Когда ответил оператор, она сказала, что это Хиллари и хочет говорить с Биллом срочно! Оператор соединил ее с Овальным оффисом и Билл ответил. Хиллари начала кричать: - Ты знаешь, что ты сделал, ты кретин! Ты сделал меня беременной!!! Никакого ответа не последовало. Хиллари опять повторила, крича: - Ты знаешь, что ты сделал, ты никому не нужный кретин! Ты сделал меня беременной!!!!!!!!!! Наконец, послышался ответ: - Кто это???................");
INSERT INTO chat_shutnik VALUES("370","Управляющий беседует с молодым человеком, который хочет устроиться на работу: - В нашей фирме, - говорит управляющий, - очень заботятся о чистоте. Вы вытерли ноги о коврик перед тем как войти? - О да, разумеется.\n- Во-вторых, - продолжает управляющий, - мы требуем от наших сотрудников правдивости. Никакого коврика там нет.");
INSERT INTO chat_shutnik VALUES("371","Если к поэту приходит муза, к поэтессе приходит музык.");
INSERT INTO chat_shutnik VALUES("372","- Не понимаю, почему ты развелась с мужем? - Мне вообще не повезло с замужеством. Сначала оно напоминало мираж в пустыне: дворцы, фонтаны, пальмы, яхты, путешествия на верблюдах по Африке...\n- А потом? - Потом дворцы, фонтаны исчезли, яхта пришла в негодность, осталась одна верблюжья работа.");
INSERT INTO chat_shutnik VALUES("373","Директор мебельной фабрики поехал в командировку в Париж. Возвращается - масса впечатлений. Рассказывает своим приятелям: - О, такой город! Такие улицы! Такие магазины! - Ну а женщины? - О-о! Это что-то невероятное! Мечта! Главное - любого мужика понимают с полуслова. Вот например: захожу я в маленький ресторанчик, сажусь за столик. Ко мне подсаживается умопомрачительная красотка. Ну сразу сообразила, что я по ихнему - ни слова. Рисует мне на салфетке рюмку. Я - наливаю ей шампанского. Рисует сигарету. Я - даю закурить. Рисует две танцующие фигурки. Я - приглашаю ее на танец.\n- Ну а потом? - Рисует кровать...\n- А ты? - Хмм... До сих пор не пойму - как она узнала, что я - директор мебельной фабрики...");
INSERT INTO chat_shutnik VALUES("374","Молодой офицер попадает служить на боевой корабль, который немедленно направляется в длительный поход. \"Товарищ капитан первого ранга, я и с девушкой-то не успел побыть, а тут такой длительный поход - жалуется он командиру. \"Ничего, лейтенант, у нас для этих целей кок есть.\" \"Как можно - возмущается лейтенант - ведь он мужчина.\" \"Ну не хотите, как хотите, но если что, посодействую.\" Проходит три месяца. Лейтенант подходит к командиру: \"Товарищ капитан первого ранга, Вы что-то насчет кока говорили...\" \"Мичман! - зовет тот - приведи кока в каюту лейтенанта и не забудь взять еще троих.\" \"Зачем троих? - смущается лейтенант - а нельзя ли нам с коком один на один?\" \"Ты один с ним не справишься, сынок. Его же сначала надо с ног сбить и к кровати прижать.\"");
INSERT INTO chat_shutnik VALUES("375","На балу к поручику подскочил корнет и решив блеснуть остроумием и поетическим даром сказал: \"Поручик-ключик-чайничек\" Ржевский ответил: \"Корнет-кларнет-тромбон-гандон- и вообще ты пидарас\"");
INSERT INTO chat_shutnik VALUES("376","Самое сложное для артиста пародирующего Баскова - также не попасть в ноты.");
INSERT INTO chat_shutnik VALUES("377","Анекдот из сериала \"Скорая помощь\". Врач дает указания практикантке: - В третьей смотровой пациент повредил прямую кишку большой морковью. Составьте анамнез и заполните его карточку. Практикантка изумленно: - Как он проглотил целую морковь?!!");
INSERT INTO chat_shutnik VALUES("378","Ночь была темной. Часовому хотелось курить.\n- Эй, Мак! - окликнул он, как ему показалось, своего товарища, проходившего недалеко от поста.\n- У тебя нет сигаретки? И тут он рассмотрел, что окликнул генерала.\n- Виноват, сэр! - гаркнул он и принял стойку \"смирно\".\n- Вольно, рядовой, - отдал команду генерал.\n- И считай, тебе повезло, что я не лейтенант!");
INSERT INTO chat_shutnik VALUES("379","В фотоателье мастер долго и пристально смотрит на клиента. Тот заерзал в кресле: - Что-то не так ? - Да Вы не волнуйтесь, все в порядке - просто если б не усы, Вы были бы вылитая моя теща.\n- Но у меня нет усов ! - А вот у нее есть.");
INSERT INTO chat_shutnik VALUES("380","- Как получить миллиард долларов? - Очень просто. Надо поймать Березовского и продать его Гусинскому.");
INSERT INTO chat_shutnik VALUES("381","Вернулся мужик из командировки. Приехал домой, открывает дверь и видит на вешалке чужое мужское пальто. Заходит в спальню. В постели жена лежит, всюду мужская одежда разбросана, а тут еще из ванной выходит голый мужчина. Муж только открывает рот, но его тут же перебивает жена: - Ну, конечно, всегда так ! Ты сейчас будешь верить своим бесстыжим глазам, а не любимой жене !");
INSERT INTO chat_shutnik VALUES("382","Молодой, талантливый пианист пришел записываться на радиостудию. Но вот непруха! Чем больше играет, тем хуже получается. И дальше - хуже... Время часов ночи. За стеклышком сидит оператор грустный... Кофе кончился, сигарет нет, жена три раза звонила, обещала из дому выгнать. Надоело ему это все. Включает он микрофон в студии и говорит: - \"Слушай, мужик! Ладно, все, хорош! Ну не получается. Но ты хоть гамму-то сыграть можешь?\" Тот ему: - Гамму! Нет проблем! - Сыграй, а я потом нарежу!");
INSERT INTO chat_shutnik VALUES("383","- Какая разница между женщиной без груди и брюками без карманов? - Никакой. Некуда руки девать.");
INSERT INTO chat_shutnik VALUES("384","Около ранчо остановилось стадо баранов и уставилось на ворота.\n- Чего они смотрят? - спросили у пастуха.\n- Ведь ворота старые? - Бараны новые, - ответил пастух.");
INSERT INTO chat_shutnik VALUES("385","Встречаются на том свете три старых седых мужика, узнают друг у друга, как и отчего приключилась смерть. Первый говорит: - Я всю жизнь работал и смерть меня настигла в процессе труда. А работа была нелегкой, и поседел я лет в шестьдесят. Второй говорит: - А я всю жизнь воровал потихоньку, в конце концов меня и убили из-за денег. И при этом лет в сорок поседел, понимая, чем кончится мой промысел. Третий говорит: - Ну, вы, мужики, круты, хоть чего-то в жизни добились, а вот я вообще не делал ни хрена, и, как услышал, что моя собственная жена хочет меня на пересадку органов пустить, сначала поседел, а потом - при операции - сердце не выдержало... Голем");
INSERT INTO chat_shutnik VALUES("386","Жили в одной избушке Медведь, Волк и Заяц. У Медведя была заначка водки. Как-то раз ушел он в лес, а Волк с Зайцем остались дома. Заяц подходит к Волку и говорит: - Давай выпьем! - Да ты что, Медведь нам потом головы оторвет.\n- Ничего, когда он станет про водку спрашивать, ты, главное, глаза побольше сделай, мол, и не видели ее даже, а там как-нибудь выкрутимся. Выпили они медвежью заначку. Вечером Медведь обнаружил пропажу и спрашивает - А где моя водка? У Волка глаза по пятаку, а Заяц ему и говорит: - Ну что глазенки-то выпятил, рассказывай все дяде Мише!");
INSERT INTO chat_shutnik VALUES("387","Мужики взбунтовались, взяли вилы, топоры, дубье и поперли к усадьбе. Шумят, матерятся, гул стоит. Подходят к усадьбе. Выходит староста, пытается уговорить мужиков разойтись, потом управляющий - не слушают, матерятся, требуют, чтоб Сам вышел. Выходит помещик, после завтрака, халат расстегнут, левой рукой чешет брюхо, правой зубочистку держит, во рту ковыряется. Мужики притихли. Барин зевает, поворачивается к толпе и негромким голосом спрашивает: - Ну, чего вам, мужики? Мужики стоят молча. Барин смотрит на них, ждет ответа минуты три, потом лениво уходит. Мужики стоят, молчат, потом, спустя полчаса понемногу расходятся. Дня через три один из зачинщиков обедает дома, ест шти. Вдруг посреди обеда останавливается, задумывается, потом бах ложкой об стол и орет: - ЧАВО, ЧАВО, А НИЧАВО!");
INSERT INTO chat_shutnik VALUES("388","- Что можно снять с голой женщины? - Только голого мужчину.");
INSERT INTO chat_shutnik VALUES("389","Учительница прибегает к директору в слезах: - Ах это просто невыносим ! Не ученики - животные, скоты ! А один даже грозился меня изнасиловать ! Представляете ?! Директор встает и идет в класс. Входит. Молча осматривает ряды учеников и тыкает пальцем в Вовочку: - Этот сказал ? Понимаю: этот раз сказал - сделает.");
INSERT INTO chat_shutnik VALUES("390","\"Хуюшки вам, а не Кунашир!\" - сказал японцам Владимир Путин. И остров Хуюшки из Курильской гряды пришлось отдать.");
INSERT INTO chat_shutnik VALUES("391","- Любите ли вы Шекспира? - Трудно сказать. Скорее, мы просто приятели.");
INSERT INTO chat_shutnik VALUES("392","Начало чемнионата России по футболу. Матч \"Динамо\" - \"Спартак\". Опоздавший болельщик - соседу: - Ну и кто из наших лучше всех играет, точнее всех бьет? - Ковтун.\n- Но на табло :, и два гола забил Терехин....\n- Много ты понимаешь! Терехин десять раз ударил и два раза забил, а Ковтун три раза ударил, и для всех троих сезон уже закончился!");
INSERT INTO chat_shutnik VALUES("393","- Кто, в конце концов, в доме хозяин?! - набравшись духу, закричал муж.\n- Я,- спокойно ответила жена,- А что? - Да нет, ничего... Все в порядке. Я просто так спросил.");
INSERT INTO chat_shutnik VALUES("394","- Где у женщин расположен аппендикс? - Как войдешь - налево.");
INSERT INTO chat_shutnik VALUES("395","Где-то загорелся дом. Все тушат. Прибегает хозяин и кричит: - Hа меня ведро воды! Выплеснули на него ведро, вбежал в горящий дом, через какое-то время выскоч ил. Проходит минут , мужик опять: - Hа меня ведро воды! Снова забежал в дом, через некоторое время выскочил. Прошло еще минут , у дома крыша уже обваливается, мужик опять: - Hа меня ведер! Ему говорят, мол, куда ты полезешь, и вещей не спасешь, и сам погибнешь.\n- Какие вещи! Там моя теща, а я ее переворачиваю.");
INSERT INTO chat_shutnik VALUES("396","Однажды пришли к габровцам гости, да слишком засиделись. Не вытерпела хозяйка и громко сказала мужу, чтобы все услышали: - Давай, муженек, ляжем спать, а то, наверное, гости уже хотят идти домой!..");
INSERT INTO chat_shutnik VALUES("397","Революция кончилась. Петька с Василием Ивановичем думают о новой жизни: - Петька, что бы нам теперь построить? - Построим консерваторию! - Точно! А на крышу пулемет поставим! - А это зачем? - Чтобы все консервы не растащили!");
INSERT INTO chat_shutnik VALUES("398","Мужик жалуется приятелю: - А ведь когда-то у меня было все: деньги, роскошный дом, мерс, красивая женщина, которая меня по-настоящему любила. И всего этого я лишился в одночасье.\n- А что случилось? - Да какой-то козел рассказал об этом моей жене!");
INSERT INTO chat_shutnik VALUES("399","Из письма А. Б. Чубайсу. Уважаемый Анатолий Борисович, пишет вам электрик Эрнест Петрович Сидоров. Сделайте что-нибудь. Ввиду огромного внешнего сходства с вами, мне очень часто бьют морду. С уважением Э. П. Сидоров");
INSERT INTO chat_shutnik VALUES("400","Глубокой ночью Сталин поднимает трубку.\n- Слушай, товарищ Молотов, а ты так же все заикаешься? - Заикаюсь, товарищ Сталин, но если нужно будет для дела строительства социализма, тоЄ - Нет, ничего не надо. Спи спокойно. И кладет трубку. Звонит Микояну.\n- Слушай, товарищ Микоян, сколько там было бакинских комиссаров? - , товарищ СталинЄ - А сколько погибло? - , товарищ Сталин.\n- Ну, спи спокойно, наш двадцать седьмой бакинский комиссар! И кладет трубку. Звонит Берии.\n- Слушай, товарищ Берия, ты Бухарина надежно расстрелял? - Надежно, товарищ Сталин. А что? - Да ничего. Спи спокойно. Кладет трубку и говорит: - Ну вот, их успокоил, теперь можно м самому уснуть.");
INSERT INTO chat_shutnik VALUES("401","Англичанин среднего достатка заходит в респектабельный магазин. Немного оглядевшись спрашивает продавца.\n- Скажите, сколько стоит вон та шляпа? -Тысячу долларов, Сэр.\n-Черт.., А вон та? -Два черта, Сэр. FiL");
INSERT INTO chat_shutnik VALUES("402","Гpузин в pестоpане любуется новыими \"коpочками\" кандидата наук. Официант ехидно спpашивает: - Что, только что купил ? - Вах ! Зачэм стpашиваэш ! Зачэм сpазу: Купиль ! Дpуззя подаpиль !!");
INSERT INTO chat_shutnik VALUES("403","Встречаются два директора советского и японского предприятий. Предприятия изготавливают совершенно одинаковую продукцию и в одинаковых количествах. Директор нашего завода спрашивает: - Сколько людей у тебя работает? - Девять. А у тебя? У нашего вообще-то пятьсот, но он говорит: - Десять! На следующий день японец говорит: - Слушай, я всю ночь думал и никак не могу понять: что у тебя этот десятый делает?");
INSERT INTO chat_shutnik VALUES("404","\"Фанта. Вкус апельсина.\" До сих пор не могу понять, что именно дает этот вкус. То ли вода с сахаром и диоксидом углерода, то ли регулятор кислотности и стабилизатор гуммиарабик. А может, изо-бутират ацетат сахарозы с антиоксидантом аскорбиновая кислота? Хотя, вероятнее всего, краситель \"желтый солнечный загар\" с идентичными натуральным ароматизаторами... Нет, наверное, все-таки бензоат натрия!..");
INSERT INTO chat_shutnik VALUES("405","Жена: - Не могли бы мы как-нибудь сходить в кино ? Муж: - Мы же были в кино.\n- Да, но теперь там идут звуковые фильмы...");
INSERT INTO chat_shutnik VALUES("406","Садятся старик со старухой ужинать. Старуха поставила перед стариком сковородку картошки. Он поковырялся вилкой, взял сковородку да как треснет старухе по лбу.\n- Старик, ты одурел, что ли? - Как вспомню что не целкой взял, так аппетит пропадает!!!");
INSERT INTO chat_shutnik VALUES("407","У минетчицы спрашивают: - как дела? - Да вот вот хреново! Всякая пошлятина в голову лезет!");
INSERT INTO chat_shutnik VALUES("408","Выполз уж из ресторана: \"Гав. Неа.. Ку-ка-реку Неа.. Мяу Неа... Шшшш, бля буду, шшшшш!\"");
INSERT INTO chat_shutnik VALUES("409","Леди не захочет, джентльмен не вскочит.");
INSERT INTO chat_shutnik VALUES("410","- Ва-ань, а Ва-ань, ты за ско-олько доходишь от кровати до двери? - Я - за час, а ты за сколько? - За полчаса! - Ну, ты вообще, как метеор!");
INSERT INTO chat_shutnik VALUES("411","Фиpма, пpодающая пилюли для похудения, получила письмо: \"Ваши пилюли бесподобны. За пеpвые две недели моя жена похудела на шесть кг, а вскоpе исчезла вообще.\"");
INSERT INTO chat_shutnik VALUES("412","Врач - пациенту, глядя в историю болезни: - Э-э ,батенька, с сегодняшнего дня бросайте курить - положение серьезное! - Доктор, но я не курю! Не люблю.\n- Да? Тогда ни капли спиртного!! - Но, доктор, я не пью! Не люблю! - Да??... Но что-нибудь вы любите!!?? - Картошку...\n- Так вот! С сегодняшнего дня я вам решительно запрещаю есть картошку!!!");
INSERT INTO chat_shutnik VALUES("413","- Рабинович, говорят, вы большой интриган? - Да, а кто это ценит...");
INSERT INTO chat_shutnik VALUES("414","Социальная реклама Мы yже не pаз обманывали вас. Вы защищали нас осенью -го, мы стpеляли в вас осенью -го. Мы pазвалили вашy стpанy в -м, обокpали в -м, надyли с двyмя Волгами в -м, с помощью МММ-ов pаскpyтили на бабки в -м, посылали ваших детей на бойню в -м, неплохо \"повтоpничали\" в -м, и полностью огpабили в -м. Hо y нас опять кончились деньги. Пожалyйста, заплатите налоги...");
INSERT INTO chat_shutnik VALUES("415","- Дорогой! Наш сосед подарил тебе на день рождения двухрожковую люстру! - Это он на что намекает?!");
INSERT INTO chat_shutnik VALUES("416","Недавно на ж/д переезде № пожарный инспектор Василий М. обнаружил цистерну со спиртом, близкую к самовозгоранию. Лишь к вечеру силами жителей семи окрестных сел риск самовозгорания уменьшился ровно наполовину.");
INSERT INTO chat_shutnik VALUES("417","Молодой фермер, призванный на военную службу, в письме домой написал: \"Эта армейская жизнь - сплошное удовольствие. Можно валяться в постели до пяти часов утра\".");
INSERT INTO chat_shutnik VALUES("418","- Что вы будете делать, сержант Тейер, если запасы воды в вашем взводе окажутся зараженными? - Лучшим выходом было бы перейти на пиво.");
INSERT INTO chat_shutnik VALUES("419","Встречаются две подруги. Одна две недели назад вышла замуж. Вторая любопытствует: - Ну и как тебе семейная жизнь? - Да так себе, ничего. Только вот, представляешь, а Жан-то, оказывается, пьет...\n- Как пьет! Вы же два года были знакомы! И ты не знала? - Так ведь два года все было нормально, но вот вчера он пришел трезвым!");
INSERT INTO chat_shutnik VALUES("420","Почему евреи так популярны у женщин? Потому, что у них есть длинный, большой и толстый... Нет, не то, о чем Вы подумали: длинный - рубль, большой - счет в банке, а толстый - бумажник! Голем");
INSERT INTO chat_shutnik VALUES("421","\"micro soft works for micro soft windows\" означает \"Микро программное обеспечение работает для микро окон программного обеспечения\" (Перевод выполнен ПО Stylus for Windows , в. .)");
INSERT INTO chat_shutnik VALUES("422","Больной вызывает врача в три часа ночи. После осмотра врач задумывается, потом говорит: - Вы составили завещание? - Нет, доктор.\n- Так вызовите, пожалуйста, нотариуса и двух свидетелей.\n- Боже мой, это так серьезно? - Нет, но я не хотел бы быть единственным дураком, которого вы подняли в три часа ночи.");
INSERT INTO chat_shutnik VALUES("423","Ж) - Смотри какие тени длинные, и облака тяжелые... Х) - Длинные - потому что уже поздно, а тяжелые потому что мы уже -й день пьем.");
INSERT INTO chat_shutnik VALUES("424","- Хаим, я слышал - вы женитесь! - Таки-да! - И как вам ваша будущая жена? - Ой, сколько людей, столько и мнений. Маме нравится, мне - нет.");
INSERT INTO chat_shutnik VALUES("425","Племянник разговаривает с Лениным: - Дядя Вова, у тебя такая большая умная голова!? - Да, Витенька, ей я думаю, как людям лучше жить.\n- У тебя такие руки!? - Да, Витенька, ими я указываю людям верную дорогу.\n- А усы тебе зачем? - А чтобы тетю Надю щекотать!");
INSERT INTO chat_shutnik VALUES("426","Один еврей рассказывает: - Представляешь, прихожу домой, а там жена с любовником. А глаза у них хитрые-хитрые... Думаю, что за черт! Бегу прямо к холодильнику, открываю его, так и есть! Всю фаршированную рыбу съели, сволочи!");
INSERT INTO chat_shutnik VALUES("427","Дочка спрашивает у мамы: - Мама, а что такое фаллоимитатор? Мама, немного смутившись, отвечает - Ну, доченька, это прибор, который заменяет мужа. Дочка (с восхищением): - Классно! И он сам по ночам жрет котлеты из холодильника и храпит?");
INSERT INTO chat_shutnik VALUES("428","Встречаются два приятеля: - Говорят, ты женился на девушке, о которой даже не мог и мечтать.\n- Правильно говорят... Неужели ты думаешь, что я мог мечтать о такой стерве?");
INSERT INTO chat_shutnik VALUES("429","Начальник лагеря объявляет: - Сегодня день смены белья. Первый барак меняется со вторым.");
INSERT INTO chat_shutnik VALUES("430","Вышел как-то Брежнев на балкон - на звезды посмотреть. Глянул - а луна-то не красная! Он позвонил кому надо, ему ответили, мол, все ОК, будет сделано! Выходит на следующий день - луна красная, как мак! Ильич лег спать довольным. На следующий день вышел - у луны снизу треугольник белый и надпись черным - Marlboro. Он звонит, ему - будет сделано! Он ложится спать. На следующий день - красная луна, белый треугольник, Мальборо и подпись внизу - \"московская фабрика Дукат\". Ильич ложится довольным. Следующий день. Глянул Брежнев - красная луна, Мальборо, фабрика Дукат, а внизу подпись - по лицензии компании Phillip Morris Ltd. Звонит, ему - будет сделано. Следующий день. Брежнев на балконе. Красная луна, белый треугольник, надпись Marlboro, подпись \"московская фабрика Дукат\", еще подпись \"по лицензии компании Phillip Morris Ltd.\", а внизу крупными буквами - МИНИСТЕРСТВО ОБОРОНЫ СССР ПРЕДУПРЕЖДАЕТ...");
INSERT INTO chat_shutnik VALUES("431","Вовочка пpедлагает Машеньке: - Машка, а давай мы с тобой в семью поигpаем? - А как? - Сначала потp#хаемся - а потом хаpактеpами не сойдёмся!");
INSERT INTO chat_shutnik VALUES("432","После того, как хирург сделал даме пластическую операцию, удалив двойной подбородок и придав носу классическую форму, она попросила, чтобы он расширил ей глаза.\n- Это уже лишнее, - заявил хирург, - у вас глаза станут и без того широкими, когда вы увидите счет за две первые операции.");
INSERT INTO chat_shutnik VALUES("433","Новый русский приходит к дантисту. Садится в кресло, открывает рот и дантист обалдевает: верхняя челюсть платиновая, а нижняя - золотая! Обалдевши дантист спрашивает: - А чем я могу помочь !??? - Как чем? Ты сигнализатцию поставь.");
INSERT INTO chat_shutnik VALUES("434","И настали в России смутные времена - лица кавказской национальности стали проверять прописку у работников милиции, а гаишники давать взятки водителям...");
INSERT INTO chat_shutnik VALUES("435","- Что-нибудь поймали? - интересуется прохожий.\n- Да, - мрачно отвечает рыбак.\n- Поймал одного и бросил в реку.\n- Наверное, маленький был? - Да, ростом примерно с вас и такой же назойливый.");
INSERT INTO chat_shutnik VALUES("436","- Мадам, почему вы уменьшили свой возраст на шесть лет? - Дело в том, что первые шесть лет я не умела считать.");
INSERT INTO chat_shutnik VALUES("437","Ленин с Крупской сидят и пьют чай. Вдруг на лестнице раздался страшный грохот и лязг.\n- Наденька, кажется, в прихожей упал несгораемый шкаф...\n- Нет, Володя, это железный Феликс на перилах катается.");
INSERT INTO chat_shutnik VALUES("438","Вопрос: Почему большинство женщин не может уснуть после оргазма? Ответ: Потому что им нужно еще до дома добираться!");
INSERT INTO chat_shutnik VALUES("439","- Доктор, я после ампутации не чувствую правую ногу.\n- Как же вы, голубчик, хотите ее чувствовать, если она у вас ампутирована?.\n- Так мне же ампутировали левую!");
INSERT INTO chat_shutnik VALUES("440","С завистью про одну знакомую: - Она только что вернулась с черноморского побережья с чудесно загоревшим языком!");
INSERT INTO chat_shutnik VALUES("441","Винни-Пух полез за медом и застрял.\n- Пятачок! Пятачок! Отдери меня! Ну Пятачок и отодрал. Через два дня пошел дождь, Винни-Пух отлип и упал.");
INSERT INTO chat_shutnik VALUES("442","Как пытают Саддама Хусейна? - показывают портрет Мадлен Олбрайт");
INSERT INTO chat_shutnik VALUES("443","У нового рyсского спрашивают: \"За сколько минимyм Вы пробежите метровкy?\" (HР): \"Минимyм за $.\"");
INSERT INTO chat_shutnik VALUES("444","\"Как я учился трахаться\" - руководство по установке \"Windows\"");
INSERT INTO chat_shutnik VALUES("445","Парочка едет на спортивном автомобиле. Она: - Дорогой, не надо ехать так быстро, я боюсь. Он: - А ты закрой глаза, как я.");
INSERT INTO chat_shutnik VALUES("446","Вопpос к аpмянскому pадио: - Женятся ли онанисты? Ответ: - Да. Hа дояpках!");
INSERT INTO chat_shutnik VALUES("447","Солдат стройбата берет пачку \"Беломора\" и по слогам читает: - Минздрав предупреждает...\n- прикурил, затянулся, поглядел мечтательно вдаль и произнес: - Вот же гады, на лопатах-то такое не пишут.");
INSERT INTO chat_shutnik VALUES("448","- Pядовой Петpов - выйти из cтpоя - шагов впеpед! - Pаз, два, тpи... Cемь! Дальше не могy, товаpищ майоp, - стена! - А дальше и не надо! Pота - ПЛИ !!!");
INSERT INTO chat_shutnik VALUES("449","Все хорошо, что хорошо конча...");
INSERT INTO chat_shutnik VALUES("450","Встречаются два друга. Один спрашивает другого: - Ты, я вижу, к Интернету подключился! - Как ты узнал? - По глазам.\n- Стали умнее? - Нет, краснее... (с) АС");
INSERT INTO chat_shutnik VALUES("451","Нынче очень легко стало отличить КТО есть КТО в американской политике. Демократы называют его Кеннет Старр, а Республиканцы уважительно Судья Старр...");
INSERT INTO chat_shutnik VALUES("452","К врачу приходит пациент с полностью черным языком.\n- Что это с вами? - Да вот, пролил водку на свежеуложенный асфальт...");
INSERT INTO chat_shutnik VALUES("453","В кабинет врача входит девушка: - Раздевайтесь, пожалуйста, - говорит ей врач.\n- Зачем?! - вспыхивает девушка.\n- У меня ведь болит ухо! - В таком случае вам не ко мне, - отвечает врач.\n- Я глазник.");
INSERT INTO chat_shutnik VALUES("454","Похороны. Катафалк, после того как на него погрузили гроб, трогается с места. Случайные свидетели наблюдают такую душераздирающую сцену: за катафалком бежит мальчуган лет восьми и рыдает: - Папа, папочка, куда же ты, не оставляй меня, я хочу с тобой!!! Но тут вдруг катафалк останавливается, из кабины выходит шофер и орет мальчику: - А ну марш домой, кому сказал! Не сделаешь уроки к моему приходу - я тебе ремня дам!");
INSERT INTO chat_shutnik VALUES("455","Сдают мужики сперму в больнице. Очередь большая. Вдруг подходит девушка и становится молча в очередь. Пять минут стоит и молчит. Десять. Народ удивляется. Подходит к ней мужик и спрашивает: - А вы что, тоже сперму сдаете ? А она отвечает, не раскрывая рта: - Угу.");
INSERT INTO chat_shutnik VALUES("456","В кабинет врача входит девушка: - Раздевайтесь, пожалуйста, - говорит ей врач.\n- Зачем?! - вспыхивает девушка.\n- У меня ведь болит ухо! - В таком случае вам не ко мне, - отвечает врач.\n- Я глазник.");
INSERT INTO chat_shutnik VALUES("457","Похороны. Катафалк, после того как на него погрузили гроб, трогается с места. Случайные свидетели наблюдают такую душераздирающую сцену: за катафалком бежит мальчуган лет восьми и рыдает: - Папа, папочка, куда же ты, не оставляй меня, я хочу с тобой!!! Но тут вдруг катафалк останавливается, из кабины выходит шофер и орет мальчику: - А ну марш домой, кому сказал! Не сделаешь уроки к моему приходу - я тебе ремня дам!");
INSERT INTO chat_shutnik VALUES("458","Сдают мужики сперму в больнице. Очередь большая. Вдруг подходит девушка и становится молча в очередь. Пять минут стоит и молчит. Десять. Народ удивляется. Подходит к ней мужик и спрашивает: - А вы что, тоже сперму сдаете ? А она отвечает, не раскрывая рта: - Угу.");
INSERT INTO chat_shutnik VALUES("459","Приходит барышня к гинекологу.\n- Доктор, вы мне вчера спиральку поставили...\n- Да, помню.\n- Но она слишком длинная.\n- Присядьте пока, через минут поменяю. Барышня садится: пау-уау-уау!");
INSERT INTO chat_shutnik VALUES("460","Тяпница (день недели - время выпить)");
INSERT INTO chat_shutnik VALUES("461","Три секретарши в кафе обсуждают своего негодяя-босса.\n- Я вылила пузырек чернил в ящик его письменного стола.\n- А я нашла у него в столе презерватив и проколола его иглой. Третья падает в обморок.");
INSERT INTO chat_shutnik VALUES("462","Чукча приехал домой из Москвы и говорит: - Чукча в Москве был, чукча умным стал, все знает. Оказывается, Карл, Маркс, Фридрих, Энгельс не четыре человека, а два, а Слава КПСС - вообще не человек.");
INSERT INTO chat_shutnik VALUES("463","Если бы люди водили автомобили также, как они работают на компьютерах (разговор по телефону Водителя и Техника из тех. поддержки) Техник: Водительская тех. поддержка. Чем можем помочь? Водитель: Эта... Машина у меня не заводится. Техник: Ясненько. Какая у вашей машины марка, модель, и год выпуска? Водитель: А я... хрен его знает! Я ее купил в магазин ездить, откуда мне знать... Техник: Хорошо-хорошо, успокойтесь. Попробуем обойтись без этой информации... (вздох) У вас есть бензин в баке? Водитель: Гм... Бензин в баке, говоришь... А как я узнаю? Техник: На передней панели посмотрите. Куда стрелка показывает, на \"Е\" или на \"F\"? Водитель: А где передняя панель? Техник: Она находится сразу за рулем если вы сидите в водительском кресле. Водитель: А! Вижу. .. Тэкс... А тут стрелок много, которую из них смотреть? Техник: Смотрите на ту, рядом с которой написано Е или F. Там еще может быть бензоколонка нарисована. Водитель: Ааа! Вижу. Стрелка показывает на ноль. Техник: Как на ноль? Водитель: Ага. Прямо на ноль. А ещ");
INSERT INTO chat_shutnik VALUES("464","- Алло! Это \"секс по-телефону\"? - Да.\n- Значит, так. Hикаких кружевных трусиков, чулочек. Ты - блондинка, толстая, раскрасневшаяся. Абсолютно голая, но в резиновых сапогах. Звать тебя Клава. Hедавно кончилась война, примерно сорок шестой год. Мы - на сеновале. Пахнет конским навозом. Лучик света сквозь дыру в крыше упал на мою спину... Поехали, Клавка!");
INSERT INTO chat_shutnik VALUES("465","Отправляют первого китайца в космос. В напутствие ему говорят: Летишь ты не надолго, но еды мы тебе дадим много - кушай сколько хочешь, а мешочек (для естественных отходов организма) в скафандр пришили небольшой (ну на сутки, зачем большой?)... Приземлятся китайский космонавт. Еда нетронута, а вот мешочек порвался :( (c) Toha, onliner.by");
INSERT INTO chat_shutnik VALUES("466","Разговор мужа и жены: - Слушай, что мы подарим на этот раз моей маме на день рождения ? - А что мы дарили в прошлый раз ? - В прошлый раз мы подарили ей стул.\n- Hу а теперь подведем к нему электричество.");
INSERT INTO chat_shutnik VALUES("467","- Моня, ты что делаешь сегодня вечером? - Да, вроде, ничего.\n- Давай пойдем в клуб \"Кому за тридцать\". Договорились, но Моня не пришел. Встречаются на другой день.\n- Ну чего же ты не пришел? Я так хорошо провел время, там такие женщины...\n- Хаим, а я померил, у меня только двадцать четыре... Ну я и не пошел.");
INSERT INTO chat_shutnik VALUES("468","На еврейском кладбище в Одессе три землекопа присели отдохнуть у трех могил известных людей.\n- Хотел бы я лежать вот здесь, рядом с Рабиновичем, а ты? - говорит один.\n- Нет, я предпочел бы рядом с Абрамовичем.\n- А я предпочел бы прямо сейчас лежать с женой Когана...\n- Так она же жива! - Вот и я про то же!");
INSERT INTO chat_shutnik VALUES("469","Один приятель другому: - Ты знаешь, я когда в командировку последний раз уезжал, в шкафу капкан на медведя оставил. Представляешь - приезжаю и сразу к шкафу бегу, смотрю - сидит красавец! - Кто? Любовник? - Да нет... Медведь!");
INSERT INTO chat_shutnik VALUES("470","Явлинский-Болдырев-Лукин - ЯБЛоко. Немцов-Хакамада-Чубайс - НеХаЧу. Коалиция: \"НЕХАЧУ ЯБЛОКО\". &copy; Хрюн");
INSERT INTO chat_shutnik VALUES("471","- У этой пьесы был счастливый конец? - Конечно, все были так рады, что она закончилась.");
INSERT INTO chat_shutnik VALUES("472","Как называется человек, который не дарит подарков своей любовнице? Ответ: Дармоёб");
INSERT INTO chat_shutnik VALUES("473","- Доктоp, я пеpестала получать удовольствие от колбасы.\n- А что вы с ней, пpостите, делаете? - Я ее ем...");
INSERT INTO chat_shutnik VALUES("474","Пришел муж домой, уставший с работы. Поел и лег с женой спать. Всю ночь жена ластится к нему и так, и сяк, а он ворчит: - Отстань, Машка, у меня еще колосок не созрел... Спать хочу! На следующую ночь повторяется то же самое. На третью ночь муж начал сам к ней ластиться - и так, и сяк. А она ему отвечает: - Чё пристал? - Колосок-то созрел, - отвечает муж.\n- Ну вот еще, - ворчит жена, - буду из-за одного колоска весь комбайн заводить!");
INSERT INTO chat_shutnik VALUES("475","Два часа ночи. Звонок в дверь. Жена открывает дверь и... тело мужа падает в коридор.\n- Свинья! Ну что за радость каждый раз напиваться до полусмерти..!? - Прасти, драгая, ккак вседа денег неххватило....!!!");
INSERT INTO chat_shutnik VALUES("476","Заходит мужик в аптеку. М. У вас бананы есть? А. Нет. Здесь дорогой аптека и бананов не бывает. а следующий день снова он же заходит в аптеку. М. У вас Бананы есть? А. Да нет же здесь аптека здесь лекарства разные банки и т.д. Так повторяется в течении пяти дней, заебанный аптекарь на большом ватмане крупными буквами пишет объявление \"БАНАНОВ НЕТ! \" Заходит тот же мужчина, внимательно читает объявление, Подходит к Аптекарю и с обидой говорит \"А значит были бананы!\"");
INSERT INTO chat_shutnik VALUES("477","Дерется Чебурашка с Кощеем Бессмертным. Кощей говорит: - Все равно ты меня не убьешь. У меня смерть в яйце. Последовал удар.\n- У... да не в том!!!");
INSERT INTO chat_shutnik VALUES("478","В роддоме. Из операционной выходит молоденькая медсестра и говорит мужчине, ждущему результатов родов своей жены: - Поздравляю вас! У вас родился сын с шестью кулачками. Мужик побледнел и чуть не упал в обморок. А медсестра, хохоча: - Обманули дурачка на четыре кулачка!");
INSERT INTO chat_shutnik VALUES("479","Двое охранителей купили Мерседесы. И сразу же возник вопрос: дескать, как мы эти Мерседесы отличать будем? Вот один и говорит: - Послушай, давай разобьем у твоего левую фару, а у моего - правую. Так и будем отличать... Другой согласился. Так и сделали. Второй посмотрел-посмотрел и спрашивает: - Послушай, братан. Фары-то мы разбили, а ты помнишь, какая фара у твоей разбита - правая или левая? - Не-а.\n- Давай разобьем и другую фару. Разбили обе фары обеих машин, сидят и смотрят...\n- Послушай, братан, а ведь опять машины не отличишь.У обеих обе фары разбиты! - Ну, слушай, надоело с этими Мерседесами цацкаться. Ты бери черную, а мне таки-да достанется белая.");
INSERT INTO chat_shutnik VALUES("480","- Эй мужик, ты пиво будешь? - Буду, конечно! - Когда будешь, то меня позови...");
INSERT INTO chat_shutnik VALUES("481","Осмотрев кран, сантехник говорит девушке - хозяйке квартиры: - А прокладку-то вам пора менять! Девушка, смущенно покраснев, бормочет: - А вы-то откуда знаете?");
INSERT INTO chat_shutnik VALUES("482","Приходит Вовочка из школы и говорит отцу: - Мне двойку по биологии поставили. Папаша: - За что? - Да спросили у кого самые большие яйца.\n- Ну а ты? - Я сказал у верблюда.\n- Правильно, а учительница? - А она говорит что у страуса. Отец (задумчиво): - У Страуса ... так вот он почему такие медленные вальсы писал.");
INSERT INTO chat_shutnik VALUES("483","Когда АбрамОвич родился, АбрАмович три дня плакал...");
INSERT INTO chat_shutnik VALUES("484","Приходит женщина к врачу: - Доктор, я хотела бы подправить форму одной груди. А то они у меня не одинаковые.\n- Ну показывайте.\n- Вот эта (вытаскивает) нормальная.\n- Вполне.\n- А вот эта (вытаскивает, грудь пля-ф-ф-ф-ф на пол) видите, какая? Доктор чешет в затылке: - Да, такое я в первый раз вижу.\n- Это, наверно, из-за моего мужа. Он, понимаете, не может заснуть, если за мою грудь не держится.\n- Ну что вы такое рассказываете? Я вам признаюсь, у меня самого есть такая маленькая мания, но у моей супруги грудь нормальная.\n- Так вы, наверно, доктор, с женой в одной комнате спите?");
INSERT INTO chat_shutnik VALUES("485","В нью-йоркском отеле вывешено объявление: \"Гасите сигареты! Помните о пожаре в Чикаго!\" Под этим объявлением кто-то подписал: \"Hе плюйте на пол, помните о весенних разливах Миссисипи!\"");
INSERT INTO chat_shutnik VALUES("486","По дороге на мопеде ехал \"голубой\". Ну и заглох его мопед. Встал он на обочине, пригорюнился. Тут к нему на \"Мерседесе\" подъезжает \"крутой\" и небрежно так открывая окно спрашивает: - Ну что, мужик, толкнем твое говно? Педик (с радостью в голосе): - Конечно, толкнем!! А потом и мопед починим!!");
INSERT INTO chat_shutnik VALUES("487","Мужик, недавно купивший себе \"Феppаpи\", несется на этой машине с огpомной скоpостью, наслаждаясь мощью двигателя. Вдpуг он видит табличку: \"Сбавь скоpость - км\". Мужик думает: \"Можно ведь было пpосто установить соответствующий запpещающий знак. А pаз они этого не сделали, значит, тут что-то сеpьезное и скоpость действительно надо сбавить\". Сбавляет он скоpость до км/ч - и чеpез некотоpое вpемя видит еще одну табличку: \"Сбавь скоpость - км\". Он и на этот pаз сбавляет скоpость до км/ч, хоть и с большой неохотой. Чеpез полчаса - опять табличка: \"Сбавь скоpость км\". Пpоклиная все на свете, он замедляется до км/ч. А еще чеpез час он видит такую вывеску: \"Добpо пожаловать в пpидоpожный pестоpан \"Сбавь скоpость!\"\"");
INSERT INTO chat_shutnik VALUES("488","В испанском публичном доме \"мадам\" кричит: - Донна Мария, дон Педро все еще на вас? - Да.\n- Не давайте ему кончить, он заплатил фальшивыми купюрами.");
INSERT INTO chat_shutnik VALUES("489","Пришел мужчина на пляж. Снимает майку - вся спина искусана. Народ: - Мужик, что у тебя со спиной-то?! Мужик, отмахиваясь: - Да вчера тут голубого трахал, дык всю спину изгрыз, зараза!");
INSERT INTO chat_shutnik VALUES("490","Мужик приходит в фирму по объявлению \"Требуется менеджер\". Показывает боссу свои дипломы - финансовый институт, школа управления, курсы менеджмента и т.п. Босс: - Это хорошо. Мне нужен сообразительный управленец. Он должен взять на себя главный наш больной вопрос - финансы. Кандидат: - С моим образованием это без проблем. А как насчет заработка? - Ну, вы начинающий, предполагаю вам пока положить $.\n- Да? Но откуда же ваша маленькая фирма берет средства, чтобы платить такие деньги? - Вот. Вот это первый вопрос, который вам предстоит решить.");
INSERT INTO chat_shutnik VALUES("491","Когда мужчины спрашивали ее о возрасте, она кокетливо смеялась и отвечала, что женщине столько лет, на сколько она выглядит. Некоторые ей верили и имели большие проблемы - паршивке еще не было -ти.");
INSERT INTO chat_shutnik VALUES("492","И волки сыты, и овцы целы. Светлая память пастуху!");
INSERT INTO chat_shutnik VALUES("493","\"Все зло от Б.А.Б.!\" В.В.П.");
INSERT INTO chat_shutnik VALUES("494","Заяц отслужил на флоте и возвращается домой. Идет по лесу, поет песню: - На побывку едет молодой моряк! В кустах его поджидает Волк, который тоже служил на флоте, и тоже тихонько напевает: - Напрасно старушка ждет сына домой!");
INSERT INTO chat_shutnik VALUES("495","В бане два маленьких мальчика увидели голого мужчину с большим животом. Спрашивают его: - Дядя, а что у тебя в животе? - Бомба. Один тихо говорит другому: - Давай взорвем ее.\n- Опасно очень короткий фитиль.");
INSERT INTO chat_shutnik VALUES("496","Два бpаконьеpа: - Вчеpа поймал огpомного осетpа. Закинyл его на спинy и идy домой.\n- Hy? - А тyт из-за кyстов - инспектоp pыбнадзоpа! - Hy?! - А я осетpа со спины - и в каpман!");
INSERT INTO chat_shutnik VALUES("497","- Твоя собака, сосед, укусила мою жену за ногу. Придется тебе заплатить штраф.\n- За то, что может быть возмещено,- отвечает Насреддин,- нельзя требовать выкупа. Пришли свою собаку, пусть она укусит за ногу мою жену. И мы в расчете!");
INSERT INTO chat_shutnik VALUES("498","Ползут по пустыне два унитаза. Один говорит другому: - Ген, а Ген ! Давай приколупаемся к той черепахе ! - Hе надо, Чебурашка, Мы уже к старику Хотабычу приколупались !");
INSERT INTO chat_shutnik VALUES("499","У Моллы был длиннорогий бык. Целые дни и ночи Молла думал: как бы хоть раз сесть быку на голову, между рогами. Но удачного случая не представлялось. Однажды ночью Молла вышел во двор и видит: бык лежит на земле, пережевывая свою жвачку. Вот подходящий момент! -подумал Молла. Подобрав полы своей чохи, он вскочил быку на голову и уселся между рогами. Бык, испугавшись, вскочил и, мотнув головой, сбросил Моллу на землю. Молла закричал и упал в обморок. Услышав крик Моллы, жена его выбежала из дому и видит: муж ее лежит в крови, без сознания. Она подняла крик. Сбежался народ. Моллу привели в чувство. Оказалось, он сломал ногу. Его подняли, внесли в дом и уложили в постель. Молла огляделся по сторонам и заметил, что жена плачет. Он поднял голову и сказал ей: - Жена, не плачь. Хотя я упал и разбился, но зато желание мое исполнилось.");
INSERT INTO chat_shutnik VALUES("500","Идет мужик пьяный, смотрит - лужа, а в луже луна отражается.\n- У, сейчас на луне покатаюсь. Сел на нее и сидит. Идет милиционер, увидел мужика и спрашивает: - Эй, мужик, ты что тут делаешь? - На луне сижу.\n- Ну сиди, сиди, сейчас луноход подойдет.");



DROP TABLE IF EXISTS `chat_vopros`;

CREATE TABLE `chat_vopros` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vopros` varchar(1024) NOT NULL,
  `otvet` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=502 DEFAULT CHARSET=utf8;

INSERT INTO chat_vopros VALUES("2","Сильная жара.","зной");
INSERT INTO chat_vopros VALUES("3","Пояс, территория с какими-либо общими признаками.","зона");
INSERT INTO chat_vopros VALUES("4","Медицинский инструмент для исследования внутренностей организма.","зонд");
INSERT INTO chat_vopros VALUES("5","Метеорологический воздушный шар.","зонд");
INSERT INTO chat_vopros VALUES("6","Крупный дикий лесной бык.","зубр");
INSERT INTO chat_vopros VALUES("7","Легкая рябь на водной поверхности.","зыбь");
INSERT INTO chat_vopros VALUES("8","Южный ветер, юг.","зюйд");
INSERT INTO chat_vopros VALUES("9","Поле, вспаханное с осени для посева яровых.","зябь");
INSERT INTO chat_vopros VALUES("10","Мысль, намерение, план.","идея");
INSERT INTO chat_vopros VALUES("11","Язык части евреев.","идиш");
INSERT INTO chat_vopros VALUES("12","Статуя, предмет, которому поклоняются как божеству.","идол");
INSERT INTO chat_vopros VALUES("13","Сушеные ягоды винограда.","изюм");
INSERT INTO chat_vopros VALUES("14","Жестокий древнеиудейский царь.","ирод");
INSERT INTO chat_vopros VALUES("15","Помесь лошади и осла.","ишак");
INSERT INTO chat_vopros VALUES("16","Осел или мул.","ишак");
INSERT INTO chat_vopros VALUES("17","Невысокая упрямая лошадь.","осел");
INSERT INTO chat_vopros VALUES("18","Исторически сложившаяся группа человечества с общими наследственными признаками.","раса");
INSERT INTO chat_vopros VALUES("19","Буква греческого алфавита.","йота");
INSERT INTO chat_vopros VALUES("20","Ледяная корка на снегу.","наст");
INSERT INTO chat_vopros VALUES("21","Представитель черной расы.","негр");
INSERT INTO chat_vopros VALUES("22","Углубление в стене, скате горы, берега.","ниша");
INSERT INTO chat_vopros VALUES("23","Число, деление на которое невозможно.","нуль");
INSERT INTO chat_vopros VALUES("24","В древнегреческой мифологии богиня победы.","ника");
INSERT INTO chat_vopros VALUES("25","Женское имя (греч. победительница).","ника");
INSERT INTO chat_vopros VALUES("26","Зазор между сопряженными поверхностями частей машин.","люфт");
INSERT INTO chat_vopros VALUES("27","Единица освещенности.","люкс");
INSERT INTO chat_vopros VALUES("28","Лучший номер в гостинице.","люкс");
INSERT INTO chat_vopros VALUES("29","Внутренняя часть коры липы, ивы.","лыко");
INSERT INTO chat_vopros VALUES("30","Материал для плетения лаптей.","лыко");
INSERT INTO chat_vopros VALUES("31","Буддийский монах.","лама");
INSERT INTO chat_vopros VALUES("32","Южноамериканское вьючное животное.","лама");
INSERT INTO chat_vopros VALUES("33","Южное вечнозеленое душистое растение, листья которого употребляются как специя.","лавр");
INSERT INTO chat_vopros VALUES("34","Стройное быстрое животное сем. оленей.","лань");
INSERT INTO chat_vopros VALUES("35","Ребро чеканной монеты.","гурт");
INSERT INTO chat_vopros VALUES("36","Стадо домашних животных.","гурт");
INSERT INTO chat_vopros VALUES("37","Духовный наставник, учитель.","гуру");
INSERT INTO chat_vopros VALUES("38","Туго натянутая веревка на судне, предохраняющая от падения людей за борт.","леер");
INSERT INTO chat_vopros VALUES("39","Ограждение вдоль бортов судна.","леер");
INSERT INTO chat_vopros VALUES("40","Край диска звезды, планеты.","лимб");
INSERT INTO chat_vopros VALUES("41","Кольцо с делениями для отсчета углов в угломерных инструментах.","лимб");
INSERT INTO chat_vopros VALUES("42","Пеньковый трос для корабельных снастей.","линь");
INSERT INTO chat_vopros VALUES("43","Пресноводная рыба сем. карповых с толстым слизистым телом.","линь");
INSERT INTO chat_vopros VALUES("44","Медоносное лиственное дерево.","липа");
INSERT INTO chat_vopros VALUES("45","Старинный струнный музыкальный инструмент.","лира");
INSERT INTO chat_vopros VALUES("46","Созвездие Северного полушария.","лира");
INSERT INTO chat_vopros VALUES("47","Денежная единица Италии, Турции.","лира");
INSERT INTO chat_vopros VALUES("48","Хитрая хищница с пушистым хвостом.","лиса");
INSERT INTO chat_vopros VALUES("49","Венгерский композитор, дирижер, создатель нового направления в пианизме, симфонии \"Орфей\", \"Прометей\".","лист");
INSERT INTO chat_vopros VALUES("50","Часть кроны дерева.","лист");
INSERT INTO chat_vopros VALUES("51","Метрическая единица объема.","литр");
INSERT INTO chat_vopros VALUES("52","Подъемник с кабиной для перемещения грузов, людей.","лифт");
INSERT INTO chat_vopros VALUES("53","Неправда, обман.","ложь");
INSERT INTO chat_vopros VALUES("54","Высший дворянский наследственный титул в Англии.","лорд");
INSERT INTO chat_vopros VALUES("55","Попугай, питающийся нектаром.","лори");
INSERT INTO chat_vopros VALUES("56","Самый крупный олень.","лось");
INSERT INTO chat_vopros VALUES("57","Крупный олень с широкими рогами.","лось");
INSERT INTO chat_vopros VALUES("58","Сохатый.","лось");
INSERT INTO chat_vopros VALUES("59","Ямка с водой.","лужа");
INSERT INTO chat_vopros VALUES("60","Корзинка бильярдного стола.","луза");
INSERT INTO chat_vopros VALUES("61","Увеличительное стекло.","лупа");
INSERT INTO chat_vopros VALUES("62","Наружное лекарство.","мазь");
INSERT INTO chat_vopros VALUES("63","Состав для натирания различных участков тела.","мазь");
INSERT INTO chat_vopros VALUES("64","Французский художник-импрессионист, картины \"Завтрак на траве\", \"Олимпия\".","мане");
INSERT INTO chat_vopros VALUES("65","Планета Солнечной системы.","марс");
INSERT INTO chat_vopros VALUES("66","В древнеримской мифологии бог войны.","марс");
INSERT INTO chat_vopros VALUES("67","Площадка на верху мачты для наблюдения над горизонтом.","марс");
INSERT INTO chat_vopros VALUES("68","Выдающаяся французская эстрадная певица.","пиаф");
INSERT INTO chat_vopros VALUES("69","Пресная сухая лепешка у евреев.","маца");
INSERT INTO chat_vopros VALUES("70","Береговой ориентир для судов.","маяк");
INSERT INTO chat_vopros VALUES("71","Непрозрачность воздуха из-за пыли, дыма, метели, сумерек.","мгла");
INSERT INTO chat_vopros VALUES("72","Ночной сумрак.","мгла");
INSERT INTO chat_vopros VALUES("73","Спортивное состязание.","матч");
INSERT INTO chat_vopros VALUES("74","Ковкий химический элемент красновато-желтого цвета.","медь");
INSERT INTO chat_vopros VALUES("75","Граница земельных участков.","межа");
INSERT INTO chat_vopros VALUES("76","Основная единица длины.","метр");
INSERT INTO chat_vopros VALUES("77","Английская морская единица длины = 1,852 км.","миля");
INSERT INTO chat_vopros VALUES("78","Английская единица длины = 1,60934 км.","миля");
INSERT INTO chat_vopros VALUES("79","Непрочная, быстропроходящая популярность.","мода");
INSERT INTO chat_vopros VALUES("80","Бабочка, вредитель вещей.","моль");
INSERT INTO chat_vopros VALUES("81","Единица количества вещества.","моль");
INSERT INTO chat_vopros VALUES("82","Французский художник-импрессионист, картина \"Кувшинки\".","моне");
INSERT INTO chat_vopros VALUES("83","Английский писатель, мастер новеллы, роман \"Луна и грош\".","моэм");
INSERT INTO chat_vopros VALUES("84","Плотная шелковая ткань, переливающаяся на свету.","муар");
INSERT INTO chat_vopros VALUES("85","В греческой мифологии одна из девяти муз, покровительница истории.","клио");
INSERT INTO chat_vopros VALUES("86","Надоедливое двукрылое насекомое.","муха");
INSERT INTO chat_vopros VALUES("87","Созвездие Южного полушария.","муха");
INSERT INTO chat_vopros VALUES("88","Моющее средство.","мыло");
INSERT INTO chat_vopros VALUES("89","Грызун, вредитель сельского хозяйства.","мышь");
INSERT INTO chat_vopros VALUES("90","Периферийное устройство компьютера.","мышь");
INSERT INTO chat_vopros VALUES("91","Нестабильная заряженная элементарная частица.","мюон");
INSERT INTO chat_vopros VALUES("92","Часть туши убитого животного, употребляемая в пищу.","мясо");
INSERT INTO chat_vopros VALUES("93","Основной источник белка в питании человека.","мясо");
INSERT INTO chat_vopros VALUES("94","Душистое лекарственное растение.","мята");
INSERT INTO chat_vopros VALUES("95","Выпуклая замкнутая плоская кривая без изломов.","овал");
INSERT INTO chat_vopros VALUES("96","Зодиакальное созвездие (март).","овен");
INSERT INTO chat_vopros VALUES("97","Домашнее жвачное животное.","овца");
INSERT INTO chat_vopros VALUES("98","Полевое земляное укрытие личного состава.","окоп");
INSERT INTO chat_vopros VALUES("99","Государство на Аравийском полуострове.","оман");
INSERT INTO chat_vopros VALUES("100","Буква греческого алфавита.","бета");
INSERT INTO chat_vopros VALUES("101","Областной центр, порт на реке Иртыш.","омск");
INSERT INTO chat_vopros VALUES("102","Аморфный драгоценный камень.","опал");
INSERT INTO chat_vopros VALUES("103","Накопленные знания и навыки.","опыт");
INSERT INTO chat_vopros VALUES("104","Научный эксперимент.","опыт");
INSERT INTO chat_vopros VALUES("105","Плод в скорлупе.","орех");
INSERT INTO chat_vopros VALUES("106","Роман Войнич .","овод");
INSERT INTO chat_vopros VALUES("107","Двукрылое насекомое, личинки которого паразитируют в теле животных.","овод");
INSERT INTO chat_vopros VALUES("108","Трудноискоренимый сорняк.","осот");
INSERT INTO chat_vopros VALUES("109","Крупная сорная колючая трава.","осот");
INSERT INTO chat_vopros VALUES("110","Способность воспринимать звуковые колебания.","слух");
INSERT INTO chat_vopros VALUES("111","Прибор для коррекции зрения.","очки");
INSERT INTO chat_vopros VALUES("112","Американские авиаконструкторы, братья, пионеры авиации.","райт");
INSERT INTO chat_vopros VALUES("113","Звание, чин.","ранг");
INSERT INTO chat_vopros VALUES("114","Кровососущее насекомое, паразит.","клоп");
INSERT INTO chat_vopros VALUES("115","Пьеса В.Маяковского .","клоп");
INSERT INTO chat_vopros VALUES("116","Связанные между собой плавучие предметы для перевозки грузов, людей.","плот");
INSERT INTO chat_vopros VALUES("117","Скрепленные между собой бревна для переправы.","плот");
INSERT INTO chat_vopros VALUES("118","Маршрут в один конец.","рейс");
INSERT INTO chat_vopros VALUES("119","Большой водный поток, текущий в русле.","река");
INSERT INTO chat_vopros VALUES("120","Порода короткошерстных кроликов.","рекс");
INSERT INTO chat_vopros VALUES("121","Способность человека говорить.","речь");
INSERT INTO chat_vopros VALUES("122","Металлический оклад на иконе.","риза");
INSERT INTO chat_vopros VALUES("123","Темп, скорость музыки.","ритм");
INSERT INTO chat_vopros VALUES("124","Твердые выросты на голове копытных животных.","рога");
INSERT INTO chat_vopros VALUES("125","Яровой злак.","рожь");
INSERT INTO chat_vopros VALUES("126","Декоративный душистый цветок с шипами на стебле.","роза");
INSERT INTO chat_vopros VALUES("127","Воплощенный актером образ.","роль");
INSERT INTO chat_vopros VALUES("128","Параллелограмм с равными сторонами.","ромб");
INSERT INTO chat_vopros VALUES("129","Река в Швейцарии и Франции.","рона");
INSERT INTO chat_vopros VALUES("130","Конденсат на почве, траве.","роса");
INSERT INTO chat_vopros VALUES("131","Английские полярные исследователи, дядя и племянник.","росс");
INSERT INTO chat_vopros VALUES("132","Японская национальная борьба.","сумо");
INSERT INTO chat_vopros VALUES("133","Небольшой лесной массив лиственных деревьев.","роща");
INSERT INTO chat_vopros VALUES("134","Минеральное полезное ископаемое, горная порода.","руда");
INSERT INTO chat_vopros VALUES("135","Поворотное устройство машин, судов.","руль");
INSERT INTO chat_vopros VALUES("136","Состриженная сплошным пластом шерсть овцы.","руно");
INSERT INTO chat_vopros VALUES("137","Водное позвоночное.","рыба");
INSERT INTO chat_vopros VALUES("138","Зодиакальное созвездие (февраль).","рыбы");
INSERT INTO chat_vopros VALUES("139","Способ бега лошади.","рысь");
INSERT INTO chat_vopros VALUES("140","Хищник с кисточками на ушах.","рысь");
INSERT INTO chat_vopros VALUES("141","Созвездие Северного полушария.","рысь");
INSERT INTO chat_vopros VALUES("142","Государство в Южной Америке.","перу");
INSERT INTO chat_vopros VALUES("143","Сладкая вязкая масса с орехами.","нуга");
INSERT INTO chat_vopros VALUES("144","Санитарка в лечебном учреждении.","няня");
INSERT INTO chat_vopros VALUES("145","Работница по уходу за детьми.","няня");
INSERT INTO chat_vopros VALUES("146","Тюремная кровать.","нары");
INSERT INTO chat_vopros VALUES("147","Немецкий писатель, мыслитель и естествоиспытатель, трагедия \"Фауст\".","гете");
INSERT INTO chat_vopros VALUES("148","Французский писатель, роман \"Отверженные\".","гюго");
INSERT INTO chat_vopros VALUES("149","Широкие массы населения.","низы");
INSERT INTO chat_vopros VALUES("150","Нижняя конечность человека.","нога");
INSERT INTO chat_vopros VALUES("151","Северный ветер, север.","норд");
INSERT INTO chat_vopros VALUES("152","Западный ветер, запад.","вест");
INSERT INTO chat_vopros VALUES("153","То же, что характер.","нрав");
INSERT INTO chat_vopros VALUES("154","Прием пищи в середине дня.","обед");
INSERT INTO chat_vopros VALUES("155","Резкий толчок.","удар");
INSERT INTO chat_vopros VALUES("156","Административно-территориальная единица в составе губернии в дореволюционной России.","уезд");
INSERT INTO chat_vopros VALUES("157","Чувство сильного страха.","ужас");
INSERT INTO chat_vopros VALUES("158","Вечерняя еда.","ужин");
INSERT INTO chat_vopros VALUES("159","Часть сбруи.","узда");
INSERT INTO chat_vopros VALUES("160","Постановление верховного органа власти, имеющее силу закона.","указ");
INSERT INTO chat_vopros VALUES("161","То же, что инъекция.","укол");
INSERT INTO chat_vopros VALUES("162","Упрек, порицание.","укор");
INSERT INTO chat_vopros VALUES("163","Военнослужащий легкой кавалерии в русской армии.","улан");
INSERT INTO chat_vopros VALUES("164","Количество пойманной рыбы, дичи.","улов");
INSERT INTO chat_vopros VALUES("165","Селение в Средней Азии и некоторых районах Сибири.","улус");
INSERT INTO chat_vopros VALUES("166","Белый медведь.","умка");
INSERT INTO chat_vopros VALUES("167","Учебный час в школе.","урок");
INSERT INTO chat_vopros VALUES("168","Сушеные абрикосы с косточками.","урюк");
INSERT INTO chat_vopros VALUES("169","Ложный слух.","утка");
INSERT INTO chat_vopros VALUES("170","Водоплавающая птица.","утка");
INSERT INTO chat_vopros VALUES("171","Начало дня.","утро");
INSERT INTO chat_vopros VALUES("172","Прибор для глаженья.","утюг");
INSERT INTO chat_vopros VALUES("173","Регистрация наличия чего-либо.","учет");
INSERT INTO chat_vopros VALUES("174","Небольшая кадка.","ушат");
INSERT INTO chat_vopros VALUES("175","В греческой мифологии царица богов, жена Зевса.","гера");
INSERT INTO chat_vopros VALUES("176","У мусульман человек иной веры.","гяур");
INSERT INTO chat_vopros VALUES("177","В старину налог с побежденных.","дань");
INSERT INTO chat_vopros VALUES("178","Календарное время какого-либо события.","дата");
INSERT INTO chat_vopros VALUES("179","Загородный участок с летним домом.","дача");
INSERT INTO chat_vopros VALUES("180","Здание, сооружение для ж/д подвижного состава.","депо");
INSERT INTO chat_vopros VALUES("181","Заросший травой верхний слой почвы.","дерн");
INSERT INTO chat_vopros VALUES("182","Волокнистое растение для изготовления, веревок канатов.","джут");
INSERT INTO chat_vopros VALUES("183","Укрепленная оборонительная огневая точка.","дзот");
INSERT INTO chat_vopros VALUES("184","Взятое взаймы.","долг");
INSERT INTO chat_vopros VALUES("185","Денежная единица Вьетнама.","донг");
INSERT INTO chat_vopros VALUES("186","Тяжелая плотная шерстяная ткань.","драп");
INSERT INTO chat_vopros VALUES("187","Близкий, верный товарищ.","друг");
INSERT INTO chat_vopros VALUES("188","Часть кривой линии.","дуга");
INSERT INTO chat_vopros VALUES("189","Часть окружности.","дуга");
INSERT INTO chat_vopros VALUES("190","Ствол огнестрельного оружия.","дуло");
INSERT INTO chat_vopros VALUES("191","Сорт небольших груш.","дуля");
INSERT INTO chat_vopros VALUES("192","Мысль, размышление.","дума");
INSERT INTO chat_vopros VALUES("193","Музыкальное произведение для двух исполнителей.","дуэт");
INSERT INTO chat_vopros VALUES("194","Старинное орудие пытки, на котором истязуемого растягивали.","дыба");
INSERT INTO chat_vopros VALUES("195","Бахчевая культура.","дыня");
INSERT INTO chat_vopros VALUES("196","Низший служитель в православной церкви.","дьяк");
INSERT INTO chat_vopros VALUES("197","Английская единица длины = 2,54 см.","дюйм");
INSERT INTO chat_vopros VALUES("198","Английская единица длины = 1/12 фута.","дюйм");
INSERT INTO chat_vopros VALUES("199","Полярная морская птица с ценным пухом.","гага");
INSERT INTO chat_vopros VALUES("200","Полярная утка.","гага");
INSERT INTO chat_vopros VALUES("201","Выжженное место в лесу.","гарь");
INSERT INTO chat_vopros VALUES("202","В греческой мифологии богиня вечной юности, супруга Геракла.","геба");
INSERT INTO chat_vopros VALUES("203","Студенистое вещество.","гель");
INSERT INTO chat_vopros VALUES("204","В западноевропейской мифологии карлик, охраняющий подземные сокровища.","гном");
INSERT INTO chat_vopros VALUES("205","Старая мера аптекарского веса = 62,21 мг.","гран");
INSERT INTO chat_vopros VALUES("206","Крупная хищная птица, питающаяся падалью.","гриф");
INSERT INTO chat_vopros VALUES("207","Часть музыкального инструмента, над которой натянуты струны.","гриф");
INSERT INTO chat_vopros VALUES("208","Сладкий разбавленный горячий напиток из рома или коньяка.","грог");
INSERT INTO chat_vopros VALUES("209","Старинная медная монета в полкопейки.","грош");
INSERT INTO chat_vopros VALUES("210","Очень подвижная рыбка.","вьюн");
INSERT INTO chat_vopros VALUES("211","Поклажа для перевозки на спине животных.","вьюк");
INSERT INTO chat_vopros VALUES("212","Сплетение нескольких букв в один сложный знак.","вязь");
INSERT INTO chat_vopros VALUES("213","Вспомогательный якорь на судне.","верп");
INSERT INTO chat_vopros VALUES("214","Древнегреческие счеты.","абак");
INSERT INTO chat_vopros VALUES("215","Монгольский крестьянин-скотовод.","арат");
INSERT INTO chat_vopros VALUES("216","Испанский гротескный живописец, гравер.","гойя");
INSERT INTO chat_vopros VALUES("217","Раскраска, оформление лица.","грим");
INSERT INTO chat_vopros VALUES("218","Тяжесть, тяжелый предмет.","груз");
INSERT INTO chat_vopros VALUES("219","Игральная карта.","дама");
INSERT INTO chat_vopros VALUES("220","Дерево с твердой древесиной сем. березовых.","граб");
INSERT INTO chat_vopros VALUES("221","Норвежский композитор, пианист, дирижер, сюита \"Пер Гюнт\".","григ");
INSERT INTO chat_vopros VALUES("222","Русский советский писатель, повесть \"Алые паруса\".","грин");
INSERT INTO chat_vopros VALUES("223","Действительное происшествие в прошлом.","быль");
INSERT INTO chat_vopros VALUES("224","Правдивая история.","быль");
INSERT INTO chat_vopros VALUES("225","Большие весы для тяжелых предметов.","вага");
INSERT INTO chat_vopros VALUES("226","Листья папоротников.","вайя");
INSERT INTO chat_vopros VALUES("227","Общее собрание горожан на Руси.","вече");
INSERT INTO chat_vopros VALUES("228","Индийский струнный щипковый музыкальный инструмент из сушеной тыквы.","вина");
INSERT INTO chat_vopros VALUES("229","Проступок, преступление.","вина");
INSERT INTO chat_vopros VALUES("230","Карточная игра.","вист");
INSERT INTO chat_vopros VALUES("231","Самая распространенная на земле жидкость.","вода");
INSERT INTO chat_vopros VALUES("232","Растаявший лед.","вода");
INSERT INTO chat_vopros VALUES("233","Короткий густой пушок на ткани.","ворс");
INSERT INTO chat_vopros VALUES("234","Материал для постройки пчелиных сот.","воск");
INSERT INTO chat_vopros VALUES("235","Путешествие, поездка.","вояж");
INSERT INTO chat_vopros VALUES("236","Ночная болотная птица.","выпь");
INSERT INTO chat_vopros VALUES("237","Небесная даль.","высь");
INSERT INTO chat_vopros VALUES("238","Французский композитор, опера \"Ромео и Джульетта\".","гуно");
INSERT INTO chat_vopros VALUES("239","Правый приток Амударьи.","вахш");
INSERT INTO chat_vopros VALUES("240","Приданое жены.","вено");
INSERT INTO chat_vopros VALUES("241","Французский математик, разработчик элементарной алгебры.","виет");
INSERT INTO chat_vopros VALUES("242","Приятная расслабленность.","кайф");
INSERT INTO chat_vopros VALUES("243","Боевое построение пехоты четырехугольником.","каре");
INSERT INTO chat_vopros VALUES("244","Столица Египта.","каир");
INSERT INTO chat_vopros VALUES("245","Порт во Франции.","кале");
INSERT INTO chat_vopros VALUES("246","Пресноводная рыба, одомашненный сазан.","карп");
INSERT INTO chat_vopros VALUES("247","Гоночный микролитражный автомобиль без кузова.","карт");
INSERT INTO chat_vopros VALUES("248","Спортивные матерчатые ботинки на резиновой подошве.","кеды");
INSERT INTO chat_vopros VALUES("249","Образец породы из скважины при бурении.","керн");
INSERT INTO chat_vopros VALUES("250","Женщина, которой Пушкин посвятил \"Я помню чудное мгновенье...\".","керн");
INSERT INTO chat_vopros VALUES("251","Дальневосточная лососевая рыба.","кета");
INSERT INTO chat_vopros VALUES("252","Ароматный и сочный тропический фрукт.","киви");
INSERT INTO chat_vopros VALUES("253","Субтропический ароматный и сочный плод.","киви");
INSERT INTO chat_vopros VALUES("254","Новозеландская бескрылая птица.","киви");
INSERT INTO chat_vopros VALUES("255","Балка днища судна от носа до кормы.","киль");
INSERT INTO chat_vopros VALUES("256","Часть хвостового оперения самолета, ракеты.","киль");
INSERT INTO chat_vopros VALUES("257","Созвездие Южного полушария.","киль");
INSERT INTO chat_vopros VALUES("258","То же, что фильм.","кино");
INSERT INTO chat_vopros VALUES("259","Зарытые, спрятанные сокровища.","клад");
INSERT INTO chat_vopros VALUES("260","Мафиозная семья.","клан");
INSERT INTO chat_vopros VALUES("261","Родовая или семейная община.","клан");
INSERT INTO chat_vopros VALUES("262","Расширение юбки, брюк, пальто внизу.","клеш");
INSERT INTO chat_vopros VALUES("263","Цепкое мелкое членистоногое животное.","клещ");
INSERT INTO chat_vopros VALUES("264","Кусок дерева, металла с сужающимся плоским концом.","клин");
INSERT INTO chat_vopros VALUES("265","Призыв, возглас.","клич");
INSERT INTO chat_vopros VALUES("266","Торчащая прядь.","клок");
INSERT INTO chat_vopros VALUES("267","Копия организма.","клон");
INSERT INTO chat_vopros VALUES("268","Культурно-просветительное учреждение.","клуб");
INSERT INTO chat_vopros VALUES("269","Зуб, расположенный сразу за резцом.","клык");
INSERT INTO chat_vopros VALUES("270","Челюсти у птиц.","клюв");
INSERT INTO chat_vopros VALUES("271","Знак в начале нотной строки.","ключ");
INSERT INTO chat_vopros VALUES("272","Приспособление для отпирания замков.","ключ");
INSERT INTO chat_vopros VALUES("273","Тряпка, насильно засовываемая в рот для предупреждения крика.","кляп");
INSERT INTO chat_vopros VALUES("274","Насильно засунутая в рот тряпка.","кляп");
INSERT INTO chat_vopros VALUES("275","Большая плеть.","кнут");
INSERT INTO chat_vopros VALUES("276","Наружный покров тела человека, животного.","кожа");
INSERT INTO chat_vopros VALUES("277","Твердое топливо.","кокс");
INSERT INTO chat_vopros VALUES("278","Столица Украины.","киев");
INSERT INTO chat_vopros VALUES("279","Украинское название волынки.","коза");
INSERT INTO chat_vopros VALUES("280","Домашнее парнокопытное животное.","коза");
INSERT INTO chat_vopros VALUES("281","То же, что рудник.","копи");
INSERT INTO chat_vopros VALUES("282","Вес чистого благородного металла в монете.","корн");
INSERT INTO chat_vopros VALUES("283","Сплетеные в виде жгута волосы.","коса");
INSERT INTO chat_vopros VALUES("284","Ручное сельскохозяйственное орудие.","коса");
INSERT INTO chat_vopros VALUES("285","Ручное сельскохозяйственное орудие для срезания травы.","коса");
INSERT INTO chat_vopros VALUES("286","Береговая отмель.","коса");
INSERT INTO chat_vopros VALUES("287","Короткохвостый рак.","краб");
INSERT INTO chat_vopros VALUES("288","Десятиногое ракообразное животное.","краб");
INSERT INTO chat_vopros VALUES("289","Эмблема на форменной фуражке моряков.","краб");
INSERT INTO chat_vopros VALUES("290","Крупная административно-территориальная единица.","край");
INSERT INTO chat_vopros VALUES("291","Обладатель несметных богатств.","крез");
INSERT INTO chat_vopros VALUES("292","Наклон судна набок.","крен");
INSERT INTO chat_vopros VALUES("293","Задняя часть туловища лошади.","круп");
INSERT INTO chat_vopros VALUES("294","Гряда холмов.","кряж");
INSERT INTO chat_vopros VALUES("295","Невысокая горная цепь.","кряж");
INSERT INTO chat_vopros VALUES("296","Крестная мать по отношению к родителям крестника.","кума");
INSERT INTO chat_vopros VALUES("297","Река в Дагестане.","кума");
INSERT INTO chat_vopros VALUES("298","Отделение в пассажирском вагоне.","купе");
INSERT INTO chat_vopros VALUES("299","Направление движения, путь транспорта.","курс");
INSERT INTO chat_vopros VALUES("300","Биржевая цена ценных бумаг.","курс");
INSERT INTO chat_vopros VALUES("301","Ветвистое травянистое растение.","куст");
INSERT INTO chat_vopros VALUES("302","Католический приходской священник.","кюре");
INSERT INTO chat_vopros VALUES("303","Жена помещика, барина в старину на Украине, в Польше.","пани");
INSERT INTO chat_vopros VALUES("304","Отец.","папа");
INSERT INTO chat_vopros VALUES("305","Глава католической церкви.","папа");
INSERT INTO chat_vopros VALUES("306","Спор с каким-либо условием.","пари");
INSERT INTO chat_vopros VALUES("307","Титул высших сановников и генералов в древней Турции.","паша");
INSERT INTO chat_vopros VALUES("308","Прежнее название клоуна.","паяц");
INSERT INTO chat_vopros VALUES("309","Торчащий из земли остаток спиленного дерева.","пень");
INSERT INTO chat_vopros VALUES("310","Орудие для письма в старину.","перо");
INSERT INTO chat_vopros VALUES("311","Стреловидный лист лука, чеснока.","перо");
INSERT INTO chat_vopros VALUES("312","Сооружение для отопления помещения.","печь");
INSERT INTO chat_vopros VALUES("313","Созвездие Южного полушария.","печь");
INSERT INTO chat_vopros VALUES("314","Род копья.","пика");
INSERT INTO chat_vopros VALUES("315","Крутое снижение самолета.","пике");
INSERT INTO chat_vopros VALUES("316","Черная масть в картах.","пики");
INSERT INTO chat_vopros VALUES("317","Зубчатый режущий инструмент.","пила");
INSERT INTO chat_vopros VALUES("318","Декоративный яркий цветок семейства лютиковых.","пион");
INSERT INTO chat_vopros VALUES("319","Нестабильная элементарная частица.","пион");
INSERT INTO chat_vopros VALUES("320","Портовое причальное сооружение.","пирс");
INSERT INTO chat_vopros VALUES("321","14-й президент США.","пирс");
INSERT INTO chat_vopros VALUES("322","Непромокаемое пальто.","плащ");
INSERT INTO chat_vopros VALUES("323","Дорожное одеяло.","плед");
INSERT INTO chat_vopros VALUES("324","Знак сложения в математике.","плюс");
INSERT INTO chat_vopros VALUES("325","Ткань с ворсом.","плюш");
INSERT INTO chat_vopros VALUES("326","Лиановое растение.","плющ");
INSERT INTO chat_vopros VALUES("327","Положение тела.","поза");
INSERT INTO chat_vopros VALUES("328","Безлесная равнинная территория.","поле");
INSERT INTO chat_vopros VALUES("329","Участок земли под посевы.","поле");
INSERT INTO chat_vopros VALUES("330","Ответственная должность.","пост");
INSERT INTO chat_vopros VALUES("331","Воздержание от скоромной пищи.","пост");
INSERT INTO chat_vopros VALUES("332","Место постоянного дежурства.","пост");
INSERT INTO chat_vopros VALUES("333","Автор стихов.","поэт");
INSERT INTO chat_vopros VALUES("334","Ремень на талии.","пояс");
INSERT INTO chat_vopros VALUES("335","Зона на Земле с одинаковым временем.","пояс");
INSERT INTO chat_vopros VALUES("336","Французский физик, вместе с женой исследовавший радиоактивность.","кюри");
INSERT INTO chat_vopros VALUES("337","Единица активности радиоактивных изотопов.","кюри");
INSERT INTO chat_vopros VALUES("338","Тонкая ветка без листьев.","прут");
INSERT INTO chat_vopros VALUES("339","Левый приток Дуная.","прут");
INSERT INTO chat_vopros VALUES("340","Неуравновешенный или душевнобольной человек.","псих");
INSERT INTO chat_vopros VALUES("341","Напиток из рома с приправами.","пунш");
INSERT INTO chat_vopros VALUES("342","Момент приведения в движение.","пуск");
INSERT INTO chat_vopros VALUES("343","Веревка, ремни, стягивающие тело пленника.","путы");
INSERT INTO chat_vopros VALUES("344","Густой труднопроходимый лес.","пуща");
INSERT INTO chat_vopros VALUES("345","Протертая масса из фруктов, ягод или овощей.","пюре");
INSERT INTO chat_vopros VALUES("346","Мелкое волнение водной поверхности.","рябь");
INSERT INTO chat_vopros VALUES("347","Открытое повреждение тканей тела.","рана");
INSERT INTO chat_vopros VALUES("348","То же, что войско.","рать");
INSERT INTO chat_vopros VALUES("349","Гитлеровская империя.","рейх");
INSERT INTO chat_vopros VALUES("350","Столица Латвии.","рига");
INSERT INTO chat_vopros VALUES("351","Французский композитор, балет \"Жизель\".","адан");
INSERT INTO chat_vopros VALUES("352","Французская писательница, роман \"Консуэло\".","санд");
INSERT INTO chat_vopros VALUES("353","Мать жены.","теща");
INSERT INTO chat_vopros VALUES("354","Полосатый полудрагоценный камень.","агат");
INSERT INTO chat_vopros VALUES("355","Работник по уходу за коровами.","дояр");
INSERT INTO chat_vopros VALUES("356","Государство в Центральной Африке.","заир");
INSERT INTO chat_vopros VALUES("357","Французский писатель, роман \"Жерминаль\".","золя");
INSERT INTO chat_vopros VALUES("358","Один из изобретателей телефона, шотландец.","белл");
INSERT INTO chat_vopros VALUES("359","Порт на реке Луара во Франции.","нант");
INSERT INTO chat_vopros VALUES("360","Столбообразное тело в жерле вулкана.","некк");
INSERT INTO chat_vopros VALUES("361","Премьер-министр Индии, сподвижник М.К.Ганди.","неру");
INSERT INTO chat_vopros VALUES("362","Французский композитор, музыка \"Марсельеза\".","лиль");
INSERT INTO chat_vopros VALUES("363","Французский композитор, опера \"Сон в летнюю ночь\".","тома");
INSERT INTO chat_vopros VALUES("364","Место переправы через реку.","брод");
INSERT INTO chat_vopros VALUES("365","Роман Ф.М.Достоевского .","бесы");
INSERT INTO chat_vopros VALUES("366","Роман Э.Золя .","нана");
INSERT INTO chat_vopros VALUES("367","Колдовство, волшебство.","чары");
INSERT INTO chat_vopros VALUES("368","Стихотворение С.Есенина .","чары");
INSERT INTO chat_vopros VALUES("369","Опера Ж.Массне .","таис");
INSERT INTO chat_vopros VALUES("370","Американский писатель, роман \"Приключения Гекльберри Финна\".","твен");
INSERT INTO chat_vopros VALUES("371","Древнегреческий баснописец.","эзоп");
INSERT INTO chat_vopros VALUES("372","Русский советский писатель, соавтор романа \"12 стульев\".","ильф");
INSERT INTO chat_vopros VALUES("373","Английский математик, разработавший алгебру логики.","буль");
INSERT INTO chat_vopros VALUES("374","Французский писатель-фантаст, роман \"Планета обезьян\".","буль");
INSERT INTO chat_vopros VALUES("375","Французский писатель, роман \"Набоб\".","доде");
INSERT INTO chat_vopros VALUES("376","Французский писатель, роман \"Калигула\".","камю");
INSERT INTO chat_vopros VALUES("377","Немецкий писатель, роман \"Будденброки\".","манн");
INSERT INTO chat_vopros VALUES("378","Картофельная крупа.","саго");
INSERT INTO chat_vopros VALUES("379","Столица Перу.","лима");
INSERT INTO chat_vopros VALUES("380","Порт во Франции у слияния рек Рона и Сона.","лион");
INSERT INTO chat_vopros VALUES("381","Река в Прикаспийской низменности.","урал");
INSERT INTO chat_vopros VALUES("382","Марка отечественного автомобиля .","урал");
INSERT INTO chat_vopros VALUES("383","Горная система на границе Европы и Азии.","урал");
INSERT INTO chat_vopros VALUES("384","Русский живописец, картина \"Бородино\".","рубо");
INSERT INTO chat_vopros VALUES("385","Русский художник, панорама \"Бородинская битва\".","рубо");
INSERT INTO chat_vopros VALUES("386","В греческой мифологии супруга спартанского царя Тиндарея.","леда");
INSERT INTO chat_vopros VALUES("387","Спутник Юпитера.","леда");
INSERT INTO chat_vopros VALUES("388","Спутник Сатурна.","феба");
INSERT INTO chat_vopros VALUES("389","Созвездие Южного полушария.","чаша");
INSERT INTO chat_vopros VALUES("390","Округлый сосуд.","чаша");
INSERT INTO chat_vopros VALUES("391","Сделка с немедленной оплатой.","спот");
INSERT INTO chat_vopros VALUES("392","Женское имя (лат. пышная, сноп).","юлия");
INSERT INTO chat_vopros VALUES("393","Тело убитого крупного зверя.","туша");
INSERT INTO chat_vopros VALUES("394","Двухмачтовое судно с прямыми парусами.","бриг");
INSERT INTO chat_vopros VALUES("395","Восковые ячейки пчелиного жилища.","соты");
INSERT INTO chat_vopros VALUES("396","Помещение для мытья с парилкой.","баня");
INSERT INTO chat_vopros VALUES("397","Запряженная ишаком двухколесная повозка.","арба");
INSERT INTO chat_vopros VALUES("398","Чернокожий, негр.","арап");
INSERT INTO chat_vopros VALUES("399","Библейский первый мужчина.","адам");
INSERT INTO chat_vopros VALUES("400","Строительный материал, балка.","брус");
INSERT INTO chat_vopros VALUES("401","Отчаянный высокий вопль.","визг");
INSERT INTO chat_vopros VALUES("402","Способность осуществлять поставленные перед собой цели.","воля");
INSERT INTO chat_vopros VALUES("403","Грузовое помещение на корабле.","трюм");
INSERT INTO chat_vopros VALUES("404","Река в Германии.","рейн");
INSERT INTO chat_vopros VALUES("405","Отец одного из супругов по отношению к родителям другого супруга.","сват");
INSERT INTO chat_vopros VALUES("406","Город и река в Коми.","инта");
INSERT INTO chat_vopros VALUES("407","Женское имя (др. евр. радость).","анна");
INSERT INTO chat_vopros VALUES("408","Легендарный бразильский футболист.","пеле");
INSERT INTO chat_vopros VALUES("409","Ловкий, искусный прием.","трюк");
INSERT INTO chat_vopros VALUES("410","Столица Индии.","дели");
INSERT INTO chat_vopros VALUES("411","Река в Московской области, левый приток Оки.","нара");
INSERT INTO chat_vopros VALUES("412","Первая столица Японии.","нара");
INSERT INTO chat_vopros VALUES("413","Освежающий летний напиток.","квас");
INSERT INTO chat_vopros VALUES("414","Южная птица отряда голенастых.","ибис");
INSERT INTO chat_vopros VALUES("415","В древнегреческой мифологии бог любви.","эрот");
INSERT INTO chat_vopros VALUES("416","Королевский футбольный клуб Испании .","реал");
INSERT INTO chat_vopros VALUES("417","Старинная испанская серебряная монета.","реал");
INSERT INTO chat_vopros VALUES("418","Бывшая столица Германии.","бонн");
INSERT INTO chat_vopros VALUES("419","Спутник Юпитера.","теба");
INSERT INTO chat_vopros VALUES("420","Спутник Юпитера.","фива");
INSERT INTO chat_vopros VALUES("421","Отклонение в сторону повышения рыночной цены золота.","ажио");
INSERT INTO chat_vopros VALUES("422","Деталь затвора огнестрельного оружия.","боек");
INSERT INTO chat_vopros VALUES("423","Островное государство в Центральной Америке.","куба");
INSERT INTO chat_vopros VALUES("424","Курортный город в Грузии.","поти");
INSERT INTO chat_vopros VALUES("425","Город в Германии, в котором родился К. Маркс.","трир");
INSERT INTO chat_vopros VALUES("426","Город в Италии с \"падающей башней\".","пиза");
INSERT INTO chat_vopros VALUES("427","Прежнее название поэта.","пиит");
INSERT INTO chat_vopros VALUES("428","Сибирские валенки.","пимы");
INSERT INTO chat_vopros VALUES("429","Меховые сапоги у северных народов.","пимы");
INSERT INTO chat_vopros VALUES("430","Американский полярный исследователь.","пири");
INSERT INTO chat_vopros VALUES("431","Государство в Западной Азии.","ирак");
INSERT INTO chat_vopros VALUES("432","Государство в Западной Африке.","мали");
INSERT INTO chat_vopros VALUES("433","Государство в Юго-Восточной Азии.","лаос");
INSERT INTO chat_vopros VALUES("434","Государство в Западной Африке.","того");
INSERT INTO chat_vopros VALUES("435","Областной центр в Забайкалье.","чита");
INSERT INTO chat_vopros VALUES("436","Серия советских космических кораблей .","союз");
INSERT INTO chat_vopros VALUES("437","Служебное слово, соединяющее преложения и слова внутри предложения.","союз");
INSERT INTO chat_vopros VALUES("438","Государственное или общественное объединение.","союз");
INSERT INTO chat_vopros VALUES("439","Объединение, союз.","уния");
INSERT INTO chat_vopros VALUES("440","Объединение православной и католической церквей.","уния");
INSERT INTO chat_vopros VALUES("441","Польский парламент.","сейм");
INSERT INTO chat_vopros VALUES("442","Список блюд в ресторане.","меню");
INSERT INTO chat_vopros VALUES("443","Единица измерения.","мера");
INSERT INTO chat_vopros VALUES("444","Старая русская единица емкости сыпучих тел.","мера");
INSERT INTO chat_vopros VALUES("445","Часть чего-либо.","доля");
INSERT INTO chat_vopros VALUES("446","Участь, судьба.","доля");
INSERT INTO chat_vopros VALUES("447","Французский изобретатель телеграфа.","бодо");
INSERT INTO chat_vopros VALUES("448","Итальянский композитор, основатель русского балета, балет \"Конек-Горбунок\".","пуни");
INSERT INTO chat_vopros VALUES("449","Тонкий слой древесины, получаемый лущением.","шпон");
INSERT INTO chat_vopros VALUES("450","Многослойная фанера.","шпон");
INSERT INTO chat_vopros VALUES("451","Гробница для хранения святых мощей.","рака");
INSERT INTO chat_vopros VALUES("452","Первая выгонка вина из барды.","рака");
INSERT INTO chat_vopros VALUES("453","Тонкие волнообразные листы.","гофр");
INSERT INTO chat_vopros VALUES("454","Знакомство и связи, используемые в личных интересах.","блат");
INSERT INTO chat_vopros VALUES("455","Стальная заготовка квадратного сечения.","блюм");
INSERT INTO chat_vopros VALUES("456","Снасть, укрепляемая на концах рея для его поворота.","брас");
INSERT INTO chat_vopros VALUES("457","Минерал для очистки металлов при пайке.","бура");
INSERT INTO chat_vopros VALUES("458","Сложенные в виде вала и укрытые для хранения овощи, корнеплоды.","бурт");
INSERT INTO chat_vopros VALUES("459","Хлопчатобумажная плотная ткань.","бязь");
INSERT INTO chat_vopros VALUES("460","Наполнение легких воздухом.","вдох");
INSERT INTO chat_vopros VALUES("461","Часть теннисной партии.","гейм");
INSERT INTO chat_vopros VALUES("462","Клинообразная дощечка с пазами для покрытия крыши.","гонт");
INSERT INTO chat_vopros VALUES("463","Прорванное или проломанное отверстие.","дыра");
INSERT INTO chat_vopros VALUES("464","Женское имя (греч. вторая).","алла");
INSERT INTO chat_vopros VALUES("465","Псевдоним Н.В.Гоголя.","алов");
INSERT INTO chat_vopros VALUES("466","Марка немецкого автомобиля .","ауди");
INSERT INTO chat_vopros VALUES("467","Марка французского автомобиля .","пежо");
INSERT INTO chat_vopros VALUES("468","Марка американского автомобиля .","додж");
INSERT INTO chat_vopros VALUES("469","Марка шведского автомобиля .","сааб");
INSERT INTO chat_vopros VALUES("470","Марка итальянского автомобиля .","фиат");
INSERT INTO chat_vopros VALUES("471","Марка американского автомобиля .","форд");
INSERT INTO chat_vopros VALUES("472","38-й президент США.","форд");
INSERT INTO chat_vopros VALUES("473","Марка отечественного легкового автомобиля .","лада");
INSERT INTO chat_vopros VALUES("474","Богиня красоты, любви и брака у древних славян.","лада");
INSERT INTO chat_vopros VALUES("475","Отец.","батя");
INSERT INTO chat_vopros VALUES("476","Французский математик, труды по теории алгебраических уравнений.","безу");
INSERT INTO chat_vopros VALUES("477","Герой одесских рассказов Исаака Бабеля.","беня");
INSERT INTO chat_vopros VALUES("478","Столица Швейцарии.","берн");
INSERT INTO chat_vopros VALUES("479","Поперечная балка, соединяющая борта корабля.","бимс");
INSERT INTO chat_vopros VALUES("480","Тонкая лепешка, знаменитое блюдо русской кухни.","блин");
INSERT INTO chat_vopros VALUES("481","Холодный приморский ветер со склонов гор.","бора");
INSERT INTO chat_vopros VALUES("482","Боковая стенка корпуса судна.","борт");
INSERT INTO chat_vopros VALUES("483","Хозяин, начальник, руководитель.","босс");
INSERT INTO chat_vopros VALUES("484","Нидерландский живописец, картина \"Искушение святого Антония\".","босх");
INSERT INTO chat_vopros VALUES("485","Химический элемент, едкая дымящаяся жидкость с неприятным запахом.","бром");
INSERT INTO chat_vopros VALUES("486","Самое сухое шампанское.","брют");
INSERT INTO chat_vopros VALUES("487","Маленький сигнальный плавучий поплавок.","буек");
INSERT INTO chat_vopros VALUES("488","Солдат, боец.","воин");
INSERT INTO chat_vopros VALUES("489","Денежная единица Кореи.","вона");
INSERT INTO chat_vopros VALUES("490","Молочные железы коровы.","вымя");
INSERT INTO chat_vopros VALUES("491","Самое простонародное имя у немцев.","ганс");
INSERT INTO chat_vopros VALUES("492","Дощечки для покрытия крыш.","гарт");
INSERT INTO chat_vopros VALUES("493","Типографский сплав.","гарт");
INSERT INTO chat_vopros VALUES("494","Составитель словаря русского языка.","даль");
INSERT INTO chat_vopros VALUES("495","Английское холодное оружие, короткое метательное копье, дротик.","дарт");
INSERT INTO chat_vopros VALUES("496","Знаток, мастер своего дела.","дока");
INSERT INTO chat_vopros VALUES("497","Лицо женского пола по отношению к своим родителям.","дочь");
INSERT INTO chat_vopros VALUES("498","Порт в Великобритании у пролива Па-де-Кале.","дувр");
INSERT INTO chat_vopros VALUES("499","Вирусная болезнь парнокопытных животных.","ящур");
INSERT INTO chat_vopros VALUES("500","Выдающийся советский вратарь.","яшин");
INSERT INTO chat_vopros VALUES("501","Левый приток Москва-реки.","яуза");



DROP TABLE IF EXISTS `chat_who`;

CREATE TABLE `chat_who` (
  `id_user` int(11) NOT NULL,
  `room` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  KEY `id_user` (`id_user`,`room`,`time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO chat_who VALUES("1","0","1494674418");
INSERT INTO chat_who VALUES("4","0","1493834661");



DROP TABLE IF EXISTS `comm`;

CREATE TABLE `comm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `desc` text NOT NULL,
  `id_user` int(11) NOT NULL DEFAULT '0',
  `time` int(11) NOT NULL DEFAULT '0',
  `id_cat` int(11) NOT NULL DEFAULT '0',
  `visits` int(11) NOT NULL DEFAULT '0',
  `adult` enum('0','1') NOT NULL DEFAULT '0',
  `chat` enum('0','1') NOT NULL DEFAULT '0',
  `forum` enum('0','1') NOT NULL DEFAULT '1',
  `files` enum('0','1') NOT NULL DEFAULT '0',
  `join_rule` enum('1','2','3') NOT NULL DEFAULT '1',
  `read_rule` enum('1','2') NOT NULL DEFAULT '1',
  `write_rule` enum('1','2') NOT NULL DEFAULT '1',
  `chat_rule` enum('1','2') NOT NULL DEFAULT '1',
  `files_rule` enum('1','2') NOT NULL DEFAULT '1',
  `deviz` text NOT NULL,
  `rules` text NOT NULL,
  `mdi` text,
  `opis` varchar(250) DEFAULT NULL,
  `interests` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO comm VALUES("1","Умора на все 100%","","1","1496046325","1","2","0","0","1","0","1","1","1","1","1","А ну-ка, спрячь своё грустило, и улыбало покажи!","Запрещается:\r\n\r\n1. Употребление нецензурных слов.\r\n\r\n2. Использование любого языка, кроме русского.\r\n\r\n3. Оскорбления в адрес других участников.\r\n\r\n4. Разжигание межнациональной и межрелигиозной вражды.\r\n\r\n5. Размещение в любом виде рекламной информации.\r\n\r\n6. Обсуждение или создание темы, которые касаются \\\"Политики\\\".","8632cc9bd79d786f117c706bc17e186a","Типо [b]тестим Описание [/b]\r\n[quote]В соо \\\"Умора на все 100%\\\"\r\nТак ржут что пыль стоит столбом.\r\nВ какую тему не войдешь\r\nот смеха просто упадешь\r\nТебе хреново? Депрессуха?\r\nВходи и будет веселуха!\r\n[/quote]","Юмор,знакомства,развлечение");



DROP TABLE IF EXISTS `comm_album`;

CREATE TABLE `comm_album` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `name` varchar(32) NOT NULL,
  `time_create` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `opis` varchar(256) NOT NULL,
  `set_password` int(11) NOT NULL,
  `foto_password` varchar(32) NOT NULL,
  `my` int(11) NOT NULL DEFAULT '0',
  `pass` varchar(11) DEFAULT NULL,
  `privat` enum('0','1','2') NOT NULL DEFAULT '0',
  `privat_komm` enum('0','1','2') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `id_user` (`id_user`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `comm_cat`;

CREATE TABLE `comm_cat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `desc` text NOT NULL,
  `pos` int(11) NOT NULL DEFAULT '0',
  `icon` varchar(30) DEFAULT 'default',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO comm_cat VALUES("1","Прочее","","1","other.png");
INSERT INTO comm_cat VALUES("2","Юмор","","2","humor.png");
INSERT INTO comm_cat VALUES("3","Эротика и секс","","3","sex.png");
INSERT INTO comm_cat VALUES("4","Фото и видео","","4","photo.png");
INSERT INTO comm_cat VALUES("5","Спорт","","5","sport.png");



DROP TABLE IF EXISTS `comm_journal`;

CREATE TABLE `comm_journal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_comm` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_ank` int(11) NOT NULL,
  `type` enum('in_blist','out_blist','in_comm','out_comm','access') DEFAULT NULL,
  `access` enum('creator','adm','mod','user') DEFAULT 'user',
  `time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

INSERT INTO comm_journal VALUES("1","1","1","0","in_comm","user","1496046325");
INSERT INTO comm_journal VALUES("2","1","1","0","access","creator","1496046326");
INSERT INTO comm_journal VALUES("3","1","2","0","in_comm","user","1496219599");
INSERT INTO comm_journal VALUES("4","1","2","0","out_comm","user","1496219914");
INSERT INTO comm_journal VALUES("5","1","2","0","in_comm","user","1496219921");
INSERT INTO comm_journal VALUES("6","1","2","1","access","creator","1496392891");
INSERT INTO comm_journal VALUES("7","1","2","1","access","creator","1496392897");
INSERT INTO comm_journal VALUES("8","1","2","1","access","creator","1496392956");
INSERT INTO comm_journal VALUES("9","1","2","1","access","creator","1496392978");
INSERT INTO comm_journal VALUES("10","1","2","1","access","","1496392988");
INSERT INTO comm_journal VALUES("11","1","2","1","access","","1496393024");
INSERT INTO comm_journal VALUES("12","1","2","1","access","","1496393062");
INSERT INTO comm_journal VALUES("13","1","2","1","access","creator","1496393066");
INSERT INTO comm_journal VALUES("14","1","2","1","access","mod","1496393071");
INSERT INTO comm_journal VALUES("15","1","2","1","access","user","1496393166");
INSERT INTO comm_journal VALUES("16","1","2","1","access","","1496393238");
INSERT INTO comm_journal VALUES("17","1","2","1","access","","1496393263");
INSERT INTO comm_journal VALUES("18","1","2","1","access","creator","1496393267");
INSERT INTO comm_journal VALUES("19","1","2","1","access","creator","1496393271");
INSERT INTO comm_journal VALUES("20","1","2","1","access","creator","1496394459");
INSERT INTO comm_journal VALUES("21","1","2","1","access","","1496394572");
INSERT INTO comm_journal VALUES("22","1","2","1","access","user","1496394581");
INSERT INTO comm_journal VALUES("23","1","2","1","access","mod","1496394586");
INSERT INTO comm_journal VALUES("24","1","6","0","in_comm","user","1496415530");
INSERT INTO comm_journal VALUES("25","1","6","0","out_comm","user","1496415533");
INSERT INTO comm_journal VALUES("26","1","6","0","in_comm","user","1496720004");
INSERT INTO comm_journal VALUES("27","1","6","0","out_comm","user","1496720007");



DROP TABLE IF EXISTS `comm_photo`;

CREATE TABLE `comm_photo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_gallery` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `ras` varchar(4) NOT NULL,
  `type` varchar(64) NOT NULL,
  `opis` varchar(1024) NOT NULL,
  `id_user` int(11) NOT NULL,
  `ava` enum('0','1') DEFAULT '0',
  `pass` varchar(11) DEFAULT NULL,
  `people` int(11) DEFAULT NULL,
  `time` int(11) NOT NULL,
  `metka` int(1) DEFAULT '0',
  `count` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `id_gallery` (`id_gallery`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `comm_photo_count`;

CREATE TABLE `comm_photo_count` (
  `id_foto` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  KEY `id_foto` (`id_foto`,`id_user`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `comm_photo_komm`;

CREATE TABLE `comm_photo_komm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_foto` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `msg` varchar(1024) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_foto` (`id_foto`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `comm_readmin`;

CREATE TABLE `comm_readmin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_comm` int(11) DEFAULT '0',
  `id_user` int(11) DEFAULT '0',
  `time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO comm_readmin VALUES("1","1","2","1496405229");



DROP TABLE IF EXISTS `comm_users`;

CREATE TABLE `comm_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_comm` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `activate` enum('0','1') DEFAULT '1',
  `invite` enum('0','1') DEFAULT '0',
  `invite_user` int(11) DEFAULT NULL,
  `access` enum('creator','adm','mod','user') DEFAULT 'user',
  `time` int(11) NOT NULL,
  `last_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO comm_users VALUES("1","1","1","1","0","0","creator","1496046325","1497191949");
INSERT INTO comm_users VALUES("3","1","2","1","0","0","mod","1496219921","1496224341");



DROP TABLE IF EXISTS `comm_visits`;

CREATE TABLE `comm_visits` (
  `time` int(11) NOT NULL,
  `id_comm` int(11) NOT NULL,
  `id_user` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO comm_visits VALUES("1497183792","1","1");
INSERT INTO comm_visits VALUES("1497191787","1","17");



DROP TABLE IF EXISTS `cron`;

CREATE TABLE `cron` (
  `id` varchar(32) NOT NULL,
  `time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO cron VALUES("clear_tmp_dir","1497191723");
INSERT INTO cron VALUES("visit","1483819702");
INSERT INTO cron VALUES("everyday","1497113561");
INSERT INTO cron VALUES("backup_mysql","1483825232");



DROP TABLE IF EXISTS `discussions`;

CREATE TABLE `discussions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `avtor` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `count` int(11) DEFAULT '0',
  `msg` varchar(1024) NOT NULL,
  `time` int(11) NOT NULL,
  `type` varchar(100) NOT NULL,
  `id_sim` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

INSERT INTO discussions VALUES("1","1","2","0","","1494151090","foto","10");
INSERT INTO discussions VALUES("2","1","4","0","","1494151090","foto","10");
INSERT INTO discussions VALUES("3","1","6","0","","1494151090","foto","10");
INSERT INTO discussions VALUES("4","1","2","0","","1494098300","foto","8");
INSERT INTO discussions VALUES("5","1","4","0","","1494098300","foto","8");
INSERT INTO discussions VALUES("6","1","6","0","","1494098300","foto","8");
INSERT INTO discussions VALUES("8","1","2","1","","1496418712","them","4");
INSERT INTO discussions VALUES("9","1","4","0","","1496418712","them","4");
INSERT INTO discussions VALUES("10","1","6","0","","1496418712","them","4");
INSERT INTO discussions VALUES("12","1","1","0","","1495004708","notes","14");
INSERT INTO discussions VALUES("13","1","2","1","","1496418516","them","5");
INSERT INTO discussions VALUES("14","1","4","0","","1496418516","them","5");
INSERT INTO discussions VALUES("15","1","6","1","","1496418516","them","5");
INSERT INTO discussions VALUES("16","1","8","1","","1496418516","them","5");
INSERT INTO discussions VALUES("17","1","1","0","","1496418516","them","5");
INSERT INTO discussions VALUES("18","1","8","1","","1496418712","them","4");
INSERT INTO discussions VALUES("19","1","1","0","","1496418712","them","4");



DROP TABLE IF EXISTS `discussions_set`;

CREATE TABLE `discussions_set` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `disc_status` int(11) DEFAULT '1',
  `disc_foto` int(11) DEFAULT '1',
  `disc_files` int(11) DEFAULT '1',
  `disc_forum` int(11) DEFAULT '1',
  `disc_notes` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

INSERT INTO discussions_set VALUES("1","1","1","1","1","1","1");
INSERT INTO discussions_set VALUES("2","2","1","1","1","1","1");
INSERT INTO discussions_set VALUES("3","3","1","1","1","1","1");
INSERT INTO discussions_set VALUES("4","4","1","1","1","1","1");
INSERT INTO discussions_set VALUES("5","5","1","1","1","1","1");
INSERT INTO discussions_set VALUES("6","6","1","1","1","1","1");
INSERT INTO discussions_set VALUES("7","7","1","1","1","1","1");
INSERT INTO discussions_set VALUES("8","8","1","1","1","1","1");
INSERT INTO discussions_set VALUES("9","9","1","1","1","1","1");
INSERT INTO discussions_set VALUES("10","10","1","1","1","1","1");
INSERT INTO discussions_set VALUES("11","11","1","1","1","1","1");
INSERT INTO discussions_set VALUES("12","12","1","1","1","1","1");
INSERT INTO discussions_set VALUES("13","13","1","1","1","1","1");
INSERT INTO discussions_set VALUES("14","14","1","1","1","1","1");
INSERT INTO discussions_set VALUES("15","15","1","1","1","1","1");
INSERT INTO discussions_set VALUES("16","16","1","1","1","1","1");
INSERT INTO discussions_set VALUES("17","17","1","1","1","1","1");



DROP TABLE IF EXISTS `forum_f`;

CREATE TABLE `forum_f` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `pos` int(11) NOT NULL,
  `opis` varchar(512) NOT NULL,
  `adm` set('0','1') NOT NULL DEFAULT '0',
  `icon` varchar(30) DEFAULT 'default',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

INSERT INTO forum_f VALUES("1","Все о Xmyx.Ru","1","Правила сайта, новости, обсуждения","0","f_news.gif");
INSERT INTO forum_f VALUES("2","Игры","2","PC, mobile, приставки и др. платформы","0","f_obshenie.gif");
INSERT INTO forum_f VALUES("3","Моб. связь и Интернет","3","ICQ, Opera, E-mail, WAP, Internet, Операторы...","0","f_tematijka.gif");
INSERT INTO forum_f VALUES("4","Android","4","Всё про Android","0","F_seks.gif");
INSERT INTO forum_f VALUES("5","iPhone и др платформы","5","Всё про iPhone","0","f_dosug.gif");
INSERT INTO forum_f VALUES("6","Компьютеры и др. техника","6","Компьютеры и др. техника","0","f_music.gif");
INSERT INTO forum_f VALUES("7","Спорт","7","Футбол, Хоккей, Фитнес,..","0","f_sport.gif");
INSERT INTO forum_f VALUES("8","Отношения","8","Семья, любовь, дружба, секс","0","f_mobil.gif");
INSERT INTO forum_f VALUES("9","Разные темы","9","Работа, Медицина, Юмор,...","0","f_vse_mobil.gif");
INSERT INTO forum_f VALUES("10","Моб. телефоны","10","Информация, советы, хитрости","0","svyaz_mob.gif");
INSERT INTO forum_f VALUES("11","Моб. загрузки","11","Игры, софт, аудио, видео","0","f_jkomp.gif");
INSERT INTO forum_f VALUES("12","Увлечения","12","Музыка, кино, авто, история, хобби...","0","bespredel.gif");
INSERT INTO forum_f VALUES("13","Субкультуры","13","Эмо, готика, РЭП...","0","default");
INSERT INTO forum_f VALUES("14","Политика","14","Здесь решаются судьбы мира","0","default");
INSERT INTO forum_f VALUES("15","Песочница, Архив","15","Архив форума + болталка","0","default");



DROP TABLE IF EXISTS `forum_files`;

CREATE TABLE `forum_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_post` int(11) NOT NULL,
  `name` varchar(64) DEFAULT NULL,
  `ras` varchar(32) NOT NULL,
  `size` int(11) NOT NULL,
  `type` varchar(32) NOT NULL,
  `count` int(11) NOT NULL DEFAULT '0',
  `rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `id_post` (`id_post`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO forum_files VALUES("1","21","4GbiTLlmwRo","jpg","18110","image/jpeg","151","0");
INSERT INTO forum_files VALUES("3","23","кс","txt","119","text/plain","1","0");
INSERT INTO forum_files VALUES("4","24","clans_no","png","1664","image/png","48","0");



DROP TABLE IF EXISTS `forum_files_rating`;

CREATE TABLE `forum_files_rating` (
  `id_file` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `rating` int(11) DEFAULT '0',
  KEY `id_file` (`id_file`),
  KEY `id_user` (`id_user`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO forum_files_rating VALUES("1","1","1");



DROP TABLE IF EXISTS `forum_filest`;

CREATE TABLE `forum_filest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_post` int(11) NOT NULL,
  `name` varchar(64) DEFAULT NULL,
  `ras` varchar(32) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_post` (`id_post`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO forum_filest VALUES("1","4","170923718.p.0.360.0","jpg");



DROP TABLE IF EXISTS `forum_p`;

CREATE TABLE `forum_p` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_forum` int(11) NOT NULL,
  `id_razdel` int(11) NOT NULL,
  `id_them` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `msg` varchar(1024) NOT NULL,
  `cit` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_user` (`id_user`),
  KEY `time` (`time`),
  KEY `id_forum` (`id_forum`),
  KEY `id_razdel` (`id_razdel`),
  KEY `id_them` (`id_them`),
  FULLTEXT KEY `msg` (`msg`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;

INSERT INTO forum_p VALUES("16","12","1","4","1","1494744676","Тест","0");
INSERT INTO forum_p VALUES("21","12","1","4","1","1494747787","lolololololol","0");
INSERT INTO forum_p VALUES("34","12","1","2","0","1496178362","Тему закрыл [url=/info.php?id=1]Tw1nGo[/url]","0");
INSERT INTO forum_p VALUES("35","15","127","5","13","1496401550","Суть игры очень проста - пишем бесконечное\r\nслово. Начало следующего - это\r\nдве последние буквы\r\nпредыдущего.\r\nНапример:\r\nадвокАТ\r\nАтлАС\r\nАСпирИН\r\nИнтернЕТ и тд","0");
INSERT INTO forum_p VALUES("36","15","127","5","4","1496418516","НароСТ","0");
INSERT INTO forum_p VALUES("37","12","1","4","4","1496418712","[img]https://pp.userapi.com/c837524/v837524316/35367/LOqTb_PHd2U.jpg[/img]","0");
INSERT INTO forum_p VALUES("38","15","127","8","0","1496954874","Тему закрыл [url=/info.php?id=14]Roms[/url]","");



DROP TABLE IF EXISTS `forum_r`;

CREATE TABLE `forum_r` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_forum` int(11) NOT NULL,
  `name` varchar(32) NOT NULL,
  `time` int(11) NOT NULL,
  `opis` varchar(512) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_forum` (`id_forum`,`time`)
) ENGINE=MyISAM AUTO_INCREMENT=128 DEFAULT CHARSET=utf8;

INSERT INTO forum_r VALUES("1","12","Хобби","1496418712","");
INSERT INTO forum_r VALUES("2","12","Охота/Рыбалка","1494759146","");
INSERT INTO forum_r VALUES("3","12","Непознанное","1494759160","");
INSERT INTO forum_r VALUES("4","1","Помощь новичкам","1494760592","Давайте вместе поможем новичкам.");
INSERT INTO forum_r VALUES("5","1","FAQ","1494760604","Частые вопросы.");
INSERT INTO forum_r VALUES("6","1","Объявления. Обсуждения","1497128025","Здесь пишем только то, что касается Xmyx!!!");
INSERT INTO forum_r VALUES("7","1","Правила сайта. Информация.","1494760637","Правила сайта. Важная информация.");
INSERT INTO forum_r VALUES("8","2","Другие игры","1494760717","");
INSERT INTO forum_r VALUES("9","2","Форумные игры и виктoрины","1494760721","");
INSERT INTO forum_r VALUES("10","2","Java-игры","1494760726","");
INSERT INTO forum_r VALUES("11","2","Windows Phone - Игры","1494760733","");
INSERT INTO forum_r VALUES("12","2","Windows Mobile - Игры","1494760738","");
INSERT INTO forum_r VALUES("13","2","Игровое видео и стримы","1494760744","");
INSERT INTO forum_r VALUES("14","2","DotA 2","1494760750","");
INSERT INTO forum_r VALUES("15","2","GTA","1494760756","");
INSERT INTO forum_r VALUES("16","2","Minecraft","1494760763","");
INSERT INTO forum_r VALUES("17","2","World of Tanks","1494760772","");
INSERT INTO forum_r VALUES("18","2","World of Warcraft (WoW)","1494760783","");
INSERT INTO forum_r VALUES("19","2","S.T.A.L.K.E.R.","1494760788","");
INSERT INTO forum_r VALUES("20","2","Counter-Strike","1494760794","");
INSERT INTO forum_r VALUES("21","2","Symbian игры","1494760802","");
INSERT INTO forum_r VALUES("22","2","iPhone игры","1494760813","");
INSERT INTO forum_r VALUES("23","2","Sony PlayStation","1494760824","");
INSERT INTO forum_r VALUES("24","2","Android Игры","1494760831","");
INSERT INTO forum_r VALUES("25","2","PC игры","1494760837","");
INSERT INTO forum_r VALUES("26","2","Онлайн-игры","1494760844","");
INSERT INTO forum_r VALUES("27","2","Новости игрового мира","1494760850","");
INSERT INTO forum_r VALUES("28","3","Общие вопросы","1494760920","");
INSERT INTO forum_r VALUES("29","3","Другие операторы","1494760926","");
INSERT INTO forum_r VALUES("30","3","Tele2","1494760930","");
INSERT INTO forum_r VALUES("31","3","Мегафон","1494760935","");
INSERT INTO forum_r VALUES("32","3","Билайн","1494760940","");
INSERT INTO forum_r VALUES("33","3","МТС","1494760945","");
INSERT INTO forum_r VALUES("34","3","SMS/MMS","1494760951","");
INSERT INTO forum_r VALUES("35","3","WAP, GPRS, EDGE, 3G, Wi-Fi","1494760956","");
INSERT INTO forum_r VALUES("36","3","E-mail","1494760962","");
INSERT INTO forum_r VALUES("37","3","Opera Mini и др. браузеры","1494760969","");
INSERT INTO forum_r VALUES("38","3","ICQ, Jimm и др мобильн. клиенты","1494760974","");
INSERT INTO forum_r VALUES("39","4","Программирование","1494760993","");
INSERT INTO forum_r VALUES("40","4","Root и прошивки","1494760997","");
INSERT INTO forum_r VALUES("41","4","Украшательства","1494761002","");
INSERT INTO forum_r VALUES("42","4","Статьи","1494761008","");
INSERT INTO forum_r VALUES("43","4","Программы","1494761014","");
INSERT INTO forum_r VALUES("44","4","Устройства","1494761020","");
INSERT INTO forum_r VALUES("45","4","Помощь и общие вопросы","1494761025","");
INSERT INTO forum_r VALUES("46","5","Прочие платформы","1494761054","");
INSERT INTO forum_r VALUES("47","5","iPhone программы","1494761059","");
INSERT INTO forum_r VALUES("48","5","iPhone статьи","1494761064","");
INSERT INTO forum_r VALUES("49","5","iPhone общие вопросы","1494761069","");
INSERT INTO forum_r VALUES("50","6","Прочие вопросы","1494761089","");
INSERT INTO forum_r VALUES("51","6","Прочая техника","1494761095","");
INSERT INTO forum_r VALUES("52","6","Фото и видеокамеры","1494761100","");
INSERT INTO forum_r VALUES("53","6","Аудио/видео техника","1494761105","");
INSERT INTO forum_r VALUES("54","6","Ноутбуки","1494761121","");
INSERT INTO forum_r VALUES("55","6","Игровые консоли","1494761126","");
INSERT INTO forum_r VALUES("56","6","Создание сайтов и программирован","1494761132","");
INSERT INTO forum_r VALUES("57","6","ПК + Телефон","1494761143","");
INSERT INTO forum_r VALUES("58","6","Операционные системы","1494761151","");
INSERT INTO forum_r VALUES("59","6","Интернет","1494761158","");
INSERT INTO forum_r VALUES("60","6","Железо","1494761164","");
INSERT INTO forum_r VALUES("61","6","Софт","1494761168","");
INSERT INTO forum_r VALUES("62","7","Спортивные тотализаторы","1494761196","");
INSERT INTO forum_r VALUES("63","7","Здоровый образ жизни","1494761208","физкультура, фитнес, аэробика");
INSERT INTO forum_r VALUES("64","7","Другие виды спорта","1494761218","");
INSERT INTO forum_r VALUES("65","7","Боевые искусства","1494761222","");
INSERT INTO forum_r VALUES("66","7","Бодибилдинг","1494761228","");
INSERT INTO forum_r VALUES("67","7","Авто/Вело/Мотоспорт","1494761233","");
INSERT INTO forum_r VALUES("68","7","Хоккей","1494761239","");
INSERT INTO forum_r VALUES("69","7","Футбол","1494761245","");
INSERT INTO forum_r VALUES("70","7","Спортивные новости","1494761250","");
INSERT INTO forum_r VALUES("71","8","Родители и дети","1494761267","");
INSERT INTO forum_r VALUES("72","8","Дружба","1494761274","");
INSERT INTO forum_r VALUES("73","8","Семья","1494761278","");
INSERT INTO forum_r VALUES("74","8","Секс","1494761285","");
INSERT INTO forum_r VALUES("75","8","Любовь","1494761290","");
INSERT INTO forum_r VALUES("76","9","Прочие темы","1494761310","");
INSERT INTO forum_r VALUES("77","9","Lifehack","1494761321","Взламываем жизнь. Практические советы и хитрости.");
INSERT INTO forum_r VALUES("78","9","Криминал и право","1494761328","");
INSERT INTO forum_r VALUES("79","9","Кулинария","1494761332","");
INSERT INTO forum_r VALUES("80","9","Юмор","1494761337","");
INSERT INTO forum_r VALUES("81","9","Туризм и путешествия","1494761343","");
INSERT INTO forum_r VALUES("82","9","Бизнес/Финансы","1494761348","");
INSERT INTO forum_r VALUES("83","9","Медицина/ Здоровье","1494761354","");
INSERT INTO forum_r VALUES("84","9","Армия/Служба","1494761360","");
INSERT INTO forum_r VALUES("85","9","Работа/Учеба","1494761366","");
INSERT INTO forum_r VALUES("86","9","За жизнь!","1494761376","Как она есть");
INSERT INTO forum_r VALUES("87","10","Общие вопросы","1494761398","");
INSERT INTO forum_r VALUES("88","10","Другие производители","1494761404","");
INSERT INTO forum_r VALUES("89","10","LG","1494761409","");
INSERT INTO forum_r VALUES("90","10","BenQ-Siemens","1494761413","");
INSERT INTO forum_r VALUES("91","10","Samsung","1494763179","");
INSERT INTO forum_r VALUES("92","10","Motorola","1494763187","");
INSERT INTO forum_r VALUES("93","10","Sony Ericsson","1494763191","");
INSERT INTO forum_r VALUES("94","10","Nokia","1494763196","");
INSERT INTO forum_r VALUES("95","11","Общие вопросы","1494763258","");
INSERT INTO forum_r VALUES("96","11","Видео","1494763262","");
INSERT INTO forum_r VALUES("97","11","Мелодии и звуки","1494763269","");
INSERT INTO forum_r VALUES("98","11","Картинки и темы","1494763273","");
INSERT INTO forum_r VALUES("99","11","Java-программы","1494763278","");
INSERT INTO forum_r VALUES("100","12","Наука","1494763360","");
INSERT INTO forum_r VALUES("101","12","Философия и Религия","1494763366","");
INSERT INTO forum_r VALUES("102","12","Культура/Искусство","1494763371","");
INSERT INTO forum_r VALUES("103","12","Животные и Природа","1494763377","");
INSERT INTO forum_r VALUES("104","12","История","1494763382","");
INSERT INTO forum_r VALUES("105","12","Литература","1494763389","");
INSERT INTO forum_r VALUES("106","12","Авто/Мото","1494763395","");
INSERT INTO forum_r VALUES("107","12","Кино и ТВ","1494763400","");
INSERT INTO forum_r VALUES("108","12","Музыка","1494763406","");
INSERT INTO forum_r VALUES("109","13","Другие субкультуры","1494763450","");
INSERT INTO forum_r VALUES("110","13","Эмо","1494763456","");
INSERT INTO forum_r VALUES("111","13","Хардкор","1494763462","");
INSERT INTO forum_r VALUES("112","13","РЭП","1494763467","");
INSERT INTO forum_r VALUES("113","13","РОК","1494763472","");
INSERT INTO forum_r VALUES("114","13","Панк","1494763478","");
INSERT INTO forum_r VALUES("115","13","Метал","1494763484","");
INSERT INTO forum_r VALUES("116","13","Клубная жизнь","1494763489","");
INSERT INTO forum_r VALUES("117","13","Готика","1494763494","");
INSERT INTO forum_r VALUES("118","13","Аниме","1494763499","");
INSERT INTO forum_r VALUES("119","13","Альтернатива","1494763505","");
INSERT INTO forum_r VALUES("120","14","Политика стран бывшего СССР","1494763527","Содружество независимых государств");
INSERT INTO forum_r VALUES("121","14","Теории заговора","1494763538","Big brother is watching you");
INSERT INTO forum_r VALUES("122","14","Мировая политика","1494763548","\\\"Мировое правительство\\\" в разделе ниже");
INSERT INTO forum_r VALUES("123","14","Российско-Украинская полемика","1494763558","Культурный взаимообмен двух братских народов");
INSERT INTO forum_r VALUES("124","14","Украинская политика","1494763569","Внутренняя политика Украины");
INSERT INTO forum_r VALUES("125","14","Политика РФ","1494763581","Внутренняя политика РФ");
INSERT INTO forum_r VALUES("126","15","Архив тем","1494763621","");
INSERT INTO forum_r VALUES("127","15","Песочница","1496954853","");



DROP TABLE IF EXISTS `forum_t`;

CREATE TABLE `forum_t` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_forum` int(11) NOT NULL,
  `id_razdel` int(11) DEFAULT NULL,
  `name` varchar(32) NOT NULL,
  `id_user` int(11) DEFAULT NULL,
  `time_create` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `up` set('0','1') NOT NULL DEFAULT '0',
  `close` set('0','1') NOT NULL DEFAULT '0',
  `text` varchar(2000) NOT NULL,
  `id_edit` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_forum` (`id_forum`,`id_razdel`),
  FULLTEXT KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

INSERT INTO forum_t VALUES("2","12","1","Тест","1","1496178362","1484818971","0","1","У Вас тоже бывают моменты, когда просто опускаются руки?\r\nТы не понимаешь, что происходит вокруг, ничего не интересно, просто существуешь, а не живешь...","1");
INSERT INTO forum_t VALUES("3","12","1","Интересные факты","2","1494447258","1494447258","0","0","Знамя Победы, привезенное в Москву 20 июня 1945 года, должны были пронести по Красной площади. И расчет знаменщиков специально тренировался. Хранитель Знамени в Музее Советской Армии А. Дементьев утверждал: водрузившие его над рейхстагом и откомандированные в Москву знаменосец Неустроев и его ассистенты Егоров, Кантария и Берест прошли на репетиции крайне неудачно – на войне им было не до строевой подготовки. У того же Неустроева к 22 годам было пять ранений, ноги были повреждены. Назначать других знаменосцев – нелепо, да и поздно. Жуков решил Знамя не выносить. Поэтому, вопреки распространенному мнению, Знамени на Параде Победы не было. Первый раз Знамя выносили на парад в 1965 году.","0");
INSERT INTO forum_t VALUES("4","12","1","Тема с файлом!","1","1496418712","1494677046","1","0","«Мистраль» сел на мель и повредил один из своих гребАных винтов!\r\n\r\nФранцузы свой Мистраль на мель посадили. Это ж надо было умудриться, возле Марианской впадины мель найти.\r\nУчения по устрашению Китая отменены.\r\nКина не будет. Китайцы ржут. Сейчас предложат свою помощь по снятию посудины с мели. За пару десятков тысяч евро!..","1");
INSERT INTO forum_t VALUES("5","15","127","Бесконечное слово","1","1496418516","1494767064","1","0","Суть игры очень проста - пишем бесконечное\r\nслово. Начало следующего - это\r\nдве последние буквы\r\nпредыдущего.\r\nНапример:\r\nадвокАТ\r\nАтлАС\r\nАСпирИН\r\nИнтернЕТ и тд\r\nИграют все!!! :)\r\n Я первый - слово ВЕСНА","1");
INSERT INTO forum_t VALUES("6","15","127","Для теста активности","1","1496433187","1496433187","0","0","Тестим форум тему для активности юзера","0");
INSERT INTO forum_t VALUES("7","15","127","Для активности форума","1","1496433376","1496433376","0","0","Тесттттт,  ну теееесттттт","0");
INSERT INTO forum_t VALUES("8","15","127","gggggggggggggggggggggggggggggggg","14","1496954874","1496954853","0","1","ghhhhhhggggggggggggggggggggggggggggggggggggggggg","14");
INSERT INTO forum_t VALUES("9","1","6","сайт класс","15","1497128025","1497128025","0","0","Хочу купить этот двиг","");



DROP TABLE IF EXISTS `forum_zakl`;

CREATE TABLE `forum_zakl` (
  `id_user` int(11) NOT NULL,
  `id_them` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `time_obn` int(11) NOT NULL,
  KEY `id_user` (`id_user`,`id_them`,`time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `frends`;

CREATE TABLE `frends` (
  `user` int(11) NOT NULL DEFAULT '0',
  `frend` int(11) NOT NULL DEFAULT '0',
  `time` int(11) NOT NULL,
  `i` int(1) DEFAULT '0',
  `lenta_forum` int(11) NOT NULL DEFAULT '1',
  `lenta_obmen` int(11) NOT NULL DEFAULT '1',
  `lenta_foto` int(11) NOT NULL DEFAULT '1',
  `lenta_notes` int(11) NOT NULL DEFAULT '1',
  `lenta_avatar` int(11) DEFAULT '1',
  `lenta_frends` int(1) DEFAULT '1',
  `lenta_status` int(1) DEFAULT '1',
  `lenta_status_like` int(1) DEFAULT '1',
  `disc_forum` int(11) NOT NULL DEFAULT '1',
  `disc_obmen` int(11) NOT NULL DEFAULT '1',
  `disc_foto` int(11) NOT NULL DEFAULT '1',
  `disc_notes` int(11) NOT NULL DEFAULT '1',
  `disc_frends` int(1) DEFAULT '1',
  `disc_status` int(1) DEFAULT '1',
  PRIMARY KEY (`user`,`frend`),
  KEY `time` (`time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO frends VALUES("4","6","1493903224","1","1","1","1","1","1","1","1","1","1","1","1","1","1","1");
INSERT INTO frends VALUES("6","4","1493903224","1","1","1","1","1","1","1","1","1","1","1","1","1","1","1");
INSERT INTO frends VALUES("4","1","1493904698","1","1","1","1","1","1","1","1","1","1","1","1","1","1","1");
INSERT INTO frends VALUES("1","4","1493904698","1","1","1","1","1","1","1","1","1","1","1","1","1","1","1");
INSERT INTO frends VALUES("8","1","1494424634","1","1","1","1","1","1","1","1","1","1","1","1","1","1","1");
INSERT INTO frends VALUES("1","8","1494424634","1","1","1","1","1","1","1","1","1","1","1","1","1","1","1");
INSERT INTO frends VALUES("14","1","1496695155","1","1","1","1","1","1","1","1","1","1","1","1","1","1","1");
INSERT INTO frends VALUES("1","14","1496695155","1","1","1","1","1","1","1","1","1","1","1","1","1","1","1");
INSERT INTO frends VALUES("6","1","1496978289","1","1","1","1","1","1","1","1","1","1","1","1","1","1","1");
INSERT INTO frends VALUES("1","6","1496978289","1","1","1","1","1","1","1","1","1","1","1","1","1","1","1");
INSERT INTO frends VALUES("17","1","1497190091","1","1","1","1","1","1","1","1","1","1","1","1","1","1","1");
INSERT INTO frends VALUES("1","17","1497190091","1","1","1","1","1","1","1","1","1","1","1","1","1","1","1");



DROP TABLE IF EXISTS `frends_new`;

CREATE TABLE `frends_new` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL DEFAULT '0',
  `to` int(11) NOT NULL DEFAULT '0',
  `time` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `time` (`time`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO frends_new VALUES("24","1","2","1496930236");



DROP TABLE IF EXISTS `gallery`;

CREATE TABLE `gallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `name` varchar(32) NOT NULL,
  `time_create` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `opis` varchar(256) NOT NULL,
  `set_password` int(11) NOT NULL,
  `foto_password` varchar(32) NOT NULL,
  `my` int(11) NOT NULL DEFAULT '0',
  `pass` varchar(11) DEFAULT NULL,
  `privat` enum('0','1','2') NOT NULL DEFAULT '0',
  `privat_komm` enum('0','1','2') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `id_user` (`id_user`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

INSERT INTO gallery VALUES("1","1","Картинки","1484057155","1496576957","","0","","0","","0","0");
INSERT INTO gallery VALUES("2","2","Тестовый","1493286002","1496432526","Описание типо )","0","","0","","0","0");
INSERT INTO gallery VALUES("3","4","ツツツツツ","1493452140","1496418392","","0","","0","","0","0");
INSERT INTO gallery VALUES("12","8","альбом","1494424757","1494424848","","0","","0","","0","0");
INSERT INTO gallery VALUES("13","9",":}","1494867362","1495097218","","0","","0","","1","2");
INSERT INTO gallery VALUES("14","6","Аватарки","1496417808","1496417869","","0","","0","","1","1");
INSERT INTO gallery VALUES("16","1","Для теста активности","1496431809","1496577239","","0","","0","","0","0");
INSERT INTO gallery VALUES("17","2","1111","1496432541","1496432549","","0","","0","","0","0");
INSERT INTO gallery VALUES("18","1","Я :)","1496577250","1496577259","","0","","0","","0","0");
INSERT INTO gallery VALUES("19","16","Слот Русалочка","1497168086","1497168120","","0","","0","","0","0");
INSERT INTO gallery VALUES("20","17","test","1497190549","1497190549","","0","","0","","0","0");



DROP TABLE IF EXISTS `gallery_foto`;

CREATE TABLE `gallery_foto` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_gallery` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `ras` varchar(4) NOT NULL,
  `type` varchar(64) NOT NULL,
  `opis` varchar(1024) NOT NULL,
  `rating` int(11) NOT NULL DEFAULT '0',
  `id_user` int(11) NOT NULL,
  `avatar` enum('0','1') DEFAULT '0',
  `pass` varchar(11) DEFAULT NULL,
  `people` int(11) DEFAULT NULL,
  `time` int(11) NOT NULL,
  `metka` int(1) DEFAULT '0',
  `count` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `id_gallery` (`id_gallery`)
) ENGINE=MyISAM AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;

INSERT INTO gallery_foto VALUES("5","2","bDF7kLyEndE","jpg","image/jpeg","","0","2","0","","0","1493286011","1","1");
INSERT INTO gallery_foto VALUES("18","3","Avatar","jpg","image/jpeg","","0","4","0","","0","1495520961","0","1");
INSERT INTO gallery_foto VALUES("8","1","u-eqJDESD6g","jpg","image/jpeg","","0","1","0","","0","1494097925","0","5");
INSERT INTO gallery_foto VALUES("9","1","bDF7kLyEndE","jpg","image/jpeg","","0","1","0","","0","1494097934","0","2");
INSERT INTO gallery_foto VALUES("10","1","A5n59j19Jx8","jpg","image/jpeg","No comments...","0","1","0","","0","1494097963","1","5");
INSERT INTO gallery_foto VALUES("13","12","авка","jpg","image/jpeg","згагсгз","0","8","1","","0","1494424848","0","2");
INSERT INTO gallery_foto VALUES("14","2","45454","jpg","image/jpeg","","0","2","1","","0","1494444552","0","2");
INSERT INTO gallery_foto VALUES("16","1","169819","jpg","image/jpeg","","0","1","1","","0","1494994258","0","3");
INSERT INTO gallery_foto VALUES("17","13","lova","jpg","image/jpeg","","0","9","1","","0","1495097218","0","1");
INSERT INTO gallery_foto VALUES("19","14","Аватарка","jpg","image/jpeg","","0","6","1","","0","1496417869","0","1");
INSERT INTO gallery_foto VALUES("20","3","Avatar","jpg","image/jpeg","","0","4","1","","0","1496418392","0","2");
INSERT INTO gallery_foto VALUES("46","16","u-eqJDESD6g","jpg","image/jpeg","","0","1","0","","0","1496577239","0","0");
INSERT INTO gallery_foto VALUES("47","18","FKp6vjoxF5g","jpg","image/jpeg","","0","1","0","","0","1496577259","0","3");
INSERT INTO gallery_foto VALUES("45","16","bDF7kLyEndE","jpg","image/jpeg","","0","1","0","","0","1496577211","0","0");
INSERT INTO gallery_foto VALUES("31","16","A5n59j19Jx8","jpg","image/jpeg","","0","1","0","","0","1496431947","0","0");
INSERT INTO gallery_foto VALUES("30","16","45454","jpg","image/jpeg","","0","1","0","","0","1496431881","0","0");
INSERT INTO gallery_foto VALUES("38","2","p5CUZCGTgFk","jpg","image/jpeg","","0","2","0","","0","1496432526","0","0");
INSERT INTO gallery_foto VALUES("39","17","uioooo87ii8","jpg","image/jpeg","","0","2","0","","0","1496432549","0","0");
INSERT INTO gallery_foto VALUES("42","1","OyS3-8_K4Q0","jpg","image/jpeg","","0","1","0","","0","1496576385","0","0");
INSERT INTO gallery_foto VALUES("43","1","45454","jpg","image/jpeg","","0","1","0","","0","1496576851","0","0");
INSERT INTO gallery_foto VALUES("44","1","A5n59j19Jx8","jpg","image/jpeg","","0","1","0","","0","1496576957","0","0");



DROP TABLE IF EXISTS `gallery_foto_count`;

CREATE TABLE `gallery_foto_count` (
  `id_foto` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  KEY `id_foto` (`id_foto`,`id_user`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO gallery_foto_count VALUES("5","1");
INSERT INTO gallery_foto_count VALUES("6","1");
INSERT INTO gallery_foto_count VALUES("8","2");
INSERT INTO gallery_foto_count VALUES("8","4");
INSERT INTO gallery_foto_count VALUES("8","6");
INSERT INTO gallery_foto_count VALUES("8","9");
INSERT INTO gallery_foto_count VALUES("8","14");
INSERT INTO gallery_foto_count VALUES("9","2");
INSERT INTO gallery_foto_count VALUES("9","6");
INSERT INTO gallery_foto_count VALUES("10","2");
INSERT INTO gallery_foto_count VALUES("10","4");
INSERT INTO gallery_foto_count VALUES("10","6");
INSERT INTO gallery_foto_count VALUES("10","7");
INSERT INTO gallery_foto_count VALUES("10","9");
INSERT INTO gallery_foto_count VALUES("13","1");
INSERT INTO gallery_foto_count VALUES("13","4");
INSERT INTO gallery_foto_count VALUES("14","1");
INSERT INTO gallery_foto_count VALUES("14","14");
INSERT INTO gallery_foto_count VALUES("16","4");
INSERT INTO gallery_foto_count VALUES("16","9");
INSERT INTO gallery_foto_count VALUES("16","13");
INSERT INTO gallery_foto_count VALUES("17","1");
INSERT INTO gallery_foto_count VALUES("18","1");
INSERT INTO gallery_foto_count VALUES("19","1");
INSERT INTO gallery_foto_count VALUES("20","1");
INSERT INTO gallery_foto_count VALUES("20","6");
INSERT INTO gallery_foto_count VALUES("33","6");
INSERT INTO gallery_foto_count VALUES("34","6");
INSERT INTO gallery_foto_count VALUES("35","6");
INSERT INTO gallery_foto_count VALUES("47","6");
INSERT INTO gallery_foto_count VALUES("47","9");
INSERT INTO gallery_foto_count VALUES("47","16");



DROP TABLE IF EXISTS `gallery_komm`;

CREATE TABLE `gallery_komm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_foto` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `msg` varchar(1024) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_foto` (`id_foto`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO gallery_komm VALUES("3","8","1","1494098300","fsfdsf");
INSERT INTO gallery_komm VALUES("4","10","1","1494148170","xgfdgggggg");
INSERT INTO gallery_komm VALUES("5","10","2","1494151090","Тест..");
INSERT INTO gallery_komm VALUES("6","47","16","1497168773","Хобот)");



DROP TABLE IF EXISTS `gallery_like`;

CREATE TABLE `gallery_like` (
  `id_photo` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `like` int(11) DEFAULT '0',
  KEY `id_photo` (`id_photo`,`id_user`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO gallery_like VALUES("20","1","1");



DROP TABLE IF EXISTS `gallery_rating`;

CREATE TABLE `gallery_rating` (
  `id_foto` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `like` int(11) NOT NULL DEFAULT '0',
  `avtor` int(11) NOT NULL DEFAULT '0',
  `ready` int(11) NOT NULL DEFAULT '1',
  `time` int(11) NOT NULL DEFAULT '0',
  `read` int(1) DEFAULT '1',
  KEY `id_foto` (`id_foto`,`id_user`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO gallery_rating VALUES("6","1","6","4","1","1493452924","1");



DROP TABLE IF EXISTS `gift_categories`;

CREATE TABLE `gift_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=cp1251;

INSERT INTO gift_categories VALUES("1","10 монет");
INSERT INTO gift_categories VALUES("2","30 монет");
INSERT INTO gift_categories VALUES("3","50 монет");
INSERT INTO gift_categories VALUES("4","Зверушки");
INSERT INTO gift_categories VALUES("5","Открытки");



DROP TABLE IF EXISTS `gift_list`;

CREATE TABLE `gift_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_category` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `money` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=72 DEFAULT CHARSET=cp1251;

INSERT INTO gift_list VALUES("1","5","5 монет","5");
INSERT INTO gift_list VALUES("2","5","5 монет","5");
INSERT INTO gift_list VALUES("3","5","5 монет","5");
INSERT INTO gift_list VALUES("4","5","5 монет","5");
INSERT INTO gift_list VALUES("5","5","5 монет","5");
INSERT INTO gift_list VALUES("6","5","5 монет","5");
INSERT INTO gift_list VALUES("7","5","5 монет","5");
INSERT INTO gift_list VALUES("8","5","5 монет","5");
INSERT INTO gift_list VALUES("9","5","5 монет","5");
INSERT INTO gift_list VALUES("10","5","5 монет","5");
INSERT INTO gift_list VALUES("11","5","5 монет","5");
INSERT INTO gift_list VALUES("12","5","5 монет","5");
INSERT INTO gift_list VALUES("13","5","5 монет","5");
INSERT INTO gift_list VALUES("14","5","5 монет","5");
INSERT INTO gift_list VALUES("15","5","5 монет","5");
INSERT INTO gift_list VALUES("16","5","5 монет","5");
INSERT INTO gift_list VALUES("17","5","5 монет","5");
INSERT INTO gift_list VALUES("18","5","5 монет","5");
INSERT INTO gift_list VALUES("19","5","5 монет","5");
INSERT INTO gift_list VALUES("20","5","5 монет","5");
INSERT INTO gift_list VALUES("21","5","5 монет","5");
INSERT INTO gift_list VALUES("22","5","5 монет","5");
INSERT INTO gift_list VALUES("23","5","5 монет","5");
INSERT INTO gift_list VALUES("24","3","50 монет","50");
INSERT INTO gift_list VALUES("25","3","50 монет","50");
INSERT INTO gift_list VALUES("26","3","50 монет","50");
INSERT INTO gift_list VALUES("27","3","50 монет","50");
INSERT INTO gift_list VALUES("28","3","50 монет","50");
INSERT INTO gift_list VALUES("29","3","50 монет","50");
INSERT INTO gift_list VALUES("30","3","50 монет","50");
INSERT INTO gift_list VALUES("31","2","30 монет","30");
INSERT INTO gift_list VALUES("32","2","30 монет","30");
INSERT INTO gift_list VALUES("33","2","30 монет","30");
INSERT INTO gift_list VALUES("34","2","30 монет","30");
INSERT INTO gift_list VALUES("35","2","30 монет","30");
INSERT INTO gift_list VALUES("36","2","30 монет","30");
INSERT INTO gift_list VALUES("37","2","30 монет","30");
INSERT INTO gift_list VALUES("38","2","30 монет","30");
INSERT INTO gift_list VALUES("39","2","30 монет","30");
INSERT INTO gift_list VALUES("40","2","30 монет","30");
INSERT INTO gift_list VALUES("41","2","30 монет","30");
INSERT INTO gift_list VALUES("42","2","30 монет","30");
INSERT INTO gift_list VALUES("43","1","10 монет","10");
INSERT INTO gift_list VALUES("44","1","10 монет","10");
INSERT INTO gift_list VALUES("45","1","10 монет","10");
INSERT INTO gift_list VALUES("46","1","10 монет","10");
INSERT INTO gift_list VALUES("47","1","10 монет","10");
INSERT INTO gift_list VALUES("48","1","10 монет","10");
INSERT INTO gift_list VALUES("50","1","10 монет","10");
INSERT INTO gift_list VALUES("51","1","10 монет","10");
INSERT INTO gift_list VALUES("52","1","10 монет","10");
INSERT INTO gift_list VALUES("53","1","10 монет","10");
INSERT INTO gift_list VALUES("54","1","10 монет","10");
INSERT INTO gift_list VALUES("55","1","10 монет","10");
INSERT INTO gift_list VALUES("56","1","10 монет","10");
INSERT INTO gift_list VALUES("57","1","10 монет","10");
INSERT INTO gift_list VALUES("58","1","10 монет","10");
INSERT INTO gift_list VALUES("59","1","10 монет","10");
INSERT INTO gift_list VALUES("60","1","10 монет","10");
INSERT INTO gift_list VALUES("61","1","10 монет","10");
INSERT INTO gift_list VALUES("62","1","10 монет","10");
INSERT INTO gift_list VALUES("63","1","10 монет","10");
INSERT INTO gift_list VALUES("64","1","10 монет","10");
INSERT INTO gift_list VALUES("65","1","10 монет","10");
INSERT INTO gift_list VALUES("66","1","10 монет","10");
INSERT INTO gift_list VALUES("67","4","Зверушки","10");
INSERT INTO gift_list VALUES("68","4","Зверушки","10");
INSERT INTO gift_list VALUES("69","4","Зверушки","10");
INSERT INTO gift_list VALUES("70","4","Зверушки","10");
INSERT INTO gift_list VALUES("71","4","Зверушки","10");



DROP TABLE IF EXISTS `gifts_user`;

CREATE TABLE `gifts_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `id_ank` int(11) NOT NULL,
  `id_gift` int(11) NOT NULL,
  `anonim` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `coment` varchar(150) NOT NULL,
  `status` int(1) DEFAULT '0',
  `type` enum('1','2','3') DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=cp1251;

INSERT INTO gifts_user VALUES("12","1","1","1","0","1484594989","Лови подарок!","1","3");
INSERT INTO gifts_user VALUES("6","1","1","2","0","1484588697","Анонимный","1","1");
INSERT INTO gifts_user VALUES("10","2","1","1","0","1484589418","Личный\r\nВсе будут видеть ваш подарок, но только получатель сможет видеть ваш Ник и сообщение.","1","2");
INSERT INTO gifts_user VALUES("11","2","1","2","0","1484589819","Анонимный\r\nВсе будут видеть ваш подарок. Только получатель увидит ваше сообщение. Никто не увидит ваш Ник.","1","3");
INSERT INTO gifts_user VALUES("13","4","1","2","0","1493379205","Лови подарок!","1","2");
INSERT INTO gifts_user VALUES("15","4","1","18","0","1493972005","Лови подарок!","1","2");
INSERT INTO gifts_user VALUES("16","4","1","24","0","1493972259","Лови подарок!","1","3");
INSERT INTO gifts_user VALUES("17","4","1","34","0","1493973169","Лови подарок!","1","1");
INSERT INTO gifts_user VALUES("18","4","1","58","0","1493973197","Лови подарок!","1","1");
INSERT INTO gifts_user VALUES("19","1","1","34","0","1494165501","Лови подарок!","1","3");
INSERT INTO gifts_user VALUES("20","5","1","58","0","1494263153","Лови подарок!","1","1");
INSERT INTO gifts_user VALUES("21","7","1","58","0","1494271218","Лови подарок!","1","3");
INSERT INTO gifts_user VALUES("22","8","1","58","0","1494424617","Лови подарок!","1","2");
INSERT INTO gifts_user VALUES("23","9","1","45","0","1494842658","Ты же любишь)","1","1");
INSERT INTO gifts_user VALUES("24","4","1","30","0","1495359133","Для теста Журнала операций..","1","2");
INSERT INTO gifts_user VALUES("25","4","1","31","0","1495359299","Для теста Журнала операций..","1","3");
INSERT INTO gifts_user VALUES("26","12","1","59","0","1495964941","Добро пожаловать!","1","3");
INSERT INTO gifts_user VALUES("27","13","1","59","0","1496177219","Лови подарок!","1","2");
INSERT INTO gifts_user VALUES("28","14","1","59","0","1496695130","Лови подарок!","1","3");
INSERT INTO gifts_user VALUES("29","15","1","59","0","1497128887","Wellcome!","1","2");
INSERT INTO gifts_user VALUES("30","17","1","59","0","1497190012","Wellcome!","1","2");



DROP TABLE IF EXISTS `guest`;

CREATE TABLE `guest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL DEFAULT '0',
  `time` int(11) NOT NULL,
  `msg` varchar(1024) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `time` (`time`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO guest VALUES("1","4","1493453284",":)");
INSERT INTO guest VALUES("3","5","1493475592","=) .миг.");



DROP TABLE IF EXISTS `guests`;

CREATE TABLE `guests` (
  `ip` bigint(20) NOT NULL,
  `ua` varchar(32) NOT NULL,
  `date_aut` int(11) NOT NULL,
  `date_last` int(11) NOT NULL,
  `url` varchar(64) NOT NULL,
  `pereh` int(11) NOT NULL DEFAULT '0',
  KEY `ip_2` (`ip`,`ua`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO guests VALUES("872366384","Mozilla","1497114324","1497114324","/index.php","0");
INSERT INTO guests VALUES("2760155420","Mozilla","1497117803","1497117803","/user/anketa/index.php","0");
INSERT INTO guests VALUES("2760155471","Mozilla","1497118232","1497118232","/user/blogs/view/index.php","0");
INSERT INTO guests VALUES("100662566","Mozilla","1497118885","1497157579","/plugins/smiles/dir.php","8");
INSERT INTO guests VALUES("2366158856","Mozilla","1497118925","1497187663","/user/gifts/user_list/index.php","6");
INSERT INTO guests VALUES("2366145613","Mozilla","1497118938","1497189305","/user/info/user.them.php","2");
INSERT INTO guests VALUES("2996488263","Mozilla","1497118954","1497187717","/user/blogs/read/index.php","7");
INSERT INTO guests VALUES("2996488197","Mozilla","1497118977","1497191782","/user/guestbook/index.php","5");
INSERT INTO guests VALUES("1600959769","Mozilla","1497119003","1497174988","/user/gifts/index.php","1");
INSERT INTO guests VALUES("100662549","Mozilla","1497119024","1497186733","/user/info/welcome_list.php","4");
INSERT INTO guests VALUES("2366158612","Mozilla","1497119043","1497187720","/foto/index.php","7");
INSERT INTO guests VALUES("100662605","Mozilla","1497119067","1497119067","/foto/index.php","0");
INSERT INTO guests VALUES("2996485414","Mozilla","1497119070","1497191647","/user/activity/index.php","4");
INSERT INTO guests VALUES("2366158872","Mozilla","1497119091","1497119091","/user/anketa/index.php","0");
INSERT INTO guests VALUES("2366158865","Mozilla","1497119133","1497187707","/user/gifts/user_list/index.php","11");
INSERT INTO guests VALUES("2366158857","Mozilla","1497119155","1497119155","/user/info/user.them.php","0");
INSERT INTO guests VALUES("2366145578","Mozilla","1497121994","1497187674","/forum/index.php","4");
INSERT INTO guests VALUES("100662569","Mozilla","1497119264","1497189673","/forum/index.php","6");
INSERT INTO guests VALUES("2996488239","Mozilla","1497119302","1497119302","/index.php","0");
INSERT INTO guests VALUES("2996488221","Mozilla","1497119471","1497187712","/user/activity/index.php","4");
INSERT INTO guests VALUES("3652617396","Mozilla","1497123067","1497123067","/forum/index.php","0");
INSERT INTO guests VALUES("2366148239","Mozilla","1497119597","1497190160","/forum/index.php","1");
INSERT INTO guests VALUES("872366186","Mozilla","1497120817","1497120817","/user/gifts/user_list/index.php","0");
INSERT INTO guests VALUES("2760155457","Mozilla","1497121430","1497121430","/foto/index.php","0");
INSERT INTO guests VALUES("1042370621","Mozilla","1497121814","1497121814","/index.php","0");
INSERT INTO guests VALUES("100662588","Mozilla","1497122816","1497186742","/forum/index.php","5");
INSERT INTO guests VALUES("2834023157","Mozilla","1497127587","1497160771","/login.php","5");
INSERT INTO guests VALUES("2303381407","Mozilla","1497127607","1497127607","/foto/index.php","0");
INSERT INTO guests VALUES("873859024","Opera","1497131246","1497131246","/index.php","0");
INSERT INTO guests VALUES("1570674718","Mozilla","1497132311","1497161878","/user/friends/online/index.php","1");
INSERT INTO guests VALUES("1600967942","Mozilla","1497132314","1497186729","/user/info/user.them.php","5");
INSERT INTO guests VALUES("1570674764","Mozilla","1497132321","1497132321","/user/blogs/read/index.php","0");
INSERT INTO guests VALUES("2366148242","Mozilla","1497132377","1497132377","/user/blogs/read/index.php","0");
INSERT INTO guests VALUES("2996488232","Mozilla","1497132425","1497187682","/forum/index.php","2");
INSERT INTO guests VALUES("2366148257","Mozilla","1497132442","1497132442","/user/guestbook/index.php","0");
INSERT INTO guests VALUES("2366148117","Mozilla","1497132461","1497169087","/forum/index.php","2");
INSERT INTO guests VALUES("1600959260","Mozilla","1497132478","1497188220","/forum/index.php","1");
INSERT INTO guests VALUES("1570674716","Mozilla","1497132497","1497160290","/user/gifts/user_list/index.php","1");
INSERT INTO guests VALUES("621375793","Mozilla","1497132529","1497132529","/forum/index.php","0");
INSERT INTO guests VALUES("872366418","Mozilla","1497133226","1497133226","/forum/index.php","0");
INSERT INTO guests VALUES("2760155465","Mozilla","1497134660","1497134660","/user/blogs/index.php","0");
INSERT INTO guests VALUES("3475901803","Mozilla","1497136318","1497186829","/index.php","1");
INSERT INTO guests VALUES("872367988","Mozilla","1497142879","1497142879","/foto/index.php","0");
INSERT INTO guests VALUES("872367982","Mozilla","1497143304","1497143304","/user/gifts/user_list/index.php","0");
INSERT INTO guests VALUES("782305575","Mozilla","1497152161","1497152258","/forum/index.php","5");
INSERT INTO guests VALUES("1123631309","Mozilla","1497155775","1497155775","/index.php","0");
INSERT INTO guests VALUES("2366148233","Mozilla","1497155876","1497190041","/forum/index.php","10");
INSERT INTO guests VALUES("2366148142","Mozilla","1497155880","1497187679","/forum/index.php","6");
INSERT INTO guests VALUES("1476059149","Mozilla","1497156538","1497156538","/forum/index.php","0");
INSERT INTO guests VALUES("1600967940","Mozilla","1497156542","1497186735","/user/info/welcome_list.php","2");
INSERT INTO guests VALUES("2366145550","Mozilla","1497156661","1497186725","/user/blogs/read/index.php","2");
INSERT INTO guests VALUES("3639886570","Mozilla","1497157753","1497157753","/user/friends/index.php","0");
INSERT INTO guests VALUES("2366148228","Mozilla","1497158910","1497186715","/user/friends/index.php","2");
INSERT INTO guests VALUES("2760155429","Mozilla","1497159675","1497159675","/foto/index.php","0");
INSERT INTO guests VALUES("2366148119","Mozilla","1497169089","1497169089","/forum/index.php","0");
INSERT INTO guests VALUES("1570674710","Mozilla","1497160527","1497190043","/user/friends/index.php","1");
INSERT INTO guests VALUES("1600959780","Mozilla","1497160657","1497169713","/foto/index.php","1");
INSERT INTO guests VALUES("2366148243","Mozilla","1497161881","1497161881","/user/friends/online/index.php","0");
INSERT INTO guests VALUES("1602626156","Mozilla","1497168035","1497168055","/reg.php","4");
INSERT INTO guests VALUES("1600959256","Mozilla","1497171730","1497186719","/user/guestbook/index.php","1");
INSERT INTO guests VALUES("1299951106","Mozilla","1497170185","1497170185","/user/index.php","1");
INSERT INTO guests VALUES("39665589","Mozilla","1497170186","1497170187","/index.php","1");
INSERT INTO guests VALUES("2959755305","Mozilla","1497170187","1497170187","/user/anketa/index.php","1");
INSERT INTO guests VALUES("1408396858","Mozilla","1497170188","1497170188","/foto/index.php","0");
INSERT INTO guests VALUES("2990624035","Mozilla","1497170189","1497170189","/foto/index.php","0");
INSERT INTO guests VALUES("3169333204","Mozilla","1497170231","1497170231","/foto/index.php","0");
INSERT INTO guests VALUES("776520621","Mozilla","1497170231","1497170231","/foto/index.php","0");
INSERT INTO guests VALUES("2956172962","Mozilla","1497170244","1497170244","/user/index.php","0");
INSERT INTO guests VALUES("634662793","Mozilla","1497170276","1497170276","/plugins/smiles/dir.php","0");
INSERT INTO guests VALUES("533720435","Mozilla","1497170278","1497170278","/plugins/rules/bb-code.php","0");
INSERT INTO guests VALUES("1495460385","Mozilla","1497170283","1497170283","/plugins/smiles/index.php","0");
INSERT INTO guests VALUES("3249716036","Mozilla","1497170287","1497170287","/user/bookmarks/index.php","0");
INSERT INTO guests VALUES("623759746","Mozilla","1497170289","1497170289","/user/bookmarks/likes/index.php","0");
INSERT INTO guests VALUES("93180612","Mozilla","1497170293","1497170293","/user/bookmarks/index.php","0");
INSERT INTO guests VALUES("1539594797","Mozilla","1497170330","1497170331","/aut.php","1");
INSERT INTO guests VALUES("3644886242","Mozilla","1497170334","1497170334","/index.php","1");
INSERT INTO guests VALUES("94683607","Mozilla","1497170340","1497170340","/index.php","1");
INSERT INTO guests VALUES("3588507235","Mozilla","1497170346","1497170346","/user/friends/index.php","0");
INSERT INTO guests VALUES("1520260949","Mozilla","1497170384","1497170385","/index.php","1");
INSERT INTO guests VALUES("2960560253","Mozilla","1497170887","1497171098","/user/blogs/read/index.php","1");
INSERT INTO guests VALUES("3240275210","Mozilla","1497170889","1497170889","/foto/index.php","0");
INSERT INTO guests VALUES("3111950856","Mozilla","1497170890","1497170890","/user/blogs/read/index.php","0");
INSERT INTO guests VALUES("100548975","Mozilla","1497170893","1497170893","/foto/index.php","0");
INSERT INTO guests VALUES("3107229509","Mozilla","1497170912","1497170912","/user/index.php","0");
INSERT INTO guests VALUES("3648409365","Mozilla","1497170946","1497171164","/foto/index.php","1");
INSERT INTO guests VALUES("1709326696","Mozilla","1497171423","1497171423","/foto/index.php","0");
INSERT INTO guests VALUES("1596981003","Mozilla","1497174238","1497183771","/login.php","18");
INSERT INTO guests VALUES("2366148192","Mozilla","1497171480","1497171480","/user/activity/index.php","0");
INSERT INTO guests VALUES("1600959745","Mozilla","1497171482","1497191652","/forum/index.php","3");
INSERT INTO guests VALUES("1600959237","Mozilla","1497173688","1497189310","/user/gifts/user_list/index.php","1");
INSERT INTO guests VALUES("2996485403","Mozilla","1497181314","1497186814","/user/friends/online/index.php","1");
INSERT INTO guests VALUES("1509595692","Mozilla","1497184532","1497184534","/forum/index.php","5");
INSERT INTO guests VALUES("520974896","facebookexternalhit","1497192629","1497192629","/index.php","1");
INSERT INTO guests VALUES("1600967966","Mozilla","1497187717","1497187717","/user/blogs/read/index.php","0");
INSERT INTO guests VALUES("100662615","Mozilla","1497188227","1497188227","/user/bookmarks/index.php","0");
INSERT INTO guests VALUES("1602632470","Mozilla","1497189226","1497189250","/aut.php","3");
INSERT INTO guests VALUES("774987817","Mozilla","1497189657","1497189715","/reg.php","7");
INSERT INTO guests VALUES("1596981000","Mozilla","1497189661","1497189682","/login.php","3");
INSERT INTO guests VALUES("520974921","facebookexternalhit","1497192629","1497192629","/user/startpage.php","0");
INSERT INTO guests VALUES("2918996053","facebookexternalhit","1497192629","1497192629","/user/startpage.php","0");
INSERT INTO guests VALUES("520974915","facebookexternalhit","1497192630","1497192630","/index.php","0");
INSERT INTO guests VALUES("2918996056","facebookexternalhit","1497192631","1497192631","/index.php","0");



DROP TABLE IF EXISTS `journal`;

CREATE TABLE `journal` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user` int(10) unsigned NOT NULL,
  `time` int(10) unsigned NOT NULL,
  `act` enum('file','dnew','other','blogs') NOT NULL DEFAULT 'other',
  `opis` text NOT NULL,
  `ank` int(11) NOT NULL,
  `url` text NOT NULL,
  `count` int(11) NOT NULL,
  `read` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

INSERT INTO journal VALUES("1","1","1496666637","blogs","","0","/user/blogs/read/?id=23","0","1");
INSERT INTO journal VALUES("8","1","1496729956","blogs","<b>Tw1nGo</b> понравился ваш блог!","4","/user/blogs/read/?id=16","0","0");
INSERT INTO journal VALUES("9","6","1496748856","blogs","<b>StRaNgEr</b> понравился ваш блог!","4","/user/blogs/read/?id=19","0","0");



DROP TABLE IF EXISTS `journal_ban`;

CREATE TABLE `journal_ban` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL,
  `ank` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `konts`;

CREATE TABLE `konts` (
  `id_user` int(11) NOT NULL,
  `id_kont` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  KEY `id_user` (`id_user`,`id_kont`,`time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `liders`;

CREATE TABLE `liders` (
  `time` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `time_p` int(11) NOT NULL,
  `msg` varchar(215) NOT NULL,
  `stav` int(11) NOT NULL DEFAULT '0',
  KEY `id_user` (`id_user`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `like_object`;

CREATE TABLE `like_object` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `type` varchar(11) DEFAULT NULL,
  `like` set('1','0') NOT NULL DEFAULT '0',
  `id_object` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `links_niz`;

CREATE TABLE `links_niz` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `mini_name` varchar(32) NOT NULL,
  `url` varchar(32) NOT NULL,
  `pos` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO links_niz VALUES("1","Я","Я","/user/?id=","0");
INSERT INTO links_niz VALUES("2","Друзья","Др","/user/friends/?uid=","0");
INSERT INTO links_niz VALUES("3","Форум","Фор","/forum/","0");
INSERT INTO links_niz VALUES("4","Онлайн","Онл","/online.php","0");



DROP TABLE IF EXISTS `links_niz_user`;

CREATE TABLE `links_niz_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_link` int(11) NOT NULL,
  `id_user` int(11) DEFAULT NULL,
  `link` varchar(1000) DEFAULT '0',
  `link_name` varchar(1000) DEFAULT '0',
  `pos` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pos` (`pos`)
) ENGINE=MyISAM AUTO_INCREMENT=66 DEFAULT CHARSET=utf8;

INSERT INTO links_niz_user VALUES("1","0","0","/info.php?id=","Я","1");
INSERT INTO links_niz_user VALUES("2","0","0","/info.php?id=","Я","1");
INSERT INTO links_niz_user VALUES("3","1","0","0","0","1");
INSERT INTO links_niz_user VALUES("48","1","1","0","0","1");
INSERT INTO links_niz_user VALUES("49","2","1","0","0","2");
INSERT INTO links_niz_user VALUES("50","3","1","0","0","3");
INSERT INTO links_niz_user VALUES("20","3","4","0","0","0");
INSERT INTO links_niz_user VALUES("52","4","9","0","0","1");
INSERT INTO links_niz_user VALUES("30","4","6","0","0","0");
INSERT INTO links_niz_user VALUES("29","3","6","0","0","0");
INSERT INTO links_niz_user VALUES("28","2","6","0","0","0");
INSERT INTO links_niz_user VALUES("27","1","6","0","0","0");
INSERT INTO links_niz_user VALUES("51","4","1","0","0","4");
INSERT INTO links_niz_user VALUES("55","1","13","0","0","1");
INSERT INTO links_niz_user VALUES("56","2","13","0","0","2");
INSERT INTO links_niz_user VALUES("57","3","13","0","0","3");
INSERT INTO links_niz_user VALUES("58","4","13","0","0","4");
INSERT INTO links_niz_user VALUES("59","1","15","0","0","1");
INSERT INTO links_niz_user VALUES("60","2","15","0","0","2");
INSERT INTO links_niz_user VALUES("61","3","15","0","0","3");
INSERT INTO links_niz_user VALUES("62","4","17","0","0","1");
INSERT INTO links_niz_user VALUES("63","3","17","0","0","2");
INSERT INTO links_niz_user VALUES("64","2","17","0","0","3");
INSERT INTO links_niz_user VALUES("65","1","17","0","0","4");



DROP TABLE IF EXISTS `mail`;

CREATE TABLE `mail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `id_kont` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `msg` varchar(1024) NOT NULL,
  `read` set('0','1') NOT NULL DEFAULT '0',
  `unlink` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `id_user` (`id_user`,`id_kont`),
  KEY `read` (`read`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `mail_to_send`;

CREATE TABLE `mail_to_send` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mail` varchar(64) NOT NULL,
  `them` varchar(32) NOT NULL,
  `msg` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `mark_files`;

CREATE TABLE `mark_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `id_file` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `time` (`time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `mark_foto`;

CREATE TABLE `mark_foto` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `id_foto` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `time` (`time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `mark_notes`;

CREATE TABLE `mark_notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `id_list` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `time` (`time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `mark_people`;

CREATE TABLE `mark_people` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `id_people` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `time` (`time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `media_info`;

CREATE TABLE `media_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file` varchar(64) NOT NULL,
  `size` int(11) NOT NULL,
  `lenght` varchar(32) NOT NULL,
  `bit` varchar(32) NOT NULL,
  `codec` varchar(32) NOT NULL,
  `wh` varchar(32) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `file` (`file`,`size`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `menu`;

CREATE TABLE `menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` enum('link','razd') NOT NULL DEFAULT 'link',
  `name` varchar(32) NOT NULL,
  `url` varchar(32) NOT NULL,
  `counter` varchar(32) NOT NULL,
  `pos` int(11) NOT NULL,
  `icon` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pos` (`pos`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COMMENT='Главное меню';

INSERT INTO menu VALUES("4","link","Гостевая","/guest/","guest/count.php","9","guest.png");
INSERT INTO menu VALUES("12","link","Знакомства","/user/dating/","/user/dating/count.php","3","meets.gif");
INSERT INTO menu VALUES("14","link","Обитатели","/user/users.php","/user/count.php","11","druzya.png");



DROP TABLE IF EXISTS `money`;

CREATE TABLE `money` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `msg` text NOT NULL,
  `money` int(11) NOT NULL,
  `minus_plus` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

INSERT INTO money VALUES("1","1","Отправлен подарок пользователю Nsk154.","30","0","1495359299");
INSERT INTO money VALUES("2","1","подключение иконки пользователя ","12","0","1495443846");
INSERT INTO money VALUES("3","1","Отправлен подарок пользователю Prime.","10","0","1495964941");
INSERT INTO money VALUES("4","1","Отправлен подарок пользователю Marines.","10","0","1496177219");
INSERT INTO money VALUES("5","1","подключение иконки пользователя ","5","0","1496177808");
INSERT INTO money VALUES("6","1","Отправлен подарок пользователю Roms.","10","0","1496695130");
INSERT INTO money VALUES("7","1","подключение иконки пользователя ","5","0","1496850306");
INSERT INTO money VALUES("8","1","Отправлен подарок пользователю xolod.","10","0","1497128887");
INSERT INTO money VALUES("9","1","Отправлен подарок пользователю test.","10","0","1497190012");



DROP TABLE IF EXISTS `my_guests`;

CREATE TABLE `my_guests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_ank` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `read` enum('0','1') NOT NULL DEFAULT '1',
  `count` int(11) NOT NULL DEFAULT '1',
  `time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=103 DEFAULT CHARSET=utf8;

INSERT INTO my_guests VALUES("1","2","1","1","1","1497049728");
INSERT INTO my_guests VALUES("9","5","1","0","1","1494661164");
INSERT INTO my_guests VALUES("4","3","4","1","1","1493359989");
INSERT INTO my_guests VALUES("52","8","4","0","1","1495421584");
INSERT INTO my_guests VALUES("27","2","6","1","1","1496432698");
INSERT INTO my_guests VALUES("30","7","1","1","1","1494408245");
INSERT INTO my_guests VALUES("31","2","7","1","1","1494267851");
INSERT INTO my_guests VALUES("32","3","7","1","1","1494318658");
INSERT INTO my_guests VALUES("53","7","4","1","1","1495421588");
INSERT INTO my_guests VALUES("34","3","1","1","1","1496954104");
INSERT INTO my_guests VALUES("35","7","6","1","1","1494424460");
INSERT INTO my_guests VALUES("37","8","1","1","1","1496954477");
INSERT INTO my_guests VALUES("43","9","1","0","1","1496268893");
INSERT INTO my_guests VALUES("44","9","4","0","1","1494854116");
INSERT INTO my_guests VALUES("45","8","6","1","1","1496331845");
INSERT INTO my_guests VALUES("49","10","6","1","1","1496397114");
INSERT INTO my_guests VALUES("57","2","9","1","1","1495458831");
INSERT INTO my_guests VALUES("64","11","4","1","1","1495707224");
INSERT INTO my_guests VALUES("71","12","1","1","1","1495964892");
INSERT INTO my_guests VALUES("84","4","13","1","1","1496670467");
INSERT INTO my_guests VALUES("87","1","14","0","1","1496935131");
INSERT INTO my_guests VALUES("76","13","6","0","1","1496175141");
INSERT INTO my_guests VALUES("77","13","1","1","1","1496953428");
INSERT INTO my_guests VALUES("78","13","4","0","1","1496313811");
INSERT INTO my_guests VALUES("79","2","13","1","1","1496670494");
INSERT INTO my_guests VALUES("81","4","1","1","1","1497125997");
INSERT INTO my_guests VALUES("82","6","1","0","1","1497005745");
INSERT INTO my_guests VALUES("86","14","1","0","1","1496950166");
INSERT INTO my_guests VALUES("88","14","6","0","1","1496695807");
INSERT INTO my_guests VALUES("89","2","14","1","1","1496696435");
INSERT INTO my_guests VALUES("90","1","2","0","1","1496753369");
INSERT INTO my_guests VALUES("91","6","14","0","1","1497034594");
INSERT INTO my_guests VALUES("92","1","13","0","1","1496860722");
INSERT INTO my_guests VALUES("93","10","1","1","1","1496953625");
INSERT INTO my_guests VALUES("94","11","1","1","1","1496954093");
INSERT INTO my_guests VALUES("95","15","1","0","1","1497127773");
INSERT INTO my_guests VALUES("96","1","15","0","1","1497171253");
INSERT INTO my_guests VALUES("97","4","15","1","1","1497128132");
INSERT INTO my_guests VALUES("98","7","15","1","1","1497128281");
INSERT INTO my_guests VALUES("99","2","15","1","1","1497171296");
INSERT INTO my_guests VALUES("100","1","16","0","1","1497168736");
INSERT INTO my_guests VALUES("101","17","1","1","1","1497189979");
INSERT INTO my_guests VALUES("102","9","17","1","1","1497191115");



DROP TABLE IF EXISTS `news`;

CREATE TABLE `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `msg` varchar(10024) DEFAULT NULL,
  `time` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `title` varchar(32) DEFAULT NULL,
  `main_time` int(11) NOT NULL DEFAULT '0',
  `link` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `time` (`time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `news_komm`;

CREATE TABLE `news_komm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `msg` varchar(1024) NOT NULL,
  `time` int(11) NOT NULL,
  `id_news` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `notes`;

CREATE TABLE `notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `msg` mediumtext,
  `time` int(11) NOT NULL,
  `name` varchar(32) DEFAULT NULL,
  `private` int(11) NOT NULL DEFAULT '0',
  `tags` varchar(64) NOT NULL,
  `id_user` int(11) DEFAULT '0',
  `private_komm` int(11) DEFAULT '0',
  `count` int(11) DEFAULT '0',
  `id_dir` int(11) DEFAULT '0',
  `type` int(1) DEFAULT '0',
  `adult` int(1) DEFAULT '0',
  `file_ves` int(11) NOT NULL DEFAULT '0',
  `file_raz` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `time` (`time`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

INSERT INTO notes VALUES("10","Отныне в школах будет новая система оценок, в место \\\"5\\\", \\\"4\\\", \\\"3\\\", \\\"2\\\", \\\"1\\\" будут баллы \\\"а\\\" \\\"B\\\", \\\"C\\\", \\\"D\\\", \\\"е\\\". Училка в начале урока: — ЕСЛИ ВЫ ПЛОХО НАПИШИТЕ ДИКТАНТ, ВЫ ВСЕ ПОЛУЧИТЕ ПО \\\"Е\\\" БАЛЛУ.\r\nУченик с задней парты: — УГРАЖАЕШЬ ЧТО-ЛИ?","1493974373","Анекдот)","0","","4","0","4","3","0","0","0","");
INSERT INTO notes VALUES("12","я помню эти чудные моменты, ночи, дни\r\nкак были мы счастливы с тобой,\r\nкогда мы ждали малыша,\r\nкак все у нас было прекрасно,\r\n\r\nкак грели обнимая мы друг-друга,\r\nи ночами трогая животик,\r\nгде зарождалась наша дочь,\r\nвсе эти дни были прелестны!\r\n\r\nкогда ложились спать вдвоем,\r\nложив я руку на животик,\r\nчтоб услышав нашу дочь,\r\nи как все это было чудно,\r\nмоменты, счастья, все вдвоем...\r\n\r\nи тут однажды мы расстались,\r\nзабрав мое ты счастье у меня,\r\nи как мне плохо было, тяжко,\r\nмучался ни день, ни два, ни три,\r\nА ведь и до сих пор\r\n\r\nведь ни поймет ни кто, как больно,\r\nтерять любимых нам людей, детей...\r\nи не дай бог, Вам, испытать такое чувство,\r\nпотери, горя, муки...\r\n\r\nБерегите своих родных, и близких\r\nВедь это счастье наше все, СЕМЬЯ!\r\n____\r\nПонимаю что не складно, но от души писал","1494782114","Я помню...(","0","","1","0","5","0","0","0","0","");
INSERT INTO notes VALUES("15","[b]Астматический: А... а...\r\nГеографический: Сюда, сюда...\r\nМатематический: Еще, еще!\r\nСпортивный: Быстрее! Еще, еще чуть быстрее...\r\nНаучно-исследовательский: Глу-у-убже...\r\nЗвериный — женщина вцепляется ногтями в спину и нечленораздельно рычит.\r\nАгрономический: Засади еще!\r\nПоложительный: 0 да!\r\nОтрицательный: 0!.. Нет... О!.. Нет...\r\nРелигиозный: О боже!\r\nНевменяемый — женщина вырывается с диким криком: « НЕ В МЕНЯ!!!»\r\nСуицидальный: Я сейчас умру!\r\nКриминальный: Ты меня убиваешь...\r\nУгрожающий: Если ты остановишься, я тебя убью! (Проверять искренность ее угроз не рекомендуется.)\r\nИнцестуальный: О, мама...\r\nВиртуальный: Маша [22:39:56] Кончаю... [/b] =)","1495017655","Виды оргазма))","0","","4","0","5","3","0","1","31165","jpg");
INSERT INTO notes VALUES("16","Отец когда-то рассказывал историю. Был на судне чрезвычайно активный замполит, решивший как-то раз устроить лекцию по ГО всему плавсоставу. После инструкций о том, как уворачиваться сухогрузу от ракет \\\"воздух-земля\\\", выпущенных истребителем, он задал вопрос то ли радисту, то ли механику: \r\n\r\n- Сто метров по носу вспышка ядерного взрыва. Ваши действия? \r\n- Подаю сигнал тревоги. \r\n- А дальше? \r\n- Стою, обугливаюсь. \r\n\r\nНа этом лекция завершилась, а замполит ушел на вечер в запой.","1495972613","Отец когда-то рассказывал..)","0","","4","0","4","3","0","0","0","");
INSERT INTO notes VALUES("18","Только я","1496431026","Только я","2","","1","0","1","0","0","1","0","");
INSERT INTO notes VALUES("19","Рассказала знакомая - гуляют они как-то с мужем и маленьким сыном (4 года) по лесу, остальная компания осталась около мангалов, а они вот решили прогуляться. Взрослые идут по тропиночке, что-то между собой переговариваются потихоньку, природой наслаждаются, а чадо бегает от пенька к ромашке, от земляничке к птичке и т.д. И тут ребенок остановился, как вкопанный, возле каких-то кустов. Ага, подумали родители, наверное белочку увидал. Подходят тихо, чтобы не спугнуть, и видят такую картину: за этими кустами совсем близко на опушке какая-то парочка занимается сексом. Причем в пылу страсти нечаянных зрителей они не заметили. \r\n\r\nПока родители думали, как бы незаметно ретироваться вместе с сыном (ведь просто так не уведешь от этих кустов - вопросы начнет задавать), мальчишка не растерялся и, набрав побольше воздуха, сказал: \r\n- Дядя! Дядя, а ты неправильно делаешь! \r\n\r\nСдавливая хохот, пацана подмышку и бегом обратно.","1496459966","Рассказала знакомая..)","0","","4","0","4","3","0","0","0","");
INSERT INTO notes VALUES("21","Тестируем блоги с файлами, ну и вывод сам!","1496586863","Тестируем с файлом","0","","1","0","5","0","0","0","131817","jpg");
INSERT INTO notes VALUES("22","В сети бурно обсуждают,как Президент России во время интервью одному из популярнейших американских телеканалов резко осадил журналистку Мегин Келли, обвинившей РФ в том, что якобы вмешивалась в избирательный процесс в США .\r\nКак сообщает \\\"Российский Диалог\\\", отвечая на это обвинение Владимир Путин подчеркнул, что в отличие от РФ, США всегда активно вмешивались в выборы во всех странах мира и правительства многих государств недовольны этим вмешательством, однако об этом никто почему-то никто не предпочитает вспоминать.\r\n\\\"Каждое действие имеет соответствующее противодействие\\\", — добавил Путин, подчеркнув, что лидеры Америки меняются, однако они продолжают традиционную политическую линию и по сути, в Кремле уж знают примерный политический курс Вашингтона.\r\nОтметим, что ранее Владимир Путин выступая на пленарном заедании ПМЭФ заявил, что не подкрепленные фактами обвинения РФ в выборы в Соединенных Штатах уже переросли в болтовню, которая является не только вредной, но и бесполезной.","1496651190","В сети бурно обсуждают,как Путин","0","","1","0","1","18","0","0","0","");
INSERT INTO notes VALUES("23","Талантливый бразильский художник Жоао Карвальо (João Carvalho) впервые дал знать о себе миру, когда ему было 15 лет. Тогда он впечатлил нас своими невероятными трёхмерными рисунками, сделанными в обычном блокноте.\r\n\r\nСейчас парню 17 лет, и его навыки рисования за это время усовершенствовались настолько, что работы Жоао не вызывают ничего, кроме возгласов восхищения! Взгляните!!","1496651459","Невероятные 3D-рисунки!","0","","1","0","4","10","0","0","31441","jpg");



DROP TABLE IF EXISTS `notes_count`;

CREATE TABLE `notes_count` (
  `id_notes` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  KEY `id_notes` (`id_notes`,`id_user`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO notes_count VALUES("10","1");
INSERT INTO notes_count VALUES("10","4");
INSERT INTO notes_count VALUES("10","6");
INSERT INTO notes_count VALUES("10","9");
INSERT INTO notes_count VALUES("12","1");
INSERT INTO notes_count VALUES("12","4");
INSERT INTO notes_count VALUES("12","9");
INSERT INTO notes_count VALUES("12","13");
INSERT INTO notes_count VALUES("12","14");
INSERT INTO notes_count VALUES("15","1");
INSERT INTO notes_count VALUES("15","4");
INSERT INTO notes_count VALUES("15","5");
INSERT INTO notes_count VALUES("15","6");
INSERT INTO notes_count VALUES("15","13");
INSERT INTO notes_count VALUES("16","1");
INSERT INTO notes_count VALUES("16","4");
INSERT INTO notes_count VALUES("16","5");
INSERT INTO notes_count VALUES("16","6");
INSERT INTO notes_count VALUES("18","1");
INSERT INTO notes_count VALUES("19","1");
INSERT INTO notes_count VALUES("19","4");
INSERT INTO notes_count VALUES("19","6");
INSERT INTO notes_count VALUES("19","13");
INSERT INTO notes_count VALUES("21","1");
INSERT INTO notes_count VALUES("21","6");
INSERT INTO notes_count VALUES("21","14");
INSERT INTO notes_count VALUES("21","15");
INSERT INTO notes_count VALUES("21","16");
INSERT INTO notes_count VALUES("22","1");
INSERT INTO notes_count VALUES("23","1");
INSERT INTO notes_count VALUES("23","14");
INSERT INTO notes_count VALUES("23","16");
INSERT INTO notes_count VALUES("23","17");



DROP TABLE IF EXISTS `notes_dir`;

CREATE TABLE `notes_dir` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `icon` varchar(30) DEFAULT 'default',
  `name` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

INSERT INTO notes_dir VALUES("1","newsi.png","Новости и Происшествия");
INSERT INTO notes_dir VALUES("2","game.png","Игры");
INSERT INTO notes_dir VALUES("3","humor.png","Юмор");
INSERT INTO notes_dir VALUES("4","programm.png","Гаджеты и Софт");
INSERT INTO notes_dir VALUES("5","internet.png","Информационные технологии");
INSERT INTO notes_dir VALUES("6","science.png","Наука и Hi-tech");
INSERT INTO notes_dir VALUES("7","auto.png","Авто и Мото");
INSERT INTO notes_dir VALUES("8","sport.png","Спорт");
INSERT INTO notes_dir VALUES("9","business.png","Экономика, Финансы, Бизнес");
INSERT INTO notes_dir VALUES("10","hobby.png","Развлечения и Хобби");
INSERT INTO notes_dir VALUES("11","cinema.png","Кино и ТВ");
INSERT INTO notes_dir VALUES("12","music.png","Музыка");
INSERT INTO notes_dir VALUES("13","design.png","Искусство и Дизайн");
INSERT INTO notes_dir VALUES("14","book.png","Литература и Творчество");
INSERT INTO notes_dir VALUES("15","history.png","История");
INSERT INTO notes_dir VALUES("16","philosophy.png","Философия и Религия");
INSERT INTO notes_dir VALUES("17","relationship.png","Психология и Отношения");
INSERT INTO notes_dir VALUES("18","politic.png","Политика и Общество");
INSERT INTO notes_dir VALUES("19","education.png","Образование и Карьера");
INSERT INTO notes_dir VALUES("20","myhouse.png","Свой дом, Строительство, Ремонт");
INSERT INTO notes_dir VALUES("21","animal.png","Животные");
INSERT INTO notes_dir VALUES("22","cook.png","Кулинария");
INSERT INTO notes_dir VALUES("23","style.png","Мода и Стиль");
INSERT INTO notes_dir VALUES("24","health.png","Здоровье и Фитнес");
INSERT INTO notes_dir VALUES("25","putesestviya.png","Путешествия и Туризм");
INSERT INTO notes_dir VALUES("26","xmyxru.png","Xmyx.Ru");
INSERT INTO notes_dir VALUES("27","default.png","Разные каналы");



DROP TABLE IF EXISTS `notes_komm`;

CREATE TABLE `notes_komm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `id_notes` varchar(50) NOT NULL,
  `msg` varchar(1024) NOT NULL,
  `time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

INSERT INTO notes_komm VALUES("23","1","23","Круто!","1496669878");



DROP TABLE IF EXISTS `notes_like`;

CREATE TABLE `notes_like` (
  `id_notes` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `like` int(11) DEFAULT '0',
  KEY `id_notes` (`id_notes`,`id_user`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO notes_like VALUES("1","1","1");
INSERT INTO notes_like VALUES("8","4","1");
INSERT INTO notes_like VALUES("10","1","1");
INSERT INTO notes_like VALUES("12","4","1");
INSERT INTO notes_like VALUES("15","1","1");
INSERT INTO notes_like VALUES("12","13","0");
INSERT INTO notes_like VALUES("16","1","1");
INSERT INTO notes_like VALUES("19","6","1");
INSERT INTO notes_like VALUES("21","15","1");
INSERT INTO notes_like VALUES("23","17","1");



DROP TABLE IF EXISTS `notification`;

CREATE TABLE `notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `id_object` int(11) NOT NULL,
  `type` varchar(11) NOT NULL,
  `avtor` int(11) DEFAULT NULL,
  `all_type` varchar(11) DEFAULT NULL,
  `read` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

INSERT INTO notification VALUES("1","2","1484564647","1","otm_frend","1","","1");
INSERT INTO notification VALUES("2","1","1493285978","2","ok_frend","2","","1");
INSERT INTO notification VALUES("4","4","1493902141","1","ok_frend","1","","1");
INSERT INTO notification VALUES("5","2","1493902310","1","del_frend","1","","1");
INSERT INTO notification VALUES("6","2","1493902451","1","ok_frend","1","","1");
INSERT INTO notification VALUES("7","2","1493902724","1","del_frend","1","","1");
INSERT INTO notification VALUES("8","1","1493902859","2","ok_frend","2","","1");
INSERT INTO notification VALUES("9","2","1493902926","1","del_frend","1","","1");
INSERT INTO notification VALUES("10","1","1493902956","2","ok_frend","2","","1");
INSERT INTO notification VALUES("11","4","1493903169","1","del_frend","1","","1");
INSERT INTO notification VALUES("12","4","1493903342","1","del_frend","1","","1");
INSERT INTO notification VALUES("13","2","1494064485","1","otm_frend","1","","1");
INSERT INTO notification VALUES("14","2","1494064490","1","otm_frend","1","","1");
INSERT INTO notification VALUES("15","2","1494064498","1","otm_frend","1","","1");
INSERT INTO notification VALUES("16","4","1495003631","14","notes_komm","1","","1");
INSERT INTO notification VALUES("17","1","1495003827","14","notes_komm","4","","1");
INSERT INTO notification VALUES("18","4","1495003912","14","notes_komm","1","","1");
INSERT INTO notification VALUES("19","1","1495003993","14","notes_komm","4","","1");
INSERT INTO notification VALUES("20","4","1495004170","14","notes_komm","1","","1");
INSERT INTO notification VALUES("21","1","1495004510","14","notes_komm","4","","1");
INSERT INTO notification VALUES("22","4","1495004639","14","notes_komm","1","","1");
INSERT INTO notification VALUES("23","1","1495004708","14","notes_komm","4","","1");



DROP TABLE IF EXISTS `notification_set`;

CREATE TABLE `notification_set` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `komm` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

INSERT INTO notification_set VALUES("1","1","1");
INSERT INTO notification_set VALUES("2","2","1");
INSERT INTO notification_set VALUES("3","3","1");
INSERT INTO notification_set VALUES("4","4","1");
INSERT INTO notification_set VALUES("5","5","1");
INSERT INTO notification_set VALUES("6","6","1");
INSERT INTO notification_set VALUES("7","7","1");
INSERT INTO notification_set VALUES("8","8","1");
INSERT INTO notification_set VALUES("9","9","1");
INSERT INTO notification_set VALUES("10","10","1");
INSERT INTO notification_set VALUES("11","11","1");
INSERT INTO notification_set VALUES("12","12","1");
INSERT INTO notification_set VALUES("13","13","1");
INSERT INTO notification_set VALUES("14","14","1");
INSERT INTO notification_set VALUES("15","15","1");
INSERT INTO notification_set VALUES("16","16","1");
INSERT INTO notification_set VALUES("17","17","1");



DROP TABLE IF EXISTS `obmennik_dir`;

CREATE TABLE `obmennik_dir` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `num` int(11) DEFAULT '0',
  `name` varchar(64) NOT NULL,
  `ras` varchar(512) NOT NULL,
  `maxfilesize` int(11) NOT NULL,
  `dir` varchar(512) NOT NULL DEFAULT '/',
  `dir_osn` varchar(512) DEFAULT '/',
  `upload` set('1','0') NOT NULL DEFAULT '0',
  `my` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `num` (`num`),
  KEY `dir` (`dir`(333))
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO obmennik_dir VALUES("1","0","Личные файлы","wmv;zip;rar;tar;avi;3gp;mp4;mp3;amr;txt;cab;thm;sdt;nth;mtf;col;scs;utz;gif;jpg;jpeg;bmp;png;wbmp;pic;ani;pco;mmf;mid;amr;mp3;wav;aac;seq;vox;dxm;imy;emy;pmd;rng;doc;docx;swf;tsk;apk;sis;sisx;jar","33554432","/Lichnye_fajly/","/","1","1");



DROP TABLE IF EXISTS `obmennik_files`;

CREATE TABLE `obmennik_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `id_dir` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `ras` varchar(36) NOT NULL,
  `type` varchar(64) NOT NULL,
  `time` int(11) NOT NULL,
  `time_last` int(11) NOT NULL,
  `size` int(11) NOT NULL,
  `k_loads` int(11) DEFAULT '0',
  `time_go` int(11) DEFAULT '0',
  `opis` text NOT NULL,
  `my_dir` int(11) DEFAULT '0',
  `metka` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `obmennik_komm`;

CREATE TABLE `obmennik_komm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_file` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `msg` varchar(1024) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_file` (`id_file`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `opsos`;

CREATE TABLE `opsos` (
  `min` bigint(11) DEFAULT NULL,
  `max` bigint(11) DEFAULT NULL,
  `opsos` varchar(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  KEY `min` (`min`,`max`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO opsos VALUES("3274702592","3274702847","Kcel");
INSERT INTO opsos VALUES("1333559296","1333575679","life:)");
INSERT INTO opsos VALUES("-734354944","-734354433","life:)");
INSERT INTO opsos VALUES("3582431104","3582434943","TambovGSM");
INSERT INTO opsos VALUES("1358905344","1358905471","UMC");
INSERT INTO opsos VALUES("1490444288","1490452479","UMC");
INSERT INTO opsos VALUES("1490436096","1490444287","UMC");
INSERT INTO opsos VALUES("3588472832","3588489215","WellCOM GSM");
INSERT INTO opsos VALUES("3253698560","3253699071","WellCOM GSM");
INSERT INTO opsos VALUES("3557661440","3557661695","КаР-Тел");
INSERT INTO opsos VALUES("3240705024","3240706047","Киевстар");
INSERT INTO opsos VALUES("1360467968","1360470015","Киевстар");
INSERT INTO opsos VALUES("1360465920","1360467967","Киевстар");
INSERT INTO opsos VALUES("1402278912","1402279935","МегаФон");
INSERT INTO opsos VALUES("1402286080","1402287103","МегаФон");
INSERT INTO opsos VALUES("1402273792","1402275839","MegaFon");
INSERT INTO opsos VALUES("3650368512","3650368767","МОТИВ");
INSERT INTO opsos VALUES("1410459648","1410460159","МТС");
INSERT INTO opsos VALUES("3641237504","3641241599","МТС");
INSERT INTO opsos VALUES("3276428288","3276428543","МТС");
INSERT INTO opsos VALUES("3258356736","3258357759","МТС");
INSERT INTO opsos VALUES("3562834880","3562834943","МТС");
INSERT INTO opsos VALUES("3579259392","3579265535","МТС");
INSERT INTO opsos VALUES("1347674112","1347678207","МТС");
INSERT INTO opsos VALUES("3579267072","3579267935","МТС");
INSERT INTO opsos VALUES("1358906880","1358907135","МТС");
INSERT INTO opsos VALUES("1476194816","1476195071","МТС");
INSERT INTO opsos VALUES("1372794624","1372794879","МТС");
INSERT INTO opsos VALUES("3642047744","3642047999","МТС");
INSERT INTO opsos VALUES("3579269120","3579273215","МТС");
INSERT INTO opsos VALUES("3277188608","3277188863","МТС");
INSERT INTO opsos VALUES("3645018112","3645019135","МТС");
INSERT INTO opsos VALUES("1347126528","1347127167","МТС");
INSERT INTO opsos VALUES("3281465344","3281465599","МТС");
INSERT INTO opsos VALUES("1360933376","1360933887","МТС");
INSERT INTO opsos VALUES("3647698432","3647698687","МТС");
INSERT INTO opsos VALUES("3267023360","3267023488","МТС");
INSERT INTO opsos VALUES("1535627776","1535628031","МТС");
INSERT INTO opsos VALUES("1410457600","1410459647","МТС");
INSERT INTO opsos VALUES("1433788416","1433788671","МТС");
INSERT INTO opsos VALUES("1389383040","1389383167","НСС");
INSERT INTO opsos VALUES("1358122240","1358123007","НТК");
INSERT INTO opsos VALUES("1358118912","1358119423","НТК");
INSERT INTO opsos VALUES("1438682304","1438682335","Оренбург-GSM");
INSERT INTO opsos VALUES("1509752832","1509756927","Скай Линк");
INSERT INTO opsos VALUES("3565250560","3565254655","Скай Линк");
INSERT INTO opsos VALUES("1536507904","1536516095","Скай Линк");
INSERT INTO opsos VALUES("1536516096","1536518143","Скай Линк");
INSERT INTO opsos VALUES("3578853376","3578854079","Скай Линк");
INSERT INTO opsos VALUES("1406738432","1406739967","Скай Линк");
INSERT INTO opsos VALUES("3266342656","3266342911","Скай Мобайл");
INSERT INTO opsos VALUES("1346736128","1346737151","СМАРТС");
INSERT INTO opsos VALUES("3260286336","3260286463","СМАРТС");
INSERT INTO opsos VALUES("1509527552","1509528575","СТеК Джи Эс Эм");
INSERT INTO opsos VALUES("1506762752","1506764799","ТАТИНКОМ-Т");
INSERT INTO opsos VALUES("1404203008","1404211199","Теле2");
INSERT INTO opsos VALUES("3580231936","3580232191","Теле2");
INSERT INTO opsos VALUES("1404215296","1404219391","Теле2");
INSERT INTO opsos VALUES("1404874752","1404875775","Теле2");
INSERT INTO opsos VALUES("1404189184","1404189695","Теле2");
INSERT INTO opsos VALUES("1404829696","1404837887","Теле2");
INSERT INTO opsos VALUES("3580236800","3580237567","Теле2");
INSERT INTO opsos VALUES("3580235264","3580235775","Теле2");
INSERT INTO opsos VALUES("1404837888","1404846079","Теле2");
INSERT INTO opsos VALUES("3580214272","3580214783","Теле2");
INSERT INTO opsos VALUES("1404227584","1404232191","Теле2");
INSERT INTO opsos VALUES("3580232448","3580233215","Теле2");
INSERT INTO opsos VALUES("3580239360","3580239871","Теле2");
INSERT INTO opsos VALUES("3580231680","3580231935","Теле2");
INSERT INTO opsos VALUES("1441366016","1441371903","Utel");
INSERT INTO opsos VALUES("1401450496","1401450751","Utel");
INSERT INTO opsos VALUES("1506570240","1506574335","Utel");
INSERT INTO opsos VALUES("3571187712","3571191807","Utel");
INSERT INTO opsos VALUES("3564676832","3564676863","Utel");
INSERT INTO opsos VALUES("1494507776","1494508031","Utel");
INSERT INTO opsos VALUES("3641816064","3641816319","Utel");
INSERT INTO opsos VALUES("3651755008","3651756031","Цифровая экспансия");
INSERT INTO opsos VALUES("2130706433","2130706433","localhost");
INSERT INTO opsos VALUES("3283979853","3283979853","Opera Mini");
INSERT INTO opsos VALUES("1412413440","1412413951","Наука-Связь");
INSERT INTO opsos VALUES("1518993408","1519058943","Теле2");
INSERT INTO opsos VALUES("1410269184","1410334719","Bite GSM");
INSERT INTO opsos VALUES("1407907840","1407908351","Ульяновск-GSM");
INSERT INTO opsos VALUES("2197028864","2197094399","Теле2");
INSERT INTO opsos VALUES("3274702592","3274702847","Kcel");
INSERT INTO opsos VALUES("-734351360","-734347265","life:)");
INSERT INTO opsos VALUES("-734353408","-734351361","life:)");
INSERT INTO opsos VALUES("3582431104","3582434943","TambovGSM");
INSERT INTO opsos VALUES("1358905344","1358905471","UMC");
INSERT INTO opsos VALUES("1490444288","1490452479","UMC");
INSERT INTO opsos VALUES("1490436096","1490444287","UMC");
INSERT INTO opsos VALUES("3588472832","3588489215","WellCOM GSM");
INSERT INTO opsos VALUES("3253698560","3253699071","WellCOM GSM");
INSERT INTO opsos VALUES("3557661440","3557661695","КаР-Тел");
INSERT INTO opsos VALUES("3240705024","3240706047","Киевстар");
INSERT INTO opsos VALUES("1360467968","1360470015","Киевстар");
INSERT INTO opsos VALUES("1360465920","1360467967","Киевстар");
INSERT INTO opsos VALUES("1402275840","1402276863","МегаФон");
INSERT INTO opsos VALUES("1402278912","1402279935","МегаФон");
INSERT INTO opsos VALUES("1402286080","1402287103","МегаФон");
INSERT INTO opsos VALUES("1402273792","1402275839","МегаФон");
INSERT INTO opsos VALUES("1346621440","1346622463","МегаФон");
INSERT INTO opsos VALUES("3251233792","3251234815","МегаФон");
INSERT INTO opsos VALUES("1402284032","1402285055","МегаФон");
INSERT INTO opsos VALUES("1402281984","1402283007","МегаФон");
INSERT INTO opsos VALUES("1402287104","1402288127","МегаФон");
INSERT INTO opsos VALUES("1402279936","1402280959","МегаФон");
INSERT INTO opsos VALUES("1402277888","1402278911","МегаФон");
INSERT INTO opsos VALUES("3650368512","3650368767","МОТИВ");
INSERT INTO opsos VALUES("1410459648","1410460159","МТС");
INSERT INTO opsos VALUES("3641237504","3641241599","МТС");
INSERT INTO opsos VALUES("3276428288","3276428543","МТС");
INSERT INTO opsos VALUES("3258356736","3258357759","МТС");
INSERT INTO opsos VALUES("3562834880","3562834943","МТС");
INSERT INTO opsos VALUES("3579259392","3579265535","МТС");
INSERT INTO opsos VALUES("1347674112","1347678207","МТС");
INSERT INTO opsos VALUES("3579267072","3579267935","МТС");
INSERT INTO opsos VALUES("1358906880","1358907135","МТС");
INSERT INTO opsos VALUES("1476194816","1476195071","МТС");
INSERT INTO opsos VALUES("1372794624","1372794879","МТС");
INSERT INTO opsos VALUES("3642047744","3642047999","МТС");
INSERT INTO opsos VALUES("3579269120","3579273215","МТС");
INSERT INTO opsos VALUES("3277188608","3277188863","МТС");
INSERT INTO opsos VALUES("3645018112","3645019135","МТС");
INSERT INTO opsos VALUES("1347126528","1347127167","МТС");
INSERT INTO opsos VALUES("3281465344","3281465599","МТС");
INSERT INTO opsos VALUES("1360933376","1360933887","МТС");
INSERT INTO opsos VALUES("3647698432","3647698687","МТС");
INSERT INTO opsos VALUES("3267023360","3267023488","МТС");
INSERT INTO opsos VALUES("3645566976","3645569023","МТС");
INSERT INTO opsos VALUES("1535627776","1535628031","МТС");
INSERT INTO opsos VALUES("1410457600","1410459647","МТС");
INSERT INTO opsos VALUES("1433788416","1433788671","МТС");
INSERT INTO opsos VALUES("1389383040","1389383167","НСС");
INSERT INTO opsos VALUES("1358122240","1358123007","НТК");
INSERT INTO opsos VALUES("1358118912","1358119423","НТК");
INSERT INTO opsos VALUES("1438682304","1438682335","Оренбург-GSM");
INSERT INTO opsos VALUES("1509752832","1509756927","Скай Линк");
INSERT INTO opsos VALUES("3565250560","3565254655","Скай Линк");
INSERT INTO opsos VALUES("1536507904","1536516095","Скай Линк");
INSERT INTO opsos VALUES("1536516096","1536518143","Скай Линк");
INSERT INTO opsos VALUES("3578853376","3578854079","Скай Линк");
INSERT INTO opsos VALUES("1406738432","1406739967","Скай Линк");
INSERT INTO opsos VALUES("3266342656","3266342911","Скай Мобайл");
INSERT INTO opsos VALUES("1346736128","1346737151","СМАРТС");
INSERT INTO opsos VALUES("3260286336","3260286463","СМАРТС");
INSERT INTO opsos VALUES("1509527552","1509528575","СТеК Джи Эс Эм");
INSERT INTO opsos VALUES("1506762752","1506764799","ТАТИНКОМ-Т");
INSERT INTO opsos VALUES("1404203008","1404211199","Теле2");
INSERT INTO opsos VALUES("3580231936","3580232191","Теле2");
INSERT INTO opsos VALUES("1404215296","1404219391","Теле2");
INSERT INTO opsos VALUES("1404874752","1404875775","Теле2");
INSERT INTO opsos VALUES("1404189184","1404189695","Теле2");
INSERT INTO opsos VALUES("1404829696","1404837887","Теле2");
INSERT INTO opsos VALUES("3580236800","3580237567","Теле2");
INSERT INTO opsos VALUES("3580235264","3580235775","Теле2");
INSERT INTO opsos VALUES("1404837888","1404846079","Теле2");
INSERT INTO opsos VALUES("3580214272","3580214783","Теле2");
INSERT INTO opsos VALUES("1404227584","1404232191","Теле2");
INSERT INTO opsos VALUES("3580232448","3580233215","Теле2");
INSERT INTO opsos VALUES("3580239360","3580239871","Теле2");
INSERT INTO opsos VALUES("3580231680","3580231935","Теле2");
INSERT INTO opsos VALUES("1441366016","1441371903","Utel");
INSERT INTO opsos VALUES("1401450496","1401450751","Utel");
INSERT INTO opsos VALUES("1506570240","1506574335","Utel");
INSERT INTO opsos VALUES("3571187712","3571191807","Utel");
INSERT INTO opsos VALUES("3564676832","3564676863","Utel");
INSERT INTO opsos VALUES("1494507776","1494508031","Utel");
INSERT INTO opsos VALUES("3641816064","3641816319","Utel");
INSERT INTO opsos VALUES("3651755008","3651756031","Цифровая экспансия");
INSERT INTO opsos VALUES("2130706433","2130706433","localhost");
INSERT INTO opsos VALUES("3283979853","3283979853","Opera Mini");
INSERT INTO opsos VALUES("1412413440","1412413951","Наука-Связь");
INSERT INTO opsos VALUES("3588390912","3588391935","Bite GSM");
INSERT INTO opsos VALUES("1518993408","1519058943","Теле2");
INSERT INTO opsos VALUES("1410269184","1410334719","Bite GSM");
INSERT INTO opsos VALUES("1407907840","1407908351","Ульяновск-GSM");
INSERT INTO opsos VALUES("2197028864","2197094399","Теле2");
INSERT INTO opsos VALUES("-646557696","-646556673","Beeline");
INSERT INTO opsos VALUES("3274702592","3274702847","K cel");
INSERT INTO opsos VALUES("-712536192","-712532353","TambovGSM");
INSERT INTO opsos VALUES("1333575680","1333592063","life:)");
INSERT INTO opsos VALUES("-734355456","-734355201","life:)");
INSERT INTO opsos VALUES("1536278528","1536294911","Life:)");
INSERT INTO opsos VALUES("3582431104","3582434943","TambovGSM");
INSERT INTO opsos VALUES("1358905344","1358905471","UMC");
INSERT INTO opsos VALUES("1490444288","1490452479","UMC");
INSERT INTO opsos VALUES("1490436096","1490444287","UMC");
INSERT INTO opsos VALUES("3588472832","3588489215","WellCOM GSM");
INSERT INTO opsos VALUES("3253698560","3253699071","WellCOM GSM");
INSERT INTO opsos VALUES("1519796224","1519800319","Уралсвязьинформ");
INSERT INTO opsos VALUES("1388849152","1388850175","ИНДИГО");
INSERT INTO opsos VALUES("1427948288","1427948543","Дальсвязь");
INSERT INTO opsos VALUES("1385632000","1385632255","БашСЕЛ");
INSERT INTO opsos VALUES("3273026560","3273027583","БашСЕЛ");
INSERT INTO opsos VALUES("1347599104","1347599359","Байкалвестком");
INSERT INTO opsos VALUES("1360162816","1360166911","Байкалвестком");
INSERT INTO opsos VALUES("1360163840","1360164351","Байкалвестком");
INSERT INTO opsos VALUES("3588519936","3588520447","Байкалвестком");
INSERT INTO opsos VALUES("1407888896","1407889151","Байкалвестком");
INSERT INTO opsos VALUES("3564188672","3564188927","Utel");
INSERT INTO opsos VALUES("3564189696","3564191743","Utel");
INSERT INTO opsos VALUES("1441366016","1441371903","Utel");
INSERT INTO opsos VALUES("1401450496","1401450751","Utel");
INSERT INTO opsos VALUES("1506570240","1506574335","Utel");
INSERT INTO opsos VALUES("3571187712","3571191807","Utel");
INSERT INTO opsos VALUES("3564676832","3564676863","Utel");
INSERT INTO opsos VALUES("1494507776","1494508031","Utel");
INSERT INTO opsos VALUES("3641816064","3641816319","Utel");
INSERT INTO opsos VALUES("3564189440","3564189695","Utel");
INSERT INTO opsos VALUES("2130706433","2130706433","localhost");
INSERT INTO opsos VALUES("3283979853","3283979853","Opera Mini");
INSERT INTO opsos VALUES("3588390912","3588391935","Bite GSM");
INSERT INTO opsos VALUES("3585764352","3585764607","Utel");
INSERT INTO opsos VALUES("1410269184","1410334719","Bite GSM");
INSERT INTO opsos VALUES("3564189184","3564189439","Utel");
INSERT INTO opsos VALUES("3582031776","3582031807","Мегафон");
INSERT INTO opsos VALUES("1427812352","1427813375","Мегафон");
INSERT INTO opsos VALUES("1433657344","1433657599","Билайн");
INSERT INTO opsos VALUES("3648405504","3648406527","Билайн");
INSERT INTO opsos VALUES("3648406528","3648407551","Билайн");
INSERT INTO opsos VALUES("3648408576","3648409599","Билайн");
INSERT INTO opsos VALUES("3648409600","3648410623","Билайн");
INSERT INTO opsos VALUES("3648410624","3648411647","Билайн");
INSERT INTO opsos VALUES("3648411648","3648412671","Билайн");
INSERT INTO opsos VALUES("3648412672","3648413695","Билайн");
INSERT INTO opsos VALUES("1047070464","1047072255","Utel");
INSERT INTO opsos VALUES("1401451520","1401451775","Utel");
INSERT INTO opsos VALUES("1425981440","1425997823","Utel");
INSERT INTO opsos VALUES("3272364544","3272364799","Utel");
INSERT INTO opsos VALUES("3564675072","3564675583","Utel");
INSERT INTO opsos VALUES("3641816576","3641816831","Utel");
INSERT INTO opsos VALUES("1519779840","1519910911","Utel");
INSERT INTO opsos VALUES("3274599168","3274599423","БайкалВестКом");
INSERT INTO opsos VALUES("1042394624","1042394879","МТС");
INSERT INTO opsos VALUES("1346950400","1346950655","МТС");
INSERT INTO opsos VALUES("3281453056","3281518591","МТС");
INSERT INTO opsos VALUES("3287259392","3287259647","МТС");
INSERT INTO opsos VALUES("3559689216","3559689471","МТС");
INSERT INTO opsos VALUES("3562834688","3562834879","МТС");
INSERT INTO opsos VALUES("3578831872","3578832127","МТС");
INSERT INTO opsos VALUES("3648478720","3648479231","МТС");
INSERT INTO opsos VALUES("3579268096","3579268607","МТС");
INSERT INTO opsos VALUES("1404862464","1404870655","Tele2");
INSERT INTO opsos VALUES("1404846080","1404854271","Tele2");
INSERT INTO opsos VALUES("1404854272","1404862463","Tele2");
INSERT INTO opsos VALUES("1518927872","1518944255","Tele2");
INSERT INTO opsos VALUES("3650367488","3650368511","Мотив");
INSERT INTO opsos VALUES("3278955480","3278955515","ЕТК");
INSERT INTO opsos VALUES("3278956288","3278956543","ЕТК");
INSERT INTO opsos VALUES("3278960128","3278960383","ЕТК");
INSERT INTO opsos VALUES("1432330240","1432334335","НСС");
INSERT INTO opsos VALUES("3282161664","3282163711","НСС");
INSERT INTO opsos VALUES("3282171904","3282173951","НСС");
INSERT INTO opsos VALUES("3585171456","3585174271","НСС");
INSERT INTO opsos VALUES("3267008512","3267008767","НСС");
INSERT INTO opsos VALUES("3277992448","3277992959","НСС");
INSERT INTO opsos VALUES("1441609984","1441610239","НСС");
INSERT INTO opsos VALUES("3645731072","3645731079","Смартс");
INSERT INTO opsos VALUES("1310210048","1310211071","Смартс");
INSERT INTO opsos VALUES("1536099328","1536099839","Смартс");
INSERT INTO opsos VALUES("3587219456","3587219711","Смартс");
INSERT INTO opsos VALUES("3648294912","3648295935","Stek GSM");
INSERT INTO opsos VALUES("1481787392","1481787647","Татинком-Т");
INSERT INTO opsos VALUES("3652001536","3652001599","Татинком-Т");
INSERT INTO opsos VALUES("1052193280","1052193535","MTT");
INSERT INTO opsos VALUES("1347125248","1347125759","MTT");
INSERT INTO opsos VALUES("1358119424","1358120703","НТК");
INSERT INTO opsos VALUES("1406740480","1406746623","Sky Link");
INSERT INTO opsos VALUES("3564593152","3564593919","Sky Link");
INSERT INTO opsos VALUES("3564595968","3564596735","Sky Link");
INSERT INTO opsos VALUES("3564599808","3564601343","Sky Link");
INSERT INTO opsos VALUES("3565248512","3565250047","Sky Link");
INSERT INTO opsos VALUES("3565250048","3565250559","Sky Link");
INSERT INTO opsos VALUES("3648212992","3648217087","Sky Link");
INSERT INTO opsos VALUES("1386348544","1386414079","Акос");
INSERT INTO opsos VALUES("1566410752","1566411775","Ульяновск GSM");
INSERT INTO opsos VALUES("3651751936","3651752191","Цифровая экспансия");
INSERT INTO opsos VALUES("3651752192","3651752447","Цифровая экспансия");
INSERT INTO opsos VALUES("3287244288","3287244543","Индиго");
INSERT INTO opsos VALUES("3560612864","3560613887","Киевстар");
INSERT INTO opsos VALUES("1486487552","1486553087","Киевстар");
INSERT INTO opsos VALUES("1295253504","1295319039","UMC");
INSERT INTO opsos VALUES("1358907392","1358907647","UMC");
INSERT INTO opsos VALUES("1358907648","1358907903","UMC");
INSERT INTO opsos VALUES("1358907904","1358908031","UMC");
INSERT INTO opsos VALUES("1358908160","1358908415","UMC");
INSERT INTO opsos VALUES("1358908416","1358908671","UMC");
INSERT INTO opsos VALUES("1358908672","1358908927","UMC");
INSERT INTO opsos VALUES("1358908928","1358909183","UMC");
INSERT INTO opsos VALUES("1358909184","1358909439","UMC");
INSERT INTO opsos VALUES("2516451328","2516516863","T-Mobile");
INSERT INTO opsos VALUES("3562889472","3562889727","LMT");
INSERT INTO opsos VALUES("3651710976","3651715071","AzerCellTelecom");
INSERT INTO opsos VALUES("1365222400","1365223423","Ge-Magticom");
INSERT INTO opsos VALUES("3645744128","3645744639","Vodafon");
INSERT INTO opsos VALUES("3584180736","3584180991","T-Mobile");
INSERT INTO opsos VALUES("1358192896","1358193151","Vodafon");
INSERT INTO opsos VALUES("1507835904","1507852287","Vodafon");
INSERT INTO opsos VALUES("1507819520","1507827711","Vodafon");
INSERT INTO opsos VALUES("1507827712","1507835903","Vodafon");
INSERT INTO opsos VALUES("1536655360","1536659455","Geocell");
INSERT INTO opsos VALUES("3253712384","3253712895","Voxtel");
INSERT INTO opsos VALUES("3560144384","3560144639","Mobtel");
INSERT INTO opsos VALUES("3644964864","3644965479","T-Mobile");
INSERT INTO opsos VALUES("1054471936","1054472191","Orange");
INSERT INTO opsos VALUES("3275173632","3275173695","TME");
INSERT INTO opsos VALUES("1404190720","1404198911","Tele2");
INSERT INTO opsos VALUES("3583496320","3583496447","Orange");
INSERT INTO opsos VALUES("3266322432","3266322687","Omnitel");
INSERT INTO opsos VALUES("1407033600","1407033855","Unitel");
INSERT INTO opsos VALUES("3568795648","3568799999","Vodafon");
INSERT INTO opsos VALUES("1407188992","1407210495","Vodafon");
INSERT INTO opsos VALUES("3645317120","3645318015","EMT");
INSERT INTO opsos VALUES("3240329216","3240333311","Orange");
INSERT INTO opsos VALUES("3254619392","3254619647","Orange");
INSERT INTO opsos VALUES("1358598144","1358600191","Cellcom");
INSERT INTO opsos VALUES("1296285696","1296302079","Tcell");
INSERT INTO opsos VALUES("3576365056","3576397823","Tcell");
INSERT INTO opsos VALUES("1449959424","1449967615","Tcell");
INSERT INTO opsos VALUES("1336598528","1336599521","Mordcell");
INSERT INTO opsos VALUES("3566895360","3566895615","МТС");
INSERT INTO opsos VALUES("3279123456","3279124479","SRR");
INSERT INTO opsos VALUES("3652165632","3652167167","OutRemer");
INSERT INTO opsos VALUES("3283979776","3283980287","Opera Mini");
INSERT INTO opsos VALUES("3242554368","3242554495","Opera Mini");
INSERT INTO opsos VALUES("1357411584","1357411839","Opera Mini");
INSERT INTO opsos VALUES("1540055040","1540056063","Opera Mini");
INSERT INTO opsos VALUES("1593212416","1593212927","Opera Mini");
INSERT INTO opsos VALUES("-1010987520","-1010987009","Opera Mini");
INSERT INTO opsos VALUES("-646555136","-646554369","Вымпелком");
INSERT INTO opsos VALUES("-646554368","-646553857","Вымпелком WiFi");



DROP TABLE IF EXISTS `reg_mail`;

CREATE TABLE `reg_mail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `mail` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mail` (`mail`),
  KEY `id_user` (`id_user`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `rekl`;

CREATE TABLE `rekl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `img` varchar(64) NOT NULL,
  `link` varchar(64) NOT NULL,
  `time_last` int(11) NOT NULL,
  `sel` set('1','2','3','4') NOT NULL DEFAULT '1',
  `count` int(11) NOT NULL DEFAULT '0',
  `dop_str` set('0','1') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `sel` (`sel`),
  KEY `time_last` (`time_last`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `rules`;

CREATE TABLE `rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `msg` mediumtext,
  `time` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `title` varchar(60) DEFAULT NULL,
  `url` varchar(999) DEFAULT NULL,
  `name_url` varchar(52) DEFAULT NULL,
  `pos` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `time` (`time`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO rules VALUES("1","","1495574015","1","Правила безопасности","","","1");



DROP TABLE IF EXISTS `rules_p`;

CREATE TABLE `rules_p` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `msg` mediumtext NOT NULL,
  `time` int(11) NOT NULL,
  `id_news` int(11) NOT NULL,
  `pos` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO rules_p VALUES("1","1","[b]Сделайте себе нормальный пароль.[/b]\r\nКакие пароли легко подобрать:\r\n- Любые наборы цифр (26739, 2478904, ...)\r\n- Даты рождения (010680, 120495...)\r\n- Номера телефонов\r\n- Имена людей и клички домашних животных.\r\nЕсли Вы делаете себе такой пароль, считайте, что ваш ник уже не ваш.\r\nНормальный пароль должен содержать не менее 8 символов и состоять из набора букв и цифр.\r\nЕсли Вы используете в качестве пароля номер телефона, то добавьте к нему хотя бы пару букв. Это значительно усложнит подбор вашего пароля.\r\nВот примеры хороших паролей: sUti42Dd, 7u8YY59, L0161Aoo\r\nЧтобы пароль было легче запомнить, можете заменять некоторые буквы в слове цифрами.\r\nНапример: k0le5oOO, 90LoVast1k и т.п.\r\nИзменить пароль Вы можете прямо сейчас, в своих настройках.","1495574033","1","1");
INSERT INTO rules_p VALUES("2","1","[b]Запомните свой пароль.[/b]\r\nА лучше запишите на бумажку и спрячьте дома в надежном месте.","1495574047","1","2");
INSERT INTO rules_p VALUES("3","1","[b]Подозрительные письма.[/b]\r\nВы можете сообщить администрации о подозрительных письмах с помощью кнопки \\\"Блок\\\".\r\nНапример:\r\n- Вам на почту пришло письмо якобы от администрации с просьбой сообщить пароль,\r\n- Вам предлагают секретный метод повышения рейтинга,\r\n- Вас приглашают зайти на какой-то сайт,\r\n- Вам предлагают отправить SMS на короткий номер,\r\n- Любое другое нежелательное письмо, в том числе оскорбления.\r\nВо всех этих случаях жмите кнопку \\\"Блок\\\", либо кнопку \\\"Заблокировать\\\".","1495606515","1","3");
INSERT INTO rules_p VALUES("4","1","[b]Фишинг.[/b]\r\nЧасто мошенники создают подложный сайт, который выглядит в точности так же, как Spaces.ru. Затем мошенники рассылают пользователям сообщения, которые выглядят так, как будто они отправлены администрацией сайта, но при этом содержат ссылку на подложный сайт. Пройдя по ссылке, вы попадаете на поддельный сайт, где вам предлагается ввести ваши данные – Ник и Пароль. Это называется \\\"Фишинг\\\".\r\nПрежде чем ввести свои данные или поменять пароль, всегда проверяйте, что вы находитесь на Xmyx.Ru!","1495606675","1","4");
INSERT INTO rules_p VALUES("5","1","[b]Выманивание ПИН-кодов (карт оплаты).[/b]\r\nНаиболее распространенное мошенничество, при котором вы просто теряете свои деньги и ничего не получаете взамен.\r\nПредлогов может быть много - от \\\"почти\\\" бесплатных интим-услуг сногсшибательной \\\"красотки\\\", до откровенного выпрашивания на \\\"операцию\\\" (давят на жалость).\r\nПродажа интим-фото/видео - тот же самый обман.\r\nОбычно за просьбой сообщить пин-код (код активации карты оплаты) скрывается обычный мошенник, для которого это \\\"бизнес\\\".","1495606714","1","5");



DROP TABLE IF EXISTS `smile`;

CREATE TABLE `smile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `smile` varchar(64) NOT NULL,
  `dir` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=47 DEFAULT CHARSET=utf8;

INSERT INTO smile VALUES("1",":?:","1");
INSERT INTO smile VALUES("2",":чай:","1");
INSERT INTO smile VALUES("3",":супер:","1");
INSERT INTO smile VALUES("4",":пока2:","1");
INSERT INTO smile VALUES("5",":фига:","1");
INSERT INTO smile VALUES("11",":дружба2:","1");
INSERT INTO smile VALUES("12",":ужас:","1");
INSERT INTO smile VALUES("13",":злодей:","1");
INSERT INTO smile VALUES("14",":фингал:","1");
INSERT INTO smile VALUES("15",":идиот:","1");
INSERT INTO smile VALUES("16",":мартини:","1");
INSERT INTO smile VALUES("17",":кофе:","1");
INSERT INTO smile VALUES("18",":кур:","1");
INSERT INTO smile VALUES("19",":дружба:","1");
INSERT INTO smile VALUES("20",":стена:","1");
INSERT INTO smile VALUES("21",":девил:","1");
INSERT INTO smile VALUES("22",":пиво:","1");
INSERT INTO smile VALUES("23",":скалка:","1");
INSERT INTO smile VALUES("24",":-*","1");
INSERT INTO smile VALUES("25",":роза:","1");
INSERT INTO smile VALUES("26",":пока:","1");
INSERT INTO smile VALUES("27",":всемпривет","1");
INSERT INTO smile VALUES("28",":-.","1");
INSERT INTO smile VALUES("29",":!:","1");
INSERT INTO smile VALUES("30",":-?","1");
INSERT INTO smile VALUES("31",":злой:","1");
INSERT INTO smile VALUES("32",":игрив:","1");
INSERT INTO smile VALUES("33",":нытик:","1");
INSERT INTO smile VALUES("34",":плак:","1");
INSERT INTO smile VALUES("35",":-о","1");
INSERT INTO smile VALUES("36","8-о","1");
INSERT INTO smile VALUES("37",":-р","1");
INSERT INTO smile VALUES("38","8-)","1");
INSERT INTO smile VALUES("39",":(","1");
INSERT INTO smile VALUES("40","о_О","1");
INSERT INTO smile VALUES("41",":-/","1");
INSERT INTO smile VALUES("42",";)","1");
INSERT INTO smile VALUES("43",":))","1");
INSERT INTO smile VALUES("44",":-D","1");
INSERT INTO smile VALUES("45","=)","1");
INSERT INTO smile VALUES("46",":)","1");



DROP TABLE IF EXISTS `smile_dir`;

CREATE TABLE `smile_dir` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `opis` varchar(320) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO smile_dir VALUES("1","Основные","");



DROP TABLE IF EXISTS `spaces_icons`;

CREATE TABLE `spaces_icons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `id_icon` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `vid` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

INSERT INTO spaces_icons VALUES("28","1","57","1497455106","0");



DROP TABLE IF EXISTS `spaces_icons_my`;

CREATE TABLE `spaces_icons_my` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `id_icon` int(11) NOT NULL,
  `vid_icon` int(2) DEFAULT '0',
  `time` int(11) NOT NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `spamus`;

CREATE TABLE `spamus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `msg` varchar(512) DEFAULT NULL,
  `razdel` varchar(40) DEFAULT NULL,
  `id_spam` int(11) NOT NULL,
  `types` int(11) DEFAULT '0',
  `time` int(12) DEFAULT NULL,
  `id_post` int(111) DEFAULT NULL,
  `spam` varchar(1000) DEFAULT NULL,
  `id_object` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `stena`;

CREATE TABLE `stena` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `id_stena` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `msg` varchar(1024) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `read` int(11) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `time` (`time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `stena_like`;

CREATE TABLE `stena_like` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `id_stena` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `survey_v`;

CREATE TABLE `survey_v` (
  `id_s` int(11) NOT NULL,
  `id_r` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  KEY `id_s` (`id_s`,`id_r`,`id_user`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `tape`;

CREATE TABLE `tape` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `id_file` int(11) NOT NULL,
  `avtor` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `type` varchar(24) NOT NULL,
  `read` set('0','1') NOT NULL DEFAULT '0',
  `avatar` int(11) DEFAULT '0',
  `ot_kogo` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_user` (`id_user`,`avtor`),
  KEY `read` (`read`)
) ENGINE=MyISAM AUTO_INCREMENT=117 DEFAULT CHARSET=utf8;

INSERT INTO tape VALUES("1","1","1","2","2","1496432526","album","1","0","0");
INSERT INTO tape VALUES("2","2","5","1","1","1496576957","album","1","0","0");
INSERT INTO tape VALUES("5","2","1","4","1","1493903221","frends","1","0","0");
INSERT INTO tape VALUES("7","1","1","4","6","1493903224","frends","1","0","0");
INSERT INTO tape VALUES("8","1","0","10","4","1493974373","notes","1","0","0");
INSERT INTO tape VALUES("42","4","0","14","1","1494839722","notes","1","0","0");
INSERT INTO tape VALUES("15","2","1","8","1","1494424634","frends","1","0","0");
INSERT INTO tape VALUES("18","1","1","12","8","1494424848","album","1","0","0");
INSERT INTO tape VALUES("19","1","0","3","2","1494447258","them","1","0","0");
INSERT INTO tape VALUES("21","2","0","4","1","1494677046","them","1","0","0");
INSERT INTO tape VALUES("22","4","0","4","1","1494677046","them","1","0","0");
INSERT INTO tape VALUES("25","2","0","5","1","1494767064","them","1","0","0");
INSERT INTO tape VALUES("26","4","0","5","1","1494767064","them","1","0","0");
INSERT INTO tape VALUES("38","4","0","13","1","1494823209","notes","1","0","0");
INSERT INTO tape VALUES("41","2","0","14","1","1494839722","notes","1","0","0");
INSERT INTO tape VALUES("33","2","0","12","1","1494782114","notes","1","0","0");
INSERT INTO tape VALUES("34","4","0","12","1","1494782114","notes","1","0","0");
INSERT INTO tape VALUES("37","2","0","13","1","1494823209","notes","1","0","0");
INSERT INTO tape VALUES("45","4","6","1","1","1496576957","album","0","0","0");
INSERT INTO tape VALUES("48","1","0","15","4","1495017655","notes","1","0","0");
INSERT INTO tape VALUES("50","1","1","3","4","1496418392","album","1","0","0");
INSERT INTO tape VALUES("52","1","0","16","4","1495972613","notes","1","0","0");
INSERT INTO tape VALUES("53","6","0","16","4","1495972613","notes","1","0","0");
INSERT INTO tape VALUES("54","1","1","14","6","1496417869","album","1","0","0");
INSERT INTO tape VALUES("55","4","1","14","6","1496417869","album","1","0","0");
INSERT INTO tape VALUES("56","6","1","3","4","1496418392","album","1","0","0");
INSERT INTO tape VALUES("73","1","1","17","2","1496432549","album","1","0","0");
INSERT INTO tape VALUES("84","1","0","19","4","1496459966","notes","1","0","0");
INSERT INTO tape VALUES("74","2","0","6","1","1496433187","them","1","0","0");
INSERT INTO tape VALUES("60","8","10","15","1","1496431732","album","0","0","0");
INSERT INTO tape VALUES("61","2","0","17","1","1496430686","notes","1","0","0");
INSERT INTO tape VALUES("62","4","0","17","1","1496430686","notes","1","0","0");
INSERT INTO tape VALUES("64","8","0","17","1","1496430686","notes","0","0","0");
INSERT INTO tape VALUES("65","2","0","18","1","1496431026","notes","1","0","0");
INSERT INTO tape VALUES("66","4","0","18","1","1496431026","notes","1","0","0");
INSERT INTO tape VALUES("67","6","0","18","1","1496431026","notes","1","0","0");
INSERT INTO tape VALUES("68","8","0","18","1","1496431026","notes","0","0","0");
INSERT INTO tape VALUES("69","2","2","16","1","1496577239","album","1","0","0");
INSERT INTO tape VALUES("70","4","3","16","1","1496577239","album","0","0","0");
INSERT INTO tape VALUES("71","6","3","16","1","1496577239","album","1","0","0");
INSERT INTO tape VALUES("72","8","3","16","1","1496577239","album","0","0","0");
INSERT INTO tape VALUES("75","4","0","6","1","1496433187","them","1","0","0");
INSERT INTO tape VALUES("76","6","0","6","1","1496433187","them","1","0","0");
INSERT INTO tape VALUES("77","8","0","6","1","1496433187","them","0","0","0");
INSERT INTO tape VALUES("78","2","0","7","1","1496433376","them","1","0","0");
INSERT INTO tape VALUES("79","4","0","7","1","1496433376","them","1","0","0");
INSERT INTO tape VALUES("80","6","0","7","1","1496433376","them","1","0","0");
INSERT INTO tape VALUES("81","8","0","7","1","1496433376","them","0","0","0");
INSERT INTO tape VALUES("82","6","6","1","1","1496576957","album","1","0","0");
INSERT INTO tape VALUES("83","8","6","1","1","1496576957","album","0","0","0");
INSERT INTO tape VALUES("85","6","0","19","4","1496459966","notes","1","0","0");
INSERT INTO tape VALUES("86","2","1","18","1","1496577259","album","1","0","0");
INSERT INTO tape VALUES("87","4","1","18","1","1496577259","album","0","0","0");
INSERT INTO tape VALUES("88","6","1","18","1","1496577259","album","1","0","0");
INSERT INTO tape VALUES("89","8","1","18","1","1496577259","album","0","0","0");
INSERT INTO tape VALUES("106","4","1","14","1","1496695155","frends","0","0","0");
INSERT INTO tape VALUES("91","4","0","20","1","1496586789","notes","0","0","0");
INSERT INTO tape VALUES("93","8","0","20","1","1496586789","notes","0","0","0");
INSERT INTO tape VALUES("94","2","0","21","1","1496586863","notes","1","0","0");
INSERT INTO tape VALUES("95","4","0","21","1","1496586863","notes","0","0","0");
INSERT INTO tape VALUES("96","6","0","21","1","1496586863","notes","1","0","0");
INSERT INTO tape VALUES("97","8","0","21","1","1496586863","notes","0","0","0");
INSERT INTO tape VALUES("98","2","0","22","1","1496651190","notes","1","0","0");
INSERT INTO tape VALUES("99","4","0","22","1","1496651190","notes","0","0","0");
INSERT INTO tape VALUES("100","6","0","22","1","1496651190","notes","1","0","0");
INSERT INTO tape VALUES("101","8","0","22","1","1496651190","notes","0","0","0");
INSERT INTO tape VALUES("102","2","0","23","1","1496651459","notes","1","0","0");
INSERT INTO tape VALUES("103","4","0","23","1","1496651459","notes","0","0","0");
INSERT INTO tape VALUES("104","6","0","23","1","1496651459","notes","1","0","0");
INSERT INTO tape VALUES("105","8","0","23","1","1496651459","notes","0","0","0");
INSERT INTO tape VALUES("107","6","1","14","1","1496695155","frends","1","0","0");
INSERT INTO tape VALUES("108","8","1","14","1","1496695155","frends","0","0","0");
INSERT INTO tape VALUES("109","1","0","8","14","1496954853","them","1","0","");
INSERT INTO tape VALUES("110","4","1","6","1","1496978289","frends","0","0","");
INSERT INTO tape VALUES("111","8","1","6","1","1496978289","frends","0","0","");
INSERT INTO tape VALUES("112","14","1","6","1","1496978289","frends","1","0","");
INSERT INTO tape VALUES("113","4","1","17","1","1497190091","frends","0","0","");
INSERT INTO tape VALUES("114","6","1","17","1","1497190091","frends","0","0","");
INSERT INTO tape VALUES("115","8","1","17","1","1497190091","frends","0","0","");
INSERT INTO tape VALUES("116","14","1","17","1","1497190091","frends","0","0","");



DROP TABLE IF EXISTS `tape_set`;

CREATE TABLE `tape_set` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `lenta_status_like` int(11) DEFAULT '1',
  `lenta_status` int(11) DEFAULT '1',
  `lenta_foto` int(11) DEFAULT '1',
  `lenta_files` int(11) DEFAULT '1',
  `lenta_forum` int(11) DEFAULT '1',
  `lenta_notes` int(11) DEFAULT '1',
  `lenta_avatar` int(11) DEFAULT '1',
  `lenta_frends` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

INSERT INTO tape_set VALUES("1","1","1","1","1","1","1","1","1","1");
INSERT INTO tape_set VALUES("2","2","1","1","1","1","1","1","1","1");
INSERT INTO tape_set VALUES("3","3","1","1","1","1","1","1","1","1");
INSERT INTO tape_set VALUES("4","4","1","1","1","1","1","1","1","1");
INSERT INTO tape_set VALUES("5","5","1","1","1","1","1","1","1","1");
INSERT INTO tape_set VALUES("6","6","1","1","1","1","1","1","1","1");
INSERT INTO tape_set VALUES("7","7","1","1","1","1","1","1","1","1");
INSERT INTO tape_set VALUES("8","8","1","1","1","1","1","1","1","1");
INSERT INTO tape_set VALUES("9","9","1","1","1","1","1","1","1","1");
INSERT INTO tape_set VALUES("10","10","1","1","1","1","1","1","1","1");
INSERT INTO tape_set VALUES("11","11","1","1","1","1","1","1","1","1");
INSERT INTO tape_set VALUES("12","12","1","1","1","1","1","1","1","1");
INSERT INTO tape_set VALUES("13","13","1","1","1","1","1","1","1","1");
INSERT INTO tape_set VALUES("14","14","1","1","1","1","1","1","1","1");
INSERT INTO tape_set VALUES("15","15","1","1","1","1","1","1","1","1");
INSERT INTO tape_set VALUES("16","16","1","1","1","1","1","1","1","1");
INSERT INTO tape_set VALUES("17","17","1","1","1","1","1","1","1","1");



DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nick` varchar(32) NOT NULL,
  `pass` varchar(32) NOT NULL,
  `sess` varchar(32) DEFAULT NULL,
  `activation` varchar(32) DEFAULT NULL,
  `ban` int(11) NOT NULL DEFAULT '0',
  `ban_pr` varchar(64) DEFAULT NULL,
  `ip` bigint(20) NOT NULL DEFAULT '0',
  `ip_cl` bigint(20) NOT NULL DEFAULT '0',
  `ip_xff` bigint(20) NOT NULL DEFAULT '0',
  `ua` varchar(32) DEFAULT NULL,
  `date_reg` int(11) NOT NULL DEFAULT '0',
  `time` int(11) NOT NULL,
  `date_aut` int(11) NOT NULL DEFAULT '0',
  `date_last` int(11) NOT NULL DEFAULT '0',
  `balls` int(11) NOT NULL DEFAULT '0',
  `rating` int(11) NOT NULL DEFAULT '0',
  `level` enum('0','1','2','3','4') NOT NULL DEFAULT '0',
  `group_access` int(10) unsigned NOT NULL DEFAULT '1',
  `pol` enum('0','1') NOT NULL DEFAULT '1',
  `url` varchar(64) NOT NULL DEFAULT '/',
  `show_url` enum('0','1') NOT NULL DEFAULT '1',
  `ank_g_r` int(4) DEFAULT NULL,
  `ank_m_r` int(2) DEFAULT NULL,
  `ank_d_r` int(2) DEFAULT NULL,
  `ank_city` varchar(32) DEFAULT NULL,
  `ank_o_sebe` varchar(512) DEFAULT NULL,
  `ank_icq` int(9) DEFAULT NULL,
  `ank_skype` varchar(16) DEFAULT NULL,
  `ank_mail` varchar(32) DEFAULT NULL,
  `ank_n_tel` varchar(11) DEFAULT NULL,
  `ank_name` varchar(32) DEFAULT NULL,
  `set_time_chat` int(11) DEFAULT '30',
  `set_p_str` int(11) DEFAULT '10',
  `set_show_icon` set('0','1','2') DEFAULT '1',
  `set_translit` enum('0','1') NOT NULL DEFAULT '1',
  `set_files` enum('0','1') NOT NULL DEFAULT '0',
  `set_timesdvig` int(11) NOT NULL DEFAULT '0',
  `set_news_to_mail` enum('0','1') NOT NULL DEFAULT '0',
  `set_show_mail` enum('0','1') NOT NULL DEFAULT '0',
  `set_them` varchar(32) DEFAULT 'default',
  `set_them2` varchar(32) DEFAULT 'default',
  `meteo_country` int(11) NOT NULL DEFAULT '0',
  `autorization` enum('0','1') NOT NULL DEFAULT '0',
  `add_konts` enum('0','1','2') NOT NULL DEFAULT '1',
  `wall` int(1) DEFAULT '1',
  `browser` varchar(3) DEFAULT 'wap',
  `ank_rost` int(11) DEFAULT NULL,
  `ank_ves` int(11) DEFAULT NULL,
  `ank_telosl` int(1) NOT NULL,
  `ank_cvet_glas` varchar(11) NOT NULL,
  `ank_volos` varchar(11) NOT NULL,
  `ank_orien` int(1) DEFAULT '0',
  `ank_lov_1` int(11) DEFAULT '0',
  `ank_lov_2` int(11) DEFAULT '0',
  `ank_lov_3` int(11) DEFAULT '0',
  `ank_lov_4` int(11) DEFAULT '0',
  `ank_lov_5` int(11) DEFAULT '0',
  `ank_lov_6` int(11) DEFAULT '0',
  `ank_lov_7` int(11) DEFAULT '0',
  `ank_lov_8` int(11) DEFAULT '0',
  `ank_lov_15` int(11) DEFAULT '0',
  `ank_o_par` varchar(215) NOT NULL,
  `ank_smok` int(11) NOT NULL,
  `ank_mat_pol` int(11) NOT NULL,
  `ank_proj` int(11) NOT NULL,
  `ank_baby` int(11) NOT NULL,
  `ank_avto` varchar(215) NOT NULL,
  `ank_avto_n` int(11) NOT NULL,
  `ank_alko` varchar(215) DEFAULT NULL,
  `ank_alko_n` int(11) DEFAULT '0',
  `ank_nark` int(11) DEFAULT '0',
  `rating_tmp` int(11) DEFAULT '0',
  `sort` int(1) DEFAULT '0',
  `news_read` int(1) DEFAULT '0',
  `ban_where` varchar(10) DEFAULT NULL,
  `abuld` int(1) DEFAULT '0',
  `vk_id` int(11) DEFAULT NULL,
  `type_reg` varchar(100) DEFAULT NULL,
  `identity` varchar(100) DEFAULT NULL,
  `set_nick` int(1) DEFAULT '0',
  `money` int(11) DEFAULT '0',
  `ank_family` varchar(32) DEFAULT NULL,
  `diary_wellcome` varchar(250) NOT NULL,
  `diary_vid` int(1) NOT NULL DEFAULT '0',
  `set_p_maill` int(11) DEFAULT '10',
  `sem_pol` int(11) NOT NULL,
  `ank_zan` int(11) NOT NULL,
  `ank_profes` varchar(215) DEFAULT NULL,
  `ank_interes` varchar(512) DEFAULT NULL,
  `ank_music` varchar(512) DEFAULT NULL,
  `ank_film` varchar(512) DEFAULT NULL,
  `ank_serial` varchar(512) DEFAULT NULL,
  `ank_book` varchar(512) DEFAULT NULL,
  `ank_citat` varchar(512) DEFAULT NULL,
  `polit_vzg` int(11) NOT NULL,
  `ank_mirovozr` int(11) NOT NULL,
  `ank_haracter` varchar(32) DEFAULT NULL,
  `ank_tatu` int(11) DEFAULT '0',
  `ank_pirs` int(11) DEFAULT '0',
  `ank_dating` int(11) DEFAULT '0',
  `ank_blogs` varchar(250) DEFAULT NULL,
  `user_shrift` int(11) NOT NULL DEFAULT '1',
  `panelka_st` varchar(6) DEFAULT '6780b2',
  `panelka` int(2) DEFAULT '11',
  `nick_edit` int(11) NOT NULL DEFAULT '0',
  `ico_onn` varchar(20) DEFAULT '0',
  `p_time` enum('0','1') DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `nick` (`nick`),
  KEY `url` (`url`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

INSERT INTO user VALUES("1","Tw1nGo","552df1796fd19350ff3c637580e97fec","616324f2bd7d96699a5dbb236a29e8b2","","0","","1596981000","0","1596981000","Mozilla","1483819689","268039","1497189682","1497192635","49998605","25","4","15","1","/mail.php","1","1993","6","1","Донецк","Человек ПечалькО..","0","","","","Игорь","30","7","1","1","0","0","0","0","default","default","0","0","1","1","web","178","67","1","Темные","На фото","0","1","0","0","0","0","0","0","0","0","Жена есть!","2","0","0","0","","0","","0","0","68","1","0","","0","0","","","0","49998004","Слепко","","0","10","2","6","Не скажу..",".....","Trap, dubSteP","Комедии, ужасы..",".....","Букварь","..........","4","1","Норм..","1","0","1","Ну типо приветствие!","1","67b2b2","9","1","1","1");
INSERT INTO user VALUES("2","Тестер","c22e3704b739a9d33ec528fdc14a6a66","1a43960230536611f5c8429ef7b7e03f","","0","","1596981008","0","1596981008","Mozilla","1484389551","8217","1496870527","1496870550","13","1","0","1","1","/exit.php","1","1993","2","1","Донецк","Кому нужно, тот спросит.","0","null","","","Тестеровщик","30","7","1","1","0","0","0","0","default","default","0","0","1","0","web","0","0","0","","","0","0","0","0","0","0","0","0","0","0","","0","0","0","0","","0","","2","0","49","0","0","","0","0","","","0","0","Сайта","","0","10","7","3","","","TRAP, EBASH","","","","","0","1","","0","0","0","","1","6780b2","11","0","0","0");
INSERT INTO user VALUES("3","AMEPOH","b1382be6b2b70a4556a4d45303c366cf","355e37d991fb29ed641e8b5e5bc73d39","","0","","3579279502","0","3579279502","Mozilla","1486301059","302","0","1493359928","3","0","0","1","1","/exit.php","1","","","","","","0","","","","","30","7","1","1","0","0","0","0","default","default","0","0","1","0","web","0","0","0","","","0","1","1","1","1","0","0","1","1","0","","0","0","0","0","","0","","0","0","6","0","0","","0","0","","","0","0","","","0","10","0","0","","","","","","","","0","0","","0","0","1","","1","6780b2","11","0","0","0");
INSERT INTO user VALUES("4","Nsk154","562f39d91899d7f4ff92c817de7562fd","308d49c11601a8b6bd103ce34e7c43ff","","0","","3579280119","0","3579280119","Mozilla","1493359969","45388","1495103254","1496554234","38","1","0","1","1","/index.php","1","","","","","","0","","","","","30","7","1","1","0","4","0","0","default","default","0","0","1","0","web","0","0","0","","","0","0","0","0","0","0","0","0","0","0","","0","0","0","0","","0","","0","0","45","0","0","","0","0","","","0","0","","","0","10","0","0","","","","","","","","0","0","Нормальный","0","0","1","","1","6767b2","12","0","0","1");
INSERT INTO user VALUES("5","Bro","1f664b15e6047385ec680411ba36fae8","7c9357dc1384365a339ee9de0b1f5766","","0","","1607850556","0","0","Mozilla","1493467250","1149","1497031907","1497031928","2","0","0","1","1","/user/guest/index.php","1","1996","4","3","","","0","","","","","30","7","1","1","0","0","0","0","default","default","0","0","1","0","web","0","0","0","","","0","0","0","0","0","0","0","0","0","0","","0","0","0","0","","0","","0","0","7","0","0","","0","0","","","0","0","","","0","10","0","0","","","","","","","","0","0","","0","0","0","","1","6780b2","11","0","0","0");
INSERT INTO user VALUES("6","StRaNgEr","17833e931459cf9fe7b3a2dcf8774b7d","01fa4f6b26e9d82cc6db21c154f07e3a","","0","","3283668665","0","3283668665","Mozilla","1493744281","7335","1495650593","1497161263","8","0","0","1","1","/user/index.php","1","1997","10","3","Донецк","","0","","","","Владислав","30","7","1","1","0","0","0","0","default","default","0","0","1","0","web","186","84","1","Карие","","1","1","0","0","0","0","0","0","0","0","","2","0","0","0","","0","","2","0","24","0","0","","0","0","","","0","0","","","0","10","1","3","","","","","","","","0","0","","0","0","1","","0","444475","33","1","0","1");
INSERT INTO user VALUES("7","WiZcaS","06a7f95852411b1fce1d134c979560be","0a660f6cc850921bbc1f823f1d81bd63","","0","","3105535150","0","0","Opera Mini (Mozilla)","1494267284","3440","1494453016","1494453017","4","0","0","1","1","/index.php","1","2000","1","8","Донецк","","0","","","","No","30","7","1","1","0","0","0","0","default","default","0","0","1","0","wap","0","0","0","","","0","0","0","0","0","0","0","0","0","0","","0","0","0","0","","0","","0","0","8","0","0","","0","0","","","0","0","Name","","0","10","6","7","....","","","","","","","0","0","","0","0","0","","1","6780b2","11","0","0","0");
INSERT INTO user VALUES("8","_ZVIR-20111_","17833e931459cf9fe7b3a2dcf8774b7d","8a7f3325cfeac84ddd117ac84ef0c124","","0","","2365590543","0","0","Opera Mini (Mozilla)","1494424556","2122","1496331762","1496331778","3","0","0","1","1","/mail.php","1","","","","","","0","","","","","30","10","1","1","0","0","0","0","default","default","0","0","1","0","wap","0","0","0","","","0","0","0","0","0","0","0","0","0","0","","0","0","0","0","","0","","0","0","11","0","0","","0","0","","","0","0","","","0","10","0","0","","","","","","","","0","0","","0","0","1","","1","6780b2","11","0","0","0");
INSERT INTO user VALUES("9","EkleRchIk","4f08937db37808afa78e36a455def9d1","57d6ffa6fe4c7237f0d57223a97aeb03","","0","","136701992","0","0","Mozilla","1494747475","6307","1496260070","1497169109","3","0","0","1","0","/online.php","1","1995","7","13","","","0","","","","Олька","30","10","1","1","0","0","0","0","default","default","0","0","1","0","web","0","0","0","","","0","0","0","0","0","0","0","0","0","0","","0","0","0","0","","0","","0","0","14","0","0","","0","0","","","0","0","","","0","10","0","0","","","","","","","","0","0","","0","0","0","","1","8067b2","13","0","0","0");
INSERT INTO user VALUES("10","koder_alex","17833e931459cf9fe7b3a2dcf8774b7d","4025e9b2173e5d55123bafab9b35ccf6","","0","","3562863598","0","3562863598","Mozilla","1495288869","451","1496390657","1496390858","2","0","0","1","1","/konts.php","1","","","","","","0","","","","","30","10","1","1","0","0","0","0","default","default","0","0","1","0","web","0","0","0","","","0","0","0","0","0","0","0","0","0","0","","0","0","0","0","","0","","0","0","3","0","0","","0","0","","","0","0","","","0","10","0","0","","","","","","","","0","0","","0","0","0","","1","6799b2","10","0","0","0");
INSERT INTO user VALUES("11","User","c22e3704b739a9d33ec528fdc14a6a66","4db8252d3f65e8a2be7c9e9dd09ba855","","0","","1596981012","0","1596981012","Mozilla","1495706817","134","0","1495706950","2","0","0","1","1","/exit.php","1","","","","","","0","","","","","30","10","1","1","0","0","0","0","default","default","0","0","1","1","web","","","0","","","0","0","0","0","0","0","0","0","0","0","","0","0","0","0","","0","","0","0","2","0","0","","0","0","","","0","0","","","0","10","0","0","","","","","","","","0","0","","0","0","0","","1","6780b2","11","0","0","0");
INSERT INTO user VALUES("12","Prime","17833e931459cf9fe7b3a2dcf8774b7d","d97abcf66ea8d5818ebf5eb128f0de13","","0","","785609953","0","785609953","Mozilla","1495964831","97","0","1495964928","1","0","0","1","1","/index.php","1","","","","","","0","","","","","30","10","1","1","0","0","0","0","default","default","0","0","1","1","web","","","0","","","0","0","0","0","0","0","0","0","0","0","","0","0","0","0","","0","","0","0","1","0","0","","0","0","","","0","0","","","0","10","0","0","","","","","","","","0","0","","0","0","0","","1","6780b2","11","0","0","0");
INSERT INTO user VALUES("13","Marines","8bf16c79d3b4668ac3c171ab273b289c","62275c18dedaea7980ba544c1245261e","","0","","784960395","0","784960395","Mozilla","1496173277","1264","1497029598","1497037248","3","0","0","1","1","/index.php","1","","","","","","0","","","","","30","10","1","1","0","0","0","0","default","default","0","0","1","1","web","","","0","","","0","0","0","0","0","0","0","0","0","0","","0","0","0","0","","0","","0","0","10","0","0","","0","0","","","0","0","","","0","10","0","0","","","","","","","","0","0","","0","0","0","","1","b26767","0","0","0","0");
INSERT INTO user VALUES("14","Roms","b1562848a88cfd1454296026e5885300","e24dfb4b7ec2bf3d8682eb7cce993e2e","","0","","529848892","0","529848892","Mozilla","1496694993","3312","1497088876","1497090004","2","0","0","1","1","/online.php","1","","","","","","0","","","","","30","10","1","1","0","0","0","0","default","default","0","0","1","1","web","","","0","","","0","0","0","0","0","0","0","0","0","0","","0","0","0","0","","0","","0","0","3","0","0","","0","0","","","0","0","","","0","10","0","0","","","","","","","","0","0","","0","0","0","","1","447554","28","0","0","0");
INSERT INTO user VALUES("17","test","720808c2f7b9bb68283b30da8cd3a7d1","1faab713327e700e42d81a14cb4b60ba","","0","","774987817","0","774987817","Mozilla","1497189715","1085","0","1497192613","1","0","0","1","1","/user/startpage.php","1","","","","","","","","","","","30","10","1","1","0","0","0","0","default","default","0","0","1","1","web","","","0","","","0","0","0","0","0","0","0","0","0","0","","0","0","0","0","","0","","0","0","1","0","0","","0","","","","0","0","","","0","10","0","0","","","","","","","","0","0","","0","0","0","","1","6780b2","11","0","0","0");
INSERT INTO user VALUES("15","xolod","17833e931459cf9fe7b3a2dcf8774b7d","b9ebca4d5202da66386f295a2337c794","","0","","2834023157","0","0","Mozilla","1497127668","1414","1497160771","1497171296","1","0","0","1","1","/user/index.php","1","2003","7","6","","","","","","","Вадим","30","10","1","1","0","0","0","0","default","default","0","0","1","1","web","","","0","","","0","0","0","0","0","0","0","0","0","0","","0","0","0","0","","0","","0","0","1","0","0","","0","","","","0","0","Холод","","0","10","0","0","","","","","","","","0","0","","0","0","0","","1","6767b2","12","0","0","0");
INSERT INTO user VALUES("16","VIP_Bot","8bf16c79d3b4668ac3c171ab273b289c","9d0f4ac438a0101d11b27ec590e8141f","","0","","1602626156","0","1602626156","Mozilla","1497168055","343","0","1497168793","0","0","0","1","1","/index.php","1","","","","","","","","","","","30","10","1","1","0","0","0","0","default","default","0","0","1","1","web","","","0","","","0","0","0","0","0","0","0","0","0","0","","0","0","0","0","","0","","0","0","0","0","0","","0","","","","0","0","","","0","10","0","0","","","","","","","","0","0","","0","0","1","","1","6780b2","11","0","0","0");



DROP TABLE IF EXISTS `user_activity`;

CREATE TABLE `user_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `id_file` int(11) NOT NULL,
  `avtor` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `type` varchar(24) NOT NULL,
  `ot_kogo` int(11) DEFAULT NULL,
  `id_photo` int(11) NOT NULL,
  `avatar` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_user` (`id_user`,`avtor`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

INSERT INTO user_activity VALUES("17","1","0","16","1","1496577239","album","0","46","0");
INSERT INTO user_activity VALUES("2","1","0","17","1","1496430686","notes","0","0","0");
INSERT INTO user_activity VALUES("3","1","0","18","1","1496431026","notes","0","0","0");
INSERT INTO user_activity VALUES("7","2","1","2","2","1496432526","album","0","0","0");
INSERT INTO user_activity VALUES("8","2","1","17","2","1496432549","album","0","0","0");
INSERT INTO user_activity VALUES("9","1","0","6","1","1496433187","them","0","0","0");
INSERT INTO user_activity VALUES("10","1","0","7","1","1496433376","them","0","0","0");
INSERT INTO user_activity VALUES("12","4","0","19","4","1496459966","notes","0","0","0");
INSERT INTO user_activity VALUES("16","1","0","16","1","1496577211","album","0","45","0");
INSERT INTO user_activity VALUES("18","1","0","18","1","1496577259","album","0","47","0");
INSERT INTO user_activity VALUES("20","1","0","21","1","1496586863","notes","0","0","0");
INSERT INTO user_activity VALUES("21","1","0","22","1","1496651190","notes","0","0","0");
INSERT INTO user_activity VALUES("22","1","0","23","1","1496651459","notes","0","0","0");
INSERT INTO user_activity VALUES("23","14","0","8","14","1496954853","them","","0","0");
INSERT INTO user_activity VALUES("24","15","0","9","15","1497128025","them","","0","0");
INSERT INTO user_activity VALUES("25","16","0","19","16","1497168120","album","","48","0");



DROP TABLE IF EXISTS `user_collision`;

CREATE TABLE `user_collision` (
  `id_user` int(11) NOT NULL,
  `id_user2` int(11) NOT NULL,
  `type` set('sess','ip_ua_time') NOT NULL DEFAULT 'sess',
  KEY `id_user` (`id_user`,`id_user2`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO user_collision VALUES("2","1","ip_ua_time");
INSERT INTO user_collision VALUES("4","3","ip_ua_time");
INSERT INTO user_collision VALUES("11","1","ip_ua_time");



DROP TABLE IF EXISTS `user_files`;

CREATE TABLE `user_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `name` varchar(32) NOT NULL,
  `time` int(11) NOT NULL,
  `msg` varchar(256) NOT NULL,
  `id_dir` int(11) DEFAULT NULL,
  `osn` int(1) DEFAULT '0',
  `type` varchar(20) DEFAULT NULL,
  `id_dires` varchar(215) DEFAULT '/',
  `pass` varchar(12) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_user` (`id_user`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

INSERT INTO user_files VALUES("1","1","Файлы","0","","0","1","","/","");
INSERT INTO user_files VALUES("2","0","Файлы","0","","0","1","","/","");
INSERT INTO user_files VALUES("3","2","Файлы","0","","0","1","","/","");
INSERT INTO user_files VALUES("4","3","Файлы","0","","0","1","","/","");
INSERT INTO user_files VALUES("5","4","Файлы","0","","0","1","","/","");
INSERT INTO user_files VALUES("6","5","Файлы","0","","0","1","","/","");
INSERT INTO user_files VALUES("7","6","Файлы","0","","0","1","","/","");
INSERT INTO user_files VALUES("8","7","Файлы","0","","0","1","","/","");
INSERT INTO user_files VALUES("9","8","Файлы","0","","0","1","","/","");
INSERT INTO user_files VALUES("10","9","Файлы","0","","0","1","","/","");
INSERT INTO user_files VALUES("11","10","Файлы","0","","0","1","","/","");
INSERT INTO user_files VALUES("12","11","Файлы","0","","0","1","","/","");
INSERT INTO user_files VALUES("13","12","Файлы","0","","0","1","","/","");
INSERT INTO user_files VALUES("14","13","Файлы","0","","0","1","","/","");



DROP TABLE IF EXISTS `user_group`;

CREATE TABLE `user_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `level` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

INSERT INTO user_group VALUES("1","Пользователь","0");
INSERT INTO user_group VALUES("2","Модератор чата","1");
INSERT INTO user_group VALUES("3","Модератор форума","1");
INSERT INTO user_group VALUES("4","Модератор Зоны обмена","1");
INSERT INTO user_group VALUES("5","Модератор библиотеки","1");
INSERT INTO user_group VALUES("6","Модератор фотогалереи","1");
INSERT INTO user_group VALUES("7","Модератор","2");
INSERT INTO user_group VALUES("8","Администратор","3");
INSERT INTO user_group VALUES("9","Главный администратор","9");
INSERT INTO user_group VALUES("15","Создатель","10");
INSERT INTO user_group VALUES("11","Модератор дневников","1");
INSERT INTO user_group VALUES("12","Модератор гостевой","1");



DROP TABLE IF EXISTS `user_group_access`;

CREATE TABLE `user_group_access` (
  `id_group` int(10) unsigned NOT NULL,
  `id_access` varchar(32) NOT NULL,
  KEY `id_group` (`id_group`,`id_access`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO user_group_access VALUES("2","adm_info");
INSERT INTO user_group_access VALUES("2","adm_panel_show");
INSERT INTO user_group_access VALUES("2","adm_ref");
INSERT INTO user_group_access VALUES("2","adm_set_chat");
INSERT INTO user_group_access VALUES("2","adm_show_adm");
INSERT INTO user_group_access VALUES("2","adm_statistic");
INSERT INTO user_group_access VALUES("2","chat_clear");
INSERT INTO user_group_access VALUES("2","chat_room");
INSERT INTO user_group_access VALUES("2","user_ban_set");
INSERT INTO user_group_access VALUES("2","user_ban_set_h");
INSERT INTO user_group_access VALUES("2","user_ban_unset");
INSERT INTO user_group_access VALUES("2","user_prof_edit");
INSERT INTO user_group_access VALUES("2","user_show_add_info");
INSERT INTO user_group_access VALUES("2","user_show_ua");
INSERT INTO user_group_access VALUES("3","adm_banlist");
INSERT INTO user_group_access VALUES("3","adm_panel_show");
INSERT INTO user_group_access VALUES("3","adm_set_forum");
INSERT INTO user_group_access VALUES("3","adm_show_adm");
INSERT INTO user_group_access VALUES("3","adm_statistic");
INSERT INTO user_group_access VALUES("3","forum_for_edit");
INSERT INTO user_group_access VALUES("3","forum_post_ed");
INSERT INTO user_group_access VALUES("3","forum_razd_create");
INSERT INTO user_group_access VALUES("3","forum_razd_edit");
INSERT INTO user_group_access VALUES("3","forum_them_del");
INSERT INTO user_group_access VALUES("3","forum_them_edit");
INSERT INTO user_group_access VALUES("3","user_ban_set_h");
INSERT INTO user_group_access VALUES("3","user_prof_edit");
INSERT INTO user_group_access VALUES("3","user_show_add_info");
INSERT INTO user_group_access VALUES("3","user_show_ip");
INSERT INTO user_group_access VALUES("3","user_show_ua");
INSERT INTO user_group_access VALUES("4","adm_info");
INSERT INTO user_group_access VALUES("4","adm_panel_show");
INSERT INTO user_group_access VALUES("4","adm_set_loads");
INSERT INTO user_group_access VALUES("4","adm_show_adm");
INSERT INTO user_group_access VALUES("4","adm_statistic");
INSERT INTO user_group_access VALUES("4","loads_dir_create");
INSERT INTO user_group_access VALUES("4","loads_dir_delete");
INSERT INTO user_group_access VALUES("4","loads_dir_mesto");
INSERT INTO user_group_access VALUES("4","loads_dir_rename");
INSERT INTO user_group_access VALUES("4","loads_file_delete");
INSERT INTO user_group_access VALUES("4","loads_file_edit");
INSERT INTO user_group_access VALUES("4","loads_file_upload");
INSERT INTO user_group_access VALUES("4","loads_unzip");
INSERT INTO user_group_access VALUES("5","adm_info");
INSERT INTO user_group_access VALUES("5","adm_lib_repair");
INSERT INTO user_group_access VALUES("5","adm_panel_show");
INSERT INTO user_group_access VALUES("5","adm_ref");
INSERT INTO user_group_access VALUES("5","adm_set_foto");
INSERT INTO user_group_access VALUES("5","adm_statistic");
INSERT INTO user_group_access VALUES("5","lib_dir_create");
INSERT INTO user_group_access VALUES("5","lib_dir_delete");
INSERT INTO user_group_access VALUES("5","lib_dir_edit");
INSERT INTO user_group_access VALUES("5","lib_dir_mesto");
INSERT INTO user_group_access VALUES("5","lib_stat_create");
INSERT INTO user_group_access VALUES("5","lib_stat_delete");
INSERT INTO user_group_access VALUES("5","lib_stat_txt");
INSERT INTO user_group_access VALUES("5","lib_stat_zip");
INSERT INTO user_group_access VALUES("5","user_ban_set_h");
INSERT INTO user_group_access VALUES("5","user_prof_edit");
INSERT INTO user_group_access VALUES("6","adm_banlist");
INSERT INTO user_group_access VALUES("6","adm_info");
INSERT INTO user_group_access VALUES("6","adm_panel_show");
INSERT INTO user_group_access VALUES("6","adm_set_foto");
INSERT INTO user_group_access VALUES("6","adm_show_adm");
INSERT INTO user_group_access VALUES("6","adm_statistic");
INSERT INTO user_group_access VALUES("6","foto_alb_del");
INSERT INTO user_group_access VALUES("6","foto_foto_edit");
INSERT INTO user_group_access VALUES("6","foto_komm_del");
INSERT INTO user_group_access VALUES("6","user_ban_set_h");
INSERT INTO user_group_access VALUES("6","user_show_ua");
INSERT INTO user_group_access VALUES("7","adm_banlist");
INSERT INTO user_group_access VALUES("7","adm_lib_repair");
INSERT INTO user_group_access VALUES("7","adm_panel_show");
INSERT INTO user_group_access VALUES("7","adm_set_chat");
INSERT INTO user_group_access VALUES("7","adm_set_forum");
INSERT INTO user_group_access VALUES("7","adm_set_foto");
INSERT INTO user_group_access VALUES("7","adm_statistic");
INSERT INTO user_group_access VALUES("7","chat_clear");
INSERT INTO user_group_access VALUES("7","chat_room");
INSERT INTO user_group_access VALUES("7","forum_post_close");
INSERT INTO user_group_access VALUES("7","forum_post_ed");
INSERT INTO user_group_access VALUES("7","forum_razd_create");
INSERT INTO user_group_access VALUES("7","forum_razd_edit");
INSERT INTO user_group_access VALUES("7","forum_them_del");
INSERT INTO user_group_access VALUES("7","forum_them_edit");
INSERT INTO user_group_access VALUES("7","foto_foto_edit");
INSERT INTO user_group_access VALUES("7","foto_komm_del");
INSERT INTO user_group_access VALUES("7","guest_clear");
INSERT INTO user_group_access VALUES("7","guest_delete");
INSERT INTO user_group_access VALUES("7","guest_show_ip");
INSERT INTO user_group_access VALUES("7","lib_stat_create");
INSERT INTO user_group_access VALUES("7","lib_stat_txt");
INSERT INTO user_group_access VALUES("7","loads_file_delete");
INSERT INTO user_group_access VALUES("7","loads_file_edit");
INSERT INTO user_group_access VALUES("7","loads_file_upload");
INSERT INTO user_group_access VALUES("7","notes_delete");
INSERT INTO user_group_access VALUES("7","notes_edit");
INSERT INTO user_group_access VALUES("7","obmen_dir_create");
INSERT INTO user_group_access VALUES("7","obmen_dir_delete");
INSERT INTO user_group_access VALUES("7","obmen_dir_edit");
INSERT INTO user_group_access VALUES("7","obmen_file_delete");
INSERT INTO user_group_access VALUES("7","obmen_file_edit");
INSERT INTO user_group_access VALUES("7","obmen_komm_del");
INSERT INTO user_group_access VALUES("7","user_ban_set");
INSERT INTO user_group_access VALUES("7","user_ban_set_h");
INSERT INTO user_group_access VALUES("7","user_ban_unset");
INSERT INTO user_group_access VALUES("7","user_collisions");
INSERT INTO user_group_access VALUES("7","user_prof_edit");
INSERT INTO user_group_access VALUES("7","user_show_add_info");
INSERT INTO user_group_access VALUES("7","user_show_ua");
INSERT INTO user_group_access VALUES("8","adm_banlist");
INSERT INTO user_group_access VALUES("8","adm_ban_ip");
INSERT INTO user_group_access VALUES("8","adm_forum_sinc");
INSERT INTO user_group_access VALUES("8","adm_info");
INSERT INTO user_group_access VALUES("8","adm_lib_repair");
INSERT INTO user_group_access VALUES("8","adm_news");
INSERT INTO user_group_access VALUES("8","adm_panel_show");
INSERT INTO user_group_access VALUES("8","adm_ref");
INSERT INTO user_group_access VALUES("8","adm_set_chat");
INSERT INTO user_group_access VALUES("8","adm_set_forum");
INSERT INTO user_group_access VALUES("8","adm_set_foto");
INSERT INTO user_group_access VALUES("8","adm_set_loads");
INSERT INTO user_group_access VALUES("8","adm_show_adm");
INSERT INTO user_group_access VALUES("8","adm_statistic");
INSERT INTO user_group_access VALUES("8","chat_clear");
INSERT INTO user_group_access VALUES("8","chat_room");
INSERT INTO user_group_access VALUES("8","forum_for_create");
INSERT INTO user_group_access VALUES("8","forum_for_delete");
INSERT INTO user_group_access VALUES("8","forum_for_edit");
INSERT INTO user_group_access VALUES("8","forum_post_ed");
INSERT INTO user_group_access VALUES("8","forum_razd_create");
INSERT INTO user_group_access VALUES("8","forum_razd_edit");
INSERT INTO user_group_access VALUES("8","forum_them_del");
INSERT INTO user_group_access VALUES("8","forum_them_edit");
INSERT INTO user_group_access VALUES("8","foto_alb_del");
INSERT INTO user_group_access VALUES("8","foto_foto_edit");
INSERT INTO user_group_access VALUES("8","foto_komm_del");
INSERT INTO user_group_access VALUES("8","guest_clear");
INSERT INTO user_group_access VALUES("8","guest_delete");
INSERT INTO user_group_access VALUES("8","guest_show_ip");
INSERT INTO user_group_access VALUES("8","lib_dir_create");
INSERT INTO user_group_access VALUES("8","lib_dir_delete");
INSERT INTO user_group_access VALUES("8","lib_dir_edit");
INSERT INTO user_group_access VALUES("8","lib_dir_mesto");
INSERT INTO user_group_access VALUES("8","lib_stat_create");
INSERT INTO user_group_access VALUES("8","lib_stat_delete");
INSERT INTO user_group_access VALUES("8","lib_stat_txt");
INSERT INTO user_group_access VALUES("8","lib_stat_zip");
INSERT INTO user_group_access VALUES("8","loads_dir_create");
INSERT INTO user_group_access VALUES("8","loads_dir_delete");
INSERT INTO user_group_access VALUES("8","loads_dir_mesto");
INSERT INTO user_group_access VALUES("8","loads_dir_rename");
INSERT INTO user_group_access VALUES("8","loads_file_delete");
INSERT INTO user_group_access VALUES("8","loads_file_edit");
INSERT INTO user_group_access VALUES("8","loads_file_upload");
INSERT INTO user_group_access VALUES("8","loads_unzip");
INSERT INTO user_group_access VALUES("8","notes_delete");
INSERT INTO user_group_access VALUES("8","notes_edit");
INSERT INTO user_group_access VALUES("8","obmen_dir_create");
INSERT INTO user_group_access VALUES("8","obmen_dir_delete");
INSERT INTO user_group_access VALUES("8","obmen_dir_edit");
INSERT INTO user_group_access VALUES("8","obmen_file_delete");
INSERT INTO user_group_access VALUES("8","obmen_file_edit");
INSERT INTO user_group_access VALUES("8","obmen_komm_del");
INSERT INTO user_group_access VALUES("8","user_ban_set");
INSERT INTO user_group_access VALUES("8","user_ban_set_h");
INSERT INTO user_group_access VALUES("8","user_ban_unset");
INSERT INTO user_group_access VALUES("8","user_change_group");
INSERT INTO user_group_access VALUES("8","user_change_nick");
INSERT INTO user_group_access VALUES("8","user_collisions");
INSERT INTO user_group_access VALUES("8","user_delete");
INSERT INTO user_group_access VALUES("8","user_prof_edit");
INSERT INTO user_group_access VALUES("8","user_show_add_info");
INSERT INTO user_group_access VALUES("8","user_show_ip");
INSERT INTO user_group_access VALUES("8","user_show_ua");
INSERT INTO user_group_access VALUES("8","votes_create");
INSERT INTO user_group_access VALUES("8","votes_settings");
INSERT INTO user_group_access VALUES("9","adm_banlist");
INSERT INTO user_group_access VALUES("9","adm_ban_ip");
INSERT INTO user_group_access VALUES("9","adm_forum_sinc");
INSERT INTO user_group_access VALUES("9","adm_info");
INSERT INTO user_group_access VALUES("9","adm_ip_edit");
INSERT INTO user_group_access VALUES("9","adm_lib_repair");
INSERT INTO user_group_access VALUES("9","adm_log_read");
INSERT INTO user_group_access VALUES("9","adm_menu");
INSERT INTO user_group_access VALUES("9","adm_news");
INSERT INTO user_group_access VALUES("9","adm_panel_show");
INSERT INTO user_group_access VALUES("9","adm_ref");
INSERT INTO user_group_access VALUES("9","adm_rekl");
INSERT INTO user_group_access VALUES("9","adm_set_chat");
INSERT INTO user_group_access VALUES("9","adm_set_forum");
INSERT INTO user_group_access VALUES("9","adm_set_foto");
INSERT INTO user_group_access VALUES("9","adm_set_loads");
INSERT INTO user_group_access VALUES("9","adm_set_sys");
INSERT INTO user_group_access VALUES("9","adm_set_user");
INSERT INTO user_group_access VALUES("9","adm_show_adm");
INSERT INTO user_group_access VALUES("9","adm_statistic");
INSERT INTO user_group_access VALUES("9","adm_themes");
INSERT INTO user_group_access VALUES("9","chat_clear");
INSERT INTO user_group_access VALUES("9","chat_room");
INSERT INTO user_group_access VALUES("9","forum_for_create");
INSERT INTO user_group_access VALUES("9","forum_for_delete");
INSERT INTO user_group_access VALUES("9","forum_for_edit");
INSERT INTO user_group_access VALUES("9","forum_post_close");
INSERT INTO user_group_access VALUES("9","forum_post_ed");
INSERT INTO user_group_access VALUES("9","forum_razd_create");
INSERT INTO user_group_access VALUES("9","forum_razd_edit");
INSERT INTO user_group_access VALUES("9","forum_them_del");
INSERT INTO user_group_access VALUES("9","forum_them_edit");
INSERT INTO user_group_access VALUES("9","foto_alb_del");
INSERT INTO user_group_access VALUES("9","foto_foto_edit");
INSERT INTO user_group_access VALUES("9","foto_komm_del");
INSERT INTO user_group_access VALUES("9","guest_clear");
INSERT INTO user_group_access VALUES("9","guest_delete");
INSERT INTO user_group_access VALUES("9","guest_show_ip");
INSERT INTO user_group_access VALUES("9","lib_dir_create");
INSERT INTO user_group_access VALUES("9","lib_dir_delete");
INSERT INTO user_group_access VALUES("9","lib_dir_edit");
INSERT INTO user_group_access VALUES("9","lib_dir_mesto");
INSERT INTO user_group_access VALUES("9","lib_stat_create");
INSERT INTO user_group_access VALUES("9","lib_stat_delete");
INSERT INTO user_group_access VALUES("9","lib_stat_txt");
INSERT INTO user_group_access VALUES("9","lib_stat_zip");
INSERT INTO user_group_access VALUES("9","loads_dir_create");
INSERT INTO user_group_access VALUES("9","loads_dir_delete");
INSERT INTO user_group_access VALUES("9","loads_dir_mesto");
INSERT INTO user_group_access VALUES("9","loads_dir_rename");
INSERT INTO user_group_access VALUES("9","loads_file_delete");
INSERT INTO user_group_access VALUES("9","loads_file_edit");
INSERT INTO user_group_access VALUES("9","loads_file_import");
INSERT INTO user_group_access VALUES("9","loads_file_upload");
INSERT INTO user_group_access VALUES("9","loads_unzip");
INSERT INTO user_group_access VALUES("9","notes_delete");
INSERT INTO user_group_access VALUES("9","notes_edit");
INSERT INTO user_group_access VALUES("9","obmen_dir_create");
INSERT INTO user_group_access VALUES("9","obmen_dir_delete");
INSERT INTO user_group_access VALUES("9","obmen_dir_edit");
INSERT INTO user_group_access VALUES("9","obmen_file_delete");
INSERT INTO user_group_access VALUES("9","obmen_file_edit");
INSERT INTO user_group_access VALUES("9","obmen_komm_del");
INSERT INTO user_group_access VALUES("9","user_ban_set");
INSERT INTO user_group_access VALUES("9","user_ban_set_h");
INSERT INTO user_group_access VALUES("9","user_ban_unset");
INSERT INTO user_group_access VALUES("9","user_change_group");
INSERT INTO user_group_access VALUES("9","user_change_nick");
INSERT INTO user_group_access VALUES("9","user_collisions");
INSERT INTO user_group_access VALUES("9","user_delete");
INSERT INTO user_group_access VALUES("9","user_mass_delete");
INSERT INTO user_group_access VALUES("9","user_prof_edit");
INSERT INTO user_group_access VALUES("9","user_show_add_info");
INSERT INTO user_group_access VALUES("9","user_show_ip");
INSERT INTO user_group_access VALUES("9","user_show_ua");
INSERT INTO user_group_access VALUES("9","votes_create");
INSERT INTO user_group_access VALUES("9","votes_settings");
INSERT INTO user_group_access VALUES("11","adm_banlist");
INSERT INTO user_group_access VALUES("11","adm_info");
INSERT INTO user_group_access VALUES("11","adm_panel_show");
INSERT INTO user_group_access VALUES("11","adm_show_adm");
INSERT INTO user_group_access VALUES("11","adm_statistic");
INSERT INTO user_group_access VALUES("11","forum_post_close");
INSERT INTO user_group_access VALUES("11","notes_delete");
INSERT INTO user_group_access VALUES("11","notes_edit");
INSERT INTO user_group_access VALUES("11","user_ban_set");
INSERT INTO user_group_access VALUES("11","user_ban_set_h");
INSERT INTO user_group_access VALUES("12","adm_banlist");
INSERT INTO user_group_access VALUES("12","adm_info");
INSERT INTO user_group_access VALUES("12","adm_panel_show");
INSERT INTO user_group_access VALUES("12","adm_show_adm");
INSERT INTO user_group_access VALUES("12","adm_statistic");
INSERT INTO user_group_access VALUES("12","guest_clear");
INSERT INTO user_group_access VALUES("12","guest_delete");
INSERT INTO user_group_access VALUES("12","user_ban_set");
INSERT INTO user_group_access VALUES("12","user_ban_set_h");
INSERT INTO user_group_access VALUES("15","adm_accesses");
INSERT INTO user_group_access VALUES("15","adm_banlist");
INSERT INTO user_group_access VALUES("15","adm_ban_ip");
INSERT INTO user_group_access VALUES("15","adm_forum_sinc");
INSERT INTO user_group_access VALUES("15","adm_info");
INSERT INTO user_group_access VALUES("15","adm_ip_edit");
INSERT INTO user_group_access VALUES("15","adm_lib_repair");
INSERT INTO user_group_access VALUES("15","adm_log_delete");
INSERT INTO user_group_access VALUES("15","adm_log_read");
INSERT INTO user_group_access VALUES("15","adm_menu");
INSERT INTO user_group_access VALUES("15","adm_mysql");
INSERT INTO user_group_access VALUES("15","adm_news");
INSERT INTO user_group_access VALUES("15","adm_panel_show");
INSERT INTO user_group_access VALUES("15","adm_ref");
INSERT INTO user_group_access VALUES("15","adm_rekl");
INSERT INTO user_group_access VALUES("15","adm_set_chat");
INSERT INTO user_group_access VALUES("15","adm_set_forum");
INSERT INTO user_group_access VALUES("15","adm_set_foto");
INSERT INTO user_group_access VALUES("15","adm_set_loads");
INSERT INTO user_group_access VALUES("15","adm_set_sys");
INSERT INTO user_group_access VALUES("15","adm_set_user");
INSERT INTO user_group_access VALUES("15","adm_show_adm");
INSERT INTO user_group_access VALUES("15","adm_statistic");
INSERT INTO user_group_access VALUES("15","adm_themes");
INSERT INTO user_group_access VALUES("15","chat_clear");
INSERT INTO user_group_access VALUES("15","chat_room");
INSERT INTO user_group_access VALUES("15","forum_for_create");
INSERT INTO user_group_access VALUES("15","forum_for_delete");
INSERT INTO user_group_access VALUES("15","forum_for_edit");
INSERT INTO user_group_access VALUES("15","forum_post_close");
INSERT INTO user_group_access VALUES("15","forum_post_ed");
INSERT INTO user_group_access VALUES("15","forum_razd_create");
INSERT INTO user_group_access VALUES("15","forum_razd_edit");
INSERT INTO user_group_access VALUES("15","forum_them_del");
INSERT INTO user_group_access VALUES("15","forum_them_edit");
INSERT INTO user_group_access VALUES("15","foto_alb_del");
INSERT INTO user_group_access VALUES("15","foto_foto_edit");
INSERT INTO user_group_access VALUES("15","foto_komm_del");
INSERT INTO user_group_access VALUES("15","guest_clear");
INSERT INTO user_group_access VALUES("15","guest_delete");
INSERT INTO user_group_access VALUES("15","guest_show_ip");
INSERT INTO user_group_access VALUES("15","lib_dir_create");
INSERT INTO user_group_access VALUES("15","lib_dir_delete");
INSERT INTO user_group_access VALUES("15","lib_dir_edit");
INSERT INTO user_group_access VALUES("15","lib_dir_mesto");
INSERT INTO user_group_access VALUES("15","lib_stat_create");
INSERT INTO user_group_access VALUES("15","lib_stat_delete");
INSERT INTO user_group_access VALUES("15","lib_stat_txt");
INSERT INTO user_group_access VALUES("15","lib_stat_zip");
INSERT INTO user_group_access VALUES("15","loads_dir_create");
INSERT INTO user_group_access VALUES("15","loads_dir_delete");
INSERT INTO user_group_access VALUES("15","loads_dir_mesto");
INSERT INTO user_group_access VALUES("15","loads_dir_rename");
INSERT INTO user_group_access VALUES("15","loads_file_delete");
INSERT INTO user_group_access VALUES("15","loads_file_edit");
INSERT INTO user_group_access VALUES("15","loads_file_import");
INSERT INTO user_group_access VALUES("15","loads_file_upload");
INSERT INTO user_group_access VALUES("15","loads_unzip");
INSERT INTO user_group_access VALUES("15","notes_delete");
INSERT INTO user_group_access VALUES("15","notes_edit");
INSERT INTO user_group_access VALUES("15","obmen_dir_create");
INSERT INTO user_group_access VALUES("15","obmen_dir_delete");
INSERT INTO user_group_access VALUES("15","obmen_dir_edit");
INSERT INTO user_group_access VALUES("15","obmen_file_delete");
INSERT INTO user_group_access VALUES("15","obmen_file_edit");
INSERT INTO user_group_access VALUES("15","obmen_komm_del");
INSERT INTO user_group_access VALUES("15","user_ban_set");
INSERT INTO user_group_access VALUES("15","user_ban_set_h");
INSERT INTO user_group_access VALUES("15","user_ban_unset");
INSERT INTO user_group_access VALUES("15","user_change_group");
INSERT INTO user_group_access VALUES("15","user_change_nick");
INSERT INTO user_group_access VALUES("15","user_collisions");
INSERT INTO user_group_access VALUES("15","user_delete");
INSERT INTO user_group_access VALUES("15","user_mass_delete");
INSERT INTO user_group_access VALUES("15","user_prof_edit");
INSERT INTO user_group_access VALUES("15","user_show_add_info");
INSERT INTO user_group_access VALUES("15","user_show_ip");
INSERT INTO user_group_access VALUES("15","user_show_ua");
INSERT INTO user_group_access VALUES("15","votes_create");
INSERT INTO user_group_access VALUES("15","votes_settings");



DROP TABLE IF EXISTS `user_guest`;

CREATE TABLE `user_guest` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `id_guest` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `msg` varchar(1024) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `reply_id_user` int(11) DEFAULT '0',
  PRIMARY KEY (`uid`),
  KEY `time` (`time`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

INSERT INTO user_guest VALUES("1","1","1","1495137034","Тест..","0");
INSERT INTO user_guest VALUES("2","2","1","1495448264","роро","1");
INSERT INTO user_guest VALUES("3","2","2","1495448438","Тестер[1]","0");
INSERT INTO user_guest VALUES("4","2","2","1495448458","Тестер[2]","0");
INSERT INTO user_guest VALUES("5","1","4","1495607224","Ку-ку :)","0");
INSERT INTO user_guest VALUES("6","4","1","1495607373","Привет)","1");
INSERT INTO user_guest VALUES("7","4","1","1495607467","=)","1");
INSERT INTO user_guest VALUES("9","1","1","1495628859","Чем занимаешься?)","4");
INSERT INTO user_guest VALUES("10","4","1","1495629047","Дома диван давлю)","1");
INSERT INTO user_guest VALUES("11","1","1","1495629163","хех)\r\nнормас)","4");
INSERT INTO user_guest VALUES("12","4","1","1495629204","Вечер у меня уже)","1");
INSERT INTO user_guest VALUES("13","1","1","1495629297","та и у меня уже 15:35 )","4");
INSERT INTO user_guest VALUES("14","4","1","1495629363","У тебя что нового,чем занят?","1");
INSERT INTO user_guest VALUES("15","1","1","1495630119","Систему переписую) а ты?","4");
INSERT INTO user_guest VALUES("16","4","1","1495631658","Телек смотрю)","1");
INSERT INTO user_guest VALUES("17","1","1","1495637484","Интересное что-то?","4");
INSERT INTO user_guest VALUES("18","4","1","1495638234","Листаю туда сюда,всякая хрень идёт)","1");
INSERT INTO user_guest VALUES("19","1","1","1495638278","понятно :)","4");
INSERT INTO user_guest VALUES("20","8","8","1495835085",":)","0");
INSERT INTO user_guest VALUES("21","17","17","1497190670","hello","0");



DROP TABLE IF EXISTS `user_guest_like`;

CREATE TABLE `user_guest_like` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `id_post` int(11) NOT NULL,
  `like` int(11) NOT NULL DEFAULT '0',
  `dlike` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO user_guest_like VALUES("1","2","0","1","1","0");
INSERT INTO user_guest_like VALUES("2","1","0","2","0","1");
INSERT INTO user_guest_like VALUES("3","1","0","4","1","0");
INSERT INTO user_guest_like VALUES("4","1","0","3","0","1");
INSERT INTO user_guest_like VALUES("5","1","0","18","1","0");
INSERT INTO user_guest_like VALUES("6","4","0","5","1","0");



DROP TABLE IF EXISTS `user_log`;

CREATE TABLE `user_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `method` set('1','0') NOT NULL DEFAULT '0',
  `time` int(11) NOT NULL,
  `ip` bigint(20) NOT NULL DEFAULT '0',
  `ua` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_user` (`id_user`),
  KEY `time` (`time`)
) ENGINE=MyISAM AUTO_INCREMENT=198 DEFAULT CHARSET=utf8;

INSERT INTO user_log VALUES("1","2","1","1484654336","1596981001","Mozilla");
INSERT INTO user_log VALUES("2","2","1","1484679313","1596981001","Mozilla");
INSERT INTO user_log VALUES("3","2","1","1484729337","1596981001","Mozilla");
INSERT INTO user_log VALUES("4","1","1","1485046542","1596980998","Mozilla");
INSERT INTO user_log VALUES("5","1","1","1485067690","136702793","Mozilla");
INSERT INTO user_log VALUES("6","1","1","1485157526","1596981021","Mozilla");
INSERT INTO user_log VALUES("7","1","1","1485761900","1596981021","Mozilla");
INSERT INTO user_log VALUES("8","1","1","1485872687","1596981010","Mozilla");
INSERT INTO user_log VALUES("9","1","1","1488473850","1596981017","Mozilla");
INSERT INTO user_log VALUES("10","1","1","1491311635","1596980999","Mozilla");
INSERT INTO user_log VALUES("11","1","1","1491466553","1596981004","Mozilla");
INSERT INTO user_log VALUES("12","1","1","1492450909","1596981018","Mozilla");
INSERT INTO user_log VALUES("13","1","1","1492754760","1596981015","Mozilla");
INSERT INTO user_log VALUES("14","1","1","1493189552","1596981002","Mozilla");
INSERT INTO user_log VALUES("15","1","1","1493265428","1596981016","Mozilla");
INSERT INTO user_log VALUES("16","2","1","1493285951","1596981002","Mozilla");
INSERT INTO user_log VALUES("17","1","1","1493288500","1596980999","Mozilla");
INSERT INTO user_log VALUES("18","2","1","1493288538","1596980999","Mozilla");
INSERT INTO user_log VALUES("19","1","1","1493289451","1596980999","Mozilla");
INSERT INTO user_log VALUES("20","2","1","1493290415","1596980999","Mozilla");
INSERT INTO user_log VALUES("21","1","1","1493290611","1596980999","Mozilla");
INSERT INTO user_log VALUES("22","2","1","1493290791","1596980999","Mozilla");
INSERT INTO user_log VALUES("23","1","1","1493379064","1596980999","Mozilla");
INSERT INTO user_log VALUES("24","1","1","1493450996","1596981001","Mozilla");
INSERT INTO user_log VALUES("25","1","1","1493529186","1596980996","Mozilla");
INSERT INTO user_log VALUES("26","1","1","1493558525","1596981005","Mozilla");
INSERT INTO user_log VALUES("27","1","1","1493632848","1596981005","Mozilla");
INSERT INTO user_log VALUES("28","1","1","1493700166","1596981009","Mozilla");
INSERT INTO user_log VALUES("29","1","1","1493714215","1596981019","Mozilla");
INSERT INTO user_log VALUES("30","1","1","1493805143","1596981005","Mozilla");
INSERT INTO user_log VALUES("31","1","1","1493893958","1596980995","Mozilla");
INSERT INTO user_log VALUES("32","2","1","1493902332","1596980999","Mozilla");
INSERT INTO user_log VALUES("33","1","1","1493902436","1596981011","Mozilla");
INSERT INTO user_log VALUES("34","2","1","1493902760","1596981011","Mozilla");
INSERT INTO user_log VALUES("35","1","1","1493902870","1596981011","Mozilla");
INSERT INTO user_log VALUES("36","2","1","1493902943","1596981011","Mozilla");
INSERT INTO user_log VALUES("37","1","1","1493902967","1596981011","Mozilla");
INSERT INTO user_log VALUES("38","2","1","1493904064","1596981011","Mozilla");
INSERT INTO user_log VALUES("39","1","1","1493904149","1596981011","Mozilla");
INSERT INTO user_log VALUES("40","1","1","1493934689","1596981001","Mozilla");
INSERT INTO user_log VALUES("41","1","1","1493962536","1596981001","Mozilla");
INSERT INTO user_log VALUES("42","1","1","1493972301","1596981017","Mozilla");
INSERT INTO user_log VALUES("43","1","1","1494034405","1596981017","Mozilla");
INSERT INTO user_log VALUES("44","1","1","1494047768","1596980999","Mozilla");
INSERT INTO user_log VALUES("45","1","1","1494055423","1596981006","Mozilla");
INSERT INTO user_log VALUES("46","2","1","1494059163","1596981011","Mozilla");
INSERT INTO user_log VALUES("47","1","1","1494059192","1596981006","Mozilla");
INSERT INTO user_log VALUES("48","2","1","1494065078","1596981006","Mozilla");
INSERT INTO user_log VALUES("49","6","1","1494094875","3283668665","Mozilla");
INSERT INTO user_log VALUES("50","1","1","1494095028","1596981006","Mozilla");
INSERT INTO user_log VALUES("51","1","1","1494103463","1596981015","Mozilla");
INSERT INTO user_log VALUES("52","1","1","1494105448","1596981015","Mozilla");
INSERT INTO user_log VALUES("53","1","1","1494135421","1596981015","Mozilla");
INSERT INTO user_log VALUES("54","2","1","1494150369","1596981006","Mozilla");
INSERT INTO user_log VALUES("55","6","1","1494153950","3283668665","Mozilla");
INSERT INTO user_log VALUES("56","1","1","1494165218","1596980998","Mozilla");
INSERT INTO user_log VALUES("57","6","1","1494166862","3283668665","Mozilla");
INSERT INTO user_log VALUES("58","6","1","1494172580","3283668665","Mozilla");
INSERT INTO user_log VALUES("59","1","1","1494173417","1596980998","Mozilla");
INSERT INTO user_log VALUES("60","6","1","1494181527","3283668665","Mozilla");
INSERT INTO user_log VALUES("61","1","1","1494223351","2457362421","Mozilla");
INSERT INTO user_log VALUES("62","6","1","1494225994","3283668665","Mozilla");
INSERT INTO user_log VALUES("63","2","1","1494237478","1596980998","Mozilla");
INSERT INTO user_log VALUES("64","1","1","1494237778","1596981023","Mozilla");
INSERT INTO user_log VALUES("65","1","1","1494286710","1596981005","Mozilla");
INSERT INTO user_log VALUES("66","1","1","1494314677","1596981005","Mozilla");
INSERT INTO user_log VALUES("67","1","1","1494361062","1596980994","Mozilla");
INSERT INTO user_log VALUES("68","1","1","1494362066","1596981012","Mozilla");
INSERT INTO user_log VALUES("69","1","1","1494395514","1596981012","Mozilla");
INSERT INTO user_log VALUES("70","1","1","1494408216","1596981012","Mozilla");
INSERT INTO user_log VALUES("71","6","1","1494424447","3283668665","Mozilla");
INSERT INTO user_log VALUES("72","8","1","1494425177","2365590936","Opera Mini (Mozilla)");
INSERT INTO user_log VALUES("73","1","1","1494436884","1596981022","Mozilla");
INSERT INTO user_log VALUES("74","2","1","1494443950","1596981023","Mozilla");
INSERT INTO user_log VALUES("75","1","1","1494444575","1596981022","Mozilla");
INSERT INTO user_log VALUES("76","2","1","1494447155","1596981022","Mozilla");
INSERT INTO user_log VALUES("77","1","1","1494447272","1596981022","Mozilla");
INSERT INTO user_log VALUES("78","6","1","1494519523","3283668665","Mozilla");
INSERT INTO user_log VALUES("79","8","1","1494615072","1385291463","Opera Mini (Mozilla)");
INSERT INTO user_log VALUES("80","1","1","1494628914","1596981022","Mozilla");
INSERT INTO user_log VALUES("81","1","1","1494660568","1596981009","Mozilla");
INSERT INTO user_log VALUES("82","1","1","1494661129","1596981018","Mozilla");
INSERT INTO user_log VALUES("83","1","1","1494661604","1596981018","Mozilla");
INSERT INTO user_log VALUES("84","1","1","1494674144","1596981018","Mozilla");
INSERT INTO user_log VALUES("85","1","1","1494696263","1596981018","Mozilla");
INSERT INTO user_log VALUES("86","8","1","1494705291","2365591038","Opera Mini (Mozilla)");
INSERT INTO user_log VALUES("87","8","1","1494731420","2365590954","Opera Mini (Mozilla)");
INSERT INTO user_log VALUES("88","1","1","1494742170","1596981008","Mozilla");
INSERT INTO user_log VALUES("89","4","1","1494746676","3579280921","Mozilla");
INSERT INTO user_log VALUES("90","8","1","1494761528","1385290993","Opera Mini (Mozilla)");
INSERT INTO user_log VALUES("91","1","1","1494781785","1596980995","Mozilla");
INSERT INTO user_log VALUES("92","6","1","1494819023","3283668665","Mozilla");
INSERT INTO user_log VALUES("93","1","1","1494821579","1596980995","Mozilla");
INSERT INTO user_log VALUES("94","1","1","1494853715","1596981020","Mozilla");
INSERT INTO user_log VALUES("95","8","1","1494879889","1385291654","Opera Mini (Mozilla)");
INSERT INTO user_log VALUES("96","1","1","1494926654","1596981018","Mozilla");
INSERT INTO user_log VALUES("97","1","1","1494942304","1596981019","Mozilla");
INSERT INTO user_log VALUES("98","1","1","1494969500","1596981018","Mozilla");
INSERT INTO user_log VALUES("99","1","1","1494993572","1596981018","Mozilla");
INSERT INTO user_log VALUES("100","1","1","1495028798","1596980993","Mozilla");
INSERT INTO user_log VALUES("101","1","1","1495084720","1596980993","Mozilla");
INSERT INTO user_log VALUES("102","8","1","1495086706","1385291491","Opera Mini (Mozilla)");
INSERT INTO user_log VALUES("103","1","1","1495093480","1596981016","Mozilla");
INSERT INTO user_log VALUES("104","9","1","1495096280","780499124","Mozilla");
INSERT INTO user_log VALUES("105","4","1","1495103254","3579280111","Mozilla");
INSERT INTO user_log VALUES("106","1","1","1495132669","1596980995","Mozilla");
INSERT INTO user_log VALUES("107","1","1","1495136003","1596980995","Mozilla");
INSERT INTO user_log VALUES("108","1","1","1495218895","1596980995","Mozilla");
INSERT INTO user_log VALUES("109","1","1","1495261799","1596981006","Mozilla");
INSERT INTO user_log VALUES("110","9","1","1495268642","780518111","Mozilla");
INSERT INTO user_log VALUES("111","1","1","1495349718","1596981003","Mozilla");
INSERT INTO user_log VALUES("112","1","1","1495372569","1596981022","Mozilla");
INSERT INTO user_log VALUES("113","6","1","1495388177","3283668665","Mozilla");
INSERT INTO user_log VALUES("114","1","1","1495398075","1596981022","Mozilla");
INSERT INTO user_log VALUES("115","1","1","1495441157","1596981016","Mozilla");
INSERT INTO user_log VALUES("116","2","1","1495447407","1596981022","Mozilla");
INSERT INTO user_log VALUES("117","1","1","1495448888","1596981002","Mozilla");
INSERT INTO user_log VALUES("118","1","1","1495449958","1596981002","Mozilla");
INSERT INTO user_log VALUES("119","1","1","1495519921","1596981005","Mozilla");
INSERT INTO user_log VALUES("120","1","1","1495571623","1596981007","Mozilla");
INSERT INTO user_log VALUES("121","1","1","1495601494","1596981007","Mozilla");
INSERT INTO user_log VALUES("122","1","1","1495605056","1596981022","Mozilla");
INSERT INTO user_log VALUES("123","1","1","1495628821","1596981022","Mozilla");
INSERT INTO user_log VALUES("124","1","1","1495637444","1596981022","Mozilla");
INSERT INTO user_log VALUES("125","6","1","1495650593","3283668665","Mozilla");
INSERT INTO user_log VALUES("126","1","1","1495657102","1596981007","Mozilla");
INSERT INTO user_log VALUES("127","1","1","1495657169","1596981007","Mozilla");
INSERT INTO user_log VALUES("128","1","1","1495700370","1596981007","Mozilla");
INSERT INTO user_log VALUES("129","1","1","1495706954","1596981012","Mozilla");
INSERT INTO user_log VALUES("130","1","1","1495720312","1596981012","Mozilla");
INSERT INTO user_log VALUES("131","8","1","1495835048","2365590539","Opera Mini (Mozilla)");
INSERT INTO user_log VALUES("132","1","1","1495916117","1596981012","Mozilla");
INSERT INTO user_log VALUES("133","1","1","1495963615","3111290964","Mozilla");
INSERT INTO user_log VALUES("134","1","1","1495999506","1596980997","Mozilla");
INSERT INTO user_log VALUES("135","1","1","1496034747","1596980998","Mozilla");
INSERT INTO user_log VALUES("136","1","1","1496040018","1596981020","Mozilla");
INSERT INTO user_log VALUES("137","1","1","1496048006","1596981002","Mozilla");
INSERT INTO user_log VALUES("138","1","1","1496063432","1596981002","Mozilla");
INSERT INTO user_log VALUES("139","5","1","1496068571","1607850556","Mozilla");
INSERT INTO user_log VALUES("140","1","1","1496083672","1596981002","Mozilla");
INSERT INTO user_log VALUES("141","1","1","1496134774","1596981007","Mozilla");
INSERT INTO user_log VALUES("142","5","1","1496142004","1607850556","Mozilla");
INSERT INTO user_log VALUES("143","1","1","1496170387","1596981000","Mozilla");
INSERT INTO user_log VALUES("144","1","1","1496175542","1596981014","Mozilla");
INSERT INTO user_log VALUES("145","1","1","1496180093","1596981014","Mozilla");
INSERT INTO user_log VALUES("146","8","1","1496180937","3105535033","Opera Mini (Mozilla)");
INSERT INTO user_log VALUES("147","8","1","1496209219","2365590824","Opera Mini (Mozilla)");
INSERT INTO user_log VALUES("148","1","1","1496217093","1596981014","Mozilla");
INSERT INTO user_log VALUES("149","2","1","1496218950","1596981002","Mozilla");
INSERT INTO user_log VALUES("150","1","1","1496224046","1596981012","Mozilla");
INSERT INTO user_log VALUES("151","2","1","1496224296","1596981012","Mozilla");
INSERT INTO user_log VALUES("152","1","1","1496244790","1596981012","Mozilla");
INSERT INTO user_log VALUES("153","9","1","1496260070","136701992","Mozilla");
INSERT INTO user_log VALUES("154","8","1","1496261807","1385291453","Opera Mini (Mozilla)");
INSERT INTO user_log VALUES("155","1","1","1496268843","1596981017","Mozilla");
INSERT INTO user_log VALUES("156","8","1","1496302328","1385291029","Opera Mini (Mozilla)");
INSERT INTO user_log VALUES("157","1","1","1496311531","1596981017","Mozilla");
INSERT INTO user_log VALUES("158","8","1","1496331762","3105535042","Opera Mini (Mozilla)");
INSERT INTO user_log VALUES("159","1","1","1496339944","522783414","Mozilla");
INSERT INTO user_log VALUES("160","1","1","1496390156","1596981004","Mozilla");
INSERT INTO user_log VALUES("161","1","1","1496412604","1596981011","Mozilla");
INSERT INTO user_log VALUES("162","1","1","1496427899","1596981015","Mozilla");
INSERT INTO user_log VALUES("163","2","1","1496432389","1596981012","Mozilla");
INSERT INTO user_log VALUES("164","1","1","1496432428","1596981015","Mozilla");
INSERT INTO user_log VALUES("165","2","1","1496432489","1596981015","Mozilla");
INSERT INTO user_log VALUES("166","1","1","1496433134","1596981015","Mozilla");
INSERT INTO user_log VALUES("167","1","1","1496469266","1596981015","Mozilla");
INSERT INTO user_log VALUES("168","1","1","1496508102","522783274","Mozilla");
INSERT INTO user_log VALUES("169","1","1","1496515933","1596981014","Mozilla");
INSERT INTO user_log VALUES("170","1","1","1496574160","1596981014","Mozilla");
INSERT INTO user_log VALUES("171","13","1","1496604724","784960395","Mozilla");
INSERT INTO user_log VALUES("172","1","1","1496610198","1596980993","Mozilla");
INSERT INTO user_log VALUES("173","1","1","1496646208","1596980993","Mozilla");
INSERT INTO user_log VALUES("174","1","1","1496651961","1596981022","Mozilla");
INSERT INTO user_log VALUES("175","1","1","1496688502","1596981022","Mozilla");
INSERT INTO user_log VALUES("176","2","1","1496691863","1596981015","Mozilla");
INSERT INTO user_log VALUES("177","1","1","1496725629","1596981009","Mozilla");
INSERT INTO user_log VALUES("178","1","1","1496726261","1596981002","Mozilla");
INSERT INTO user_log VALUES("179","1","1","1496751831","1596981002","Mozilla");
INSERT INTO user_log VALUES("180","1","1","1496752194","1596981002","Mozilla");
INSERT INTO user_log VALUES("181","2","1","1496753360","1596981009","Mozilla");
INSERT INTO user_log VALUES("182","1","1","1496753580","1596981002","Mozilla");
INSERT INTO user_log VALUES("183","1","1","1496769279","1596980994","Mozilla");
INSERT INTO user_log VALUES("184","1","1","1496850280","1596980994","Mozilla");
INSERT INTO user_log VALUES("185","1","1","1496862718","1596981008","Mozilla");
INSERT INTO user_log VALUES("186","2","1","1496870527","1596980994","Mozilla");
INSERT INTO user_log VALUES("187","1","1","1496870569","1596981008","Mozilla");
INSERT INTO user_log VALUES("188","1","1","1496871263","1596981008","Mozilla");
INSERT INTO user_log VALUES("189","1","1","1496928084","1596981008","Mozilla");
INSERT INTO user_log VALUES("190","1","1","1496950156","1596981007","Mozilla");
INSERT INTO user_log VALUES("191","1","1","1497005735","1596980998","Mozilla");
INSERT INTO user_log VALUES("192","1","1","1497029760","1596981003","Mozilla");
INSERT INTO user_log VALUES("193","5","1","1497031907","1607850556","Mozilla");
INSERT INTO user_log VALUES("194","1","1","1497078431","1596981023","Mozilla");
INSERT INTO user_log VALUES("195","1","1","1497174243","1596981021","Mozilla");
INSERT INTO user_log VALUES("196","1","1","1497183771","1596981003","Mozilla");
INSERT INTO user_log VALUES("197","1","1","1497189682","1596981000","Mozilla");



DROP TABLE IF EXISTS `user_music`;

CREATE TABLE `user_music` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `dir` varchar(64) NOT NULL,
  `id_file` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `user_ref`;

CREATE TABLE `user_ref` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `time` int(10) unsigned NOT NULL,
  `id_user` int(10) unsigned NOT NULL,
  `url` varchar(1024) DEFAULT NULL,
  `type_input` varchar(12) DEFAULT 'cookie',
  PRIMARY KEY (`id`),
  KEY `time` (`time`,`id_user`),
  KEY `type_input` (`type_input`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO user_ref VALUES("1","1496691589","1","h2.keo.su","session");
INSERT INTO user_ref VALUES("2","1495964928","12","gix.su","reg");
INSERT INTO user_ref VALUES("3","1497131270","1","quirktools.com","session");



DROP TABLE IF EXISTS `user_set`;

CREATE TABLE `user_set` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `privat_str` int(11) DEFAULT '1',
  `privat_mail` int(11) DEFAULT '1',
  `ocenka` int(11) DEFAULT '0',
  `guestbook_access` int(11) DEFAULT '0',
  `guestbook_komm` int(11) DEFAULT '0',
  `privat_friend` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

INSERT INTO user_set VALUES("1","1","1","1","1493539315","1","0","2");
INSERT INTO user_set VALUES("2","2","1","2","0","1","2","0");
INSERT INTO user_set VALUES("3","3","1","1","0","0","0","1");
INSERT INTO user_set VALUES("4","4","1","1","0","0","0","1");
INSERT INTO user_set VALUES("5","5","1","1","0","0","0","1");
INSERT INTO user_set VALUES("6","6","1","1","0","0","0","1");
INSERT INTO user_set VALUES("7","7","1","1","0","0","0","1");
INSERT INTO user_set VALUES("8","8","1","1","0","0","0","1");
INSERT INTO user_set VALUES("9","9","1","1","0","0","0","1");
INSERT INTO user_set VALUES("10","10","1","1","0","0","0","1");
INSERT INTO user_set VALUES("11","11","1","1","0","0","0","1");
INSERT INTO user_set VALUES("12","12","1","1","0","0","0","1");
INSERT INTO user_set VALUES("13","13","1","1","0","0","0","1");
INSERT INTO user_set VALUES("14","14","1","1","0","0","0","1");
INSERT INTO user_set VALUES("15","15","1","1","0","0","0","1");
INSERT INTO user_set VALUES("16","16","1","1","0","0","0","1");
INSERT INTO user_set VALUES("17","17","1","1","0","0","0","1");



DROP TABLE IF EXISTS `user_voice2`;

CREATE TABLE `user_voice2` (
  `id_user` int(11) NOT NULL,
  `id_kont` int(11) NOT NULL,
  `rating` int(11) NOT NULL DEFAULT '0',
  `msg` varchar(256) DEFAULT NULL,
  `time` int(11) NOT NULL,
  KEY `id_user` (`id_user`,`id_kont`),
  KEY `time` (`time`),
  KEY `rating` (`rating`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `users_konts`;

CREATE TABLE `users_konts` (
  `id_user` int(11) NOT NULL,
  `id_kont` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `new_msg` int(11) NOT NULL DEFAULT '0',
  `type` enum('common','ignor','favorite','deleted') NOT NULL DEFAULT 'common',
  `name` varchar(64) DEFAULT NULL,
  UNIQUE KEY `id_user` (`id_user`,`id_kont`),
  KEY `type` (`type`),
  KEY `time` (`time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `visit_everyday`;

CREATE TABLE `visit_everyday` (
  `time` int(11) NOT NULL,
  `host` int(11) NOT NULL,
  `hit` int(11) NOT NULL,
  `host_ip_ua` int(11) NOT NULL,
  KEY `time` (`time`),
  KEY `host` (`host`),
  KEY `hit` (`hit`),
  KEY `host_ip_ua` (`host_ip_ua`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO visit_everyday VALUES("1483650000","0","0","0");
INSERT INTO visit_everyday VALUES("1483736400","1","3","1");
INSERT INTO visit_everyday VALUES("1483822800","37","69","41");
INSERT INTO visit_everyday VALUES("1483909200","36","56","36");
INSERT INTO visit_everyday VALUES("1483995600","26","220","28");
INSERT INTO visit_everyday VALUES("1484082000","3","235","3");
INSERT INTO visit_everyday VALUES("1484168400","31","222","32");
INSERT INTO visit_everyday VALUES("1484254800","25","246","26");
INSERT INTO visit_everyday VALUES("1484341200","23","690","23");
INSERT INTO visit_everyday VALUES("1484427600","14","286","14");
INSERT INTO visit_everyday VALUES("1484514000","31","1298","32");
INSERT INTO visit_everyday VALUES("1484600400","21","1277","22");
INSERT INTO visit_everyday VALUES("1484686800","33","211","35");
INSERT INTO visit_everyday VALUES("1484773200","16","349","17");
INSERT INTO visit_everyday VALUES("1484859600","6","44","6");
INSERT INTO visit_everyday VALUES("1484946000","20","32","20");
INSERT INTO visit_everyday VALUES("1485032400","15","381","15");
INSERT INTO visit_everyday VALUES("1485118800","25","211","26");
INSERT INTO visit_everyday VALUES("1485205200","13","67","13");
INSERT INTO visit_everyday VALUES("1485291600","14","110","15");
INSERT INTO visit_everyday VALUES("1485378000","17","218","17");
INSERT INTO visit_everyday VALUES("1485464400","9","12","9");
INSERT INTO visit_everyday VALUES("1485550800","36","71","37");
INSERT INTO visit_everyday VALUES("1485637200","14","24","14");
INSERT INTO visit_everyday VALUES("1485723600","17","45","19");
INSERT INTO visit_everyday VALUES("1485810000","9","47","12");
INSERT INTO visit_everyday VALUES("1485896400","20","24","21");
INSERT INTO visit_everyday VALUES("1485982800","16","19","16");
INSERT INTO visit_everyday VALUES("1486069200","17","27","18");
INSERT INTO visit_everyday VALUES("1486155600","15","24","15");
INSERT INTO visit_everyday VALUES("1486242000","9","35","9");
INSERT INTO visit_everyday VALUES("1486328400","8","9","8");
INSERT INTO visit_everyday VALUES("1486414800","23","49","26");
INSERT INTO visit_everyday VALUES("1488315600","8","8","8");
INSERT INTO visit_everyday VALUES("1488402000","1","160","1");
INSERT INTO visit_everyday VALUES("1488488400","5","13","6");
INSERT INTO visit_everyday VALUES("1488574800","7","7","7");
INSERT INTO visit_everyday VALUES("1488747600","7","14","8");
INSERT INTO visit_everyday VALUES("1488834000","5","40","5");
INSERT INTO visit_everyday VALUES("1488920400","7","7","7");
INSERT INTO visit_everyday VALUES("1489006800","3","4","4");
INSERT INTO visit_everyday VALUES("1489093200","2","2","2");
INSERT INTO visit_everyday VALUES("1489438800","20","36","20");
INSERT INTO visit_everyday VALUES("1489525200","5","8","5");
INSERT INTO visit_everyday VALUES("1489611600","8","8","8");
INSERT INTO visit_everyday VALUES("1489698000","7","14","9");
INSERT INTO visit_everyday VALUES("1489784400","7","8","7");
INSERT INTO visit_everyday VALUES("1489870800","9","11","10");
INSERT INTO visit_everyday VALUES("1489957200","12","17","12");
INSERT INTO visit_everyday VALUES("1491166800","7","11","7");
INSERT INTO visit_everyday VALUES("1491253200","1","15","1");
INSERT INTO visit_everyday VALUES("1491339600","7","12","7");
INSERT INTO visit_everyday VALUES("1491426000","3","29","3");
INSERT INTO visit_everyday VALUES("1491512400","6","7","6");
INSERT INTO visit_everyday VALUES("1491598800","1","4","1");
INSERT INTO visit_everyday VALUES("1491685200","2","2","2");
INSERT INTO visit_everyday VALUES("1491771600","5","5","5");
INSERT INTO visit_everyday VALUES("1491858000","6","7","6");
INSERT INTO visit_everyday VALUES("1491944400","5","10","5");
INSERT INTO visit_everyday VALUES("1492030800","2","2","2");
INSERT INTO visit_everyday VALUES("1492117200","4","7","4");
INSERT INTO visit_everyday VALUES("1492203600","1","1","1");
INSERT INTO visit_everyday VALUES("1492290000","2","5","2");
INSERT INTO visit_everyday VALUES("1492462800","4","64","4");
INSERT INTO visit_everyday VALUES("1492549200","4","4","4");
INSERT INTO visit_everyday VALUES("1492635600","10","14","10");
INSERT INTO visit_everyday VALUES("1492722000","2","44","2");
INSERT INTO visit_everyday VALUES("1492808400","2","14","2");
INSERT INTO visit_everyday VALUES("1492894800","2","37","2");
INSERT INTO visit_everyday VALUES("1493067600","2","3","2");
INSERT INTO visit_everyday VALUES("1493154000","11","778","11");
INSERT INTO visit_everyday VALUES("1493240400","24","2107","24");
INSERT INTO visit_everyday VALUES("1493326800","32","414","32");
INSERT INTO visit_everyday VALUES("1493413200","31","1069","31");
INSERT INTO visit_everyday VALUES("1493499600","39","561","40");
INSERT INTO visit_everyday VALUES("1493586000","27","215","28");
INSERT INTO visit_everyday VALUES("1493672400","28","637","28");
INSERT INTO visit_everyday VALUES("1493758800","24","492","24");
INSERT INTO visit_everyday VALUES("1493845200","27","2147","28");
INSERT INTO visit_everyday VALUES("1493931600","36","3115","37");
INSERT INTO visit_everyday VALUES("1494018000","47","1614","48");
INSERT INTO visit_everyday VALUES("1494104400","57","2211","60");
INSERT INTO visit_everyday VALUES("1494190800","61","2918","61");
INSERT INTO visit_everyday VALUES("1494277200","47","1763","48");
INSERT INTO visit_everyday VALUES("1494363600","56","2031","59");
INSERT INTO visit_everyday VALUES("1494450000","47","254","50");
INSERT INTO visit_everyday VALUES("1494536400","39","220","39");
INSERT INTO visit_everyday VALUES("1494622800","39","817","40");
INSERT INTO visit_everyday VALUES("1494709200","84","3112","84");
INSERT INTO visit_everyday VALUES("1494795600","60","1553","63");
INSERT INTO visit_everyday VALUES("1494882000","30","249","31");
INSERT INTO visit_everyday VALUES("1494968400","36","2277","38");
INSERT INTO visit_everyday VALUES("1495054800","25","1554","28");
INSERT INTO visit_everyday VALUES("1495141200","41","275","42");
INSERT INTO visit_everyday VALUES("1495227600","46","2588","47");
INSERT INTO visit_everyday VALUES("1495314000","103","2530","103");
INSERT INTO visit_everyday VALUES("1495400400","58","3141","63");
INSERT INTO visit_everyday VALUES("1495486800","46","1158","46");
INSERT INTO visit_everyday VALUES("1495573200","43","2144","43");
INSERT INTO visit_everyday VALUES("1495659600","44","4549","44");
INSERT INTO visit_everyday VALUES("1495746000","24","171","24");
INSERT INTO visit_everyday VALUES("1495832400","35","254","35");
INSERT INTO visit_everyday VALUES("1495918800","88","1597","89");
INSERT INTO visit_everyday VALUES("1496005200","102","2212","104");
INSERT INTO visit_everyday VALUES("1496091600","68","1877","72");
INSERT INTO visit_everyday VALUES("1496178000","57","1869","59");
INSERT INTO visit_everyday VALUES("1496264400","65","681","67");
INSERT INTO visit_everyday VALUES("1496350800","51","3709","52");
INSERT INTO visit_everyday VALUES("1496437200","73","833","74");
INSERT INTO visit_everyday VALUES("1496523600","89","1319","90");
INSERT INTO visit_everyday VALUES("1496610000","91","3100","93");
INSERT INTO visit_everyday VALUES("1496696400","95","2422","99");
INSERT INTO visit_everyday VALUES("1496782800","71","705","77");
INSERT INTO visit_everyday VALUES("1496869200","72","1541","78");
INSERT INTO visit_everyday VALUES("1496955600","56","446","56");
INSERT INTO visit_everyday VALUES("1497042000","56","824","59");



DROP TABLE IF EXISTS `visit_today`;

CREATE TABLE `visit_today` (
  `ip` bigint(11) NOT NULL,
  `ua` varchar(128) DEFAULT NULL,
  `time` int(11) NOT NULL,
  KEY `ip` (`ip`),
  KEY `ua` (`ua`),
  KEY `time` (`time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497171197");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497171176");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497171166");
INSERT INTO visit_today VALUES("3648409365","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497171164");
INSERT INTO visit_today VALUES("2366148142","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497171115");
INSERT INTO visit_today VALUES("2960560253","Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/537.36","1497171098");
INSERT INTO visit_today VALUES("3648409365","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497170946");
INSERT INTO visit_today VALUES("3107229509","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497170912");
INSERT INTO visit_today VALUES("100548975","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497170893");
INSERT INTO visit_today VALUES("3111950856","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497170890");
INSERT INTO visit_today VALUES("3240275210","Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497170889");
INSERT INTO visit_today VALUES("2960560253","Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/537.36","1497170887");
INSERT INTO visit_today VALUES("1520260949","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497170385");
INSERT INTO visit_today VALUES("1520260949","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497170384");
INSERT INTO visit_today VALUES("3588507235","Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497170346");
INSERT INTO visit_today VALUES("94683607","Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497170340");
INSERT INTO visit_today VALUES("94683607","Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497170340");
INSERT INTO visit_today VALUES("3644886242","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497170334");
INSERT INTO visit_today VALUES("3644886242","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497170334");
INSERT INTO visit_today VALUES("1539594797","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36","1497170331");
INSERT INTO visit_today VALUES("1539594797","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36","1497170330");
INSERT INTO visit_today VALUES("93180612","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497170293");
INSERT INTO visit_today VALUES("623759746","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36 OPR/45.0.2552","1497170289");
INSERT INTO visit_today VALUES("3249716036","Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36 OPR/45.0.2552.888","1497170287");
INSERT INTO visit_today VALUES("1495460385","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497170283");
INSERT INTO visit_today VALUES("533720435","Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/537.36 OPR/36.0.2130.80","1497170278");
INSERT INTO visit_today VALUES("634662793","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497170276");
INSERT INTO visit_today VALUES("2956172962","Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/537.36","1497170244");
INSERT INTO visit_today VALUES("776520621","Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36 OPR/45.0.2552.888","1497170231");
INSERT INTO visit_today VALUES("3169333204","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497170231");
INSERT INTO visit_today VALUES("2990624035","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497170189");
INSERT INTO visit_today VALUES("1408396858","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36","1497170188");
INSERT INTO visit_today VALUES("2959755305","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497170187");
INSERT INTO visit_today VALUES("39665589","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497170187");
INSERT INTO visit_today VALUES("2959755305","Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497170187");
INSERT INTO visit_today VALUES("39665589","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497170186");
INSERT INTO visit_today VALUES("1299951106","Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36 OPR/44.0.2510.1218","1497170185");
INSERT INTO visit_today VALUES("1299951106","Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36 OPR/44.0.2510.1218","1497170185");
INSERT INTO visit_today VALUES("2366145578","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497169778");
INSERT INTO visit_today VALUES("1600959780","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497169713");
INSERT INTO visit_today VALUES("2996488221","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497169578");
INSERT INTO visit_today VALUES("2996488197","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497169532");
INSERT INTO visit_today VALUES("2996488221","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497169206");
INSERT INTO visit_today VALUES("2366148233","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497169375");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497169109");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497169109");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497169106");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497169106");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497169106");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497169106");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497169106");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497169106");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497169106");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497169106");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497169105");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497169104");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497169104");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497169104");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497169104");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497169104");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497169104");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497169104");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497169093");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497169093");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497169093");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497169093");
INSERT INTO visit_today VALUES("2366148119","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497169089");
INSERT INTO visit_today VALUES("2366148117","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497169087");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168793");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168790");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168790");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168788");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168786");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168786");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168783");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168783");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168780");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168780");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168779");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168776");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168773");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168773");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168773");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168760");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168760");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168759");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168759");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168757");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168754");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168754");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168752");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168747");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168747");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168744");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168744");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168741");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168741");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168741");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168739");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168739");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168739");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168736");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168736");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168695");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168688");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168688");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168688");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168688");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168688");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168688");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168675");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168675");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168675");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168675");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168675");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168675");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168666");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168666");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168666");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168666");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168666");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168663");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168268");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168264");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168251");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168222");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168217");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168216");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168216");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168214");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168209");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168205");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168202");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168202");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168202");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168202");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168202");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168202");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168201");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168199");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168196");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168187");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168185");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168182");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168178");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168177");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168176");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168175");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168174");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168173");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168170");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168168");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168166");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168163");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168161");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168161");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168159");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168158");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168155");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168153");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168153");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168150");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168148");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168146");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168143");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168140");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168137");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168136");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168135");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168135");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168135");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168135");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168135");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168135");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168135");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168134");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168134");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168134");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168134");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168134");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168132");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168130");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168129");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168127");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168127");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168120");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168120");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168120");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168087");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168086");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168086");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168078");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168077");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168074");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168070");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168060");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168055");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168055");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168045");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168041");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168040");
INSERT INTO visit_today VALUES("1602626156","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497168035");
INSERT INTO visit_today VALUES("2366158865","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497167934");
INSERT INTO visit_today VALUES("2366148228","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497167878");
INSERT INTO visit_today VALUES("2366148233","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497167326");
INSERT INTO visit_today VALUES("2996488263","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497167304");
INSERT INTO visit_today VALUES("2366148142","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497167214");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497166346");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497166346");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497166346");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497166346");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497166346");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497166346");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497166346");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497166346");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497166345");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497166303");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497166303");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497166302");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497166298");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497166298");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497166298");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497166291");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497166291");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497166291");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497166291");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497166291");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497166291");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497166284");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497166284");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497166266");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497166266");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497166266");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497166215");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497166215");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497166215");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497166151");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497166151");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497166151");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497166151");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497166120");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497166120");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497166119");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497166016");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497166016");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497166016");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497166016");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497166016");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497166016");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497166016");
INSERT INTO visit_today VALUES("136701992","Mozilla/5.0 (Linux; U; Android 5.1; en-US; BV2000s Build/LMY47I) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser/11","1497166016");
INSERT INTO visit_today VALUES("100662549","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497166014");
INSERT INTO visit_today VALUES("2996488263","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497165984");
INSERT INTO visit_today VALUES("2366148142","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497165748");
INSERT INTO visit_today VALUES("2366148233","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497165423");
INSERT INTO visit_today VALUES("2366158856","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497163858");
INSERT INTO visit_today VALUES("2366158865","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497163768");
INSERT INTO visit_today VALUES("100662588","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497162130");
INSERT INTO visit_today VALUES("2366148243","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497161881");
INSERT INTO visit_today VALUES("1570674718","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497161878");
INSERT INTO visit_today VALUES("3283668665","Mozilla/5.0 (Linux; Android 5.1; Nomi i504 Build/LMY47I) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 YaBrowser/17","1497161263");
INSERT INTO visit_today VALUES("3283668665","Mozilla/5.0 (Linux; Android 5.1; Nomi i504 Build/LMY47I) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 YaBrowser/17","1497161263");
INSERT INTO visit_today VALUES("3283668665","Mozilla/5.0 (Linux; Android 5.1; Nomi i504 Build/LMY47I) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 YaBrowser/17","1497161263");
INSERT INTO visit_today VALUES("3283668665","Mozilla/5.0 (Linux; Android 5.1; Nomi i504 Build/LMY47I) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 YaBrowser/17","1497161253");
INSERT INTO visit_today VALUES("3283668665","Mozilla/5.0 (Linux; Android 5.1; Nomi i504 Build/LMY47I) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 YaBrowser/17","1497161253");
INSERT INTO visit_today VALUES("3283668665","Mozilla/5.0 (Linux; Android 5.1; Nomi i504 Build/LMY47I) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 YaBrowser/17","1497161253");
INSERT INTO visit_today VALUES("3283668665","Mozilla/5.0 (Linux; Android 5.1; Nomi i504 Build/LMY47I) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 YaBrowser/17","1497161253");
INSERT INTO visit_today VALUES("3283668665","Mozilla/5.0 (Linux; Android 5.1; Nomi i504 Build/LMY47I) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 YaBrowser/17","1497161253");
INSERT INTO visit_today VALUES("3283668665","Mozilla/5.0 (Linux; Android 5.1; Nomi i504 Build/LMY47I) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 YaBrowser/17","1497161253");
INSERT INTO visit_today VALUES("3283668665","Mozilla/5.0 (Linux; Android 5.1; Nomi i504 Build/LMY47I) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 YaBrowser/17","1497161253");
INSERT INTO visit_today VALUES("3283668665","Mozilla/5.0 (Linux; Android 5.1; Nomi i504 Build/LMY47I) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 YaBrowser/17","1497161252");
INSERT INTO visit_today VALUES("3283668665","Mozilla/5.0 (Linux; Android 5.1; Nomi i504 Build/LMY47I) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 YaBrowser/17","1497161250");
INSERT INTO visit_today VALUES("3283668665","Mozilla/5.0 (Linux; Android 5.1; Nomi i504 Build/LMY47I) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 YaBrowser/17","1497161249");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497160898");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497160897");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497160883");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497160867");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497160860");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497160851");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497160843");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497160843");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497160819");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497160813");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497160800");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497160794");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497160790");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497160779");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497160779");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497160776");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497160772");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497160771");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497160771");
INSERT INTO visit_today VALUES("1600959780","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497160657");
INSERT INTO visit_today VALUES("100662588","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497160577");
INSERT INTO visit_today VALUES("1570674710","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497160527");
INSERT INTO visit_today VALUES("2366158865","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497160421");
INSERT INTO visit_today VALUES("2366148117","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497160293");
INSERT INTO visit_today VALUES("1570674716","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497160290");
INSERT INTO visit_today VALUES("2366158612","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497160206");
INSERT INTO visit_today VALUES("2760155429","Mozilla/5.0 (compatible; AhrefsBot/5.2; +http://ahrefs.com/robot/)","1497159675");
INSERT INTO visit_today VALUES("2366148228","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497158910");
INSERT INTO visit_today VALUES("2366148233","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497158907");
INSERT INTO visit_today VALUES("2366148233","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497158895");
INSERT INTO visit_today VALUES("2366158856","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497158835");
INSERT INTO visit_today VALUES("3639886570","Mozilla/5.0 (compatible; DotBot/1.1; http://www.opensiteexplorer.org/dotbot, help@moz.com)","1497157753");
INSERT INTO visit_today VALUES("100662566","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497157579");
INSERT INTO visit_today VALUES("100662549","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497157264");
INSERT INTO visit_today VALUES("2366145550","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497156661");
INSERT INTO visit_today VALUES("2366158612","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497156557");
INSERT INTO visit_today VALUES("2996485414","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497156553");
INSERT INTO visit_today VALUES("2366158865","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497156549");
INSERT INTO visit_today VALUES("2366158856","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497156545");
INSERT INTO visit_today VALUES("1600967940","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497156542");
INSERT INTO visit_today VALUES("1476059149","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497156538");
INSERT INTO visit_today VALUES("2996485414","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497156535");
INSERT INTO visit_today VALUES("2996488197","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497156532");
INSERT INTO visit_today VALUES("100662566","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497156528");
INSERT INTO visit_today VALUES("2366148142","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497155880");
INSERT INTO visit_today VALUES("2366148233","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497155876");
INSERT INTO visit_today VALUES("100662588","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497155872");
INSERT INTO visit_today VALUES("100662566","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497155869");
INSERT INTO visit_today VALUES("2366158865","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497155830");
INSERT INTO visit_today VALUES("1123631309","Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)","1497155775");
INSERT INTO visit_today VALUES("782305575","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.96 Safari/537.36","1497152258");
INSERT INTO visit_today VALUES("782305575","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.96 Safari/537.36","1497152223");
INSERT INTO visit_today VALUES("782305575","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.96 Safari/537.36","1497152220");
INSERT INTO visit_today VALUES("782305575","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.96 Safari/537.36","1497152184");
INSERT INTO visit_today VALUES("782305575","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.96 Safari/537.36","1497152171");
INSERT INTO visit_today VALUES("782305575","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.96 Safari/537.36","1497152161");
INSERT INTO visit_today VALUES("872367982","Mozilla/5.0 (compatible; AhrefsBot/5.2; +http://ahrefs.com/robot/)","1497143304");
INSERT INTO visit_today VALUES("872367988","Mozilla/5.0 (compatible; AhrefsBot/5.2; +http://ahrefs.com/robot/)","1497142879");
INSERT INTO visit_today VALUES("3475901803","Mozilla/5.0 (compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm)","1497136318");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497135379");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497135379");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497135379");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497135379");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497135379");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497135379");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497135379");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497135378");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497135338");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497135338");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497135338");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497135338");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497135338");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497135338");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497135338");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497135338");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497135334");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497135334");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497135333");
INSERT INTO visit_today VALUES("2760155465","Mozilla/5.0 (compatible; AhrefsBot/5.2; +http://ahrefs.com/robot/)","1497134660");
INSERT INTO visit_today VALUES("872366418","Mozilla/5.0 (compatible; AhrefsBot/5.2; +http://ahrefs.com/robot/)","1497133226");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497133052");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497133052");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497133052");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497133052");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497133052");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497133052");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497133052");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497133051");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497133050");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497133049");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497133046");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497133046");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497133046");
INSERT INTO visit_today VALUES("100662566","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497132555");
INSERT INTO visit_today VALUES("100662566","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497132543");
INSERT INTO visit_today VALUES("1600967942","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497132532");
INSERT INTO visit_today VALUES("621375793","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497132529");
INSERT INTO visit_today VALUES("2366158865","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497132514");
INSERT INTO visit_today VALUES("1570674716","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497132497");
INSERT INTO visit_today VALUES("1600959260","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497132478");
INSERT INTO visit_today VALUES("2366148117","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497132461");
INSERT INTO visit_today VALUES("2366148257","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497132442");
INSERT INTO visit_today VALUES("2996488232","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497132425");
INSERT INTO visit_today VALUES("100662566","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497132401");
INSERT INTO visit_today VALUES("2366148242","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497132377");
INSERT INTO visit_today VALUES("1570674764","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497132321");
INSERT INTO visit_today VALUES("100662566","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497132316");
INSERT INTO visit_today VALUES("1600967942","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497132314");
INSERT INTO visit_today VALUES("1570674718","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497132311");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131629");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131629");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131629");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131629");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131629");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131629");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131627");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131629");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131290");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131290");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131290");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131290");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131290");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131290");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131289");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131290");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131279");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131279");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131279");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131279");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131279");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131278");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131270");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131270");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131259");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131259");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131259");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131256");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131256");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131251");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131250");
INSERT INTO visit_today VALUES("873859024","Opera/9.30 (Nintendo Wii; U; ; 2047-7; en)","1497131246");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131229");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131229");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131229");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131203");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131203");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131141");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131140");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131140");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131140");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131140");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131140");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131140");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131138");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131101");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131101");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131101");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131101");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131101");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131101");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131101");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131099");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131015");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131015");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131015");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131015");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131014");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131015");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131014");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131012");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131002");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131002");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131002");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131002");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131002");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131001");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131001");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497131000");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497130616");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497130616");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497130616");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497130616");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497130616");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497130616");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497130615");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497130614");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497130526");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497130526");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497130526");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497130526");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497130526");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497130525");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497130524");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497130525");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129840");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129840");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129840");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129840");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129840");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129840");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129838");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129840");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129697");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129697");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129697");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129697");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129697");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129697");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129697");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129695");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129556");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129556");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129556");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129556");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129556");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129556");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129556");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129555");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129552");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129550");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129551");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129549");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129544");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129544");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129541");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129541");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129539");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129539");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129537");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129537");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129537");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129414");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129415");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129414");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129411");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129410");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129411");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129392");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129391");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129389");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129390");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497129043");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497129040");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497129037");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497129029");
INSERT INTO visit_today VALUES("780503647","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497129026");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497129025");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497129025");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129023");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497129024");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128999");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128998");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128996");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128991");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128989");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128988");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128985");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128986");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128984");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128980");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128976");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128950");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128974");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128949");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128949");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128891");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128891");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128889");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128889");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128887");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128887");
INSERT INTO visit_today VALUES("780503647","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128887");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128887");
INSERT INTO visit_today VALUES("780503647","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128885");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128883");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128882");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128876");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128876");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128873");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128872");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128870");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128865");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128870");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128864");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128862");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128861");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128861");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128861");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128861");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128861");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128861");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128861");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128858");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128858");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128856");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128856");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128827");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128826");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128825");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128825");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128822");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128772");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128817");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128769");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128771");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128768");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128766");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128753");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128765");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128752");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128743");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128744");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128677");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128676");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128662");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128661");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128662");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128652");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128651");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128649");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128648");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128623");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128624");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128611");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128611");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128609");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128609");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128597");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128597");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128593");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128593");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128593");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128593");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128593");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128593");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128592");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128593");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128588");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128588");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128587");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128586");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128586");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128586");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128586");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128586");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128584");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128580");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128575");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128573");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128572");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128566");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128558");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128551");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128543");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128534");
INSERT INTO visit_today VALUES("780503647","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128532");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128530");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128530");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128530");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128529");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128529");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128517");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128516");
INSERT INTO visit_today VALUES("780503647","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128506");
INSERT INTO visit_today VALUES("780503647","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128504");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128502");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128500");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128502");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128500");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128496");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128495");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128468");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128467");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128441");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128467");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128440");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128437");
INSERT INTO visit_today VALUES("780503647","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128436");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128434");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128434");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128422");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128421");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128421");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128421");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128416");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497128411");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128409");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128408");
INSERT INTO visit_today VALUES("1596981021","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497128408");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497171209");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497171212");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497171212");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497171245");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497171246");
INSERT INTO visit_today VALUES("780477337","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497171248");
INSERT INTO visit_today VALUES("780477337","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497171251");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497171253");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497171253");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497171270");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497171270");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497171270");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497171270");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497171296");
INSERT INTO visit_today VALUES("2834023157","Mozilla/5.0 (Linux; U; Android 5.1.1; en-US; Faustino Build/LMY49F) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 UCBrowser","1497171296");
INSERT INTO visit_today VALUES("1709326696","Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center","1497171423");
INSERT INTO visit_today VALUES("1600967942","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497171478");
INSERT INTO visit_today VALUES("2366148192","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497171480");
INSERT INTO visit_today VALUES("1600959745","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497171482");
INSERT INTO visit_today VALUES("2366158865","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497171714");
INSERT INTO visit_today VALUES("1600959256","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497171730");
INSERT INTO visit_today VALUES("1600967942","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497172904");
INSERT INTO visit_today VALUES("2366148142","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497172939");
INSERT INTO visit_today VALUES("100662569","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497172984");
INSERT INTO visit_today VALUES("2366148233","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497173010");
INSERT INTO visit_today VALUES("2366145578","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497173048");
INSERT INTO visit_today VALUES("2996488221","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497173050");
INSERT INTO visit_today VALUES("2366158856","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497173188");
INSERT INTO visit_today VALUES("2366148233","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497173265");
INSERT INTO visit_today VALUES("1600959237","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497173688");
INSERT INTO visit_today VALUES("2366148142","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497173695");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Linux; Android 5.1.1; SM-J200H Build/LMY48B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safa","1497174238");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Linux; Android 5.1.1; SM-J200H Build/LMY48B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safa","1497174238");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Linux; Android 5.1.1; SM-J200H Build/LMY48B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safa","1497174238");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Linux; Android 5.1.1; SM-J200H Build/LMY48B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safa","1497174239");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Linux; Android 5.1.1; SM-J200H Build/LMY48B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safa","1497174239");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Linux; Android 5.1.1; SM-J200H Build/LMY48B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safa","1497174239");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Linux; Android 5.1.1; SM-J200H Build/LMY48B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safa","1497174239");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Linux; Android 5.1.1; SM-J200H Build/LMY48B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safa","1497174241");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Linux; Android 5.1.1; SM-J200H Build/LMY48B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safa","1497174243");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Linux; Android 5.1.1; SM-J200H Build/LMY48B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safa","1497174243");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Linux; Android 5.1.1; SM-J200H Build/LMY48B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safa","1497174244");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Linux; Android 5.1.1; SM-J200H Build/LMY48B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safa","1497174245");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Linux; Android 5.1.1; SM-J200H Build/LMY48B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safa","1497174245");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Linux; Android 5.1.1; SM-J200H Build/LMY48B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safa","1497174248");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Linux; Android 5.1.1; SM-J200H Build/LMY48B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safa","1497174248");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Linux; Android 5.1.1; SM-J200H Build/LMY48B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safa","1497174285");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Linux; Android 5.1.1; SM-J200H Build/LMY48B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safa","1497174285");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Linux; Android 5.1.1; SM-J200H Build/LMY48B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safa","1497174285");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Linux; Android 5.1.1; SM-J200H Build/LMY48B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safa","1497174288");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Linux; Android 5.1.1; SM-J200H Build/LMY48B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safa","1497174289");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Linux; Android 5.1.1; SM-J200H Build/LMY48B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safa","1497174289");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Linux; Android 5.1.1; SM-J200H Build/LMY48B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safa","1497174291");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Linux; Android 5.1.1; SM-J200H Build/LMY48B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safa","1497174291");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Linux; Android 5.1.1; SM-J200H Build/LMY48B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safa","1497174291");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Linux; Android 5.1.1; SM-J200H Build/LMY48B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safa","1497174292");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Linux; Android 5.1.1; SM-J200H Build/LMY48B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safa","1497174292");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Linux; Android 5.1.1; SM-J200H Build/LMY48B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safa","1497174292");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Linux; Android 5.1.1; SM-J200H Build/LMY48B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safa","1497174292");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Linux; Android 5.1.1; SM-J200H Build/LMY48B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safa","1497174292");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Linux; Android 5.1.1; SM-J200H Build/LMY48B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safa","1497174292");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Linux; Android 5.1.1; SM-J200H Build/LMY48B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safa","1497174294");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Linux; Android 5.1.1; SM-J200H Build/LMY48B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safa","1497174294");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Linux; Android 5.1.1; SM-J200H Build/LMY48B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safa","1497174294");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Linux; Android 5.1.1; SM-J200H Build/LMY48B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safa","1497174301");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Linux; Android 5.1.1; SM-J200H Build/LMY48B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safa","1497174302");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Linux; Android 5.1.1; SM-J200H Build/LMY48B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safa","1497174302");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Linux; Android 5.1.1; SM-J200H Build/LMY48B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safa","1497174302");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Linux; Android 5.1.1; SM-J200H Build/LMY48B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safa","1497174302");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Linux; Android 5.1.1; SM-J200H Build/LMY48B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safa","1497174302");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Linux; Android 5.1.1; SM-J200H Build/LMY48B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safa","1497174302");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Linux; Android 5.1.1; SM-J200H Build/LMY48B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safa","1497174302");
INSERT INTO visit_today VALUES("1600959769","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497174988");
INSERT INTO visit_today VALUES("2366145550","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497175416");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497178039");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497178040");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497178043");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497178044");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497178044");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497178044");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497178044");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497178044");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497178044");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497178365");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497178368");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497178368");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497178368");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497178368");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497178369");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497178369");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497178703");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497178704");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497178705");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497178705");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497178705");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497178705");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497178705");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497179435");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497179437");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497179437");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497179437");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497179437");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497179437");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497179437");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497180032");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497180033");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497180036");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497180036");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497180036");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497180036");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497180036");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497180037");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497180037");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497180464");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497180467");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497180467");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497180467");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497180467");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497180467");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497180467");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497180467");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497180469");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497180469");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497180471");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497180474");
INSERT INTO visit_today VALUES("2996485403","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497181314");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183759");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183761");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183762");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183762");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183762");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183762");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183762");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183762");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183769");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183771");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183772");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183772");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183781");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183781");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183783");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183784");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183792");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183793");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183796");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183796");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183823");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183823");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183823");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183826");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183826");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183826");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183830");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183830");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183830");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183833");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183834");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183835");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183835");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183835");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183837");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183837");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183837");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183847");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183847");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183850");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183851");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183862");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183863");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183883");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183884");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183921");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183922");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183924");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183925");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183980");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183980");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183982");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183983");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183990");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183990");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183991");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183991");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183991");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183991");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183991");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183991");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183998");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183999");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183999");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183999");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183999");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183999");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183999");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497183999");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184001");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184001");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184027");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184027");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184030");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184030");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184031");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184032");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184033");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184033");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184035");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184035");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184037");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184037");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184046");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184047");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184049");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184049");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184057");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184058");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184059");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184060");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184073");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184074");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184077");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184077");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184077");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184077");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184077");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184091");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184091");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184091");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184095");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184095");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184097");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184098");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184105");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184105");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184110");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184110");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184115");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184116");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184118");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184118");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184118");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184120");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184121");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184121");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184123");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184123");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184123");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184129");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184129");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184131");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184132");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184134");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184135");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184135");
INSERT INTO visit_today VALUES("1509595692","Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184532");
INSERT INTO visit_today VALUES("1509595692","Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184533");
INSERT INTO visit_today VALUES("1509595692","Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184533");
INSERT INTO visit_today VALUES("1509595692","Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184533");
INSERT INTO visit_today VALUES("1509595692","Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184533");
INSERT INTO visit_today VALUES("1509595692","Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184534");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184555");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184556");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184556");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184569");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184570");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184570");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184570");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184570");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184570");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184570");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184571");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184739");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184740");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184740");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184740");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184740");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184740");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184740");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497184740");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497185401");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497185403");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497185403");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497185403");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497185403");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497185403");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497185404");
INSERT INTO visit_today VALUES("1596981003","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497185404");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497185679");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497185680");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497185697");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497185698");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497185699");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497185699");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497185699");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497185699");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497185699");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497185699");
INSERT INTO visit_today VALUES("2996488197","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497186708");
INSERT INTO visit_today VALUES("1600967942","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497186710");
INSERT INTO visit_today VALUES("2996488197","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497186712");
INSERT INTO visit_today VALUES("2366148228","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497186715");
INSERT INTO visit_today VALUES("1600959745","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497186717");
INSERT INTO visit_today VALUES("1600959256","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497186719");
INSERT INTO visit_today VALUES("100662588","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497186721");
INSERT INTO visit_today VALUES("2996488263","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497186723");
INSERT INTO visit_today VALUES("2366145550","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497186725");
INSERT INTO visit_today VALUES("1600959745","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497186727");
INSERT INTO visit_today VALUES("1600967942","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497186729");
INSERT INTO visit_today VALUES("1600967940","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497186731");
INSERT INTO visit_today VALUES("100662549","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497186733");
INSERT INTO visit_today VALUES("1600967940","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497186735");
INSERT INTO visit_today VALUES("2996488232","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497186738");
INSERT INTO visit_today VALUES("2366158612","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497186740");
INSERT INTO visit_today VALUES("100662588","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497186742");
INSERT INTO visit_today VALUES("2996485403","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497186814");
INSERT INTO visit_today VALUES("100662569","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497186817");
INSERT INTO visit_today VALUES("2366158865","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497186822");
INSERT INTO visit_today VALUES("2366158612","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497186824");
INSERT INTO visit_today VALUES("3475901803","Mozilla/5.0 (compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm)","1497186829");
INSERT INTO visit_today VALUES("2366158856","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497187663");
INSERT INTO visit_today VALUES("2996485414","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497187671");
INSERT INTO visit_today VALUES("2366145578","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497187674");
INSERT INTO visit_today VALUES("2366148142","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497187679");
INSERT INTO visit_today VALUES("2366148233","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497187679");
INSERT INTO visit_today VALUES("2996488232","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497187682");
INSERT INTO visit_today VALUES("2366148233","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497187692");
INSERT INTO visit_today VALUES("100662569","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497187696");
INSERT INTO visit_today VALUES("2996488263","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497187701");
INSERT INTO visit_today VALUES("2366158865","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497187707");
INSERT INTO visit_today VALUES("2996488221","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497187712");
INSERT INTO visit_today VALUES("2996488263","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497187717");
INSERT INTO visit_today VALUES("1600967966","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497187717");
INSERT INTO visit_today VALUES("2366158612","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497187720");
INSERT INTO visit_today VALUES("1600959260","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497188220");
INSERT INTO visit_today VALUES("100662615","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497188227");
INSERT INTO visit_today VALUES("1602632470","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189225");
INSERT INTO visit_today VALUES("1602632470","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189227");
INSERT INTO visit_today VALUES("1602632470","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189227");
INSERT INTO visit_today VALUES("1602632470","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189227");
INSERT INTO visit_today VALUES("1602632470","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189227");
INSERT INTO visit_today VALUES("1602632470","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189227");
INSERT INTO visit_today VALUES("1602632470","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189227");
INSERT INTO visit_today VALUES("1602632470","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189227");
INSERT INTO visit_today VALUES("1602632470","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189250");
INSERT INTO visit_today VALUES("1602632470","Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189250");
INSERT INTO visit_today VALUES("2366145613","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497189305");
INSERT INTO visit_today VALUES("1600959237","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497189310");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189657");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497189661");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189668");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189671");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189673");
INSERT INTO visit_today VALUES("100662569","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497189673");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189674");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189675");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497189677");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497189677");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497189677");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497189677");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497189677");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497189677");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497189677");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497189679");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189679");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497189682");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497189682");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497189682");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497189686");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497189686");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497189686");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497189690");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497189691");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497189696");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497189696");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189715");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189715");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189725");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189731");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189813");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189817");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189821");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189825");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189825");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189826");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189826");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189828");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189828");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189829");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189829");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189830");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189832");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189833");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189836");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189836");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189839");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189841");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189845");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189847");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189849");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189849");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189849");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189849");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189849");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189849");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189849");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189915");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189915");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189915");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189916");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189919");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189919");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189919");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189919");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189923");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189924");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189935");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189937");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189939");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189941");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497189947");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497189976");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497189977");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497189978");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497189978");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497189978");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497189978");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497189978");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497189978");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497189978");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497189978");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497189979");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497189980");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497189983");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497189983");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497189984");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497189987");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497189987");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497189993");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497189994");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497189996");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497189996");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190012");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190013");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190013");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190017");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190018");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190032");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190032");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190032");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190036");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190039");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190039");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190040");
INSERT INTO visit_today VALUES("2366148233","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497190041");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190041");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190043");
INSERT INTO visit_today VALUES("1570674710","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497190043");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190044");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190045");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190047");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190051");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190052");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190054");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190054");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190063");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190064");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190064");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190068");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190072");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190072");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190074");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190079");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190080");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190081");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190083");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190085");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190090");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190090");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190091");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190092");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190094");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190104");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190106");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190108");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190121");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190126");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190130");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190141");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190142");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190143");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190144");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190145");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190146");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190147");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190148");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190148");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190149");
INSERT INTO visit_today VALUES("2366148239","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497190160");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190167");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190167");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190168");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190177");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190177");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190178");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190189");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190189");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190189");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190189");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190189");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190189");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190189");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190189");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190192");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190194");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190200");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190200");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190202");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190203");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190205");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190206");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190207");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190207");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190207");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190214");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190214");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190214");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190214");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190214");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190266");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190266");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190272");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190273");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190273");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190273");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190273");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190273");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190273");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190273");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190290");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190291");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190291");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190291");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190291");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190291");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190291");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190291");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190292");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190293");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190294");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190294");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190297");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190298");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190298");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190298");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190298");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190298");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190298");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190299");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190316");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190317");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190320");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190324");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190327");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190333");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190336");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190339");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190344");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190345");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190347");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190351");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190352");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190367");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190368");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190369");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190369");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190369");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190369");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190369");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190369");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190452");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190454");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190455");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190456");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190457");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190458");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190459");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190460");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190461");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190466");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190468");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190471");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190474");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190475");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190477");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190477");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190493");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190494");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190494");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190495");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190495");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190515");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190518");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190518");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190518");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190518");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190518");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190525");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190528");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190529");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190534");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190538");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190539");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190549");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190549");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190550");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190551");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190551");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190551");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190551");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190551");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190551");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190551");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190551");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190552");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190553");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190554");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190556");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190556");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190559");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190560");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190562");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190563");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190563");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190580");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190581");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190583");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190583");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190585");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190585");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190586");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190586");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190591");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190592");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190618");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190619");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190619");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190623");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190623");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190623");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190624");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190629");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190634");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190641");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190642");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190643");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190646");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190648");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190650");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190652");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190655");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190658");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190662");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190666");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190670");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190671");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190678");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190682");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190686");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190686");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190688");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190689");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190690");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190690");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190690");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190690");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190690");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190690");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190693");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190701");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190701");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190744");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190745");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190756");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190757");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190757");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190760");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190766");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190767");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190772");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190776");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190776");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190784");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190784");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190784");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190790");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190798");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497190798");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190816");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190817");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190863");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190864");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190870");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190870");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190872");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190872");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190881");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190882");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190882");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190885");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190886");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190886");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190887");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190940");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190941");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190941");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190943");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190944");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190944");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190946");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497190947");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191063");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191064");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191092");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191093");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497191101");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497191102");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497191103");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497191103");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497191103");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497191103");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497191103");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497191103");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497191115");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497191115");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497191122");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497191122");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497191125");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497191125");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497191131");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497191131");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497191140");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497191140");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497191140");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191418");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191418");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191418");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191422");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191422");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191424");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191424");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191426");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191426");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191428");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191428");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191430");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191430");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191516");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191517");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191597");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191598");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191614");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191614");
INSERT INTO visit_today VALUES("2996485414","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497191647");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191649");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191649");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191650");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191650");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191650");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191650");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191650");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191650");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191650");
INSERT INTO visit_today VALUES("1600959745","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497191652");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191659");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191659");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191661");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191661");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191663");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191663");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191665");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191666");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191667");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191667");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191669");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191669");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191670");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191688");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191689");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191691");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191692");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191692");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191692");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191692");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191692");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191692");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191693");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191699");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191700");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191700");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191700");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191700");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191700");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191701");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191701");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191701");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191702");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191707");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191708");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191708");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191712");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191712");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191723");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191724");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191727");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191727");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191729");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191729");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191738");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191738");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191741");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191741");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191775");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191776");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497191780");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497191781");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497191781");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191781");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191782");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191782");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191782");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191782");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191782");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191782");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191782");
INSERT INTO visit_today VALUES("2996488197","Mozilla/5.0 (compatible; YandexBot/3.0; +http://yandex.com/bots)","1497191782");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497191783");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497191787");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191819");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191820");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191820");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191820");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191820");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191820");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191820");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191820");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191821");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191821");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191823");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191823");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191842");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191843");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191845");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191846");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191847");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191847");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191851");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191852");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191943");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191944");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191949");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191949");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191954");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191954");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497191955");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497192239");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497192240");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497192240");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497192243");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497192243");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497192243");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497192243");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497192243");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497192243");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497192243");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497192243");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497192300");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497192302");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497192302");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497192302");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497192302");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497192302");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497192302");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497192302");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192339");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192341");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192348");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192484");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192485");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192485");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192485");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192487");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192488");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192494");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192497");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192498");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192499");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192503");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192505");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192509");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192509");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192509");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192509");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192511");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192511");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192511");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192511");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192513");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192513");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192513");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192517");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192517");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192517");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192517");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192523");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192524");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192525");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497192547");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497192547");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497192549");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497192550");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497192550");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497192553");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497192553");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497192555");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497192555");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497192555");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497192556");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497192557");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497192558");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497192558");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497192558");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497192558");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497192559");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497192559");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497192559");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192565");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192568");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192570");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192571");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192572");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192580");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192583");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192583");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192590");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192591");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192594");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192596");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192604");
INSERT INTO visit_today VALUES("774987817","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36","1497192613");
INSERT INTO visit_today VALUES("520974896","facebookexternalhit/1.1","1497192629");
INSERT INTO visit_today VALUES("520974921","facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)","1497192629");
INSERT INTO visit_today VALUES("2918996053","facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)","1497192629");
INSERT INTO visit_today VALUES("520974896","facebookexternalhit/1.1","1497192629");
INSERT INTO visit_today VALUES("520974915","facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)","1497192630");
INSERT INTO visit_today VALUES("2918996056","facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)","1497192631");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497192635");
INSERT INTO visit_today VALUES("1596981000","Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0","1497192635");



DROP TABLE IF EXISTS `wellcome`;

CREATE TABLE `wellcome` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `text` varchar(500) NOT NULL,
  `on_off` int(11) NOT NULL,
  `ask` int(11) DEFAULT '0',
  `time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;

INSERT INTO wellcome VALUES("1","1","Обидно, когда поверил человеку, а через некоторое время понимаешь, что все, что он говорил и делал было на#бом!","0","0","1484733238");
INSERT INTO wellcome VALUES("2","1","Не с красотой тебе жить, а с человеком.\r\n\r\n- Помни.","0","0","1484733395");
INSERT INTO wellcome VALUES("3","1","Есть моменты, которые хочется растянуть на всю жизнь..\r\n\r\nЕсть люди, которых хочется видеть всегда..","0","0","1484733414");
INSERT INTO wellcome VALUES("4","1","Не страшно поздно жениться и принять любимую девушку с ребенком, страшно жениться слишком рано и бросить уже своего ребенка.","0","0","1484733431");
INSERT INTO wellcome VALUES("5","2","Есть моменты, которые хочется растянуть на всю жизнь..\r\n\r\nЕсть люди, которых хочется видеть всегда..","0","0","1484738699");
INSERT INTO wellcome VALUES("6","3","всем привет","1","0","1486301108");
INSERT INTO wellcome VALUES("7","1","Есть моменты, которые хочется растянуть на всю жизнь..\r\n\r\nЕсть люди, которых хочется видеть всегда..//","0","0","1492450941");
INSERT INTO wellcome VALUES("9","4","Не с красотой тебе жить, а с человеком.\r\n\r\n- Помни.","0","0","1493451368");
INSERT INTO wellcome VALUES("10","1","Тестинг ,.!..","0","0","1493538915");
INSERT INTO wellcome VALUES("19","4","13515311","0","0","1493900907");
INSERT INTO wellcome VALUES("20","4","Тестинг ,.!..","0","0","1493975349");
INSERT INTO wellcome VALUES("21","8","привет","1","0","1494429697");
INSERT INTO wellcome VALUES("22","1","привет","0","0","1494437153");
INSERT INTO wellcome VALUES("23","8","Обидно, когда поверил человеку, а через некоторое время понимаешь, что все, что он говорил и делал было на#бом!","0","0","1494438736");
INSERT INTO wellcome VALUES("26","1","[img]http://xmyx.ru/style/stat_music.png[/img] KDrew – Last Train To Paradise (Mendus Remix)","0","0","1494841308");
INSERT INTO wellcome VALUES("27","1","[img]http://xmyx.ru/style/stat_music.png[/img] Kavabanga & Depo & Kolibri – Держи её за руку","1","0","1495011521");
INSERT INTO wellcome VALUES("29","11","[img]http://xmyx.ru/style/stat_music.png[/img] Kavabanga & Depo & Kolibri – Держи её за руку","1","0","1495706915");
INSERT INTO wellcome VALUES("30","4","привет","1","0","1495725353");
INSERT INTO wellcome VALUES("36","1","kjhkjh","0","0","1496753266");
INSERT INTO wellcome VALUES("37","2","[img]http://xmyx.ru/style/stat_music.png[/img] Kavabanga & Depo & Kolibri – Держи её за руку","0","0","1496753381");



DROP TABLE IF EXISTS `wellcome_share`;

CREATE TABLE `wellcome_share` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `id_wellcome` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

INSERT INTO wellcome_share VALUES("1","2","1484738699","3");
INSERT INTO wellcome_share VALUES("2","4","1493451368","2");
INSERT INTO wellcome_share VALUES("3","6","1493744428","9");
INSERT INTO wellcome_share VALUES("4","4","1493900907","16");
INSERT INTO wellcome_share VALUES("5","4","1493975349","10");
INSERT INTO wellcome_share VALUES("6","1","1494437153","21");
INSERT INTO wellcome_share VALUES("7","8","1494438736","1");
INSERT INTO wellcome_share VALUES("8","11","1495706915","27");
INSERT INTO wellcome_share VALUES("9","4","1495725353","22");
INSERT INTO wellcome_share VALUES("10","2","1496753381","27");



