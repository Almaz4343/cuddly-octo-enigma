<?

include_once 'sys/inc/start.php';

include_once 'sys/inc/compress.php';

include_once 'sys/inc/sess.php';

include_once 'sys/inc/home.php';

include_once 'sys/inc/settings.php';

include_once 'sys/inc/db_connect.php';

include_once 'sys/inc/ipua.php';

include_once 'sys/inc/fnc.php';

include_once 'sys/inc/user.php';



if (!isset($user)){
$_SESSION['message'] = 'Посмотреть список сообщений могут только авторизованные пользователи.'; 
header("Location: /aut.php");exit;
}



if ((!isset($_SESSION['refer']) || $_SESSION['refer']==NULL)

&& isset($_SERVER['HTTP_REFERER']) && $_SERVER['HTTP_REFERER']!=NULL &&

!preg_match('#mail\.php#',$_SERVER['HTTP_REFERER']))

$_SESSION['refer']=str_replace('&','&amp;',preg_replace('#^http://[^/]*/#','/', $_SERVER['HTTP_REFERER']));





if (!isset($_GET['id'])){
	header("Location: /konts.php".SID);exit;
}

$ank = get_user($_GET['id']);

if (!$ank){
	header("Location: /konts.php?".SID);exit;
}


// помечаем как прочитанные
mysql_query("UPDATE `mail` SET `read` = '1' WHERE `id_kont` = '$user[id]' AND `id_user` = '$ank[id]'");



$ank = get_user($ank['id']);


/* Бан пользователя */ 
if ($user['group_access'] < 1 && mysql_result(mysql_query("SELECT COUNT(*) FROM `ban` WHERE `razdel` = 'all' AND `id_user` = '$ank[id]' AND (`time` > '$time' OR `view` = '0')"), 0)!=0){

$ank = get_user($ank['id']);

$set['title'] = $ank['nick'] . ' : Почта : ' . $user['nick'];

include_once 'sys/inc/thead.php';
title();

?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $user['id']?>"><?= $user['nick']?></a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/konts.php">Почта</a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/mail.php?id=<?= $ank['id']?>"><?= $ank['nick']?></a> </span>       </div>
<div class="wrapper">
<div class="busi"> Вы не можете отправлять сообщения пользователю, так как он Заблокирован  <span id="transmark" style="display: none; width: 0px; height: 0px;"></span> за нарушение правил ресурса! </div>
</div>
<?

include_once 'sys/inc/tfoot.php';
exit;
}	

// ИНФА О СМС
if (isset($_GET['info'])){

$set['title'] = 'Новое сообщение : ' . $ank['nick'] . ' : Почта : ' . $user['nick'];

include_once 'sys/inc/thead.php';

?>
<link rel="stylesheet" type="text/css" href="http://spac.me/css/custom/Mail/MailMainMobile.css?r=1445p" data-tmp_css="1" />
<?

title();

$meska = mysql_fetch_assoc(mysql_query("SELECT * FROM `mail` WHERE `id` = '".intval($_GET['info'])."' limit 1"));
$ank3 = get_user($meska['id_user']);
if($ank3['id'] == $user['id']){
$cVeT = 'my';
}else{
$cVeT = '';
}
?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $user['id']?>"><?= $user['nick']?></a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/konts.php">Почта</a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/mail.php?id=<?= $ank['id']?>"><?= $ank['nick']?></a> </span>   <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <span class="lc_br_text">Новое сообщение</span> </span>    </div>

<div class="wrapper" id="stickers_on">   
<form action="/mail.php?id=<?= $ank['id']?>" method="post"> 
<div class="block block_fix wide pdb">      
<div class="mail__dialog_wrapper mail__dialog_wrapper_extended">  
<div class="   block_narrow pdt pad_b_a  "> 
<div class="  block message <?= $cVeT?> answer  "> 
<div class="oh">   
<span class="user__nick">   
<?= group($ank3['id'])?>
<a href="/user/?id=<?= $ank3['id']?>" class="mysite-link"><b class="nick black"><?= $ank3['nick']?></b></a>     
</span>        
<span class="slb right padd_left"> <?= vremja($meska['time'])?> </span>   
</div>  
<div class="word_break">  <div>  <div> 
<div id="previewText"> 
<div class="mail__dialog_text_fix"></div> <?= output_text($meska['msg'])?>   
</div> 
</div>   </div>  </div>  
<div class="oh slb cl pad_t_a">   
<span class="right mt_1">       
<?
if ($ank3['id'] > 0 && $ank3['id'] != $user['id']){
?> 
<a href="/mail.php?id=<?= $ank3['id']?>&amp;spam=<?= $meska['id']?>" class="inl-link ">  <!--      --><span>Блок</span>
<!--   --><!-- --><!-- --><!-- -->
</a><!-- -->       |  
<?
}
?>   
<a href="/mail.php?id=<?= $ank3['id']?>&amp;delete=<?= $meska['id']?>" class="inl-link ">  <!--      --><span>Удалить</span>
<!--   --><!-- --><!-- --><!-- -->
</a><!-- -->  
</span> 
</div>  </div> 
</div> <div class="cl"></div> </div>    
</div> 
<?
if($ank3['id'] > 0){
?>  
<div class="block  js-toolbar_wrap">  
<div class="text-input__wrap"> <div class="cl" style="margin-bottom: 5px;"> <div class="relative">  
<div class="input-txt_wrapper"> 
<textarea class="input-txt" tabindex="1" name="msg" rows="4" id="textarea" data-maxlength="20000" data-toolbar="{disable:{}}" cols="17" placeholder="Введите сообщение"></textarea> 
</div> 
</div> </div>    
</div> </div>    
<div class="block block_fix wide pdt">     
<div class="right">  
<input tabindex="2" id="mainSubmitInMessagesList" name="send" value="Отправить" class="main_submit" type="submit">  
</div> 
<div class="tools-wrap o_vis"> 
<span class="form-tools__left left">   
<!-- --><!-- --><!-- --><!-- --><!-- -->
<button name="smiles" value="" class="  url-btn     " id="smiles_btn">
<!--   --><img src="/style/i/ico/smile.png" alt="" class="m"> <!--   --><span class="m"> </span><!-- -->
</button><!-- --><!-- -->   </span>  
<span class="form-tools__left left"> 
<span class="js-bb_toggle"> 
<!-- --><!-- --><!-- --><!-- --><!-- -->
<button name="bb_teg" value="" class="  url-btn     " id="response_btn">
<!--   --><img src="/style/i/a.png" alt="" class="m"> <!--   --><span class="m"> </span><!-- --></button><!-- --><!-- --> 
</span>  
</span>  
<div class="cl"></div> </div> 

</div>  
</form> <div class="cl"></div>  
<?
}
?>  
</div>
<a href="/mail.php?id=<?= $ank['id']?>" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?


include_once 'sys/inc/tfoot.php';
exit;
}	


$set['title']  =  'Почта: '.$ank['nick'];

include_once 'sys/inc/thead.php';

?>
<link rel="stylesheet" type="text/css" href="http://spac.me/css/custom/Mail/MailMainMobile.css?r=1445p" data-tmp_css="1" />
<?

title();


?>
<div class="lc_br wbg font0 relative oh" id="header_path">  <a href="/" style="font-size:0;"> <img src="/style/i/lb/home.png" alt=""> </a>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/user/?id=<?= $user['id']?>"><?= $user['nick']?></a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/konts.php">Почта</a> </span>     <span class="lc_brw"> <img src="/style/i/lb/sep.png" alt="" class="lc_br_sep"> <a href="/mail.php?id=<?= $ank['id']?>"><?= $ank['nick']?></a> </span>       </div>
<?






/*

================================

Модуль жалобы на пользователя

и его сообщение либо контент

в зависимости от раздела

================================

*/

if (isset($_GET['spam'])  &&  $ank['id'] != 0)

{

$mess = mysql_fetch_assoc(mysql_query("SELECT * FROM `mail` WHERE `id` = '".intval($_GET['spam'])."' limit 1"));

$spamer = get_user($mess['id_user']);

if (mysql_result(mysql_query("SELECT COUNT(*) FROM `spamus` WHERE `id_user` = '$user[id]' AND `id_spam` = '$spamer[id]' AND `razdel` = 'mail'"),0)==0)

{

if (isset($_POST['msg']))

{

if ($mess['id_kont']==$user['id'])

{

$msg=mysql_real_escape_string($_POST['msg']);



if (strlen2($msg)<3)$err='Укажите подробнее причину жалобы';

if (strlen2($msg)>1512)$err='Длина текста превышает предел в 512 символов';



if(isset($_POST['types'])) $types=intval($_POST['types']);

else $types='0'; 

if (!isset($err))

{

mysql_query("INSERT INTO `spamus` (`id_user`, `msg`, `id_spam`, `time`, `types`, `razdel`, `spam`) values('$user[id]', '$msg', '$spamer[id]', '$time', '$types', 'mail', '".my_esc($mess['msg'])."')");

$_SESSION['message'] = 'Заявка на рассмотрение отправлена'; 

header("Location: ?id=$ank[id]&spam=$mess[id]");

exit;

}

}

}

}



err();



if (mysql_result(mysql_query("SELECT COUNT(*) FROM `spamus` WHERE `id_user` = '$user[id]' AND `id_spam` = '$spamer[id]' AND `razdel` = 'mail'"),0)==0)

{

echo "<div class='mess'>Ложная информация может привести к блокировке ника. 

Если вас постоянно достает один человек - пишет всякие гадости, вы можете добавить его в черный список.</div>";

echo "<form class='nav1' method='post' action='/mail.php?id=$ank[id]&amp;spam=$mess[id]'>\n";

echo "<b>Пользователь:</b> ";

echo " ".status($spamer['id'])." <a href=\"/user/?id=$spamer[id]\">$spamer[nick]</a>\n";

echo "".medal($spamer['id'])." ".online($spamer['id'])." (".vremja($mess['time']).")<br />";

echo "<b>Нарушение:</b> <font color='green'>".output_text($mess['msg'])."</font><br />";

echo "Причина:<br />\n<select name='types'>\n";

echo "<option value='1' selected='selected'>Спам/Реклама</option>\n";

echo "<option value='2' selected='selected'>Мошенничество</option>\n";

echo "<option value='3' selected='selected'>Оскорбление</option>\n";

echo "<option value='0' selected='selected'>Другое</option>\n";

echo "</select><br />\n";

echo "Комментарий:";

echo $tPanel."<textarea name=\"msg\"></textarea><br />";

echo "<input value=\"Отправить\" type=\"submit\" />\n";

echo "</form>\n";

}else{

echo "<div class='mess'>Жалоба на <font color='green'>$spamer[nick]</font> будет рассмотрена в ближайшее время.</div>";

}



echo "<div class='foot'>\n";

echo "<img src='/style/icons/str2.gif' alt='*'> <a href='/mail.php?id=$ank[id]'>Назад</a><br />\n";

echo "</div>\n";

include_once 'sys/inc/tfoot.php';

}

/*

==================================

The End

==================================

*/





// добавляем в контакты

if ($user['add_konts'] == 2 && mysql_result(mysql_query("SELECT COUNT(*) FROM `users_konts` WHERE `id_user` = '$user[id]' AND `id_kont` = '$ank[id]'"),0)==0)

mysql_query("INSERT INTO `users_konts` (`id_user`, `id_kont`, `time`) VALUES ('$user[id]', '$ank[id]', '$time')");

// обновление сведений о контакте

mysql_query("UPDATE `users_konts` SET `new_msg` = '0' WHERE `id_kont` = '$ank[id]' AND `id_user` = '$user[id]' LIMIT 1");



if (isset($_POST['smiles'])){
header("Location: /plugins/smiles/".SID);
exit;
}
if (isset($_POST['bb_teg'])){
header("Location: /plugins/rules/bb-code.php".SID);
exit;
}


if (isset($_POST['msg']) && $ank['id']!=0 && !isset($_GET['spam']))

{





$msg=$_POST['msg'];

if (isset($_POST['translit']) && $_POST['translit']==1)$msg=translit($msg);

if (strlen2($msg)>1024)$err[]='Сообщение превышает 1024 символа';

if (strlen2($msg)<2)$err[]='Слишком короткое сообщение';



$mat=antimat($msg);

if ($mat)$err[]='В тексте сообщения обнаружен мат: '.$mat;



if (!isset($err) && mysql_result(mysql_query("SELECT COUNT(*) FROM `mail` WHERE `id_user` = '$user[id]' AND `id_kont` = '$ank[id]' AND `time` > '".($time-360)."' AND `msg` = '".my_esc($msg)."'"),0)==0)

{

// отправка сообщения

mysql_query("INSERT INTO `mail` (`id_user`, `id_kont`, `msg`, `time`) values('$user[id]', '$ank[id]', '".my_esc($msg)."', '$time')");

// добавляем в контакты

if ($user['add_konts']==1 && mysql_result(mysql_query("SELECT COUNT(*) FROM `users_konts` WHERE `id_user` = '$user[id]' AND `id_kont` = '$ank[id]'"),0)==0)

mysql_query("INSERT INTO `users_konts` (`id_user`, `id_kont`, `time`) VALUES ('$user[id]', '$ank[id]', '$time')");

// обновление сведений о контакте

mysql_query("UPDATE `users_konts` SET `time` = '$time' WHERE `id_user` = '$user[id]' AND `id_kont` = '$ank[id]' OR `id_user` = '$ank[id]' AND `id_kont` = '$user[id]'");

$_SESSION['message'] = 'Сообщение успешно отправлено';

header("Location: ?id=$ank[id]");

exit;

}

}





if (isset($_GET['delete'])  && $_GET['delete']!='add')

{

$mess = mysql_fetch_assoc(mysql_query("SELECT * FROM `mail` WHERE `id` = '".intval($_GET['delete'])."' limit 1"));

if ($mess['id_user']==$user['id'] || $mess['id_kont']==$user['id'])

{

if ($mess['unlink']!=$user['id'] && $mess['unlink']!=0)

mysql_query("DELETE FROM `mail` WHERE `id` = '".$mess['id']."'");

else

mysql_query("UPDATE `mail` SET `unlink` = '$user[id]' WHERE `id` = '$mess[id]' LIMIT 1");

$_SESSION['message'] = 'Сообщение удалено';

header("Location: ?id=$ank[id]");

exit;

}

}



if (isset($_GET['delete']) && $_GET['delete']=='add')

{

mysql_query("DELETE FROM `mail` WHERE `unlink` = '$ank[id]'  AND `id_user` = '$user[id]' AND `id_kont` = '$ank[id]' OR `id_user` = '$ank[id]' AND `id_kont` = '$user[id]' AND `unlink` = '$ank[id]'  ");

mysql_query("UPDATE `mail` SET `unlink` = '$user[id]' WHERE  `id_user` = '$user[id]' AND `id_kont` = '$ank[id]' OR `id_user` = '$ank[id]' AND `id_kont` = '$user[id]'");

$_SESSION['message'] = 'Сообщения удалены';

header("Location: ?id=$ank[id]");

exit;

}









err();





/*

==================================

Приватность почты пользователя

==================================

*/

	$block = true;

	$uSet = mysql_fetch_array(mysql_query("SELECT * FROM `user_set` WHERE `id_user` = '$ank[id]'  LIMIT 1"));

	$frend=mysql_result(mysql_query("SELECT COUNT(*) FROM `frends` WHERE (`user` = '$user[id]' AND `frend` = '$ank[id]') OR (`user` = '$ank[id]' AND `frend` = '$user[id]') LIMIT 1"),0);

	$frend_new=mysql_result(mysql_query("SELECT COUNT(*) FROM `frends_new` WHERE (`user` = '$user[id]' AND `to` = '$ank[id]') OR (`user` = '$ank[id]' AND `to` = '$user[id]') LIMIT 1"),0);


if($ank['id'] == 0){
$ank['group_access'] = '0';
}
if ($user['group_access'] == 0 || $user['group_access'] <= $ank['group_access'])

{



	if ($uSet['privat_mail'] == 2 && $frend != 2) // Если только для друзей

	{

?>
<div class="error mt"> Вы не можете отправлять сообщения пользователю, так как он закрыл свою Почту<span id="transmark" style="display: none; width: 0px; height: 0px;"></span> от всех, кроме своих друзей и известных ему контактов. </div>
<?

		$block = false;



	}

	

	if ($uSet['privat_mail'] == 0) // Если закрыта

	{
?>
<div class="error mt"> Вы не можете отправлять сообщения пользователю, так как он закрыл свою Почту<span id="transmark" style="display: none; width: 0px; height: 0px;"></span> от всех. </div>
<?

		$block = false;		

		

	}



}


?>
<div class="wrapper"> 

<div class="js-row block bord-botm oh grey relative block-cntrl">        
<div class="left font0">   
<?
if($ank['id'] != 0){
?>
<a href="/user/?id=<?= $ank['id']?>" class="tdn">       
<span class="pr">   <div class="inl_bl relative"> <?= ava40($ank['id'])?>  </div>     </span>        
</a>  
<?
}else{
?>
<div class="tdn">       <span class="pr">   
<div class="inl_bl relative">  <?= ava40($ank['id'])?>  </div>     
</span>        </div>
<?
}
?>
</div>   
<div class="pre_content_wrap break-word"> 
<?= group($ank['id'])?>   
<?
if($ank['id'] != 0){
?>
<a href="/user/?id=<?= $ank['id']?>" class="black full_link">   
<?
}
?>
<b><?= $ank['nick']?></b>  
<?
if($ank['id'] != 0){
?>
</a>
<?
}
?>   
<?= medal($ank['id'])?>             
<?
if($ank['id'] != 0){
?>
<span class="grey">(<?= vremja($ank['date_last'])?>)</span>
<?
}
?>     
</div>       
</div>
<?


if ($ank['id'] !=  0 && $block == true){

?>
<div class="wbg      " id="messages_list_form">    
<div class="mail_form_fix"> 
<form action="/mail.php?id=<?= $ank['id']?>" method="post"> 
<div class="block  js-toolbar_wrap">  <div class="text-input__wrap"> <div class="cl" style="margin-bottom: 5px;"> <div class="relative">  
<div class="input-txt_wrapper"> 
<textarea class="input-txt" tabindex="1" name="msg" rows="4" id="textarea" data-maxlength="20000" data-toolbar="{hide:true,disable:{}}" cols="17"></textarea> 
</div> 
</div> </div></div> </div>    
<div class="block block_fix wide pdt">        
<div class="right">  
<input tabindex="2" id="mainSubmitInMessagesList" name="send" value="Отправить" class="main_submit" type="submit">  
</div> 
<div class="tools-wrap o_vis"> 
<span class="form-tools__left left">   
<!-- --><!-- --><!-- --><!-- --><!-- -->
<button name="smiles" value="" class="  url-btn     " id="smiles_btn">
<!--   --><img src="/style/i/ico/smile.png" alt="" class="m"> 
<!--   -->
<span class="m"> </span><!-- --></button><!-- --><!-- -->   
</span>     
<span class="form-tools__left left"> 
<span class="js-bb_toggle"> 
<!-- --><!-- --><!-- --><!-- --><!-- -->
<button name="bb_teg" value="" class="  url-btn     " id="response_btn">
<!--   --><img src="/style/i/a.png" alt="" class="m"> <!--   --><span class="m"> </span><!-- --></button><!-- --><!-- --> 
</span>  
</span>  
<div class="cl"></div> </div> <div class="js-attach_menu spoiler_inject"></div>  </div>    
</form> 
<div class="cl"></div>  
</div>   
<div class="clear"></div> 
</div>
<?

}


$k_post=mysql_result(mysql_query("SELECT COUNT(*) FROM `mail` WHERE `unlink` != '$user[id]' AND `id_user` = '$user[id]' AND `id_kont` = '$ank[id]' OR `id_user` = '$ank[id]' AND `id_kont` = '$user[id]' AND  `unlink` != '$user[id]'"),0);

$k_page=k_page($k_post,$set['p_str']);
$page=page($k_page);
$start=$set['p_str']*$page-$set['p_str'];

if ($k_post == 0)
{
?>
</div>
<div class="wrapper">
<div class="col_blocks block">  Ваша переписка пуста.  </div>
</div>
<?
}
else{

?>
<div class="pad_t_a">
<?

$q = mysql_query("SELECT * FROM `mail` WHERE `unlink` != '$user[id]' AND `id_user` = '$user[id]' AND `id_kont` = '$ank[id]' OR `id_user` = '$ank[id]' AND `id_kont` = '$user[id]' AND `unlink` != '$user[id]' ORDER BY id DESC LIMIT $start, $set[p_str]");

while ($post = mysql_fetch_array($q))
{

$ank2 = get_user($post['id_user']);

if ($ank2 && $ank2['id']){

if($ank2['id'] == $user['id']){
?>
<div class="mail__dialog_wrapper mail__dialog_my">  
<div class="   block_narrow pdt pad_b_a  "> 
<div class="  block message my  "> 
<div class="oh">    
<?
if ($post['read']==0){
?>
<span style="color:#CC0000" class="not_read_text">(не прочитано)</span>
<?
}
?>
<span class="slb right padd_left">  
<a href="/mail.php?id=<?= $ank['id']?>&info=<?= $post['id']?>"> 
<span class="slb m padd_right"><?= vremja($post['time'])?></span> 
<img src="/style/i/dots_grey.png" alt="" class="m" width="3px" height="15px"> 
</a>   
</span>   
</div>  
<div class="word_break">  
<div>  <div> 
<div id="previewText341773807"> <div class="mail__dialog_text_fix"></div>   <?= output_text($post['msg'])?>  </div> 
</div>   </div>  
</div>  
</div> </div> 
<div class="cl"></div> 
</div>
<?
/*
echo " ".group($ank2['id'])." <a href=\"/user/?id=$ank2[id]\">$ank2[nick]</a>\n";

echo "".medal($ank2['id'])." ".online($ank2['id'])." (".vremja($post['time']).")<br />";
*/
}elseif($ank2['id'] != $user['id']){
?>
<div class="mail__dialog_wrapper">  
<div class="   block_narrow pdt pad_b_a  "> 
<div class="  block message answer  "> 
<div class="oh">   
<span class="user__nick">   
<a href="/user/?id=<?= $ank2['id']?>"><?= group($ank2['id'])?></a> 
<a href="/user/?id=<?= $ank2['id']?>" class="mysite-link"><b class="nick black"><?= unick($ank2['id'])?></b></a>     
</span>        
<span class="slb right padd_left">  
<a href="/mail.php?id=<?= $ank['id']?>&info=<?= $post['id']?>"> <span class="slb m padd_right"><?= vremja($post['time'])?></span> 
<img src="/style/i/dots_grey.png" alt="" class="m" width="3px" height="15px"> 
</a>   
</span>   
</div>  
<div class="word_break">  <div>  <div> 
<div id="previewText339971124"> 
<div class="mail__dialog_text_fix"></div> <?= output_text($post['msg'])?> 
</div> 
</div>   </div>  </div>  
</div> </div> 
<div class="cl"></div> </div>
<?

}
}
else if ($ank2['id']==0)

{
?>
<div class="mail__dialog_wrapper">  
<div class="   block_narrow pdt pad_b_a  "> 
<div class="  block message answer  "> 
<div class="oh">   
<span class="user__nick">   <?= group($ank2['id'])?> <b class="nick black">Система</b></span>        
<span class="slb right padd_left">  
<a href="/mail.php?id=<?= $ank['id']?>&info=<?= $post['id']?>"> <span class="slb m padd_right"><?= vremja($post['time'])?></span> 
<img src="/style/i/dots_grey.png" alt="" class="m" width="3px" height="15px"> 
</a>   
</span>   
</div>  
<div class="word_break">  <div>  <div> 
<div id="previewText339971124"> 
<div class="mail__dialog_text_fix"></div> <?= output_text($post['msg'])?> 
</div> 
</div>   </div>  </div>  
</div> </div> 
<div class="cl"></div> </div>
<?
}

else

{

echo "[Удален!]\n";

echo "(".vremja($post['time']).")\n";

}






}


?> 
</div></div>
<?
}

if ($k_page > 1){
?>
<div class="wrapper">
<?
str("mail.php?id=$ank[id]&amp;",$k_page,$page); // Вывод страниц
?>
</div>
<?

}



?>
<div class="wrapper wrap_list">  
<?
if($k_post > 0){
?>
<div>    
<a href="/mail.php?id=<?= $ank['id']?>&amp;P=<?= $page?>&amp;delete=add" class="link        "> 
<span><!--     --><img src="/style/i/mail/cross_light.png" alt="" class="m"> <!--   --><span class="m">Очистить почту</span><!--   --></span> 
</a>   
</div> 
<?
}
if ($ank['id'] !=  0 && $block == true){


if (mysql_result(mysql_query("SELECT COUNT(*) FROM `users_konts` WHERE `id_user` = '$user[id]' AND `id_kont` = '$ank[id]'"), 0)==1)
{
$kont = mysql_fetch_array(mysql_query("SELECT * FROM `users_konts` WHERE `id_user` = '$user[id]' AND `id_kont` = '$ank[id]'"));
?>
<div>    
<a href="/konts.php?type=<?= $kont['type']?>&amp;act=del&amp;id=<?= $ank['id']?>" class="link        "> 
<span><!--     --><img src="/style/i/mail/garbage.png" alt="" class="m"> <!--   --><span class="m">Удалить контакт</span><!--   --></span>  
</a>   
</div> 
<?
}
else
{
?>
<div>    
<a href="/konts.php?type=common&amp;act=add&amp;id=<?= $ank['id']?>" class="link        "> 
<span><!--     --><img src="/style/i/plus_grey.png" alt="" class="m"> <!--   --><span class="m">Добавить в контакты</span><!--   --></span>  
</a>   
</div> 
<?

}
}


?> 
</div>

<a href="/konts.php" class="link darkblue return full_link">  <span class="ico ico_arrow-back"></span>   Назад  </a>
<?

include_once 'sys/inc/tfoot.php';

?>